return function(mod)

  -- ==========================================
  -- STATUS SCREEN PATCH (PAGE 3: Clean Gen 1 Aesthetic)
  -- ==========================================
  local SummaryMenu
  pcall(function() SummaryMenu = package.loaded["src.ui.SummaryMenu"] or require("src.ui.SummaryMenu") end)

  if SummaryMenu and SummaryMenu.update and SummaryMenu.draw then
    
    local originalDraw = SummaryMenu.draw

    -- 1. Patch the Update function to allow a 3rd page
    SummaryMenu.update = function(self, dt)
      local input = self.game.input
      
      if input:wasPressed("a") or input:wasPressed("b") then
        if self.page == 1 then
          self.page = 2
        elseif self.page == 2 then
          self.page = 3
        else
          self.game.stack:pop()
        end
      end
    end

    -- 2. Patch the Draw function to render Page 3 on a clean slate
    SummaryMenu.draw = function(self)
      
      -- ONLY let the vanilla game draw Pages 1 and 2. 
      -- This stops Page 2's EXP text from bleeding into Page 3!
      if self.page == 1 or self.page == 2 then
        originalDraw(self)
      
      elseif self.page == 3 then
        local Font = package.loaded["src.render.Font"] or require("src.render.Font")
        local HudTiles = package.loaded["src.render.HudTiles"] or require("src.render.HudTiles")
        local mon = self.mon
        local def = self.game.data.pokemon[mon.species]

        local function printLevel(tx, ty, level)
          local x = tx * 8
          if level < 100 then
            HudTiles.statusTile(0x6E, x, ty * 8)
            x = x + 8
          end
          Font.draw(tostring(level), x, ty * 8)
        end

        local function drawLineBox(tx, ty, b, c)
          for i = 0, b - 1 do HudTiles.statusTile(0x78, tx * 8, (ty + i) * 8) end
          HudTiles.statusTile(0x77, tx * 8, (ty + b) * 8)
          for i = 1, c do HudTiles.statusTile(0x76, (tx - i) * 8, (ty + b) * 8) end
          HudTiles.statusTile(0x6F, (tx - c - 1) * 8, (ty + b) * 8)
        end

        -- --- START RECREATING THE CLEAN HEADER ---
        -- 1. Draw solid white background
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.rectangle("fill", 0, 0, 160, 144)

        -- 2. Draw Sprite (Mirrored)
        if self.sprite then
          love.graphics.draw(self.sprite, 8 + self.sprite:getWidth(),
                             math.max(0, 56 - self.sprite:getHeight()), 0, -1, 1)
        end

        -- 3. Draw Header Text (Name, No.)
        love.graphics.setColor(0, 0, 0, 1)
        Font.draw(mon.nickname or def.name, 72, 8)
        HudTiles.statusTile(0x74, 8, 56)  -- №
        Font.drawCode(0xF2, 16, 56)       -- <DOT>
        Font.draw(("%03d"):format(def.dex or 0), 24, 56)
        -- --- END HEADER ---

        -- Draw the Level box in the top right
        printLevel(14, 2, mon.level)
        drawLineBox(19, 1, 6, 10)
        
        -- Fetch hidden stats safely
        local dvs = mon.dvs or mon.ivs or (mon.stats and (mon.stats.dvs or mon.stats.ivs)) or {}
        local statExp = mon.statExp or {}
        local hpDv = dvs.hp or ((dvs.attack or 0) % 2) * 8 + ((dvs.defense or 0) % 2) * 4 + ((dvs.speed or 0) % 2) * 2 + ((dvs.special or 0) % 2)

        -- THE FIX: HP Data mapped exactly to your mockup!
        -- Start at X=80 so it perfectly aligns with the EXP column in the bottom box
        Font.draw("HP", 72, 24)
        Font.draw(("DV %6d"):format(hpDv), 80, 32)
        
        Font.draw("HP", 72, 40)
        Font.draw(("EXP %5d"):format(statExp.hp or 0), 80, 48)
        
        -- Draw full-width bottom box
        Font.drawBox(0, 8, 20, 10)
        
        -- Core stats list
        local statsData = {
          { "ATTACK", dvs.attack or 0, statExp.attack or 0 },
          { "DEFENSE", dvs.defense or 0, statExp.defense or 0 },
          { "SPEED", dvs.speed or 0, statExp.speed or 0 },
          { "SPECIAL", dvs.special or 0, statExp.special or 0 }
        }
        
        -- Print the data dynamically down the box
        for i, row in ipairs(statsData) do
          local y = 72 + (i - 1) * 16
          Font.draw(row[1], 8, y)
          Font.draw(("DV %2d"):format(row[2]), 32, y + 8)
          Font.draw(("EXP %5d"):format(row[3]), 80, y + 8)
        end
        
        -- Reset draw color back to white to prevent tinting the rest of the game
        if love and love.graphics then
          love.graphics.setColor(1, 1, 1, 1)
        end
      end
    end
    
    mod.log:info("DV Tracker Mod: Successfully patched SummaryMenu for Page 3!")
  else
    mod.log:error("DV Tracker Mod: Could not locate SummaryMenu to patch.")
  end

end