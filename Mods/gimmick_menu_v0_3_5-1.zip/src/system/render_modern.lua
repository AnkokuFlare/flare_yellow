-- Modern presentation for the gimmick ring/list. Same draw surface and
-- geometry as render.lua -- this still runs inside battle.overlay on the
-- native low-resolution battle canvas, not gen1_modern_ui's separate
-- high-resolution hud pass -- just styled with rounded panels and
-- color-coded states instead of the classic bordered box and glyph
-- cursor. Selected by the MODERN UI option in main.lua; render.lua stays
-- the default and is untouched.

local Registry = require("mods.gimmick_menu.src.logic.registry")

local RenderModern = {}

local function setColor(color)
  love.graphics.setColor(color[1], color[2], color[3], color[4] or 1)
end

-- Draws registered gimmicks only, same four-entry cap as render.lua.
function RenderModern.drawRibbon(Font, battle, layout, state)
  if battle.phase ~= "moveSelect" then return end
  local gimmicks = Registry.getRegistered()
  if #gimmicks == 0 then return end

  local tokens = layout.modern
  local battler = battle.player

  if not battle:wideLayout() then
    if not state or not state.focus then return end
    local box = layout.classicList
    local visible = math.min(#gimmicks, 4)
    local rowH = (box.h - tokens.padding * 2) / 4

    setColor(tokens.colors.surface)
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h, tokens.radius, tokens.radius)

    for i = 1, visible do
      local gimmick = gimmicks[i]
      local enabled = Registry.canActivate(gimmick, battle, battler)
      local rowY = box.y + tokens.padding + (i - 1) * rowH
      local focused = state.focus == gimmick.id
      local slotColor = focused and tokens.colors.selected
        or (enabled and tokens.colors.slot or tokens.colors.slotDisabled)
      setColor(slotColor)
      love.graphics.rectangle("fill", box.x + tokens.padding, rowY,
        box.w - tokens.padding * 2, rowH, tokens.radius, tokens.radius)
      setColor(enabled and tokens.colors.text or tokens.colors.textMuted)
      Font.draw(gimmick.label, box.x + 8, rowY + 1)
      if state.activated[gimmick.id] then
        setColor(tokens.colors.accent)
        Font.draw("*", box.x + box.w - 12, rowY + 1)
      end
    end
    love.graphics.setColor(1, 1, 1, 1)
    return
  end

  local ribbon = layout.ribbon
  local visible = math.min(#gimmicks, 4)
  local slotWidth = ribbon.totalW / visible

  setColor(tokens.colors.surface)
  love.graphics.rectangle("fill", 0, ribbon.y, ribbon.totalW, ribbon.h,
    tokens.radius, tokens.radius)

  for i = 1, visible do
    local gimmick = gimmicks[i]
    local enabled = Registry.canActivate(gimmick, battle, battler)
    local x = (i - 1) * slotWidth
    local focused = state and state.focus == gimmick.id
    local slotColor = focused and tokens.colors.selected
      or (enabled and tokens.colors.slot or tokens.colors.slotDisabled)
    setColor(slotColor)
    love.graphics.rectangle("fill", x + tokens.padding, ribbon.y,
      slotWidth - tokens.padding * 2, ribbon.h, tokens.radius, tokens.radius)
    setColor(enabled and tokens.colors.text or tokens.colors.textMuted)
    Font.draw(gimmick.label, x + 8, ribbon.y)
    if state and state.activated[gimmick.id] then
      setColor(tokens.colors.accent)
      Font.draw("*", x + slotWidth - 10, ribbon.y)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
end

return RenderModern
