local Logic = require("mods.gimmick_menu.src.logic.gimmick_state")
local Registry = require("mods.gimmick_menu.src.logic.registry")
local BattleState = require("src.battle.BattleState")

local Input = {}
local PRIORITY = { "left", "right", "up", "down" }

local function activeDirection(engineInput)
  for _, dir in ipairs(PRIORITY) do
    if engineInput:wasPressed(dir) then return dir end
  end
end

function Input.stateOf(battle)
  return battle.gimmickMenu
end

local function handleFrame(battle)
  local battler = battle.player
  local moves = battler and battler.curMoves
  local list = Registry.getRegistered()
  if not moves or #moves == 0 or #list == 0 then return false end

  local engineInput = battle.game.input
  local dir = activeDirection(engineInput)
  local atTop = battle.moveIndex <= 2
  local classic = not battle:wideLayout()
  local function pressed(key)
    if key == "a" or key == "b" then return engineInput:wasPressed(key) end
    return key == dir
  end

  local state = battle.gimmickMenu or Logic.newState()
  local oldFocus = state.focus
  local consumed, activationId = Logic.handleInput(state, pressed, atTop,
    battle.moveSwapIndex ~= nil, list, classic)
  if consumed and not battle.gimmickMenu then battle.gimmickMenu = state end
  if consumed and oldFocus ~= state.focus then
    Registry.emitFocusChanged(battle, state.focus, battler)
  end
  if activationId then
    -- Failure is intentionally non-fatal: a mechanic can reject activation
    -- after a last-second check; its item will be drawn disabled next frame.
    Registry.activate(activationId, battle, battler)
  end
  return consumed
end

function Input.install(mod, ownsBattle)
  if BattleState.__gimmickMenuWrapped then return end
  BattleState.__gimmickMenuWrapped = true

  local vanillaUpdate = BattleState.update
  function BattleState:update(dt)
    if self.gimmickMenu and self.phase ~= "moveSelect" then
      Logic.onPhaseExit(self.gimmickMenu)
    end

    -- gen1_modern_ui's experimental battle presenter can take over the
    -- whole battle canvas (see main.lua). When it does, close any open
    -- ring/list instead of leaving it stuck open behind an invisible menu.
    local conflict = ownsBattle and ownsBattle()
    if conflict and self.gimmickMenu then
      Logic.onPhaseExit(self.gimmickMenu)
    end

    if not conflict and mod.options:get("enabled") and self.phase == "moveSelect" then
      local ok, consumed = pcall(handleFrame, self)
      if not ok then
        mod.log:warn("gimmick_menu: input handling failed (%s) -- falling back to vanilla this frame", tostring(consumed))
      elseif consumed then
        self:tickFx()
        return
      end
    end
    return vanillaUpdate(self, dt)
  end
end

return Input
