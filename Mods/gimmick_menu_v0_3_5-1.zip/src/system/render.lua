local Registry = require("mods.gimmick_menu.src.logic.registry")

local Render = {}
local CURSOR = 0xED

-- Draws registered gimmicks only.  The ribbon has room for four entries;
-- registration remains unrestricted, but entries after the first four by
-- priority are deliberately not shown until a larger UI is added.
function Render.drawRibbon(Font, battle, layout, state)
  if battle.phase ~= "moveSelect" then return end
  local gimmicks = Registry.getRegistered()
  if #gimmicks == 0 then return end

  if not battle:wideLayout() then
    -- Classic battles have a vertical move list in this exact lower-right
    -- box. While focused, replace that list with registered gimmicks;
    -- LEFT or RIGHT (either one) opens or closes it, and UP/DOWN cycle
    -- through it once open.
    if not state or not state.focus then return end
    Font.drawBox(4, 12, 16, 6)
    local visible = math.min(#gimmicks, 4)
    local battler = battle.player
    for i = 1, visible do
      local gimmick = gimmicks[i]
      local enabled = Registry.canActivate(gimmick, battle, battler)
      love.graphics.setColor(enabled and 0 or 0.45, enabled and 0 or 0.45,
        enabled and 0 or 0.45, 1)
      Font.draw(gimmick.label, 48, 96 + i * 8)
      if state.focus == gimmick.id then Font.drawCode(CURSOR, 40, 96 + i * 8) end
      if state.activated[gimmick.id] then Font.draw("*", 144, 96 + i * 8) end
    end
    love.graphics.setColor(1, 1, 1, 1)
    return
  end

  local ribbon = layout.ribbon
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.rectangle("fill", 0, ribbon.y, ribbon.totalW, ribbon.h)

  local visible = math.min(#gimmicks, 4)
  local slotWidth = ribbon.totalW / visible
  local battler = battle.player
  for i = 1, visible do
    local gimmick = gimmicks[i]
    local enabled = Registry.canActivate(gimmick, battle, battler)
    local x = (i - 1) * slotWidth
    if enabled then
      love.graphics.setColor(0, 0, 0, 1)
    else
      love.graphics.setColor(0.45, 0.45, 0.45, 1)
    end
    Font.draw(gimmick.label, x + 8, ribbon.y)
    if state and state.focus == gimmick.id then
      Font.drawCode(CURSOR, x, ribbon.y)
    end
    if state and state.activated[gimmick.id] then
      Font.draw("*", x + slotWidth - 10, ribbon.y)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
end

return Render
