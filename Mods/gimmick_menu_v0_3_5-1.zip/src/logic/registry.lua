-- Public gimmick registry and per-battle state.  This module deliberately
-- contains no game-specific rules: each mechanic owns its own availability
-- and activation logic through the definition it registers.

local Registry = {}

local entries = {}
local activatedListeners = {}
local focusListeners = {}

local function sortedEntries()
  local list = {}
  for _, definition in pairs(entries) do
    list[#list + 1] = definition
  end
  table.sort(list, function(a, b)
    if a.priority == b.priority then return a.id < b.id end
    return a.priority < b.priority
  end)
  return list
end

local function stateFor(battle)
  assert(battle, "gimmick_menu: battle is required")
  battle.gimmickMenu = battle.gimmickMenu or {
    focus = nil,
    activated = {},
  }
  return battle.gimmickMenu
end

local function notify(list, ...)
  for _, callback in ipairs(list) do
    pcall(callback, ...)
  end
end

function Registry.register(definition)
  assert(type(definition) == "table", "gimmick_menu: definition must be a table")
  assert(type(definition.id) == "string" and definition.id ~= "",
    "gimmick_menu: definition.id must be a non-empty string")
  assert(type(definition.canActivate) == "function",
    "gimmick_menu: definition.canActivate must be a function")
  assert(type(definition.activate) == "function",
    "gimmick_menu: definition.activate must be a function")

  entries[definition.id] = {
    id = definition.id,
    label = definition.label or definition.name or definition.id,
    name = definition.name or definition.label or definition.id,
    icon = definition.icon,
    priority = definition.priority or 100,
    canActivate = definition.canActivate,
    activate = definition.activate,
  }
end

function Registry.unregister(id)
  entries[id] = nil
end

function Registry.getRegistered()
  return sortedEntries()
end

function Registry.getBattleState(battle)
  return stateFor(battle)
end

function Registry.isActivated(battle, id)
  return stateFor(battle).activated[id] == true
end

function Registry.markActivated(battle, id, battler)
  local state = stateFor(battle)
  if state.activated[id] then return false end
  state.activated[id] = true
  notify(activatedListeners, id, battle, battler, state)
  return true
end

function Registry.onActivated(callback)
  assert(type(callback) == "function", "gimmick_menu: callback must be a function")
  activatedListeners[#activatedListeners + 1] = callback
end

function Registry.onFocusChanged(callback)
  assert(type(callback) == "function", "gimmick_menu: callback must be a function")
  focusListeners[#focusListeners + 1] = callback
end

function Registry.emitFocusChanged(battle, id, battler)
  local state = stateFor(battle)
  notify(focusListeners, id, battle, battler, state)
end

function Registry.canActivate(definition, battle, battler)
  local ok, enabled, reason = pcall(definition.canActivate, battle, battler, stateFor(battle))
  if not ok then return false, "canActivate failed: " .. tostring(enabled) end
  return enabled == true, reason
end

function Registry.activate(id, battle, battler)
  local definition = entries[id]
  if not definition then return false, "gimmick is not registered" end
  local enabled, reason = Registry.canActivate(definition, battle, battler)
  if not enabled then return false, reason end
  local ok, success, failureReason = pcall(definition.activate, battle, battler, stateFor(battle))
  if not ok then return false, "activate failed: " .. tostring(success) end
  -- A mechanic can prepare an action now and report success later (for
  -- example, Dynamax replaces move entries first, then starts its sequence
  -- immediately before the chosen Max Move resolves).
  if success == "pending" then return true end
  if success ~= true then return false, failureReason end
  Registry.markActivated(battle, id, battler)
  return true
end

return Registry
