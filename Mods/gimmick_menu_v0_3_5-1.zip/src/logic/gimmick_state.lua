-- Pure navigation state for the registered gimmick ribbon.  Activation is
-- dispatched by system/input.lua so this layer has no knowledge of mods.
--
-- Wide layout: UP at the move grid's top row opens the ring (on the
-- first registered entry); LEFT/RIGHT cycle it; DOWN or B closes it.
--
-- Classic layout: the move list is vertical, so the axes swap. LEFT or
-- RIGHT (either one) opens the gimmick list in place of the move list,
-- and the same pair closes it again -- entering and exiting are
-- symmetric, not tied to which one you used to get in. UP/DOWN cycle
-- through the list, wrapping at both ends, the same as LEFT/RIGHT do in
-- the wide ring.

local Logic = {}

function Logic.newState()
  return { focus = nil, activated = {} }
end

local function indexOf(list, id)
  for i, definition in ipairs(list) do
    if definition.id == id then return i end
  end
end

local function cycle(list, id, delta)
  local at = indexOf(list, id) or 1
  return list[((at - 1 + delta) % #list) + 1].id
end

local function handleClassic(state, pressed, list)
  if not state.focus then
    if pressed("left") or pressed("right") then
      state.focus = list[1].id
      return true
    end
    return false
  end

  if pressed("b") or pressed("left") or pressed("right") then
    state.focus = nil
    return true
  end
  if pressed("up") then
    state.focus = cycle(list, state.focus, -1)
    return true
  end
  if pressed("down") then
    state.focus = cycle(list, state.focus, 1)
    return true
  end
  if pressed("a") then
    local id = state.focus
    state.focus = nil
    return true, id
  end
  return false
end

local function handleWide(state, pressed, atTop, list)
  if not state.focus then
    if pressed("up") and atTop then
      state.focus = list[1].id
      return true
    end
    return false
  end

  if pressed("b") or pressed("down") then
    state.focus = nil
    return true
  end
  if pressed("left") then
    state.focus = cycle(list, state.focus, -1)
    return true
  end
  if pressed("right") then
    state.focus = cycle(list, state.focus, 1)
    return true
  end
  if pressed("a") then
    local id = state.focus
    state.focus = nil
    return true, id
  end
  -- "up" while already focused does nothing -- there's no level above
  -- the ring -- but it's still swallowed rather than passed to vanilla,
  -- which has no idea the cursor has left the grid.
  if pressed("up") then return true end
  return false
end

-- Returns handled, activationId.  A non-nil activationId asks the caller to
-- run that registered gimmick's activation callback.
function Logic.handleInput(state, pressed, atTop, swapping, list, classic)
  if swapping or #list == 0 then return false end
  if classic then return handleClassic(state, pressed, list) end
  return handleWide(state, pressed, atTop, list)
end

function Logic.onPhaseExit(state)
  state.focus = nil
end

return Logic
