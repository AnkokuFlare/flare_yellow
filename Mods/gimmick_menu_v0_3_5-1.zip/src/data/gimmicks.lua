-- Static ribbon geometry. Registered mechanics provide their own label,
-- priority, availability rule, and activation callback at runtime; this
-- file intentionally contains no mechanic definitions.

local GIMMICKS = {}

-- Ribbon geometry: a single strip directly above the CHOOSE MOVE box.
-- The wide layout (WideBattle.lua) leaves no free margin to the left,
-- right, or below that box -- it already spans the full 304px width and
-- sits flush against the bottom of the 144px frame. y = 96..104 is the
-- one rectangle across the whole width that's guaranteed clear of both
-- HUD panels; see README.md "Layout constraint" for the measurements.
-- Move these four numbers, not the logic, if the ribbon should look
-- different.
GIMMICKS.ribbon = {
  y = 96,
  h = 8,
  totalW = 304,
  slotW = 76, -- default width when four mechanics are registered
}

-- Pixel box matching Font.drawBox(4, 12, 16, 6) in render.lua (8px tiles:
-- x=4*8, y=12*8, w=16*8, h=6*8). Kept here too so render_modern.lua does not
-- duplicate the classic box's magic numbers.
GIMMICKS.classicList = { x = 32, y = 96, w = 128, h = 48 }

-- Tokens for the MODERN UI option (main.lua, render_modern.lua). Colors
-- loosely mirror gen1_modern_ui's default theme so the ring/list read as
-- part of the same family when that mod is installed, but this table is
-- static: gen1_modern_ui exports its theme registry, not a live
-- currently-selected-theme getter, so this mod cannot track the player's
-- chosen theme or scale. Revisit if gen1_modern_ui adds that export.
GIMMICKS.modern = {
  radius = 2,
  padding = 2,
  colors = {
    surface = { 0.075, 0.105, 0.17, 0.90 },
    -- Solid fill every option sits on before it is focused/hovered.
    slot = { 0.12, 0.17, 0.27, 1 },
    slotDisabled = { 0.10, 0.12, 0.16, 0.75 },
    selected = { 0.18, 0.43, 0.72, 1 },
    -- FFD700, mild yellow used for the gimmick option labels.
    text = { 1, 0.843, 0, 1 },
    textMuted = { 0.55, 0.60, 0.68, 1 },
    accent = { 0.48, 0.86, 1.00, 1 },
  },
}

return GIMMICKS
