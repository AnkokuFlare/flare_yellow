-- Gimmick ring: a 4-option ribbon (DYNAMAX / MEGA / TERA / Z-MOVE) around
-- the wide-layout move grid, reached by pressing a direction at the
-- grid's own edge. See README.md for the layout constraint this works
-- within and why src/system/input.lua needs the engine_internals
-- permission.

local Layout = require("mods.gimmick_menu.src.data.gimmicks")
local Registry = require("mods.gimmick_menu.src.logic.registry")
local Input = require("mods.gimmick_menu.src.system.input")
local Render = require("mods.gimmick_menu.src.system.render")
local RenderModern = require("mods.gimmick_menu.src.system.render_modern")

return function(mod)
  mod.options:define({
    { key = "enabled", label = "GIMMICK RING", type = "toggle", default = true },
    -- Restyles only this mod's own ribbon/list draw; it never changes any
    -- gen1_modern_ui option or any other menu (see modernUiOwnsBattle
    -- below for the one place this mod *reads* a gen1_modern_ui option).
    { key = "modernUi", label = "MODERN UI", type = "toggle", default = false,
      description = "Draw the ring (wide layout) and list (classic layout) "
        .. "with rounded panels and color-coded states instead of the "
        .. "classic box. Only changes this menu.", },
  })

  -- ------- gen1_modern_ui compatibility
  -- gen1_modern_ui's experimental battle presenter (its BATTLE UI (WIP)
  -- option, off by default) fully replaces the classic battle canvas once
  -- its HIDE ORIGINAL UI option also clears it. When both are on, this
  -- ring gets drawn into the canvas gen1_modern_ui then wipes, so it goes
  -- invisible -- but without this check, the input wrapper below kept
  -- intercepting UP/LEFT/RIGHT/DOWN in moveSelect for that now-invisible
  -- menu, which made ordinary move selection look unresponsive. Both mods
  -- were effectively fighting for the same input and canvas.
  --
  -- gen1_modern_ui does not export a "battle UI is active" query, so this
  -- reads its options directly through mod.find as a best effort. If that
  -- ever isn't readable (older/different gen1_modern_ui build, or it isn't
  -- installed), this simply reports "no conflict" and this mod behaves
  -- exactly as before -- it never assumes a conflict it can't confirm.
  local function modernUiOwnsBattle()
    local ok, owns = pcall(function()
      local other = mod.find("gen1_modern_ui")
      local opts = other and other.options
      if not opts or not opts.get then return false end
      return opts:get("battleUiWip") == true and opts:get("hideOriginalUi") ~= false
    end)
    return ok and owns == true
  end

  Input.install(mod, modernUiOwnsBattle)

  mod.hooks:wrap("battle.overlay", function(next, battle)
    next(battle)
    if not mod.options:get("enabled") then return end
    if modernUiOwnsBattle() then return end
    local presenter = mod.options:get("modernUi") and RenderModern or Render
    local ok, err = pcall(presenter.drawRibbon, mod.ui.Font, battle, Layout,
      Input.stateOf(battle))
    if not ok then
      mod.log:warn("gimmick_menu: ribbon draw failed (%s) -- hiding it "
        .. "this frame", tostring(err))
    end
  end)

  -- ------- public modding API
  -- Mechanic mods call these through mod.find("gimmick_menu").exports.
  mod.exports.register = Registry.register
  mod.exports.unregister = Registry.unregister
  mod.exports.getRegistered = Registry.getRegistered
  mod.exports.getBattleState = Registry.getBattleState
  mod.exports.isActivated = Registry.isActivated
  mod.exports.markActivated = Registry.markActivated
  mod.exports.onActivated = Registry.onActivated
  mod.exports.onFocusChanged = Registry.onFocusChanged
end
