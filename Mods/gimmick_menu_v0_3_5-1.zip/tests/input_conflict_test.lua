-- Stubs src.battle.BattleState so Input.install can be exercised without
-- the real engine tree, the same way tests/render_test.lua stubs love.
package.path = "./?.lua;./?/init.lua;" .. package.path

local FakeBattleState = {}
FakeBattleState.__index = FakeBattleState
function FakeBattleState:wideLayout() return true end
local function vanillaUpdate(self, dt) self.vanillaCalled = true end
FakeBattleState.update = vanillaUpdate
local function resetBattleState()
  FakeBattleState.__gimmickMenuWrapped = nil
  FakeBattleState.update = vanillaUpdate
end
package.preload["src.battle.BattleState"] = function() return FakeBattleState end
package.preload["mods.gimmick_menu.src.logic.gimmick_state"] = function()
  return require("src.logic.gimmick_state")
end
package.preload["mods.gimmick_menu.src.logic.registry"] = function()
  return require("src.logic.registry")
end

local Registry = require("src.logic.registry")
local Input = require("src.system.input")

Registry.register({
  id = "DYNAMAX", label = "DYNAMAX", priority = 1,
  canActivate = function() return true end,
  activate = function() return true end,
})

local failures = 0
local function eq(got, want, message)
  if got ~= want then
    failures = failures + 1
    print(("FAIL: %s (got %s, want %s)"):format(message, tostring(got), tostring(want)))
  end
end

local function fakeMod(enabled)
  local warnings = {}
  return {
    options = { get = function(_, key) if key == "enabled" then return enabled end end },
    log = { warn = function(_, ...) warnings[#warnings + 1] = { ... } end },
  }, warnings
end

local function newBattle()
  local pressed = {}
  local battle = setmetatable({
    phase = "moveSelect", moveIndex = 1,
    player = { curMoves = { {}, {}, {}, {} } },
    game = { input = { wasPressed = function(_, key) return pressed[key] == true end } },
    tickFx = function() end,
  }, FakeBattleState)
  return battle, pressed
end

do
  -- no conflict: UP opens the ring as usual
  resetBattleState()
  local mod = fakeMod(true)
  Input.install(mod, function() return false end)
  local battle, pressed = newBattle()
  pressed.up = true
  battle:update(1 / 60)
  eq(battle.gimmickMenu and battle.gimmickMenu.focus, "DYNAMAX",
    "input is handled when gen1_modern_ui does not own the battle screen")
end

do
  -- conflict: input passes straight through to vanilla, ring stays closed
  resetBattleState()
  local mod = fakeMod(true)
  Input.install(mod, function() return true end)
  local battle, pressed = newBattle()
  pressed.up = true
  battle:update(1 / 60)
  eq(battle.gimmickMenu, nil,
    "input is left to vanilla while gen1_modern_ui owns the battle screen")
  eq(battle.vanillaCalled, true, "vanilla update still runs during the conflict")
end

do
  -- conflict appearing after the ring was already open: it gets released
  resetBattleState()
  local mod = fakeMod(true)
  local owns = false
  Input.install(mod, function() return owns end)
  local battle, pressed = newBattle()
  pressed.up = true
  battle:update(1 / 60)
  eq(battle.gimmickMenu.focus, "DYNAMAX", "ring opens before the conflict starts")
  owns = true
  pressed.up = false
  battle:update(1 / 60)
  eq(battle.gimmickMenu.focus, nil, "ring is released once the conflict is detected")
end

if failures == 0 then print("input_conflict_test: all checks passed") else os.exit(1) end
