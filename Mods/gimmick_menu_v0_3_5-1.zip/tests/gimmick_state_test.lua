package.path = "./?.lua;./?/init.lua;" .. package.path
local Logic = require("src.logic.gimmick_state")

local list = {
  { id = "DYNAMAX" }, { id = "MEGA" }, { id = "TERA" },
}
local failures = 0
local function eq(got, want, message)
  if got ~= want then
    failures = failures + 1
    print(("FAIL: %s (got %s, want %s)"):format(message, tostring(got), tostring(want)))
  end
end
local function keys(...)
  local set = {}
  for _, key in ipairs({ ... }) do set[key] = true end
  return function(key) return set[key] == true end
end

-- ===========================================================================
-- Wide layout (classic = false / omitted): unchanged
-- ===========================================================================

do
  local s = Logic.newState()
  local handled = Logic.handleInput(s, keys("up"), true, false, list)
  eq(handled, true, "UP opens a non-empty registry")
  eq(s.focus, "DYNAMAX", "first priority entry receives focus")
end

do
  local s = Logic.newState()
  eq(Logic.handleInput(s, keys("up"), true, false, {}), false, "empty registry does not capture input")
end

do
  local s = Logic.newState()
  s.focus = "DYNAMAX"
  Logic.handleInput(s, keys("left"), true, false, list)
  eq(s.focus, "TERA", "wide LEFT wraps to the final entry")
  Logic.handleInput(s, keys("right"), true, false, list)
  eq(s.focus, "DYNAMAX", "wide RIGHT wraps to the first entry")
end

do
  local s = Logic.newState()
  s.focus = "MEGA"
  local handled, id = Logic.handleInput(s, keys("a"), true, false, list)
  eq(handled, true, "A is captured")
  eq(id, "MEGA", "A asks caller to activate the focused ID")
  eq(s.focus, nil, "A returns focus to the move grid")
end

do
  local s = Logic.newState()
  s.focus = "MEGA"
  Logic.onPhaseExit(s)
  eq(s.focus, nil, "phase exit clears focus")
end

-- ===========================================================================
-- Classic layout: LEFT and RIGHT are symmetric open/close; UP/DOWN cycle
-- ===========================================================================

do
  local s = Logic.newState()
  Logic.handleInput(s, keys("right"), false, false, list, true)
  eq(s.focus, "DYNAMAX", "classic RIGHT opens the first registered gimmick")
end

do
  local s = Logic.newState()
  Logic.handleInput(s, keys("left"), false, false, list, true)
  eq(s.focus, "DYNAMAX", "classic LEFT also opens the first registered gimmick")
end

do
  local s = Logic.newState()
  eq(Logic.handleInput(s, keys("up"), true, false, list, true), false,
    "classic UP does not open the gimmick list from the move list")
  eq(s.focus, nil, "...focus stays untouched")
end

do
  local s = Logic.newState()
  eq(Logic.handleInput(s, keys("down"), true, false, list, true), false,
    "classic DOWN does not open the gimmick list from the move list either")
  eq(s.focus, nil, "...focus stays untouched")
end

do
  local s = Logic.newState()
  s.focus = "MEGA" -- not the first or last entry
  Logic.handleInput(s, keys("left"), false, false, list, true)
  eq(s.focus, nil, "classic LEFT closes the list from any entry, not just the ends")
end

do
  local s = Logic.newState()
  s.focus = "MEGA"
  Logic.handleInput(s, keys("right"), false, false, list, true)
  eq(s.focus, nil, "classic RIGHT closes the list from any entry too")
end

do
  local s = Logic.newState()
  s.focus = "DYNAMAX"
  Logic.handleInput(s, keys("down"), false, false, list, true)
  eq(s.focus, "MEGA", "classic DOWN cycles forward")
  Logic.handleInput(s, keys("down"), false, false, list, true)
  eq(s.focus, "TERA", "...one more DOWN advances again")
  Logic.handleInput(s, keys("down"), false, false, list, true)
  eq(s.focus, "DYNAMAX", "...and wraps back to the first entry past the last")
end

do
  local s = Logic.newState()
  s.focus = "DYNAMAX"
  Logic.handleInput(s, keys("up"), false, false, list, true)
  eq(s.focus, "TERA", "classic UP wraps backward to the final entry")
  Logic.handleInput(s, keys("up"), false, false, list, true)
  eq(s.focus, "MEGA", "...one more UP steps back again")
end

do
  local s = Logic.newState()
  s.focus = "MEGA"
  local handled, id = Logic.handleInput(s, keys("a"), false, false, list, true)
  eq(handled, true, "classic A is captured")
  eq(id, "MEGA", "classic A asks caller to activate the focused ID")
  eq(s.focus, nil, "classic A returns focus to the move list")
end

do
  local s = Logic.newState()
  s.focus = "MEGA"
  local handled = Logic.handleInput(s, keys("b"), false, false, list, true)
  eq(handled, true, "classic B still closes the list too")
  eq(s.focus, nil, "...same as LEFT/RIGHT")
end

if failures == 0 then
  print("gimmick_state_test: all checks passed")
  os.exit(0)
end
print(("gimmick_state_test: %d failure(s)"):format(failures))
os.exit(1)
