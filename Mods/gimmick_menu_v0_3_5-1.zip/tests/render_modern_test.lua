package.path = "./?.lua;./?/init.lua;" .. package.path
package.preload["mods.gimmick_menu.src.logic.registry"] = function()
  return require("src.logic.registry")
end
local Registry = require("src.logic.registry")
local RenderModern = require("src.system.render_modern")
local Layout = require("src.data.gimmicks")

for i, id in ipairs({ "DYNAMAX", "MEGA", "TERA", "ZMOVE" }) do
  Registry.register({
    id = id, label = id, priority = i,
    canActivate = function(_, _, state) return id ~= "TERA" and not state.activated[id] end,
    activate = function() return true end,
  })
end

local failures = 0
local function eq(got, want, message)
  if got ~= want then
    failures = failures + 1
    print(("FAIL: %s (got %s, want %s)"):format(message, tostring(got), tostring(want)))
  end
end

local rectangleCalls
_G.love = { graphics = {
  setColor = function() end,
  rectangle = function(mode, x, y, w, h, rx, ry)
    rectangleCalls[#rectangleCalls + 1] = { mode, x, y, w, h, rx, ry }
  end,
} }

local function fakeFont()
  local calls = { draw = {}, drawCode = {} }
  rectangleCalls = {}
  return calls, {
    draw = function(text, x, y) calls.draw[#calls.draw + 1] = { text, x, y } end,
    drawCode = function(code, x, y) calls.drawCode[#calls.drawCode + 1] = { code, x, y } end,
  }
end
local function fakeBattle(overrides)
  local battle = { phase = "moveSelect", player = {} }
  function battle:wideLayout() return self.wide ~= false end
  for key, value in pairs(overrides or {}) do battle[key] = value end
  return battle
end

do
  local calls, Font = fakeFont()
  RenderModern.drawRibbon(Font, fakeBattle({ phase = "menu" }), Layout, nil)
  eq(#calls.draw, 0, "nothing is drawn outside move selection")
end

do
  -- wide layout
  local calls, Font = fakeFont()
  local battle = fakeBattle()
  RenderModern.drawRibbon(Font, battle, Layout, { focus = "TERA", activated = { DYNAMAX = true } })
  eq(#rectangleCalls, 5, "one ribbon background plus one solid slot per option")
  local labels, marks = 0, 0
  for _, call in ipairs(calls.draw) do
    if call[1] == "*" then marks = marks + 1 else labels = labels + 1 end
  end
  eq(labels, 4, "four registered labels are drawn")
  eq(marks, 1, "activated entry gets a marker")
end

do
  -- classic layout, closed: nothing drawn
  local calls, Font = fakeFont()
  local battle = fakeBattle({ wide = false })
  RenderModern.drawRibbon(Font, battle, Layout, { focus = nil, activated = {} })
  eq(#calls.draw, 0, "classic list stays hidden while unfocused")
  eq(#rectangleCalls, 0, "no panel drawn while unfocused")
end

do
  -- classic layout, open
  local calls, Font = fakeFont()
  local battle = fakeBattle({ wide = false })
  RenderModern.drawRibbon(Font, battle, Layout, { focus = "MEGA", activated = { DYNAMAX = true } })
  eq(#rectangleCalls, 5, "one list panel plus one solid slot per option")
  local labels, marks = 0, 0
  for _, call in ipairs(calls.draw) do
    if call[1] == "*" then marks = marks + 1 else labels = labels + 1 end
  end
  eq(labels, 4, "four registered labels are drawn")
  eq(marks, 1, "activated entry gets a marker")
end

do
  -- unfocused options still get their own solid slot, not just the panel
  local calls, Font = fakeFont()
  local battle = fakeBattle()
  RenderModern.drawRibbon(Font, battle, Layout, { focus = "DYNAMAX", activated = {} })
  eq(#rectangleCalls, 5, "one ribbon background plus one solid slot per option")
  eq(#rectangleCalls - 1, 4, "every option (focused or not) draws its own solid slot")
end

if failures == 0 then print("render_modern_test: all checks passed") else os.exit(1) end
