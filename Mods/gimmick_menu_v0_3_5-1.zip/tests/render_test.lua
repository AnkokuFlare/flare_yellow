package.path = "./?.lua;./?/init.lua;" .. package.path
package.preload["mods.gimmick_menu.src.logic.registry"] = function()
  return require("src.logic.registry")
end
local Registry = require("src.logic.registry")
local Render = require("src.system.render")
local Layout = require("src.data.gimmicks")

for i, id in ipairs({ "DYNAMAX", "MEGA", "TERA", "ZMOVE" }) do
  Registry.register({
    id = id, label = id, priority = i,
    canActivate = function(_, _, state) return id ~= "TERA" and not state.activated[id] end,
    activate = function() return true end,
  })
end

local failures = 0
local function eq(got, want, message)
  if got ~= want then
    failures = failures + 1
    print(("FAIL: %s (got %s, want %s)"):format(message, tostring(got), tostring(want)))
  end
end

local rectangleCalls
_G.love = { graphics = {
  setColor = function() end,
  rectangle = function(mode, x, y, w, h)
    rectangleCalls[#rectangleCalls + 1] = { mode, x, y, w, h }
  end,
} }

local function fakeFont()
  local calls = { draw = {}, drawCode = {} }
  rectangleCalls = {}
  return calls, {
    draw = function(text, x, y) calls.draw[#calls.draw + 1] = { text, x, y } end,
    drawCode = function(code, x, y) calls.drawCode[#calls.drawCode + 1] = { code, x, y } end,
  }
end
local function fakeBattle(overrides)
  local battle = { phase = "moveSelect", player = {} }
  function battle:wideLayout() return self.wide ~= false end
  for key, value in pairs(overrides or {}) do battle[key] = value end
  return battle
end

do
  local calls, Font = fakeFont()
  Render.drawRibbon(Font, fakeBattle({ phase = "menu" }), Layout, nil)
  eq(#calls.draw, 0, "nothing is drawn outside move selection")
end

do
  local calls, Font = fakeFont()
  local battle = fakeBattle()
  Render.drawRibbon(Font, battle, Layout, { focus = "TERA", activated = { DYNAMAX = true } })
  eq(#rectangleCalls, 1, "one ribbon background is drawn")
  eq(#calls.drawCode, 1, "one focus cursor is drawn")
  eq(calls.drawCode[1][2], Layout.ribbon.totalW / 4 * 2, "cursor uses dynamic third slot")
  local labels, marks = 0, 0
  for _, call in ipairs(calls.draw) do
    if call[1] == "*" then marks = marks + 1 else labels = labels + 1 end
  end
  eq(labels, 4, "four registered labels are drawn")
  eq(marks, 1, "activated entry gets a marker")
end

if failures == 0 then print("render_test: all checks passed") else os.exit(1) end
