-- Copy the registration block into a gen1recomp Dynamax mod's main.lua.
-- Replace Dynamax.canUse and Dynamax.begin with that mod's real functions.

return function(mod, Dynamax)
  local menu = mod.find("gimmick_menu")
  if not menu then
    mod.log:warn("dynamax: Gimmick Menu is not loaded; Dynamax menu entry disabled")
    return
  end

  local GimmickMenu = menu.exports
  GimmickMenu.register({
    id = "DYNAMAX",
    name = "Dynamax",
    label = "DYNAMAX",
    priority = 100,

    canActivate = function(battle, battler, state)
      -- Dynamax owns this policy. Change it to allow combinations.
      if state.activated.MEGA or state.activated.TERA then
        return false, "another transformation is active"
      end
      return Dynamax.canUse(battle, battler)
    end,

    activate = function(battle, battler)
      -- Return true only after Dynamax has actually started.
      return Dynamax.begin(battle, battler) == true
    end,
  })
end
