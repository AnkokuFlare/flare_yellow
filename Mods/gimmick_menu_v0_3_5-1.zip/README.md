# Gimmick Menu Ring

Gimmick Menu is a generic, registration-based ribbon for the wide battle
layout. It does not contain Dynamax, Mega, Tera, Z-Move, or exclusivity
rules. A mechanic mod registers itself, decides when it is available, and
performs its own activation.

In the wide layout, press UP from the top row of the move grid to open the
ribbon. LEFT/RIGHT select a registered gimmick; DOWN or B closes it.

In the classic layout, press RIGHT in the move list to replace it with the
gimmick list. LEFT returns to normal moves. RIGHT advances through entries;
RIGHT on the final entry returns to normal moves. A invokes the selected
gimmick only when its `canActivate` callback returns `true`.

The ribbon shows up to four registered gimmicks, sorted by ascending
`priority` (then ID). Unavailable gimmicks are drawn grey. Register at most
four mechanics until the UI is expanded.

**MODERN UI** (default off) redraws the same ribbon and list as a rounded,
color-coded panel instead of the classic bordered box and glyph cursor. It
applies to both layouts and only changes this mod's own draw call -- no
other menu, mod, or gen1_modern_ui option is affected. Colors are a static
palette loosely matched to gen1_modern_ui's default theme; gen1_modern_ui
does not currently export the player's live theme/scale choice, so this
does not track it.

## gen1_modern_ui compatibility

gen1_modern_ui's experimental battle presenter (its **BATTLE UI (WIP)**
option, off by default) can fully replace the classic battle canvas once its
**HIDE ORIGINAL UI** option also clears it. When both are on at once, this
mod backs off entirely for that frame: it stops drawing the ring/list and
stops intercepting UP/LEFT/RIGHT/DOWN in move selection, instead of leaving
an invisible menu that still eats directional input. Detection is a
best-effort read of gen1_modern_ui's options through `mod.find`; if that
mod is not installed, or a future version doesn't expose those option keys
the same way, this falls back to "no conflict" and behaves exactly as
before.

## Public API

Obtain the API from another gen1recomp mod:

```lua
local menuMod = mod.find("gimmick_menu")
local GimmickMenu = menuMod and menuMod.exports
if not GimmickMenu then return end
```

### Register a mechanic

```lua
GimmickMenu.register({
  id = "DYNAMAX",       -- unique, stable identifier
  name = "Dynamax",
  label = "DYNAMAX",    -- keep short; it is drawn in the ribbon
  priority = 100,        -- lower numbers appear first

  canActivate = function(battle, battler, state)
    -- This is called for drawing and again immediately before activation.
    -- Return false, optionalReason to grey out the entry.
    if state.activated.MEGA then return false, "Mega already used" end
    return canDynamax(battle, battler)
  end,

  activate = function(battle, battler, state)
    -- Do the transformation. Return true only after it succeeded.
    startDynamax(battle, battler)
    return true
  end,
})
```

After an `activate` callback returns `true`, the menu marks that ID active
for that battle and broadcasts an activation event. Return `"pending"` when
your mechanic must prepare now but will call `markActivated` later. The menu never prevents
multiple gimmicks; every mechanic chooses its own compatibility policy by
examining `state.activated`.

### State and callbacks

```lua
-- state is { focus = string|nil, activated = { [id] = true, ... } }
local state = GimmickMenu.getBattleState(battle)
local usedMega = GimmickMenu.isActivated(battle, "MEGA")

GimmickMenu.onActivated(function(id, battle, battler, state)
  -- react to a successfully activated gimmick
end)

GimmickMenu.onFocusChanged(function(id, battle, battler, state)
  -- id is nil when the player closes the ribbon
end)
```

For an asynchronous mechanic, call
`GimmickMenu.markActivated(battle, "DYNAMAX", battler)` yourself after the
animation completes. It returns `true` only the first time and emits the
same activation callback. In that case, have `activate` return `false` so
the menu does not mark it immediately.

`unregister(id)` removes a mechanic. `getRegistered()` returns the current
priority-sorted definitions.

## Dynamax integration template

The supplied `Dynamax.zip` is an RPG Maker Ruby plugin, not a gen1recomp
Lua mod, so it cannot be loaded by this project directly. A gen1recomp
Dynamax port should register with the API like this:

```lua
local menuMod = mod.find("gimmick_menu")
if menuMod then
  local GimmickMenu = menuMod.exports
  GimmickMenu.register({
    id = "DYNAMAX",
    label = "DYNAMAX",
    priority = 100,
    canActivate = function(battle, battler, state)
      if state.activated.MEGA or state.activated.TERA then
        return false, "incompatible gimmick"
      end
      return Dynamax.canUse(battle, battler)
    end,
    activate = function(battle, battler)
      return Dynamax.begin(battle, battler) == true
    end,
  })
end
```

## Engine note

The menu wraps `BattleState:update` because the current public API has no
move-menu input hook. This is why `engine_internals` remains in the manifest.
