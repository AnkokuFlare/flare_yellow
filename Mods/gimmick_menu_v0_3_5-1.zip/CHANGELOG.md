# Changelog

## 0.3.5

- **Added**: gen1_modern_ui compatibility. When gen1_modern_ui's
  experimental battle presenter is active (BATTLE UI (WIP) + HIDE ORIGINAL
  UI both on), this mod now backs off entirely for that frame -- no draw,
  no input interception -- instead of leaving an invisible ring that still
  swallowed move-selection input. Best-effort detection via `mod.find`;
  falls back to current behavior if gen1_modern_ui isn't installed or
  doesn't expose those options.
- **Changed**: MODERN UI label color is now `#FFD700` (mild yellow).
- **Added**: MODERN UI mod option (default off). Draws the ring (wide
  layout) and list (classic layout) as a rounded, color-coded panel
  instead of the classic bordered box and glyph cursor. Restyles only
  this mod's own draw call -- no other option, menu, or mod is touched.
- **Changed**: under MODERN UI, every option now sits on its own solid
  slot color at rest (enabled/disabled tints), not just a plain label
  over the shared panel; focus/hover replaces the slot color with the
  selected highlight.

## 0.3.4

- **Changed**: classic layout controls, made symmetric. LEFT or RIGHT
  (either one) now opens the gimmick list from the move menu, and the
  same pair closes it again -- entering and exiting are no longer tied
  to a specific key. UP/DOWN now cycle through the list once open,
  wrapping at both ends, replacing LEFT/RIGHT's old cycling role there.

## 0.3.3

- **Fixed**: UP in the classic move list no longer opens the gimmick list.

## 0.3.2

- **Added**: classic-layout access. RIGHT opens the gimmick list from the
  move menu; LEFT returns to moves; RIGHT cycles entries and returns to
  moves after the final entry.

## 0.3.1

- **Added**: `activate` callbacks may return `"pending"` when a mechanic
  prepares an action now and will call `markActivated` later.

## 0.3.0

- **Changed**: removed the hardcoded DYNAMAX/MEGA/TERA/Z-MOVE list and
  the single `engaged` flag.
- **Added**: public registration API: `register`, `unregister`,
  `getRegistered`, `getBattleState`, `isActivated`, `markActivated`,
  `onActivated`, and `onFocusChanged`.
- **Added**: per-battle activated-gimmick state. Each mechanic now owns
  its own compatibility rule through `canActivate`.
- **Added**: disabled registered mechanics render grey and cannot be
  activated.

## 0.2.1

- **Fixed**: the ribbon background used `Font.drawBox`, a bordered
  dialog-window primitive built for boxes at least a couple tiles
  tall. At the ribbon's 1-tile height its top and bottom border rows
  land on the same pixel row and stack on each other, drawing a line
  straight through the text. Replaced with a plain rectangle fill.

## 0.2.0

- **Deprecated**: LEFT, RIGHT and DOWN as ways to open the ring from the
  grid. UP at the top row is now the only opener, and it always opens
  on DYNAMAX.
- **Added**: LEFT/RIGHT now cycle through the ring's four items once
  it's open, wrapping at both ends.
- **Changed**: DOWN (still alongside B) now closes the ring from any
  item, not just the item's own "opposite" direction.

## 0.1.0

- Initial version: DYNAMAX/MEGA/TERA/Z-MOVE ring around the wide-layout
  move grid, reached by pressing a direction at the grid's own edge.
- A arms the focused gimmick (one at a time); the opposite direction or
  B returns to the grid without disarming it.
- GIMMICK RING on/off mod option, default on.
- `exports.engaged(battle)` for other mods to react to the armed
  gimmick.
