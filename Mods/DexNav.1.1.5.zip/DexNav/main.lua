return function(mod)
  -- =====================================================================
  -- DexNav Grid UI Mod (High-Resolution Floating Panel & Full Color Icons)
  -- =====================================================================

  mod.options:define({
    { key = "modernUiStyle", label = "MODERN UI STYLE", type = "toggle", default = true, description = "Enable the Modern UI aesthetic for the DexNav (requires Gen1 Modern UI mod to be active)." }
  })

  local Font = require("src.render.Font")
  local Strings = require("src.core.Strings")
  local TextBox = require("src.render.TextBox")
  
  local Assets = require("src.render.Assets")
  local Sprites = require("src.pokemon.Sprites")
  local PartyMenu = require("src.ui.PartyMenu")
  local Map = require("src.world.Map")
  local BattleState = require("src.battle.BattleState")
  local Menu = require("src.ui.Menu")
  local Collision = require("src.world.Collision")

  -- ---------------------------------------------------------------------
  -- PART 1: Icon Rendering Helper Functions
  -- ---------------------------------------------------------------------
  local iconCache = {}
  local modernFonts = {}

  local function getObpIcon(path)
    if not (love.image and love.image.newImageData) then
      return love.graphics.newImage(Assets.resolve(path))
    end
    local id = Assets.imageData(path)
    
    id:mapPixel(function(_, _, r, g, b, a)
      local luma = 0.299 * r + 0.587 * g + 0.114 * b
      local v = 0
      if luma > 0.8 then v = 1
      elseif luma > 0.5 then v = 170 / 255
      elseif luma > 0.2 then v = 85 / 255
      else v = 0 end
      return v, v, v, a
    end)
    return love.graphics.newImage(id)
  end

  local function isTrueColorIcon(game, species)
    local ok, PartyMenuCheck = pcall(require, "src.ui.PartyMenu")
    if ok and PartyMenuCheck and PartyMenuCheck._uniqueMenuIconsTrueColorWrapped then
      return true
    end
    return false
  end

  local function getIconPath(game, species)
    local icons = game.data.icons
    if not icons then return nil, nil end
    local def = game.data.pokemon[species]
    local entry = (icons.bySpecies and icons.bySpecies[species]) or (def and def.icon)
    local name, path
    if type(entry) == "string" then
      name = entry; path = icons.icons and icons.icons[entry]
    elseif type(entry) == "table" then
      path = entry.image
    end
    if not path then
      name = def and def.dex and icons.byDex and icons.byDex[def.dex]
      path = name and icons.icons and icons.icons[name]
    end
    return Sprites.iconPath(game.data, {species=species}, path, { name = name }), name
  end

  local function getHighResIconData(game, species)
      if species == "BALL" then
          local icons = game.data.icons
          local ballPath = icons and icons.icons and (icons.icons["BALL"] or icons.icons["ball"])
          if not ballPath then return nil end
          local key = ballPath .. "#raw"
          if iconCache[key] == nil then
              local ok, img = pcall(love.graphics.newImage, Assets.resolve(ballPath))
              iconCache[key] = ok and img or false
          end
          return iconCache[key], true 
      end

      local iconPath, iconName = getIconPath(game, species)
      if not iconPath then return nil end
      
      -- Smart True Color Detection!
      local trueColor = false
      if type(iconPath) == "string" and (iconPath:find("icons_color") or iconPath:find("icons_gbc_red")) then
          trueColor = true
      end
      
      local key = trueColor and (iconPath .. "#raw") or (iconName and (iconPath .. "#obp") or iconPath)
      
      if iconCache[key] == nil then
         local ok, img
         if trueColor then
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         elseif iconName then
             ok, img = pcall(getObpIcon, iconPath)
         else
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         end
         iconCache[key] = ok and img or false
      end
      return iconCache[key], trueColor
  end

  -- =====================================================================
  -- 3D VOXEL FIX: Pre-colors grayscale pixels for the 3D overworld engine!
  -- =====================================================================
  local function getPrecoloredIcon(game, species)
      local iconPath, iconName = getIconPath(game, species)
      if not iconPath then return nil end

      local trueColor = false
      if type(iconPath) == "string" and (iconPath:find("icons_color") or iconPath:find("icons_gbc_red")) then
          trueColor = true
      end

      local key = trueColor and (iconPath .. "#raw") or (iconPath .. "#colored")
      if iconCache[key] == nil then
          if trueColor then
              local ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
              iconCache[key] = (ok and img) or false
          else
              -- Load the raw image data to manipulate the pixels directly
              local ok, id = pcall(love.image.newImageData, Assets.resolve(iconPath))
              if ok and id then
                  local pal = nil
                  local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                  if okFX and PaletteFX and PaletteFX.monPal then
                      pal = PaletteFX.monPal(game.data, species)
                  end
                  if not pal and game.data.palettes then
                      pal = game.data.palettes["CRYSTAL_251_" .. species]
                  end

                  if pal then
                      -- Map the Crystal 251 colors directly into the texture safely
                      id:mapPixel(function(_, _, r, g, b, a)
                          local luma = 0.299 * r + 0.587 * g + 0.114 * b
                          local color = {1, 1, 1}
                          
                          if luma > 0.8 then color = pal[1] or color
                          elseif luma > 0.5 then color = pal[2] or color
                          elseif luma > 0.2 then color = pal[3] or color
                          else color = pal[4] or color end
                          
                          local cr = tonumber(color[1]) or 1
                          local cg = tonumber(color[2]) or 1
                          local cb = tonumber(color[3]) or 1
                          
                          -- Normalize the color math if it uses 0-255 scaling
                          if cr > 1 or cg > 1 or cb > 1 then 
                              cr = cr / 255; cg = cg / 255; cb = cb / 255 
                          end
                          
                          return cr, cg, cb, a
                      end)
                  else
                      -- Fallback mapping if no palette is found
                      id:mapPixel(function(_, _, r, g, b, a)
                          local luma = 0.299 * r + 0.587 * g + 0.114 * b
                          local v = 0
                          if luma > 0.8 then v = 1
                          elseif luma > 0.5 then v = 170 / 255
                          elseif luma > 0.2 then v = 85 / 255
                          else v = 0 end
                          return v, v, v, a
                      end)
                  end
                  local okImg, img = pcall(love.graphics.newImage, id)
                  iconCache[key] = (okImg and img) or false
              else
                  iconCache[key] = false
              end
          end
      end
      
      -- THE CRITICAL FIX: Explicitly convert 'false' to 'nil' so the 3D engine doesn't crash!
      local result = iconCache[key]
      return result ~= false and result or nil
  end

  -- We unified the function signature so it works flawlessly in both DexNav AND PC Box!
  local function drawBoxIconScaled(game, mon, x, y, isSelected, blinkCounter, isSeen, scale, pOpac)
      -- Handle PC Box arguments seamlessly (PC Box doesn't pass 'isSeen')
      if type(isSeen) == "number" then
          pOpac = scale
          scale = isSeen
          isSeen = true
      end
      if isSeen == nil then isSeen = true end

      local img, trueColor = getHighResIconData(game, mon.species)
      if not img then return end
      
      local alt = false
      if isSelected then alt = math.floor(blinkCounter / 16) % 2 == 1 end
      
      local iw, ih = img:getDimensions()
      local _, iconName = getIconPath(game, mon.species)
      
      local jumpY = 0
      if alt and (iconName == "BALL" or iconName == "HELIX") then
          jumpY = 1 * scale
          alt = false
      end

      local frame = ih > 16 and PartyMenu.frameFor(iconName or "GENERIC", alt, ih) or 0
      
      local prevShader = love.graphics.getShader()
      local appliedShader = false

      if isSeen then
          love.graphics.setColor(1, 1, 1, pOpac or 1)
          
          -- FIX 2: Apply the color shader using Crystal 251 palettes!
          if not trueColor and mon.species ~= "BALL" then
              local ok, PaletteFX = pcall(require, "src.render.PaletteFX")
              if ok and PaletteFX then
                  local pal = PaletteFX.monPal and PaletteFX.monPal(game.data, mon.species)
                  -- Fallback for Crystal 251's custom palette registry
                  if not pal and game.data.palettes then
                      pal = game.data.palettes["CRYSTAL_251_" .. mon.species]
                  end
                  if pal then
                      local shader = PaletteFX.shader()
                      if shader then
                          pcall(PaletteFX.sendColors, shader, pal)
                          love.graphics.setShader(shader)
                          appliedShader = true
                      end
                  end
              end
          end
      else
          love.graphics.setShader()
          love.graphics.setColor(0, 0, 0, 0.7 * (pOpac or 1))
      end

      local isMirrored = iconName and PartyMenu.mirrorsIcon(iconName)
      
      if isMirrored then
          local half = love.graphics.newQuad(0, frame * 16, 8, 16, iw, ih)
          love.graphics.draw(img, half, x, y + jumpY, 0, scale, scale)
          love.graphics.draw(img, half, x + 16 * scale, y + jumpY, 0, -scale, scale)
      elseif ih > 16 then
          local quad = love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih)
          love.graphics.draw(img, quad, x, y + jumpY, 0, scale, scale)
      else
          love.graphics.draw(img, x, y + jumpY, 0, scale, scale)
      end

      if appliedShader then love.graphics.setShader(prevShader) end

      if isSeen and (trueColor or appliedShader) then
          local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
          if okFX and PaletteFX and PaletteFX.markTrueColor then
              PaletteFX.markTrueColor(x, y + jumpY, 16 * scale, 16 * scale)
          end
      end
  end

  local function getLargeSprite(game, species)
      if not species then return nil, false end
      local def = game.data.pokemon[species]
      if not def then return nil, false end
      
      local path = def.spriteFront
      local isTrueColor = false
      
      local ok, SpritesReq = pcall(require, "src.pokemon.Sprites")
      if ok and SpritesReq and type(SpritesReq.path) == "function" then
          -- Pass a context table so the sprite hooks can tell us if it's true color!
          local ctx = {kind = "summary", species = species, side = "front"}
          local p = SpritesReq.path(game.data, species, "front", ctx)
          if p then 
              path = p 
              isTrueColor = ctx.trueColor == true
          end
      end
      
      if not path then return nil, false end
      
      local okImg, img = pcall(love.graphics.newImage, Assets.resolve(path))
      if okImg and img then
          img:setFilter("nearest", "nearest")
          return img, isTrueColor
      end
      return nil, false
  end

  -- ---------------------------------------------------------------------
  -- PART 2: Encounter Data & Map Scanner
  -- ---------------------------------------------------------------------
  local function isSpeciesOwned(game, species)
    if not game or not game.save or not game.save.pokedex or not species then return false end
    local ownedTable = game.save.pokedex.owned
    if type(ownedTable) == "table" and ownedTable[species] then return true end
    local def = game.data and game.data.pokemon and game.data.pokemon[species]
    local dexNum = def and (def.dex or def.dexNum or def.number)
    if dexNum and type(ownedTable) == "table" and (ownedTable[dexNum] == true or ownedTable[tostring(dexNum)] == true) then
        return true
    end
    return false
  end

  local function checkMapCapabilities(game, mapId)
    local map = game.overworld and game.overworld.map
    if not map then return false, false end
    local hasGrass, hasWater = false, false
    local cellsX, cellsY = (map.def.width or 0) * 2, (map.def.height or 0) * 2
    for y = 0, cellsY - 1 do
      for x = 0, cellsX - 1 do
        if not hasGrass and map:isGrassCell(x, y) then hasGrass = true end
        if not hasWater and map:isWaterCell(x, y) then hasWater = true end
        if hasGrass and hasWater then break end
      end
      if hasGrass and hasWater then break end
    end
    
    local indoor = game.data.field and game.data.field.indoorEncounters
    local isIndoor = false
    if indoor and map.def.index and map.def.index >= indoor.firstIndoorMap and map.def.tileset ~= indoor.excludedTileset then
      isIndoor = true
    end

    local field = game.data.field or {}
    for _, rodDef in pairs(field.fishing or {}) do
      if type(rodDef) == "table" and rodDef.perMap and field[rodDef.perMap] and field[rodDef.perMap][mapId] then
        hasWater = true break
      end
    end
    return (hasGrass or isIndoor), hasWater
  end

  local function getMapEncounters(game)
    local mapId = game.overworld and game.overworld.map and game.overworld.map.id
    if not mapId then return {} end
    
    local _, canEncounterWater = checkMapCapabilities(game, mapId)
    local uniqueSpecies = {}
    local list = {}

    local function addSlot(species, level, method, rate)
      if species then
        local safeLevel = level or 5
        if not uniqueSpecies[species] then
          local isOwnedFlag = isSpeciesOwned(game, species)
          local entry = { 
            species = species, methods = {}, level = safeLevel, minLevel = safeLevel, maxLevel = safeLevel,
            owned = isOwnedFlag, caught = isOwnedFlag, isOwned = isOwnedFlag, hasCaught = isOwnedFlag
          }
          uniqueSpecies[species] = entry
          table.insert(list, entry)
        end
        uniqueSpecies[species].methods[method] = (uniqueSpecies[species].methods[method] or 0) + (rate or 100)
        
        if safeLevel < uniqueSpecies[species].minLevel then uniqueSpecies[species].minLevel = safeLevel end
        if safeLevel > uniqueSpecies[species].maxLevel then uniqueSpecies[species].maxLevel = safeLevel end
        if safeLevel > uniqueSpecies[species].level then uniqueSpecies[species].level = safeLevel end
      end
    end

    local okEncounter, Encounter = pcall(require, "src.world.Encounter")
    local encDef = game.data.encounters and game.data.encounters[mapId]

    if encDef then
      local globalBuckets = (game.data.constants and game.data.constants.encounterBuckets) or { 51, 102, 141, 166, 191, 216, 229, 242, 253, 256 }

      local function processTerrain(terrainType, method)
        local sourceData = encDef[terrainType]
        if not sourceData then return end
        local slots = sourceData.slots or (type(sourceData[1]) == "table" and sourceData)
        
        if slots and #slots > 0 then
          local activeBuckets = sourceData.buckets or globalBuckets
          for i, slot in ipairs(slots) do
            local species = slot.species
            local level = slot.level or slot.minLevel or 5
            if species then
              local prevB = (i == 1) and 0 or (activeBuckets[i-1] or 0)
              local currB = activeBuckets[i] or 256
              local weight = math.max(1, currB - prevB)
              local ratePct = (weight / 256) * 100
              addSlot(species, level, method, ratePct)
            end
          end
        elseif okEncounter and Encounter then
          local activeBuckets = sourceData.buckets or globalBuckets
          for i = 1, #activeBuckets do
            local prevVal = (i == 1) and 0 or activeBuckets[i-1]
            local weight = activeBuckets[i] - prevVal
            local ratePct = (weight / 256) * 100
            local mockSource = {}
            for k, v in pairs(sourceData) do mockSource[k] = v end
            mockSource.rate = 256 
            local fakeRng = function(min, max) return prevVal end
            local mockDef = { [terrainType] = mockSource }
            local baseRoll = Encounter.roll(mockDef, fakeRng)
            if baseRoll and baseRoll.species then
              addSlot(baseRoll.species, baseRoll.level, method, ratePct)
            end
          end
        end
      end

      -- Explicitly defined tables bypass the map capability gate
      if encDef.grass then processTerrain("grass", "GRASS") end
      if encDef.dungeon then processTerrain("dungeon", "GRASS") end
      if encDef.cave then processTerrain("cave", "GRASS") end
      if encDef.water then processTerrain("water", "SURF") end
      if encDef.surf then processTerrain("surf", "SURF") end
    end

    -- THE FIX: Fishing encounters strictly gated behind water presence
    if canEncounterWater then
      local field = game.data.field or {}
      for rodName, rodDef in pairs(field.fishing or {}) do
        local methodStr = "SUPER" 
        local rNameUpper = string.upper(tostring(rodName))
        if rNameUpper:find("OLD") then methodStr = "OLD" 
        elseif rNameUpper:find("GOOD") then methodStr = "GOOD" end
        
        local function addStatic(slot, defaultRate)
           if slot and slot.species then addSlot(slot.species, slot.level, methodStr, slot.rate or defaultRate or 100) end
        end
        local function addStaticSlots(slots)
           if type(slots) == "table" and #slots > 0 then 
               local defaultR = 100 / #slots
               for _, s in ipairs(slots) do addStatic(s, defaultR) end 
           end
        end

        if rodDef.always then addStatic(rodDef.always, 100) end
        if rodDef.pool then addStaticSlots(rodDef.pool) end
        if rodDef.perMap and field[rodDef.perMap] then
          local mapGroup = field[rodDef.perMap][mapId]
          if mapGroup and type(mapGroup) == "table" then
            local ver = game.version or (game.save and game.save.version) or game.data.version or game.data.gameVersion
            if ver and type(ver) == "string" then
               local vL, vU = string.lower(ver), string.upper(ver)
               local vCaps = vL:gsub("^%l", string.upper)
               mapGroup = mapGroup[vL] or mapGroup[vU] or mapGroup[vCaps] or mapGroup
            end
            if mapGroup.species then addStatic(mapGroup, 100) 
            elseif mapGroup.slots then addStaticSlots(mapGroup.slots)
            else
              local speciesCount = 0
              for _, item in pairs(mapGroup) do
                  if type(item) == "table" and item.species then speciesCount = speciesCount + 1 end
              end
              local splitRate = speciesCount > 0 and (100 / speciesCount) or 100
              for _, item in pairs(mapGroup) do
                if type(item) == "table" then
                  if item.species then addStatic(item, splitRate) 
                  else addStaticSlots(item.slots or item) end
                end
              end
            end
          end
        end
      end
    end

    return list, mapId
  end

  local function getHabitatType(game, species)
    local encs = getMapEncounters(game)
    local hasWater, hasGrass = false, false
    for _, enc in ipairs(encs) do
      if enc.species == species then
        if enc.methods["SURF"] or enc.methods["OLD"] or enc.methods["GOOD"] or enc.methods["SUPER"] then hasWater = true end
        if enc.methods["GRASS"] then hasGrass = true end
        break
      end
    end
    if not hasWater and not hasGrass then hasGrass = true end
    return hasWater, hasGrass
  end

  local function isValidTile(game, map, tx, ty, hasWater, hasGrass)
    local indoor = game.data.field and game.data.field.indoorEncounters
    local isIndoor = indoor and map.def.index and map.def.index >= indoor.firstIndoorMap and map.def.tileset ~= indoor.excludedTileset
    local isWaterTile = map:isWaterCell(tx, ty)
    local isGrassTile = map:isGrassCell(tx, ty)
    if hasWater and not hasGrass then return isWaterTile
    elseif hasGrass and not hasWater then return isGrassTile or (isIndoor and not isWaterTile)
    else return isGrassTile or isWaterTile or (isIndoor and not isWaterTile) end
  end

  -- ---------------------------------------------------------------------
  -- PART 3: Native Target Spawner
  -- ---------------------------------------------------------------------
  local function getPlayerCell(Game)
    local ow = Game.overworld
    if ow and ow.player and ow.player.cellX and ow.player.cellY then return ow.player.cellX, ow.player.cellY end
    return Game.save.x or 0, Game.save.y or 0
  end

  local function safeDespawnDexNavTarget(Game)
    local ow = Game.overworld
    local targetId = Game._dexNavTargetId
    if not targetId or not ow then return end
    if ow.interacting and ow.interacting.id == targetId then ow.interacting = nil end
    if ow.removeRuntimeObject then pcall(function() ow:removeRuntimeObject(targetId, "DexNav") end) end
    Game._dexNavTargetId = nil
    Game._dexNavTargetMapId = nil
  end

  local function spawnDexNavEncounter(Game, species, level)
    local ow = Game.overworld
    if not ow or not ow.map then return end
    
    if Game._dexNavTargetId then safeDespawnDexNavTarget(Game) end
    
    local px, py = getPlayerCell(Game)
    local candidates = {}
    local hasW, hasG = getHabitatType(Game, species)
    
    for dy = -6, 6 do
      for dx = -6, 6 do
        local tx, ty = px + dx, py + dy
        if isValidTile(Game, ow.map, tx, ty, hasW, hasG) and (math.abs(dx) > 1 or math.abs(dy) > 1) then
          local canExistHere = ow.map:isWalkableCell(tx, ty) or ow.map:isWaterCell(tx, ty)
          if canExistHere and not Collision.occupied(ow.entities, tx, ty) then
            table.insert(candidates, {x = tx, y = ty})
          end
        end
      end
    end
    
    if #candidates > 0 then
      local chosen = candidates[math.random(#candidates)]
      local objDef = { sprite = "SPRITE_POKE_BALL", x = chosen.x, y = chosen.y }
      local npcId = ow:addRuntimeObject(ow.map.id, objDef, "DexNav")
      local iconPath, iconName = getIconPath(Game, species)
      
      for _, n in ipairs(ow.npcs) do
        if n.id == npcId then
          n.dexNavSpecies = species
          n.dexNavLevel = level
          n.dexNavHasWater = hasW
          n.dexNavHasGrass = hasG
          
          if iconPath then
            -- We force trueColor to TRUE so the 3D engine doesn't apply weird NPC map palettes!
            n.sprite.def = { image = iconPath, frames = 2, walker = true, trueColor = true }
            
            -- Provide the 3D engine with the texture we manually colorized!
            n.sprite.resolveImage = function()
               return getPrecoloredIcon(Game, species)
            end
          end

          n.draw = function(n_self, camX, camY)
            n_self.animCounter = (n_self.animCounter or 0) + 1
            local bob = (n_self.moving or n_self.marching) and (math.floor((n_self.progress or 0) / 4) % 2 == 0 and 1 or 0) or 0
            drawBoxIconScaled(Game, {species=n_self.dexNavSpecies}, n_self.px - camX, n_self.py - camY - 4 - bob, true, n_self.animCounter, true, 1, 1)
          end
          
          local orig_pose = n.pose
          n.pose = function(self)
            local sprite, pos_x, pos_y = orig_pose(self)
            self.animCounter = (self.animCounter or 0) + 1
            local phase = math.floor(self.animCounter / 20) % 2
            return sprite, pos_x, pos_y, "down", phase, false
          end
          break
        end
      end
      
      Game._dexNavTargetId = npcId
      Game._dexNavTargetMapId = ow.map.id 
      require("src.core.Sound").playCry(Game.data, species)
    else
      require("src.core.Sound").play(Game.data, "Denied")
      Game.stack:push(TextBox.new(Game, Strings("No suitable habitat\nnearby for this!\f")))
    end
  end

  local function startDexNavBattle(Game, ow, targetNpc)
    local species = targetNpc.dexNavSpecies
    local level = targetNpc.dexNavLevel
    
    targetNpc.frozen = true
    if ow.interacting and ow.interacting.id == targetNpc.id then ow.interacting = nil end
    require("src.core.Sound").play(Game.data, "Collision")
    
    local battle = BattleState.newWild(Game, species, level)
    local ghost = Map.ghostBattles(ow.map.def)
    if ghost and not (ghost.unlessItem and Game.save.inventory[ghost.unlessItem]) then battle:makeGhost() end
    if Game.save.safari and Map.inRegion(ow.map.def, "SAFARI", "SAFARI_ZONE") then battle:makeSafari(Game.save.safari) end
    
    battle.onFinish = function(result) 
      pcall(function() safeDespawnDexNavTarget(Game) end)
      if ow.afterBattle then ow:afterBattle(result, battle) end
    end
    ow:pushBattle(battle)
  end

  -- ---------------------------------------------------------------------
  -- PART 4: Custom DexNav Grid Class
  -- ---------------------------------------------------------------------
  local activeDexNav = nil
  local DexNavGrid = {}
  DexNavGrid.__index = DexNavGrid

  function DexNavGrid.new(game, encounterData, mapId)
    local self = setmetatable({}, DexNavGrid)
    self.game = game
    self.boxData = encounterData
    self.mapId = mapId
    self.index = 1
    self.blink = 0
    self.isOpaque = false 
    self.isDexNavGrid = true
    self.subMenuOpen = false
    self.subMenuIndex = 1
    return self
  end

  function DexNavGrid:update(dt)
    activeDexNav = self
    self.blink = (self.blink + 1) % 320
    local input = self.game.input

    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern and self.subMenuOpen then
        if input:wasPressed("b") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            self.subMenuOpen = false
        elseif input:wasPressed("up") then
            self.subMenuIndex = self.subMenuIndex > 1 and self.subMenuIndex - 1 or 4
        elseif input:wasPressed("down") then
            self.subMenuIndex = self.subMenuIndex < 4 and self.subMenuIndex + 1 or 1
        elseif input:wasPressed("a") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            local mon = self.boxData[self.index]
            if self.subMenuIndex == 1 then 
                while self.game.stack:top() and not self.game.stack:top().isOverworld do self.game.stack:pop() end
                activeDexNav = nil
                spawnDexNavEncounter(self.game, mon.species, mon.level)
            elseif self.subMenuIndex == 2 then
                self.game.save.dexNavReg = { species = mon.species, level = mon.level }
                local def = self.game.data.pokemon[mon.species]
                require("src.core.Sound").play(self.game.data, "Save")
                self.subMenuOpen = false
                self.game.stack:pop() 
                self.game.stack:push(TextBox.new(self.game, Strings("%s registered\nto SELECT!\f", def.name)))
            elseif self.subMenuIndex == 3 then
                require("src.ui.Screens").push(self.game, "DexEntryMenu", mon.species)
            elseif self.subMenuIndex == 4 then
                self.subMenuOpen = false
            end
        end
        return 
    end

    if input:wasPressed("b") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      activeDexNav = nil
      self.game.stack:pop()
      return
    end

    if input:wasPressed("start") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      local NamingScreen = require("src.ui.NamingScreen")
      self.game.stack:push(NamingScreen.new(self.game, {
        title = "SEARCH AREA",
        default = "",
        maxLen = 10,
        onDone = function(searchText)
          if not searchText or searchText == "" then return end
          local searchUpper = searchText:upper()
          local found = false
          for i = 1, 20 do
            local mon = self.boxData[i]
            if mon then
               local def = self.game.data.pokemon[mon.species]
               local monName = (def and def.name or mon.species):upper()
               if monName:find(searchUpper) then
                  self.index = i
                  found = true
                  require("src.core.Sound").play(self.game.data, "Save")
                  break
               end
            end
          end
          if not found then
             require("src.core.Sound").play(self.game.data, "Denied")
             self.game.stack:push(TextBox.new(self.game, "That POKéMON isn't\nin this area!\f"))
          end
        end
      }))
      return
    end
    
    if input:wasPressed("a") then
      local mon = self.boxData[self.index]
      local dex = self.game.save.pokedex
      
      if mon and dex and dex.seen[mon.species] then
        require("src.core.Sound").play(self.game.data, "Press_AB")
        if isModern then
            self.subMenuOpen = true
            self.subMenuIndex = 1
        else
            local subMenu = Menu.new(self.game, {
              { label = "SEARCH", onSelect = function()
                  while self.game.stack:top() and not self.game.stack:top().isOverworld do self.game.stack:pop() end
                  activeDexNav = nil
                  spawnDexNavEncounter(self.game, mon.species, mon.level)
              end },
              { label = "REGISTER", onSelect = function()
                  self.game.save.dexNavReg = { species = mon.species, level = mon.level }
                  local def = self.game.data.pokemon[mon.species]
                  require("src.core.Sound").play(self.game.data, "Save")
                  activeDexNav = nil
                  self.game.stack:pop() 
                  self.game.stack:push(TextBox.new(self.game, Strings("%s registered\nto SELECT!\f", def.name)))
              end },
              { label = "DEX", keepOpen = true, onSelect = function()
                  require("src.ui.Screens").push(self.game, "DexEntryMenu", mon.species)
              end },
              { label = "CANCEL" }
            }, { tx = 11, ty = 6, tw = 9, th = 10, noSound = true })
            subMenu.boxData = true 
            self.game.stack:push(subMenu)
        end
      else
        require("src.core.Sound").play(self.game.data, "Collision")
      end
      return
    end

    if input:wasPressed("up") then
      self.index = self.index - 5
      if self.index < 1 then self.index = self.index + 20 end
    elseif input:wasPressed("down") then
      self.index = self.index + 5
      if self.index > 20 then self.index = self.index - 20 end
    elseif input:wasPressed("left") then
      if self.index % 5 == 1 then self.index = self.index + 4 else self.index = self.index - 1 end
    elseif input:wasPressed("right") then
      if self.index % 5 == 0 then self.index = self.index - 4 else self.index = self.index + 1 end
    end
  end

  function DexNavGrid:draw()
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern then
        local target = love.graphics.getCanvas()
        if target then love.graphics.clear(0, 0, 0, 0) end
        return
    end

    local ok, err = pcall(function()
      local cr, cg, cb, ca = love.graphics.getColor()
      love.graphics.setColor(1, 1, 1, 0.40)
      love.graphics.rectangle("fill", 0, 0, 160, 144)
      love.graphics.setColor(cr, cg, cb, ca)
      
      local prev_translucent = Font.__translucent_active
      Font.__translucent_active = true

      Font.drawBox(0, 0, 20, 18)
      local dex = self.game.save.pokedex or {}
      local dexSeen = dex.seen or {}
      local dexOwned = dex.owned or {}

      for i = 1, 20 do
        local col = ((i - 1) % 5)
        local row = math.floor((i - 1) / 5)
        local x = col * 32
        local y = row * 24
        local mon = self.boxData[i]

        if i == self.index then
          love.graphics.setScissor(x, y, 32, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x, y + 16, 32, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x, y + 8, 8, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x + 24, y + 8, 8, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor()
        end

        if mon then
          local def = self.game.data.pokemon[mon.species] or {}
          local dexNum = def.dex
          local isSeen = dexSeen[mon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
          drawBoxIconScaled(self.game, mon, x + 8, y + 4, i == self.index, self.blink, isSeen, 1, 1)
        else
          love.graphics.setColor(0.6, 0.6, 0.6, 1)
          love.graphics.rectangle("fill", x + 12, y + 11, 8, 2)
        end
      end

      local mapName = (self.mapId or "UNKNOWN"):gsub("_", " ")
      if Font.width(mapName) > 144 then
        while string.len(mapName) > 0 and Font.width(mapName .. "...") > 144 do mapName = string.sub(mapName, 1, -2) end
        mapName = mapName .. "..."
      end
      
      local mapNameWidth = Font.width(mapName)
      local mapNameX = math.floor((160 - mapNameWidth) / 2)
      
      love.graphics.setScissor(0, 96, mapNameX - 4, 8)
      Font.drawBox(0, 12, 20, 6)
      love.graphics.setScissor(mapNameX + mapNameWidth + 4, 96, 160, 8)
      Font.drawBox(0, 12, 20, 6)
      love.graphics.setScissor()
      
      local hoveredMon = self.boxData[self.index]
      
      love.graphics.setColor(0, 0, 0, 1)
      Font.draw(mapName, mapNameX, 96)
      
      if hoveredMon then
        local def = self.game.data.pokemon[hoveredMon.species] or {}
        local dexNum = def.dex
        
        local isSeen = dexSeen[hoveredMon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
        local isOwned = hoveredMon.owned or hoveredMon.caught or dexOwned[hoveredMon.species] or (dexNum and (dexOwned[dexNum] or dexOwned[tostring(dexNum)]))

        if isSeen then
          Font.draw(Strings("%s", def.name or hoveredMon.species), 8, 112)
          if isOwned then
            local icons = self.game.data.icons or {}
            local iconDefs = icons.icons or {}
            local ballEntry = iconDefs["BALL"] or iconDefs["ball"]
            local ballPath = type(ballEntry) == "table" and (ballEntry.image or ballEntry.asset or ballEntry.path) or ballEntry
            
            if ballPath and type(ballPath) == "string" then
                local key = ballPath .. "#obp"
                if iconCache[key] == nil then
                    local okIcon, img = pcall(getObpIcon, ballPath)
                    iconCache[key] = okIcon and img or false
                end
                local img = iconCache[key]
                if img then
                    love.graphics.setColor(1, 1, 1, 1)
                    local prevShader = love.graphics.getShader()
                    local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                    if okFX and PaletteFX and PaletteFX.monPal then
                        local pal = PaletteFX.monPal(self.game.data, "VOLTORB")
                        local shader = PaletteFX.shader()
                        if shader and pal then
                            pcall(PaletteFX.sendColors, shader, pal)
                            love.graphics.setShader(shader)
                        end
                    end
                    local iw, ih = img:getDimensions()
                    local frame = ih > 16 and PartyMenu.frameFor("BALL", false, ih) or 0
                    if ih > 16 then love.graphics.draw(img, love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih), 8, 124)
                    else love.graphics.draw(img, 8, 124) end
                    love.graphics.setShader(prevShader)
                    if okFX and PaletteFX and PaletteFX.markTrueColor then
                        PaletteFX.markTrueColor(8, 124, 16, 16)
                    end
                    love.graphics.setColor(0, 0, 0, 1)
                end
            end
          end
        else
          Font.draw(Strings("?????"), 8, 112)
        end

        local m = hoveredMon.methods or {}
        local displayData = {}
        local function formatRate(r)
            local val = math.floor((tonumber(r) or 0) + 0.5)
            if val > 100 then val = 100 end 
            if val == 0 and (tonumber(r) or 0) > 0 then return "<1%" end
            return val .. "%"
        end

        if m["GRASS"] then table.insert(displayData, { method = "Grass", rate = formatRate(m["GRASS"]) }) end
        if m["SURF"]  then table.insert(displayData, { method = "Surf", rate = formatRate(m["SURF"]) }) end
        if m["OLD"]   then table.insert(displayData, { method = "Old", rate = formatRate(m["OLD"]) }) end
        if m["GOOD"]  then table.insert(displayData, { method = "Good", rate = formatRate(m["GOOD"]) }) end
        if m["SUPER"] then table.insert(displayData, { method = "Super", rate = formatRate(m["SUPER"]) }) end

        if #displayData > 0 then
          local currentIndex = 1
          if #displayData > 1 then
            local cycleFrames = 100 
            currentIndex = (math.floor((tonumber(self.blink) or 0) / cycleFrames) % #displayData) + 1
          end
          local activeData = displayData[currentIndex]
          if activeData and activeData.method and activeData.rate then
              Font.draw(activeData.method, 152 - Font.width(activeData.method), 112)
              Font.draw(activeData.rate, 152 - Font.width(activeData.rate), 128)
          end
        end
      else
        Font.draw(Strings("Empty Slot"), 8, 112)
      end
      love.graphics.setColor(1, 1, 1, 1)
      Font.__translucent_active = prev_translucent
    end)
    
    if not ok then
        print("DexNavGrid Draw Error: " .. tostring(err))
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.setScissor()
    end
  end

  mod.content.screens:register("DEXNAV_GRID_VIEW", {
    new = function(game, encounterData, mapId) return DexNavGrid.new(game, encounterData, mapId) end
  })

  -- ---------------------------------------------------------------------
  -- PART 5: PERFECT KERNING TRUE-TYPE RENDER ENGINE & DETAIL PANEL
  -- ---------------------------------------------------------------------
  local function getModernFont(size, opts)
      local doubleSize = size * 2
      local isPixel = opts.pixelFont ~= false
      local key = tostring(doubleSize) .. (isPixel and "_pixel" or "_smooth")
      
      if not modernFonts[key] then
          local f
          if isPixel then
              pcall(function() f = love.graphics.newFont("assets/fonts/plainpixel/PlainPixel-Regular.ttf", doubleSize) end)
              if not f then pcall(function() f = love.graphics.newFont(doubleSize) end) end
              if f then f:setFilter("nearest", "nearest") end
          else
              pcall(function() f = love.graphics.newFont(doubleSize) end)
              if f then f:setFilter("linear", "linear") end
          end
          modernFonts[key] = f or love.graphics.getFont()
      end
      return modernFonts[key]
  end

  local function printScaled(text, x, y, fontObj, colorArray)
      love.graphics.setColor(colorArray[1], colorArray[2], colorArray[3], colorArray[4] or 1)
      love.graphics.setFont(fontObj)
      love.graphics.print(text, math.floor(x), math.floor(y), 0, 0.5, 0.5)
  end

  local function getScaledWidth(text, fontObj) return fontObj:getWidth(text) * 0.5 end
  local function getScaledHeight(fontObj) return fontObj:getHeight() * 0.5 end

  mod.hooks:wrap("render.hud", function(nextFn, ...)
      nextFn(...)
      
      if not activeDexNav then return end
      local game = activeDexNav.game
      if not game or not game.stack then return end
      if game.stack:top() ~= activeDexNav then return end

      local opts = game.save and game.save.options and game.save.options.modOptions and game.save.options.modOptions["gen1_modern_ui"] or {}
      local forceClassic = mod.options:get("modernUiStyle") == false
      local modernMod = mod.find and mod.find("gen1_modern_ui")
      if not modernMod or opts.menuUi == false or forceClassic or type(modernMod.exports) ~= "table" then return end

      local themeId = opts.theme or "gen1_modern_ui:classic_mono"
      local theme = modernMod.exports.themes[themeId] or modernMod.exports.themes["default"]
      if not theme then return end

      local w, h = love.graphics.getWidth(), love.graphics.getHeight()
      local sx, sy, sw, sh = 0, 0, w, h
      if love.window and love.window.getSafeArea then sx, sy, sw, sh = love.window.getSafeArea() end
      
      local uiScale = 1
      local fontScale = 1
      if modernMod.exports.getScaleTokens then
          local tokens = modernMod.exports.getScaleTokens({width = sw, height = sh})
          uiScale = tokens.uiScale or 1
          fontScale = tokens.fontScale or 1
      end
      
      local pOpac = (opts.panelOpacity or 100) / 100
      local fOpac = (opts.foregroundOpacity or 100) / 100
      
      local tC = theme.colors or {}
      local cSurface  = tC.surface or {0.05, 0.05, 0.05, 1}
      local cRaised   = tC.surfaceRaised or {0.15, 0.15, 0.15, 1}
      local cSelected = tC.selected or {0.2, 0.4, 0.8, 1}
      local cBackdrop = tC.backdrop or {0, 0, 0, 0.6}
      
      local function adapt(fg)
          if not fg then return fg end
          local bgLuma = 0.299 * (cSurface[1] or 0) + 0.587 * (cSurface[2] or 0) + 0.114 * (cSurface[3] or 0)
          local fgLuma = 0.299 * (fg[1] or 0) + 0.587 * (fg[2] or 0) + 0.114 * (fg[3] or 0)
          if math.abs(bgLuma - fgLuma) < 0.35 then
              if bgLuma > 0.5 then return {0.15, 0.15, 0.15, (fg[4] or 1) * fOpac}
              else return {0.95, 0.95, 0.95, (fg[4] or 1) * fOpac} end
          end
          return {fg[1], fg[2], fg[3], (fg[4] or 1) * fOpac}
      end

      local cText   = adapt(tC.text or {1, 1, 1, 1})
      local cMuted  = adapt(tC.textMuted or {0.6, 0.6, 0.6, 1})
      local cAccent = adapt(tC.accent or {0.4, 0.6, 1, 1})
      local cDivider = { (tC.divider or {0.5,0.5,0.5})[1], (tC.divider or {0.5,0.5,0.5})[2], (tC.divider or {0.5,0.5,0.5})[3], fOpac }

      local titleFont = getModernFont(math.floor((theme.typography and theme.typography.title or 24) * fontScale), opts)
      local bodyFont = getModernFont(math.floor((theme.typography and theme.typography.body or 17) * fontScale), opts)
      local captionFont = getModernFont(math.floor((theme.typography and theme.typography.caption or 13) * fontScale), opts)

      love.graphics.push("all")
      love.graphics.origin()

      local ok, err = pcall(function()
          love.graphics.setColor(cBackdrop[1], cBackdrop[2], cBackdrop[3], cBackdrop[4] or 1)
          love.graphics.rectangle("fill", 0, 0, w, h)

          local panelW = math.min(sw - 36 * uiScale, 780 * uiScale)
          local panelH = math.min(sh - 36 * uiScale, 620 * uiScale)
          local px = sx + (sw - panelW) / 2
          local py = sy + (sh - panelH) / 2
          local rad = (theme.radii and theme.radii.lg or 22) * uiScale

          love.graphics.setColor(cSurface[1], cSurface[2], cSurface[3], (cSurface[4] or 1) * pOpac)
          love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

          love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
          love.graphics.rectangle("fill", px, py, panelW, 4 * uiScale, rad)
          love.graphics.rectangle("fill", px, py + 4 * uiScale, panelW, 2 * uiScale)

          local mapName = (activeDexNav.mapId or "UNKNOWN"):gsub("_", " ") .. " DEXNAV"
          while string.len(mapName) > 0 and getScaledWidth(mapName, titleFont) > panelW - 36 * uiScale do mapName = string.sub(mapName, 1, -2) end
          printScaled(mapName, px + 18 * uiScale, py + 18 * uiScale, titleFont, cText)

          local headerH = getScaledHeight(titleFont) + 36 * uiScale
          local footerH = getScaledHeight(captionFont) + 26 * uiScale
          local pad = 18 * uiScale
          
          local detailW = math.min(380 * uiScale, panelW * 0.48)
          local gridAvailW = panelW - pad * 3 - detailW
          local gridAvailH = panelH - headerH - footerH - pad
          
          local cols, gridRows = 5, 4
          local cellSize = math.max(1, math.min(gridAvailW / cols, gridAvailH / gridRows))
          local gridW, gridH = cellSize * cols, cellSize * gridRows
          local gx = px + pad
          local gy = py + headerH + (gridAvailH - gridH) / 2
          local cellRad = (theme.radii and theme.radii.sm or 8) * uiScale

          local dex = game.save.pokedex or {}
          local dexSeen = dex.seen or {}
          local dexOwned = dex.owned or {}

          for i = 1, 20 do
              local c, r = (i - 1) % cols, math.floor((i - 1) / cols)
              local cx, cy = gx + c * cellSize, gy + r * cellSize
              local mon = activeDexNav.boxData[i]

              if i == activeDexNav.index then
                  love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
              else
                  love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
              end
              
              love.graphics.rectangle("fill", cx + 2 * uiScale, cy + 2 * uiScale, cellSize - 4 * uiScale, cellSize - 4 * uiScale, cellRad)

              if mon then
                  local def = game.data.pokemon[mon.species] or {}
                  local dexNum = def.dex
                  local isSeen = dexSeen[mon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
                  
                  local maxArtSize = cellSize * 0.68
                  local scale = math.min(maxArtSize / 16, maxArtSize / 16)
                  local qx = cx + (cellSize - 16 * scale) / 2
                  local qy = cy + (cellSize - 16 * scale) / 2
                  
                  drawBoxIconScaled(game, mon, qx, qy, i == activeDexNav.index, activeDexNav.blink, isSeen, scale, pOpac)
              end
          end

          -- ==========================================================
          -- THE ENHANCED DETAIL PANEL
          -- ==========================================================
          local dx = gx + gridW + pad
          local dy = py + headerH
          local dh = panelH - headerH - footerH - pad
          
          love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
          love.graphics.rectangle("fill", dx, dy, detailW, dh, cellRad)
          
          local hoveredMon = activeDexNav.boxData[activeDexNav.index]
          if hoveredMon then
              local def = game.data.pokemon[hoveredMon.species] or {}
              local dexNum = def.dex
              local isSeen = dexSeen[hoveredMon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
              local isOwned = hoveredMon.owned or hoveredMon.caught or dexOwned[hoveredMon.species] or (dexNum and (dexOwned[dexNum] or dexOwned[tostring(dexNum)]))
              local name = isSeen and (def.name or hoveredMon.species) or "?????"

              local spriteImg, isTrueColor = getLargeSprite(game, hoveredMon.species)
              local spriteSize = 110 * uiScale
              local iy = dy + pad

              if spriteImg then
                  -- =====================================================================
                  -- THE REAL ANIMATION FIX:
                  -- Load individual frame files natively from the Crystal Animated mod!
                  -- =====================================================================
                  local okMap, sMap = pcall(require, "mods.crystal_animated_sprites_with_shiny_visuals.species_map")
                  local okData, aData = pcall(require, "mods.crystal_animated_sprites_with_shiny_visuals.animation_data")
                  
                  if okMap and okData and sMap and aData then
                      local dex = sMap[hoveredMon.species]
                      if dex then
                          local isShiny = false
                          if hoveredMon.dvs then
                              local okStats, Stats = pcall(require, "src.pokemon.Stats")
                              if okStats and Stats and Stats.isShiny then isShiny = Stats.isShiny(hoveredMon.dvs) end
                          end
                          
                          local variant = isShiny and "shiny" or "normal"
                          local durations = aData[variant] and aData[variant][tostring(dex)]
                          
                          if durations and #durations > 0 then
                              local totalDuration = 0
                              for _, d in ipairs(durations) do totalDuration = totalDuration + (d > 0 and d or 100) end
                              
                              if totalDuration > 0 then
                                  local elapsed = (love.timer.getTime() * 1000) % totalDuration
                                  local currentFrame = 1
                                  local accum = 0
                                  for i, d in ipairs(durations) do
                                      accum = accum + (d > 0 and d or 100)
                                      if elapsed <= accum then
                                          currentFrame = i
                                          break
                                      end
                                  end
                                  
                                  local framePath = string.format("mods/crystal_animated_sprites_with_shiny_visuals/assets/front/%s/%d/%03d.png", variant, dex, currentFrame)
                                  local okImg, img = pcall(love.graphics.newImage, framePath)
                                  if okImg and img then
                                      img:setFilter("nearest", "nearest")
                                      spriteImg = img
                                      
                                      -- FIX: The Crystal Animated mod provides pre-colored images!
                                      -- We MUST flag them as trueColor so the shader skips them!
                                      isTrueColor = true
                                  end
                              end
                          end
                      end
                  end
                  
                  local iw, ih = spriteImg:getWidth(), spriteImg:getHeight()
                  local scale = math.min(spriteSize / iw, spriteSize / ih)
                  
                  local prevShader = love.graphics.getShader()
                  local appliedShader = false
                  
                  if isSeen then 
                      love.graphics.setColor(1, 1, 1, 1)
                      
                      -- Only apply the monochrome shader if it's a grayscale base game sprite!
                      if not isTrueColor then
                          local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                          if okFX and PaletteFX and PaletteFX.monPal then
                              local pal = PaletteFX.monPal(game.data, hoveredMon.species)
                              if not pal and game.data.palettes then
                                  pal = game.data.palettes["CRYSTAL_251_" .. hoveredMon.species]
                              end
                              if pal then
                                  local shader = PaletteFX.shader()
                                  if shader then
                                      pcall(PaletteFX.sendColors, shader, pal)
                                      love.graphics.setShader(shader)
                                      appliedShader = true
                                  end
                              end
                          end
                      end
                  else 
                      love.graphics.setShader()
                      love.graphics.setColor(0, 0, 0, 0.7) 
                  end

                  local qx = dx + (detailW - iw * scale) / 2
                  local qy = iy + (spriteSize - ih * scale) / 2
                  
                  love.graphics.draw(spriteImg, qx, qy, 0, scale, scale)
                  
                  if appliedShader then love.graphics.setShader(prevShader) end
              end

              local nameY = iy + spriteSize + pad * 0.5
              local nameW = getScaledWidth(name, titleFont)
              
              local bImg = nil
              local icons = game.data.icons or {}
              local iconDefs = icons.icons or {}
              local ballEntry = iconDefs["BALL"] or iconDefs["ball"]
              local ballPath = type(ballEntry) == "table" and (ballEntry.image or ballEntry.asset or ballEntry.path) or ballEntry
              
              if ballPath and type(ballPath) == "string" then
                  local bKey = ballPath .. "#raw"
                  if iconCache[bKey] == nil then
                      local okIcon, lImg = pcall(love.graphics.newImage, Assets.resolve(ballPath))
                      iconCache[bKey] = okIcon and lImg or false
                  end
                  bImg = iconCache[bKey]
              end

              local bSize = getScaledHeight(titleFont) * 0.8
              local bScale = bImg and (bSize / bImg:getHeight()) or 1
              local bWidth = bImg and (bImg:getWidth() * bScale + 8 * uiScale) or 0
              
              local totalW = bWidth + nameW
              local startX = dx + (detailW - totalW) / 2

              if bImg and isSeen then
                  if isOwned then 
                      love.graphics.setColor(1, 1, 1, 1)
                      local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                      if okFX and PaletteFX and PaletteFX.monPal then
                          local pal = PaletteFX.monPal(game.data, "VOLTORB")
                          local shader = PaletteFX.shader()
                          if shader and pal then
                              pcall(PaletteFX.sendColors, shader, pal)
                              love.graphics.setShader(shader)
                          end
                      end
                  else 
                      love.graphics.setShader()
                      love.graphics.setColor(0.1, 0.1, 0.1, 0.9) 
                  end
                  
                  local ballX = startX
                  local ballY = nameY + (getScaledHeight(titleFont) - bSize)/2
                  
                  love.graphics.draw(bImg, ballX, ballY, 0, bScale, bScale)
                  love.graphics.setShader()
              end

              printScaled(name, startX + bWidth, nameY, titleFont, cText)


              local lvlY = nameY + getScaledHeight(titleFont) + 6 * uiScale
              local lvlText = ""
              if isSeen then
                  if hoveredMon.minLevel == hoveredMon.maxLevel then lvlText = "Lv " .. hoveredMon.minLevel
                  else lvlText = "Lv " .. hoveredMon.minLevel .. " - " .. hoveredMon.maxLevel end
              else lvlText = "Lv ?? - ??" end
              
              printScaled(lvlText, dx + (detailW - getScaledWidth(lvlText, bodyFont))/2, lvlY, bodyFont, cMuted)

              local colY = lvlY + getScaledHeight(bodyFont) + pad
              local leftX = dx + pad
              -- Pushed the moves column slightly further right so "Super Rod" has plenty of room
              local rightX = dx + detailW * 0.56 
              
              printScaled("ENCOUNTER", leftX, colY, captionFont, cMuted)
              printScaled("KNOWN MOVES", rightX, colY, captionFont, cMuted)
              
              love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
              love.graphics.rectangle("fill", dx + pad, colY + getScaledHeight(captionFont) + 2 * uiScale, detailW - pad * 2, 1 * uiScale)

              local listY = colY + getScaledHeight(captionFont) + 8 * uiScale

              if isSeen then
                  local m = hoveredMon.methods or {}
                  local displayData = {}
                  local function formatRate(r)
                      local val = math.floor((tonumber(r) or 0) + 0.5)
                      if val > 100 then val = 100 end 
                      if val == 0 and (tonumber(r) or 0) > 0 then return "<1%" end
                      return val .. "%"
                  end

                  if m["GRASS"] then table.insert(displayData, { m = "Grass", r = formatRate(m["GRASS"]) }) end
                  if m["SURF"]  then table.insert(displayData, { m = "Surf", r = formatRate(m["SURF"]) }) end
                  if m["OLD"]   then table.insert(displayData, { m = "Old Rod", r = formatRate(m["OLD"]) }) end
                  if m["GOOD"]  then table.insert(displayData, { m = "Good Rod", r = formatRate(m["GOOD"]) }) end
                  if m["SUPER"] then table.insert(displayData, { m = "Super Rod", r = formatRate(m["SUPER"]) }) end

                  -- Renders all available encounter methods in a neat vertical column
                  if #displayData > 0 then
                     for idx, activeData in ipairs(displayData) do
                         local rowY = listY + (idx - 1) * (getScaledHeight(bodyFont) + 6 * uiScale)
                         if activeData and activeData.m and activeData.r then
                             printScaled(activeData.m, leftX, rowY, bodyFont, cText)
                             local rateX = leftX + getScaledWidth(activeData.m, bodyFont) + 8 * uiScale
                             printScaled(activeData.r, rateX, rowY, bodyFont, cAccent)
                         end
                     end
                  else
                      printScaled("None", leftX, listY, bodyFont, cMuted)
                  end

                  local knownMoves = {}
                  local maxLvl = hoveredMon.maxLevel or 5
                  
                  local okPkmn, Pokemon = pcall(require, "src.pokemon.Pokemon")
                  local generatedNative = false
                  if okPkmn and Pokemon and type(Pokemon.new) == "function" then
                      local dummyOk, dummyMon = pcall(Pokemon.new, game.data, hoveredMon.species, maxLvl)
                      if dummyOk and dummyMon and type(dummyMon.moves) == "table" then
                          for _, mObj in ipairs(dummyMon.moves) do
                              local mId = type(mObj) == "table" and mObj.id or mObj
                              if mId then table.insert(knownMoves, mId) end
                          end
                          generatedNative = true
                      end
                  end
                  
                  if not generatedNative then
                      for _, mList in ipairs({def.moves, def.baseMoves, def.startMoves}) do
                          for _, mData in ipairs(mList or {}) do
                              if type(mData) == "string" then table.insert(knownMoves, mData)
                              elseif type(mData) == "table" and (mData.id or mData.move) then table.insert(knownMoves, mData.id or mData.move) end
                          end
                      end
                      for _, mList in ipairs({def.levelMoves, def.learnset}) do
                          for _, mData in ipairs(mList or {}) do
                              if type(mData) == "table" then
                                  local lvl = tonumber(mData.level) or tonumber(mData[1]) or 1
                                  local mId = mData.id or mData.move or mData[2]
                                  if mId and type(mId) == "string" and lvl <= maxLvl then table.insert(knownMoves, mId) end
                              end
                          end
                      end
                  end
                  
                  local uniqueMoves, seenMoves = {}, {}
                  for _, moveId in ipairs(knownMoves) do
                      if not seenMoves[moveId] then
                          table.insert(uniqueMoves, moveId)
                          seenMoves[moveId] = true
                      end
                  end
                  
                  local finalMoves = {}
                  -- Collects up to 4 known moves to list vertically
                  for i = math.max(1, #uniqueMoves - 3), #uniqueMoves do table.insert(finalMoves, uniqueMoves[i]) end
                  
                  if #finalMoves == 0 then
                      printScaled("None", rightX, listY, bodyFont, cMuted)
                  else
                      -- Renders the moves as a static vertical list, removing the need for a blinking symbol
                      for idx, moveId in ipairs(finalMoves) do
                          local rowY = listY + (idx - 1) * (getScaledHeight(bodyFont) + 6 * uiScale)
                          local moveDef = game.data.moves and game.data.moves[moveId]
                          local mName = moveDef and moveDef.name or moveId
                          mName = mName:gsub("_", " "):upper()
                          printScaled(mName, rightX, rowY, bodyFont, cText)
                      end
                  end
              else
                  printScaled("???", leftX, listY, bodyFont, cMuted)
                  printScaled("???", rightX, listY, bodyFont, cMuted)
              end
          else
              printScaled("Empty Slot", dx + (detailW - getScaledWidth("Empty Slot", bodyFont))/2, dy + dh/2 - getScaledHeight(bodyFont)/2, bodyFont, cMuted)
          end

          love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
          love.graphics.rectangle("fill", px + pad, py + panelH - footerH - 4 * uiScale, panelW - pad * 2, 1 * uiScale)

          printScaled("A: Select   B: Close", px + pad, py + panelH - footerH + 4 * uiScale, captionFont, cMuted)

          if activeDexNav.subMenuOpen then
              love.graphics.setColor(0, 0, 0, 0.4)
              love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

              local menuW = 200 * uiScale
              local menuH = 180 * uiScale
              local mx = px + (panelW - menuW) / 2
              local my = py + (panelH - menuH) / 2
              
              love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
              love.graphics.rectangle("fill", mx, my, menuW, menuH, theme.radii.md * uiScale)
              
              love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
              love.graphics.rectangle("fill", mx, my, menuW, 4 * uiScale, theme.radii.md * uiScale)
              
              local options = {"SEARCH", "REGISTER", "DEX", "CANCEL"}
              for i, opt in ipairs(options) do
                  local optY = my + 16 * uiScale + (i-1) * 36 * uiScale
                  if i == activeDexNav.subMenuIndex then
                      love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
                      love.graphics.rectangle("fill", mx + 8 * uiScale, optY, menuW - 16 * uiScale, 32 * uiScale, theme.radii.sm * uiScale)
                      printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cText)
                  else
                      printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cMuted)
                  end
              end
          end
      end)
      
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.pop()
      
      if not ok then print("DexNav Modern Draw Error: " .. tostring(err)) end
  end)

  -- ---------------------------------------------------------------------
  -- PART 6: Overworld Integration
  -- ---------------------------------------------------------------------
  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then return out end
    return mod.ui.insertBefore(out, "SAVE", {
      label = "DEXNAV",
      onSelect = function()
        local encs, mapId = getMapEncounters(game)
        if #encs == 0 then
          require("src.core.Sound").play(game.data, "Denied")
          game.stack:push(TextBox.new(game, Strings("There are no wild\nPOKéMON here!\f")))
        else
          require("src.core.Sound").play(game.data, "Press_AB")
          mod.ui.push(game, "DEXNAV_GRID_VIEW", encs, mapId)
        end
      end,
    })
  end)

  local okOW, OverworldController = pcall(require, "src.world.OverworldController")
  if okOW and OverworldController then
    local handlers = rawget(OverworldController, "__qolSelectHandlers")
    if not handlers then
      handlers = {}
      local origHandle = OverworldController.handleInput
      OverworldController.handleInput = function(self, ...)
        for _, handler in pairs(OverworldController.__qolSelectHandlers) do
          if handler(self) then return end
        end
        return origHandle(self, ...)
      end
      OverworldController.__qolSelectHandlers = handlers
    end
    
    handlers["dexnav_select"] = function(ow)
      local Game = require("src.core.Game")
      if Game.input:wasPressed("select") and Game.save.dexNavReg then
        if not Game._dexNavTargetId and Game.stack:top() == ow then
          local reg = Game.save.dexNavReg
          local encs = getMapEncounters(Game)
          local isValid = false
          for _, enc in ipairs(encs) do
            if enc.species == reg.species then isValid = true break end
          end
          if isValid then spawnDexNavEncounter(Game, reg.species, reg.level)
          else
            require("src.core.Sound").play(Game.data, "Denied")
            Game.stack:push(TextBox.new(Game, Strings("This POKéMON isn't\nin this area!\f")))
          end
          return true 
        end
      end
      return false
    end

    if not OverworldController.__orig_update_dexnav then OverworldController.__orig_update_dexnav = OverworldController.update end
    OverworldController.update = function(self, dt)
      OverworldController.__orig_update_dexnav(self, dt)
      local Game = require("src.core.Game")
      if Game._dexNavTargetMapId and Game._dexNavTargetMapId ~= self.map.id then
         pcall(function() safeDespawnDexNavTarget(Game) end)
         return
      end
      local targetId = Game._dexNavTargetId
      if targetId then
        local targetNpc
        for _, n in ipairs(self.npcs) do
          if n.id == targetId then targetNpc = n; break end
        end
        if not targetNpc then pcall(function() safeDespawnDexNavTarget(Game) end); return end

        if self.player.bumpFrames and self.player.bumpFrames > 0 then
          local tx, ty = Collision.target(self.player.cellX, self.player.cellY, self.player.facing)
          local npc = self:npcAtCell(tx, ty)
          if npc and npc.id == targetId then
            self.player.bumpFrames = nil 
            if Game.stack:top() == self and not npc.frozen and not self.engaging and not self.runner:isRunning() and not self.transitioning then
              startDexNavBattle(Game, self, npc)
            end
          end
        end

        if not targetNpc.moving and not targetNpc.frozen and not self.transitioning then
          targetNpc.dexNavTimer = (targetNpc.dexNavTimer or 0) + 1
          if targetNpc.dexNavTimer > 80 then
            targetNpc.dexNavTimer = 0
            local dirs = {"up", "down", "left", "right"}
            local d = dirs[math.random(4)]
            local nx, ny = Collision.target(targetNpc.cellX, targetNpc.cellY, d)
            if isValidTile(Game, self.map, nx, ny, targetNpc.dexNavHasWater, targetNpc.dexNavHasGrass) and (self.map:isWalkableCell(nx, ny) or self.map:isWaterCell(nx, ny)) and not Collision.occupied(self.entities, nx, ny, targetNpc) then
              self:scriptMove(targetNpc, d, 1)
            else
              self:marchInPlace(targetNpc)
            end
          end
        end
      end
    end
    
    mod.events:on("world.interacted", function(event)
      local Game = require("src.core.Game")
      if event.kind == "npc" and event.target and event.target.id == Game._dexNavTargetId then
        local ow = Game.overworld
        if ow and Game.stack:top() == ow and not ow.engaging and not ow.runner:isRunning() and not ow.transitioning then
           startDexNavBattle(Game, ow, event.target)
        end
      end
    end)

    if not OverworldController.__orig_afterBattle_dexnav then OverworldController.__orig_afterBattle_dexnav = OverworldController.afterBattle end
    OverworldController.afterBattle = function(self, result, battle)
      local Game = require("src.core.Game")
      if Game._dexNavTargetId then
        if Game.save.defeatedTrainers then Game.save.defeatedTrainers[Game._dexNavTargetId] = nil end
        if Game.save.itemsTaken then Game.save.itemsTaken[Game._dexNavTargetId] = nil end
        pcall(function() safeDespawnDexNavTarget(Game) end)
      end
      if OverworldController.__orig_afterBattle_dexnav then OverworldController.__orig_afterBattle_dexnav(self, result, battle) end
    end
  end
  mod.log:info("DexNav Grid UI Mod: Unique Menu Icons Enabled!")
end