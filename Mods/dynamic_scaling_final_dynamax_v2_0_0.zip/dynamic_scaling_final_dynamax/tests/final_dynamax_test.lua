-- Full integration test: loads Dynamic Scaling, gimmick_menu, dynamax,
-- and this mod together through the real headless loader and drives a
-- real BattleState instance -- confirming the last-slot detection, the
-- notable-trainer classification (real engine data, not a guessed id
-- list), the HP doubling (instant), the moveset -> Max Move conversion
-- (instant), that a faint defers clearing the forced-Dynamax flag
-- rather than clearing it immediately (the shrink sequence owns that),
-- and critically, that trainer.parties is never touched.
--
-- Out of scope here, same as dynamax's own test: the frame-by-frame
-- scale value itself and the DRAMATIC_SHAPE hook. Both live in a
-- module-local table this mod doesn't export, and reading them
-- accurately would mean driving real BattleState:update(dt)/love.graphics
-- calls this headless harness doesn't stub -- verified by hand instead.
--
-- Run from the engine repo root:
--   luajit "mods/dynamic_scaling_final_dynamax/tests/final_dynamax_test.lua"

package.path = "./?.lua;./?/init.lua;" .. package.path
local T = require("tests.modkit")
local Data = T.fixtures.fresh()
local Pokemon = require("src.pokemon.Pokemon")
local SaveData = require("src.core.SaveData")
local BattleState = require("src.battle.BattleState")

-- Fixture trainer data: a few classes covering every case this mod
-- needs to tell apart -- a plain trainer (never notable), a gym leader
-- (badge-granting, via data.scripts.victories, the same real check the
-- engine's own computeMusicKind uses), a rival stage, and Elite Four.
Data.trainers = Data.trainers or {}
Data.trainers.OPP_YOUNGSTER = { id = "OPP_YOUNGSTER", parties = { {
  { species = T.fixtures.ids.species[1], level = 5 },
  { species = T.fixtures.ids.species[2], level = 5 },
} } }
Data.trainers.OPP_BROCK = { id = "OPP_BROCK", parties = { {
  { species = T.fixtures.ids.species[1], level = 12 },
  { species = T.fixtures.ids.species[2], level = 14 },
} } }
Data.trainers.OPP_RIVAL2 = { id = "OPP_RIVAL2", parties = { {
  { species = T.fixtures.ids.species[1], level = 20 },
} } }
Data.trainers.OPP_LANCE = { id = "OPP_LANCE", parties = { {
  { species = T.fixtures.ids.species[1], level = 45 },
  { species = T.fixtures.ids.species[2], level = 47 },
} } }

-- data.scripts.victories is how BattleState:computeMusicKind decides
-- isGymLeader (the "badge" field) -- populating it for OPP_BROCK only,
-- exactly mirroring how the real game data marks its 8 gym leaders.
package.loaded["data.scripts.victories"] = {
  ["OPP_BROCK#1"] = { badge = "BOULDERBADGE" },
}

local run = T.sdk.loadMods(
  { "mods/gimmick_menu", "mods/dynamax", "mods/Dynamic Scaling",
    "mods/dynamic_scaling_final_dynamax" },
  { data = Data })
-- Not asserting #run.errors == 0: dynamax's own MOD_GMAX_ONE_BLOW/
-- MOD_GMAX_RAPID_FLOW (reserved for future species, unrelated to
-- anything under test here) reference DARK/WATER in type_chart, which
-- the ROM-free fixture doesn't carry -- see dynamax's own test for the
-- same accepted gap. loader.exports below is the real evidence
-- everything actually loaded.
local failures = 0
local function check(cond, message)
  if not cond then
    failures = failures + 1
    print("FAIL: " .. message)
  end
end

local dynamaxExports = run.loader.exports.dynamax
check(dynamaxExports ~= nil, "dynamax's entry function ran and exported its API")
check(dynamaxExports and dynamaxExports.computeMaxMoveId ~= nil,
  "...including the new computeMaxMoveId export")
check(run.loader.exports.dynamic_scaling_final_dynamax ~= nil,
  "this mod's own entry function ran too")

local save = SaveData.newGame()
save.party = { Pokemon.new(Data, T.fixtures.ids.species[1], 20) }
save.options = { battleLayout = "wide" }
local game = { data = Data, save = save,
  input = { wasPressed = function() return false end },
  stack = { push = function() end, pop = function() end, top = function() end } }

_G.__DYNAMIC_SCALING = { hard_mode = false, randomize = "off" }

-- Deep-copy the party data before every battle, the only reliable way
-- to prove nothing mutated it: Dynamic Scaling itself temporarily
-- rewrites trainer.parties and restores it, so a plain reference
-- comparison wouldn't tell "restored" and "untouched" apart.
local function snapshotParty(trainerId)
  local party = Data.trainers[trainerId].parties[1]
  local copy = {}
  for i, mon in ipairs(party) do
    copy[i] = { species = mon.species, level = mon.level }
  end
  return copy
end
local function partyUnchanged(trainerId, snapshot)
  local party = Data.trainers[trainerId].parties[1]
  if #party ~= #snapshot then return false end
  for i, mon in ipairs(party) do
    if mon.species ~= snapshot[i].species or mon.level ~= snapshot[i].level then
      return false
    end
  end
  return true
end

-- ===========================================================================
-- Dynamic Scaling not active at all: nothing happens, regardless of trainer
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING = nil
  local snap = snapshotParty("OPP_BROCK")
  local battle = BattleState.newTrainer(game, "OPP_BROCK", 1)
  battle:enter() -- fires battle.started, which this mod listens for
  check(not battle.enemy.__forcedDynamax, "Dynamic Scaling inactive: gym leader's last mon does not dynamax")
  check(battle.enemy.mon.moves[1].id ~= nil
    and not battle.enemy.mon.moves[1].id:match("^MOD_MAX_"),
    "...and its moveset is completely untouched")
  check(partyUnchanged("OPP_BROCK", snap), "...and the trainer's party data is untouched")
  _G.__DYNAMIC_SCALING = { hard_mode = false, randomize = "off" }
end

-- ===========================================================================
-- Normal Mode (hard_mode = false), gym leader: still dynamaxes on the last mon
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING.hard_mode = false
  local snap = snapshotParty("OPP_BROCK")
  local battle = BattleState.newTrainer(game, "OPP_BROCK", 1)
  battle:enter()
  check(not battle.enemy.__forcedDynamax, "Normal Mode: gym leader's FIRST mon (of 2) does not dynamax yet")

  local Runtime = require("src.mods.Runtime")
  local previous = battle.enemy
  battle.enemyIndex = battle.enemyIndex + 1
  battle.enemy = BattleState.makeBattler(battle.data, battle.enemyParty[battle.enemyIndex], false)
  Runtime.emit("battle.battler_switched",
    { battle = battle, side = battle.sides and battle.sides[2], battler = battle.enemy, previous = previous })

  check(battle.enemy.__forcedDynamax == true, "Normal Mode (hard_mode = false): the last mon still dynamaxes")
  check(battle.enemy.mon.hp > 0, "HP is doubled and positive")
  check(partyUnchanged("OPP_BROCK", snap), "...and the trainer's party data is still untouched")
end

-- ===========================================================================
-- Hard mode on, plain trainer: never notable, never dynamaxes
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local battle = BattleState.newTrainer(game, "OPP_YOUNGSTER", 1)
  battle:enter()
  check(not battle.enemy.__forcedDynamax, "a plain trainer's mon never dynamaxes, hard mode or not")
end

-- ===========================================================================
-- Hard mode on, gym leader: NOT on the first mon, IS on the last
-- ===========================================================================

-- Simulates the engine's own next-mon send-out directly (mirrors
-- BattleState.lua's own onFaint -> enemyMonFainted switch exactly) rather
-- than draining onFaint's queued animation through repeated update()
-- calls -- what's under test here is this mod's reaction to the switch,
-- not the engine's own faint-processing pipeline.
local Runtime = require("src.mods.Runtime")
local function sendOutNext(battle)
  local previous = battle.enemy
  battle.enemyIndex = battle.enemyIndex + 1
  battle.enemy = BattleState.makeBattler(battle.data, battle.enemyParty[battle.enemyIndex], false)
  Runtime.emit("battle.battler_switched",
    { battle = battle, side = battle.sides and battle.sides[2], battler = battle.enemy, previous = previous })
end

do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local snap = snapshotParty("OPP_BROCK")
  local battle = BattleState.newTrainer(game, "OPP_BROCK", 1)
  battle:enter()
  check(not battle.enemy.__forcedDynamax, "gym leader's FIRST mon (of 2) does not dynamax")

  -- FIXMON_B (this trainer's 2nd/last slot) defaults to FIX_SCRATCH
  -- (its level1Moves) since no explicit moves are set in the fixture
  -- party def above -- a real, convertible damaging move.
  local originalMoveId = battle.enemy.mon.moves and battle.enemy.mon.moves[1]
    and battle.enemy.mon.moves[1].id
  check(originalMoveId == "FIX_SCRATCH", "sanity check: the last mon's move is FIX_SCRATCH before conversion")

  sendOutNext(battle) -- send out the 2nd (last) mon
  local maxHP = battle.enemy.mon.stats.hp

  check(battle.enemyIndex == 2, "now on the last party slot")
  check(battle.enemy.__forcedDynamax == true, "the gym leader's LAST mon dynamaxes")
  check(maxHP > 0 and battle.enemy.mon.hp > 0, "HP is doubled and positive on the mon that's actually out")
  -- The sprite's actual scale now ramps frame-by-frame through
  -- BattleState:update rather than being a fixed field read here --
  -- see the file header for why that's not asserted numerically in
  -- this headless test.
  check(partyUnchanged("OPP_BROCK", snap),
    "the trainer's party data is STILL untouched after the last mon dynamaxes")

  local convertedId = battle.enemy.mon.moves[1].id
  check(convertedId ~= "FIX_SCRATCH", "the move id actually changed")
  check(convertedId:match("^MOD_MAX_NORMAL_physical_%d+$") ~= nil,
    ("converted to a real Max Move id, not something malformed (got %s)"):format(tostring(convertedId)))
  check(battle.enemy.curMoves[1].id == convertedId,
    "curMoves (what AI move-selection actually reads) has the same converted id")
  local convertedDef = battle.data.moves[convertedId]
  check(convertedDef ~= nil and convertedDef.power ~= nil and convertedDef.power > 0,
    "the converted id resolves to real, usable move data -- not a dangling reference")
end

-- ===========================================================================
-- HP doubling preserves the current HP percentage, not full-heals it
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local battle = BattleState.newTrainer(game, "OPP_LANCE", 1) -- Elite Four, notable
  battle:enter()
  sendOutNext(battle) -- last mon sent out
  check(battle.enemy.__forcedDynamax == true, "Lance (Elite Four) triggers notability too")
end

-- HP doubling preserves the current HP percentage rather than full-healing
do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local battle = BattleState.newTrainer(game, "OPP_BROCK", 1)
  battle:enter()
  sendOutNext(battle)
  local maxHPBefore = battle.enemy.mon.stats.hp
  battle.enemy.__forcedDynamax = nil -- undo, so forceDynamax runs again in this test
  battle.enemy.mon.stats.hp = maxHPBefore
  battle.enemy.mon.hp = math.floor(maxHPBefore * 0.4 + 0.5) -- damaged to 40%
  Runtime.emit("battle.battler_switched",
    { battle = battle, side = battle.sides and battle.sides[2], battler = battle.enemy, previous = nil })
  local newMaxHP = battle.enemy.mon.stats.hp
  local pct = battle.enemy.mon.hp / newMaxHP
  check(pct > 0.35 and pct < 0.45,
    ("doubling preserves the ~40%% HP fraction rather than full-healing (got %.2f)"):format(pct))
end

-- ===========================================================================
-- Rival battles are notable at every stage, not just the final one
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local battle = BattleState.newTrainer(game, "OPP_RIVAL2", 1) -- 1-mon party
  battle:enter()
  check(battle.enemy.__forcedDynamax == true,
    "a rival's only mon dynamaxes immediately -- it's simultaneously first and last")
end

-- ===========================================================================
-- Faint defers clearing the forced-Dynamax flag: the shrink sequence
-- owns that, not the fainted event handler itself
-- ===========================================================================

do
  _G.__DYNAMIC_SCALING.hard_mode = true
  local battle = BattleState.newTrainer(game, "OPP_BROCK", 1)
  battle:enter()
  sendOutNext(battle)
  check(battle.enemy.__forcedDynamax == true, "sanity check: the last mon dynamaxed")

  local Runtime2 = require("src.mods.Runtime")
  local fainted = battle.enemy
  Runtime2.emit("battle.fainted", { battle = battle, battler = fainted })

  check(fainted.__forcedDynamax == true,
    "immediately after fainting, the flag is still set -- the shrink sequence "
    .. "clears it once it finishes playing, not the fainted handler itself")

  -- A second fainted event for the same battler (e.g. a residual-damage
  -- double-fire) must not restart the shrink from scratch or error.
  local ok = pcall(function()
    Runtime2.emit("battle.fainted", { battle = battle, battler = fainted })
  end)
  check(ok, "a repeated fainted event for the same battler doesn't error")
end

if failures == 0 then
  print("final_dynamax_test: all checks passed")
  os.exit(0)
end
print(("final_dynamax_test: %d failure(s)"):format(failures))
os.exit(1)
