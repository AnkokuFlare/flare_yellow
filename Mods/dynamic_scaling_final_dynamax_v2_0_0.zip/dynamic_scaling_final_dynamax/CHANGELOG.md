# Changelog

## 2.0.0

- **Changed**: the sprite no longer snaps to a fixed x1.20 the instant a
  boss dynamaxes. It now grows through the same eased, four-stage
  sequence the Dynamax mod plays for the player, at whatever final size
  and grow duration the player picked in Dynamax's own settings --
  read live off `mod.find("dynamax").options`, not copied or
  hardcoded. HP doubling and the moveset conversion still both happen
  instantly, same as before.
- **Added**: on faint, the same sequence plays in reverse before the
  boss's sprite leaves the field, instead of it just vanishing at
  whatever size it was.
- **Added**: if DRAMATIC_SHAPE is installed, its 3D stadium model for
  the boss's side scales in step with the 2D sprite, the enemy-side
  counterpart to Dynamax's own player-only stadium hook. Added as an
  `optional_dependency`.
- Everything else unchanged: last Pokemon of any rival, gym leader, or
  Elite Four trainer, on the field only, Normal or Hard Mode, never
  touches trainer.parties.

## 1.2.0

- **Changed**: fires in Dynamic Scaling's Normal Mode as well as Hard
  Mode (was Hard Mode only). Now checks only that Dynamic Scaling is
  active (`_G.__DYNAMIC_SCALING ~= nil`), not `hard_mode == true`.

## 1.1.0

- **Added**: the forced final mon's whole moveset now converts to Max
  Moves, via `dynamax`'s new `exports.computeMaxMoveId` (the same
  type/category/power-tier mapping the player-facing mod's own
  activation uses). `dynamax` is now a hard dependency alongside
  `Dynamic_Scaling`.

## 1.0.0

- Initial version: HP doubled, sprite scaled 1.20x, for the last
  Pokemon of any rival, gym leader, or Elite Four trainer, in Dynamic
  Scaling's Hard Mode only. Never touches trainer.parties.
