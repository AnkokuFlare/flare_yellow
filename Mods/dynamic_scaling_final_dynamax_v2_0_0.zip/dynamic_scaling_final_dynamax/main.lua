-- Dynamic Scaling: Final Dynamax
--
-- In Dynamic Scaling, whether Normal or Hard Mode, the last Pokemon of
-- any rival, gym leader, or Elite Four trainer Dynamaxes (doubled HP,
-- bigger sprite, moveset converted to Max Moves) the instant it's sent
-- out. Never touches team composition -- species and level are left
-- entirely to Dynamic Scaling (or vanilla, if Dynamic Scaling's own
-- randomizer/level scaling is off) and whatever the trainer's data
-- already has. This only reacts to whichever Pokemon ends up in that
-- trainer's last party slot, once it's already on the field, by
-- mutating the live battler -- never the trainer's own party data. The
-- moveset conversion is the one exception to "never touches team
-- data": it rewrites move ids on the live mon instance, the same field
-- the Dynamax mod's own player-side activation rewrites, not anything
-- Dynamic Scaling reads or restores.
--
-- The sprite doesn't just snap to its final size. It grows through the
-- same eased, four-stage sequence the Dynamax mod plays for the
-- player, at whatever final size and duration the player picked in
-- Dynamax's own settings (mod.options, read live through
-- mod.find("dynamax")) -- not a fixed size and not an instant cut.
-- Faint plays the same sequence in reverse before the boss's sprite
-- leaves the field, instead of just vanishing dynamaxed. Both also
-- drive DRAMATIC_SHAPE's 3D stadium model in step, the same "compose
-- the scale on top" approach the Dynamax mod's own player-side stadium
-- hook uses -- just for the enemy side, since that hook only ever
-- covers the player's own model.

-- =============================================================================
-- Data: duplicated from the Dynamax mod's own file rather than read
-- from it, since the growth curve's shape (as opposed to the size and
-- duration settings, which ARE read live below) isn't exported and
-- isn't a player-facing setting -- copying it here is what "respect
-- the same curve" means in practice. Keep these in sync with Dynamax's
-- own STAGE_FRACTIONS/RAMP_FRACTION/FPS if that mod ever changes them.
-- =============================================================================

local FPS = 60 -- the engine's fixed step rate; frame counts are seconds * FPS
local STAGE_FRACTIONS = { 0.10, 0.25, 0.45, 1.0 }
local RAMP_FRACTION = 0.65
local SIZE_LEVELS = { 1.2, 2, 3, 4, 5 }
local DURATION_LEVELS = { 1, 2, 3, 4 } -- seconds
local DEFAULT_SIZE = 2
local DEFAULT_DURATION = 1

local function clampLevel(v, levels, default)
  v = tonumber(v)
  if not v then return default end
  local best, bestDiff = default, math.huge
  for _, level in ipairs(levels) do
    local diff = math.abs(level - v)
    if diff < bestDiff then best, bestDiff = level, diff end
  end
  return best
end

local function buildStageScales(finalScale)
  local scales = {}
  for i, fraction in ipairs(STAGE_FRACTIONS) do
    scales[i] = 1.0 + (finalScale - 1.0) * fraction
  end
  return scales
end

local function easeOutCubic(t)
  t = t - 1
  return t * t * t + 1
end

local function growScaleAtFrame(frame, totalFrames, stageScales)
  local quarterFrames = totalFrames / 4
  local quarter = math.min(4, math.floor((frame - 1) / quarterFrames) + 1)
  local localFrame = frame - (quarter - 1) * quarterFrames
  local rampFrames = quarterFrames * RAMP_FRACTION
  local fromScale = quarter == 1 and 1.0 or stageScales[quarter - 1]
  local toScale = stageScales[quarter]
  if localFrame >= rampFrames then return toScale end
  return fromScale + (toScale - fromScale) * easeOutCubic(localFrame / rampFrames)
end

-- =============================================================================
-- Per-battle sequence state -- keyed by the live `battle` table, same
-- pattern Dynamax's own dynaxState uses, kept separate from it since
-- this is a different mod animating a different battler (the enemy,
-- never the player). Hoisted above the stadium hook below, which
-- closes over it directly.
-- =============================================================================
local fdState = {}

-- =============================================================================
-- 3D stadium model scale hook (optional, guarded) -- the enemy-side
-- counterpart to Dynamax's own player-only hook. Same technique, same
-- DRAMATIC_SHAPE 1.6.0 shapes (Stadium.update stashes the in-progress
-- battle; StadiumMon:matrix multiplies self.scale for the matching
-- side only, restoring it right after). Installed lazily and
-- independently of Dynamax's own hook -- DRAMATIC_SHAPE may load
-- before or after either mod, and wrapping is safe either way since
-- each hook only acts on its own side and chains to whatever ran
-- before it.
-- =============================================================================
local fdStadiumHookInstalled = false
local fdStadiumBattleInProgress = nil

local function ensureFdStadiumHook(mod)
  if fdStadiumHookInstalled then return end
  local dramaticShape = mod and mod.find and mod.find("DRAMATIC_SHAPE")
  local V = dramaticShape and dramaticShape.exports and dramaticShape.exports.lib
  if not V then return end
  local ok, err = pcall(function()
    local Stadium = V.require("Stadium")
    local StadiumMon = V.require("StadiumMon")

    local vanillaStadiumUpdate = Stadium.update
    function Stadium.update(dt, battle, groundY)
      fdStadiumBattleInProgress = battle
      local result = vanillaStadiumUpdate(dt, battle, groundY)
      fdStadiumBattleInProgress = nil
      return result
    end

    local vanillaMatrix = StadiumMon.matrix
    function StadiumMon:matrix(x, groundY, z, faceX, faceZ)
      if self.side == "enemy" and fdStadiumBattleInProgress then
        local st = fdState[fdStadiumBattleInProgress]
        local factor = st and st.displayScale
        if factor then
          local prevScale = self.scale
          self.scale = (prevScale or 1) * factor
          local m = vanillaMatrix(self, x, groundY, z, faceX, faceZ)
          self.scale = prevScale
          return m
        end
      end
      return vanillaMatrix(self, x, groundY, z, faceX, faceZ)
    end
  end)
  if ok then
    fdStadiumHookInstalled = true
  elseif mod.log then
    mod.log:warn("dynamic_scaling_final_dynamax: DRAMATIC_SHAPE stadium-model "
      .. "scale hook failed (%s)", tostring(err))
  end
end

-- Single point every write to a battle's forced-Dynamax display scale
-- goes through, so the 2D sprite (read off fdState[battle].displayScale
-- in the drawBattlerPic wrap below) and the 3D model (read off the same
-- field by the wrap above) never drift apart. Also the natural place to
-- lazily install the stadium hook, in case DRAMATIC_SHAPE loads after
-- this mod despite being listed as an optional dependency.
local function setForcedDisplayScale(mod, battle, st, scale)
  st.displayScale = scale
  ensureFdStadiumHook(mod)
end

local function stateFor(battle)
  local st = fdState[battle]
  if not st then
    st = {}
    fdState[battle] = st
  end
  return st
end

return function(mod)
  local BattleState = require("src.battle.BattleState")

  -- The Dynamax mod is a hard dependency (manifest.json), so this should
  -- always resolve -- the pcall/warn is defensive, not expected to fire,
  -- matching how a missing hard dependency is handled elsewhere in this
  -- set of mods rather than assuming it silently can't happen.
  local dynamaxMod = mod.find("dynamax")
  local computeMaxMoveId = dynamaxMod and dynamaxMod.exports
    and dynamaxMod.exports.computeMaxMoveId
  if not computeMaxMoveId then
    mod.log:warn("dynamic_scaling_final_dynamax: dynamax's computeMaxMoveId export "
      .. "is unavailable -- forced Dynamax will double HP and scale the sprite, "
      .. "but the moveset won't convert to Max Moves")
  end

  -- Reads Dynamax's own MAX SIZE INCREASE / GROW ANIMATION LENGTH
  -- settings live off its mod handle (mod.find("dynamax").options),
  -- the same handle shape mod.find already returns elsewhere
  -- (.exports, .log, ...) -- so a size or duration change in Dynamax's
  -- own settings screen is picked up next time a boss dynamaxes,
  -- without this mod keeping its own copy. Falls back to Dynamax's own
  -- x2/1s defaults if the options handle isn't there for any reason.
  local function readDynamaxOptions()
    local sizeMultiplier, growDuration = DEFAULT_SIZE, DEFAULT_DURATION
    local options = dynamaxMod and dynamaxMod.options
    if options and options.get then
      local ok1, v1 = pcall(function() return options:get("sizeMultiplier") end)
      if ok1 then sizeMultiplier = clampLevel(v1, SIZE_LEVELS, DEFAULT_SIZE) end
      local ok2, v2 = pcall(function() return options:get("growDuration") end)
      if ok2 then growDuration = clampLevel(v2, DURATION_LEVELS, DEFAULT_DURATION) end
    else
      mod.log:warn("dynamic_scaling_final_dynamax: could not read dynamax's own "
        .. "size/duration settings -- using its x2/1s defaults")
    end
    return sizeMultiplier, growDuration
  end

  -- ===========================================================================
  -- Trainer classification
  -- ===========================================================================
  -- Rivals and Elite Four are matched by trainer class id (OPP_RIVAL1/2/3
  -- for the three rival encounters, OPP_LORELEI/BRUNO/AGATHA/LANCE for the
  -- Elite Four -- confirmed against this engine's own source, not guessed).
  -- Gym leaders are NOT a hardcoded id list: BattleState:computeMusicKind
  -- already computes self.isGymLeader by checking which trainer classes
  -- grant a badge in data.scripts.victories -- the engine's own canonical
  -- "is this a gym leader" answer, reused here rather than duplicated.
  local ELITE_FOUR = {
    OPP_LORELEI = true, OPP_BRUNO = true, OPP_AGATHA = true, OPP_LANCE = true,
  }

  local function isNotableTrainer(battle)
    if battle.kind ~= "trainer" or not battle.trainer then return false end
    local id = battle.trainer.id
    if type(id) == "string" and id:find("^OPP_RIVAL") then return true end
    if ELITE_FOUR[id] then return true end
    local ok = pcall(function() battle:computeMusicKind() end)
    return ok and battle.isGymLeader == true
  end

  -- ===========================================================================
  -- Scaling active: Dynamic Scaling keeps this on a global table rather
  -- than exporting anything, so that's what gets read here too. Fires
  -- in Normal Mode as well as Hard Mode -- any battle Dynamic Scaling
  -- is running counts, not just hard_mode == true.
  -- ===========================================================================
  local function scalingActive()
    return _G.__DYNAMIC_SCALING ~= nil
  end

  -- ===========================================================================
  -- The effect itself: HP and moveset apply instantly (nothing about a
  -- boss's stats or moves should visually ramp up), the sprite/model
  -- scale ramps over the grow sequence. Nothing here ever reads or
  -- writes trainer.parties.
  -- ===========================================================================

  local function convertMovesToMax(battle, battler)
    if not computeMaxMoveId then return end
    local mon = battler.mon
    if not mon.moves then return end
    for i, mv in ipairs(mon.moves) do
      local maxId = computeMaxMoveId(mv.id, battle.data.moves)
      if maxId then
        mv.id = maxId
        if battler.curMoves and battler.curMoves[i] then
          battler.curMoves[i].id = maxId
        end
      end
    end
  end

  local function forceDynamax(battle, battler)
    if not battler or battler.__forcedDynamax then return end
    local mon = battler.mon
    if not mon or not mon.stats or not mon.stats.hp or mon.stats.hp <= 0 then return end

    local pct = mon.hp / mon.stats.hp
    mon.stats.hp = mon.stats.hp * 2
    mon.hp = math.max(1, math.floor(mon.stats.hp * pct + 0.5))
    battler.shownHP = mon.hp -- the HP bar's own display value, not mon.hp itself

    convertMovesToMax(battle, battler)

    battler.__forcedDynamax = true

    local sizeMultiplier, growDuration = readDynamaxOptions()
    local st = stateFor(battle)
    st.battler = battler
    st.stageScales = buildStageScales(sizeMultiplier)
    st.sequenceFrames = growDuration * FPS
    st.sequence = { kind = "grow", frame = 0 }
    setForcedDisplayScale(mod, battle, st, 1.0)
  end

  local function maybeForceDynamax(battle)
    if not battle or not battle.enemy or not battle.enemyParty then return end
    if battle.enemyIndex ~= #battle.enemyParty then return end -- not their last mon
    if not scalingActive() then return end
    if not isNotableTrainer(battle) then return end
    forceDynamax(battle, battle.enemy)
  end

  -- The trainer's first mon (including the common case of a 1-mon party,
  -- where the first mon already is the last one) is sent out during
  -- battle construction, before any battle.battler_switched event exists
  -- to hook -- battle.started is the only place to catch that case.
  mod.events:on("battle.started", function(ev)
    maybeForceDynamax(ev and ev.battle)
  end)

  -- Every later enemy mon (after a faint) arrives via this event instead.
  -- The same event also fires for the player's own switches, so this
  -- only acts when the switched-in battler is actually the enemy's.
  mod.events:on("battle.battler_switched", function(ev)
    if not ev or not ev.battle or ev.battler ~= ev.battle.enemy then return end
    maybeForceDynamax(ev.battle)
  end)

  -- At faint, play the same sequence in reverse before the sprite
  -- leaves the field, instead of just vanishing at whatever size it was.
  mod.events:on("battle.fainted", function(ev)
    local battle, battler = ev.battle, ev.battler
    if not battle or not battler or battler ~= battle.enemy or not battler.__forcedDynamax then return end
    local st = fdState[battle]
    if not st then return end
    if not st.sequence and st.displayScale == nil then return end -- already cleared
    if st.sequence and st.sequence.kind == "grow" then
      -- Fainted mid grow-in -- only reachable from residual damage before
      -- the boss's own first turn. Nothing meaningfully grown yet to play
      -- a shrink from, so just clear instead of animating from a partial
      -- scale.
      st.sequence, st.displayScale, st.stageScales, st.sequenceFrames = nil, nil, nil, nil
      battler.__forcedDynamax = nil
      st.battler = nil
      return
    end
    if st.sequence and st.sequence.kind == "shrink" then return end -- already shrinking
    st.sequence = { kind = "shrink", frame = 0 }
  end)

  -- Advances the grow/shrink frame counter and, through
  -- setForcedDisplayScale, the 2D and 3D scale together. Never blocks or
  -- delays vanillaUpdate -- unlike Dynamax's own player-side sequence,
  -- there's no menu/turn-selection state to freeze here, so the boss's
  -- send-out and the AI's first move can proceed on the engine's normal
  -- timing while the sprite ramps up alongside it.
  local vanillaUpdate = BattleState.update
  function BattleState:update(dt)
    local st = fdState[self]
    if st and st.sequence then
      local sequence = st.sequence
      sequence.frame = sequence.frame + 1
      local totalFrames = st.sequenceFrames
      if sequence.kind == "shrink" then
        setForcedDisplayScale(mod, self, st, growScaleAtFrame(totalFrames - sequence.frame + 1, totalFrames, st.stageScales))
      else
        setForcedDisplayScale(mod, self, st, growScaleAtFrame(sequence.frame, totalFrames, st.stageScales))
      end
      if sequence.frame >= totalFrames then
        if sequence.kind == "grow" then
          st.sequence = nil
          -- Locks in exactly the size setting's final scale; stays here
          -- until the boss faints, same "hold at max" behavior Dynamax's
          -- own sequence has for the full 3-turn duration.
          setForcedDisplayScale(mod, self, st, st.stageScales[4])
        else
          -- Shrink finished (only reached after a faint): fully clear.
          st.sequence, st.displayScale, st.stageScales, st.sequenceFrames = nil, nil, nil, nil
          if st.battler then st.battler.__forcedDynamax = nil end
          st.battler = nil
        end
      end
    end
    return vanillaUpdate(self, dt)
  end

  -- ===========================================================================
  -- Sprite scaling: the engine already renders every battler pic through
  -- drawBattlerPic, so scaling that real draw (around the pic's own
  -- bottom-centre, so it grows in place rather than drifting off its
  -- battle slot) preserves the battle's palette, clipping, and wide
  -- layout for free, the same technique the player-facing Dynamax mod
  -- uses for the player's own pic. Reads the live, animated scale off
  -- fdState[battle] rather than a fixed per-battler factor, so the
  -- sprite tracks the same grow/shrink curve the update wrap above
  -- advances every frame.
  -- ===========================================================================
  if not BattleState.__forcedDynamaxDrawWrapped then
    BattleState.__forcedDynamaxDrawWrapped = true

    local vanillaDrawBattlerPic = BattleState.drawBattlerPic
    function BattleState:drawBattlerPic(battler, x, y, scale)
      local st = fdState[self]
      local factor = st and battler == self.enemy and st.displayScale
      if factor and battler.sprite then
        local width = battler.sprite:getWidth() * scale
        local height = battler.sprite:getHeight() * scale
        local anchorX, anchorY = x + width / 2, y + height
        love.graphics.push()
        love.graphics.translate(anchorX, anchorY)
        love.graphics.scale(factor, factor)
        love.graphics.translate(-anchorX, -anchorY)
        vanillaDrawBattlerPic(self, battler, x, y, scale)
        love.graphics.pop()
        return
      end
      return vanillaDrawBattlerPic(self, battler, x, y, scale)
    end
  end

  mod.events:on("battle.ended", function(ev)
    fdState[ev.battle] = nil
  end)

  mod.log:info("Dynamic Scaling: Final Dynamax loaded")
end
