# Dynamic Scaling: Final Dynamax

Depends on `Dynamic_Scaling` and `dynamax`, optionally `DRAMATIC_SHAPE`.
In Dynamic Scaling, whether Normal or Hard Mode, the last Pokemon of
any **rival**, **gym leader**, or **Elite Four** trainer Dynamaxes the
instant it's sent out: doubled HP, moveset converted to Max Moves, and
a sprite that grows through the same sequence, at the same final size
and duration, as the player-facing Dynamax mod's own settings.

## Never touches teams

This is the one hard requirement it was built around: it never reads or
writes `trainer.parties`. Species, level, and moves are entirely
Dynamic Scaling's call (or vanilla's, if Dynamic Scaling's randomizer
and level scaling are off) -- this mod only reacts to whichever Pokemon
is already on the field, in a trainer's last party slot, by mutating
stats on the *live battler* once it's out. It composes on top of
whatever Dynamic Scaling already did to that trainer's team, rather
than interacting with team data at all.

## Which trainers count as notable

- **Rival**: any trainer class id starting with `OPP_RIVAL` (covers
  all three rival encounters, including the final one at the Elite
  Four).
- **Elite Four**: `OPP_LORELEI`, `OPP_BRUNO`, `OPP_AGATHA`, `OPP_LANCE`.
- **Gym leader**: not a hardcoded id list. `BattleState:computeMusicKind`
  already computes `self.isGymLeader` by checking which trainer classes
  grant a badge in the game's own victory data -- the engine's own
  canonical "is this a gym leader" answer, reused here rather than
  duplicated with a second, possibly-wrong list.

If any of these id strings don't match your actual imported ROM data,
they're all in one small table (`ELITE_FOUR`) plus the one pattern
match (`^OPP_RIVAL`) near the top of `main.lua` -- easy to correct.

## What "Dynamax" means here

HP doubled and the whole moveset converted to Max Moves -- via
`dynamax`'s own exported `computeMaxMoveId`, the exact same
type/category/power-tier mapping the player-facing mod's own
activation uses, not a second reimplementation of it -- both apply the
instant the boss is sent out. No stat or type changes -- this is a
battler on the field getting tougher and playing differently, not a
different Pokemon.

The sprite doesn't snap to size. It grows through the same eased,
four-stage sequence the Dynamax mod plays for the player -- small
jumps early, the biggest jump last, landing exactly on the chosen
final size -- read live off Dynamax's own MAX SIZE INCREASE and GROW
ANIMATION LENGTH settings (`mod.find("dynamax").options`), so changing
those in Dynamax's settings screen changes the boss too, next time one
dynamaxes. The growth curve itself (the four-stage shape) is copied
from Dynamax's file rather than read from it, since that shape isn't a
player setting or an export -- only the size and duration values are
read live.

On faint, the same sequence plays in reverse before the sprite leaves
the field. If DRAMATIC_SHAPE is installed, its 3D stadium model for
the boss's side scales in step with the 2D sprite throughout -- the
enemy-side counterpart to Dynamax's own player-only stadium hook, same
"compose the scale on top of whatever it already was" technique,
entirely opt-in and a no-op if DRAMATIC_SHAPE isn't present.

One simplification versus Dynamax's own player-side sequence: nothing
here freezes the battle menu or turn resolution while the sprite grows
in. The boss's own send-out delay covers most of the grow duration in
practice; at very long GROW ANIMATION LENGTH settings the AI's first
move could in principle land before the sprite finishes growing. Purely
cosmetic -- HP and the moveset are already fully applied by then.

Whether the trainer AI actually uses Max Moves *well* is a separate
question this mod doesn't answer -- it hands the AI valid, real move
data to choose from the same way it already evaluates any other move;
it doesn't teach the AI anything Max-Move-specific. If the existing AI
picks moves by something like expected damage, a Max Move's real
(non-zero, non-placeholder) power should get evaluated fairly
alongside everything else in its list -- but this mod makes no
promise beyond "the moves are real and selectable."

## How it finds "the last Pokemon"

Listens for `battle.started` (the trainer's first mon -- including the
common case of a 1-mon party, which is simultaneously first and last)
and `battle.battler_switched` (every mon after, once the one before it
faints), and checks `battle.enemyIndex == #battle.enemyParty` each
time. Only applies once, guarded by a flag on the battler itself, so a
lingering reference to the same battler object can't double-apply it.

## Files

- `manifest.json` -- declares `engine_internals` (needed for the sprite
  scaling, which wraps `BattleState:drawBattlerPic` and
  `BattleState:update` directly), `Dynamic_Scaling` and `dynamax` as
  dependencies, `DRAMATIC_SHAPE` as optional
- `CHANGELOG.md` -- version history
- `main.lua` -- everything: the duplicated growth curve, the
  per-battle sequence state, the DRAMATIC_SHAPE stadium hook, trainer
  classification, the HP/moveset effect, the three event listeners,
  the update and draw wraps
- `tests/final_dynamax_test.lua` -- integration test against the real
  engine (loads `Dynamic_Scaling` and this mod together); kept out of
  the packaged mod via `.modkitignore`, same reasoning as every other
  mod in this set

## Co-installing with dynamic_scaling_final_dynamax_standalone

Still not a supported combo. One change from before: this version's
2D scale now lives in per-battle state (`fdState`), not a static
`battler.__forcedDynamaxScale` field, so if both mods are loaded and
this one's `drawBattlerPic` wrap installs first, the standalone mod's
static-field approach won't produce any visible scaling for whichever
battler it applies to. Harmless (no crash, HP/moveset still apply
correctly either way), just not visually correct for both
simultaneously -- pick one mod per install.

## A heads-up about Dynamic Scaling itself

Not this mod's problem to fix, but worth knowing: `modkit validate`
flags Dynamic Scaling's own `main.lua` for an undeclared private
require (`src.battle.BattleState`, with no `engine_internals`
permission in its manifest). It still loads and runs fine -- this is a
polish/packaging gap in Dynamic Scaling, not a functional one.
