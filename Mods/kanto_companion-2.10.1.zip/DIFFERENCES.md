# Known Differences

Kanto Companion Mobile is a UI-layer companion mod. It does not change any
game logic, balance, drop rates, or mechanics — it only adds a
controller/touch-friendly overlay and two screens for managing items and
Pokemon that already exist in the base game.

- **No changes to game rules.** Box capacity (20), party capacity (6), the
  requirement to keep a healthy Pokemon in the party, and item stack limits
  are all read from and enforced against the base game's own limits — never
  loosened or tightened. Bag capacity specifically is read through the
  documented mod registry API (`mod.content.constants:get("bagSize")`), so
  a separately-installed bag-expansion mod (e.g. Bottomless Bag) is
  reflected accurately instead of assumed to be the vanilla 20 — this mod
  still never sets that value itself.
- **No changes to save data shape.** The mod reads the existing save (party,
  bag, boxes, trainer info) and writes through the same move/deposit/
  withdraw/item-transfer operations the game already exposes. It does not
  add new fields to the save.
- **No changes to what's on screen during normal play.** The overlay,
  Items screen, and Party/Boxes screen are all opt-in (off by default,
  toggled by R2/X/Y) and pause the game while open; vanilla screens and
  flow are unaffected when the mod's screens are closed.
- **No new content.** No new species, moves, items, maps, or text.

Disabling the mod restores the vanilla UI exactly — nothing it touches is
persisted outside the reads/writes the base game already performs.
