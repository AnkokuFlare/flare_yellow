return function(mod)
  -- =====================================================================
  -- Kanto In-Game Companion -- draws the same panels as the streaming mod
  -- (Kanto Stream Companion) but INSIDE the game with love.graphics, on top
  -- of the widescreen view. No server / threads / browser: it reads game.save
  -- each frame and draws. Toggle with F8. READ-ONLY.
  --
  -- State lives on a global so F5 hot-reload re-runs this file without
  -- re-wrapping love.draw / game.update / game.keypressed.
  -- =====================================================================

  -- Shows a small "last input -> ..." readout in the bottom-left corner for a
  -- few seconds after any key/gamepad/touch event, so you can see exactly
  -- what Gen1Recomp's built-in touch controls (e.g. the touch Select button)
  -- report on a device with no log access. Toggle from the mod manager
  -- (Options > Kanto Companion) -- no need to edit this file anymore.
  mod.options:define({
    { key = "debug_input_hud", type = "toggle", label = "DEBUG INPUT HUD", default = false },
    -- v63: "TOUCH SCREEN NAV" (16 chars) itself was still riding the
    -- edge of the row -- on direct report, dropped "SCREEN" from both
    -- this and touch_icon_buttons below for real margin instead of
    -- barely fitting.
    { key = "touch_nav_buttons", type = "toggle", label = "TOUCH NAV", default = false },
    -- v61: "TOUCH SCREEN ICON BUTTONS" (25 chars) turned out to be cut
    -- off too -- see the note on overlay_transparency below for the full
    -- story of how v59's assumed 25-char budget was wrong. Shortened to
    -- match TOUCH SCREEN NAV's pattern (v61) -- v63: that pattern itself
    -- was still too tight (see touch_nav_buttons above), shortened again.
    { key = "touch_icon_buttons", type = "toggle", label = "TOUCH ICONS", default = false },
    -- Session 100: manual version of the dimming that already happens
    -- automatically whenever either touch-button option above is on (see
    -- dimOverlay in C.drawOverlay) -- requested directly, since a fully
    -- solid overlay can feel intrusive during normal play even for
    -- players who don't want the touch nav/icon buttons at all. No
    -- native "grey out when X is on" field exists in this framework's
    -- options schema (checked -- the one example of that behavior on
    -- this device, another mod's VOXEL setting, turned out to be a whole
    -- custom subsystem that mod built itself, not something this schema
    -- supports) -- so this is just a third, independent OR term in
    -- dimOverlay instead: redundant-but-harmless whenever a touch option
    -- is already on, since the overlay dims either way.
    -- v59 assumed a ~25-char budget ("TOUCH SCREEN ICON BUTTONS" was
    -- believed to fit, from memory of what hadn't been reported as cut
    -- off -- never actually verified against a screenshot) and shortened
    -- this label to "OVERLAY TRANSPARENCY" (20 chars) on that basis.
    -- v61: WRONG -- a real on-device screenshot showed that label still
    -- cut off, and TOUCH SCREEN ICON BUTTONS was too (proving the v59
    -- assumption false, not just insufficient for this one label). Real
    -- working budget, read directly off what does vs. doesn't fit in
    -- that screenshot: roughly 16-17 characters, about half what v59
    -- assumed -- this engine's generic option-row renderer still has no
    -- truncation/wrapping of its own (confirmed against source, see v59's
    -- note), so it's still a hard character budget, just a much smaller
    -- one than previously believed. Shortened to "DIM OVERLAY" (11
    -- chars, comfortable margin) -- the redundancy this label used to
    -- spell out is still true and still just the OR-term in dimOverlay
    -- below, only documented in the comment now instead of the label.
    { key = "overlay_transparency", type = "toggle", label = "DIM OVERLAY", default = false },
    -- v60: the symmetric counterpart to overlay_transparency above,
    -- requested directly (Seiya's original Discord report): touch nav/
    -- icon buttons being on has always force-dimmed the overlay
    -- unconditionally, with no way to opt back out of that -- this adds
    -- exactly that opt-out. Only cancels the touchButtonsOn term in
    -- dimOverlay's formula (see C.drawOverlay); overlay_transparency and
    -- the dev-only FORCE_DIM_OVERLAY flag both still force a dim
    -- regardless, same as before -- this option only ever makes the
    -- overlay MORE opaque than the touch-buttons-on default, never less.
    -- v61: shortened from "KEEP OVERLAY OPAQUE" (19 chars, also cut off
    -- -- see overlay_transparency's note above) to "KEEP OPAQUE" (11
    -- chars), the natural short counterpart to DIM OVERLAY above.
    { key = "keep_overlay_opaque", type = "toggle", label = "KEEP OPAQUE", default = false },
    -- v75: on direct request -- "adjustable opacity for the touch nav/
    -- icon buttons themselves" (distinct from DIM OVERLAY above, which
    -- controls the whole info-panel overlay, not these two rows of
    -- buttons). Same `type = "choice"` shape DIM OVERLAY briefly used
    -- (see `choices` = {displayLabel, storedValue} pairs, cycled with
    -- Left/Right/A, confirmed against ManagerState:buildOptionRows).
    -- MAX (3) is the CURRENT look, byte-identical to what these buttons
    -- have always drawn at -- picking it changes nothing, same
    -- "top level = today's existing behavior" contract DIM OVERLAY's
    -- levels already established. OFF/LOW/MED make the buttons
    -- progressively MORE opaque/solid than today's fairly faint default
    -- (see TOUCH_BTN_TRANSPARENCY_MUL near C.drawTouchNav for the actual
    -- multiplier applied to each button's existing alpha values) --
    -- the direction this goes (less transparent, not more) matches the
    -- original Discord ask this satisfies: the buttons being too subtle
    -- to see easily, not wanting them to fade out further.
    -- v76 correction, direct report: labeled "TOUCH OPACITY" at first,
    -- but that reads backwards for how these levels actually behave --
    -- MAX is the MOST transparent setting (today's already-faint look)
    -- and OFF is the MOST opaque (fully solid), the opposite of what
    -- "opacity" going up with the level would suggest. Renamed to
    -- "TRANSPARENCY" (key and label both) -- same word DIM OVERLAY
    -- already uses for the identical MAX-is-most-see-through direction.
    -- v77 restructure, direct report: the ORIGINAL always-on look (mul
    -- 1, today's real default) sat at one END of the old 4-level range
    -- (MAX) -- meaning there was no way to go any MORE transparent than
    -- what already existed, only more opaque. Restructured to 5 levels,
    -- MIN..MAX, with the original look now the exact MIDDLE (MED, value
    -- 2, default) -- symmetric on both sides (see
    -- TOUCH_BTN_TRANSPARENCY_MUL near C.drawTouchNav: mul = 4, 2, 1,
    -- 0.5, 0.25 for MIN..MAX, a clean x2-per-step spread each direction
    -- from the untouched center). MIN (0) is the most opaque/solid end
    -- (same intent the old OFF had); MAX (4) is now genuinely MORE
    -- transparent than the buttons have ever looked, not just "the
    -- original" -- new territory the old 4-level range couldn't reach.
    -- Existing stored values from v75/v76 (0-3) will read back as
    -- whatever that same number now means in the new 5-choice layout --
    -- accepted the same way the v75 key rename already was, given this
    -- option is still mid-iteration in the same conversation that keeps
    -- adjusting it.
    { key = "touch_btn_transparency", type = "choice", label = "TOUCH TRANSP", default = 2,
      choices = { { "MIN", 0 }, { "LOW", 1 }, { "MED", 2 }, { "HIGH", 3 }, { "MAX", 4 } } },
    -- Cosmetic: recolor C.drawStickCursor (the Poké Ball-shaped stick/touch
    -- cursor) to a themed ball or a plain color. DEFAULT (0) is the
    -- original hardcoded look, byte-identical to before this option
    -- existed. Ball choices cover the 5 Gen1 ball ids this mod already
    -- tracks elsewhere (see isBallItem's id list) PLUS the 7 Gen2 Apricorn
    -- balls (Fast/Level/Lure/Heavy/Love/Friend/Moon). All 11 balls' colors
    -- are matched against real reference art -- the Gen1 five against this
    -- mod's own imported item/sprite data, the 7 Apricorn balls against
    -- reference images the user supplied directly (2026-08-26), not
    -- guessed. Park Ball was dropped: not in the user's requested list and
    -- no reference art was given for it. Labels kept under the ~16-17 char
    -- budget established above.
    { key = "cursor_color", type = "choice", label = "CURSOR COLOR", default = 0,
      -- Themed ball designs first, plain single-color skins grouped at the
      -- end (2026-08-27, direct request) -- values are unchanged, these are
      -- still C.CURSOR_PALETTES indices, only the on-screen ORDER moved.
      choices = {
        { "DEFAULT", 0 }, { "GREAT", 1 }, { "ULTRA", 2 },
        { "MASTER", 3 }, { "SAFARI", 4 }, { "FAST", 11 },
        { "LEVEL", 12 }, { "LURE", 13 }, { "HEAVY", 14 },
        { "LOVE", 15 }, { "FRIEND", 16 }, { "MOON", 17 },
        { "ROCKET", 21 },
        { "BLUE", 5 }, { "PINK", 6 }, { "GREEN", 7 }, { "PURPLE", 8 },
        { "YELLOW", 9 }, { "ORANGE", 10 },
        { "CYAN", 18 }, { "LIME", 19 }, { "RAINBOW", 20 },
      } },
    -- v2.9.5, Stage 1 of THOR_MODE_DESIGN.md: dual-screen mode for
    -- devices like the Ayn Thor, via the engine's real render.compose /
    -- SecondScreen bridge (confirmed genuine, not a hack -- see the
    -- design doc). This stage is PLUMBING ONLY: prove a pushed canvas
    -- reaches a real second display / the PC companion-window fallback
    -- before any carousel exists. Off by default -- SecondScreen.push
    -- degrades to a safe no-op with this off or with no second display
    -- present either way, but opt-in keeps a stray toggle from doing
    -- anything on a normal single-screen device. Label kept short (9
    -- chars) well inside the ~16-17 char budget this options renderer
    -- has no wrapping for (see overlay_transparency's note above for how
    -- that limit was actually found).
    { key = "thor_mode", type = "toggle", label = "THOR MODE", default = false },
  })
  mod.events:on("mod.options_changed", function(p)
    if p and p.mod == mod.id and p.key == "debug_input_hud" then
      mod.log:info("kanto_companion: debug input HUD %s", p.value and "enabled" or "disabled")
    end
  end)
  local OVERLAY_KEYS = { o = true, f8 = true }   -- toggle the passive overlay
  local ITEMS_KEY    = "i"                         -- Bag <-> PC items screen
  local PARTY_KEY    = "p"                         -- Party <-> PC boxes screen
  local EDIT_MODE_KEY = "f6"   -- LIGHT BUILD, Session 46: toggle overlay customization (edit) mode -- see C.onKeyDown below.
  local PANIC_RESET_KEY = "f9"   -- EMERGENCY, Session 64: force every panel back to default position/scale/collapse and save it, regardless of edit-mode state -- see C.onKeyDown below. Chosen deliberately not to require edit mode to be active or even renderable first, and to avoid f5 (documented elsewhere as the hot-reload key). Real keyboard F9 only, by design -- see the leftstick/L3 comment in PAD_KEYMAP below for why gamepad no longer shares this same unconditional path (Session 65).

  -- Gamepad mapping (Odin 2 Portal built-in controller, standard SDL layout).
  -- Values are LOVE GamepadButton names -> the keyboard key they stand in for,
  -- so they run through the exact same onKeyDown / onScreenKey logic as the
  -- keyboard hotkeys above. L2/R2 aren't here: LOVE reports analog triggers
  -- as axes, not buttons, so they're wired separately (see love.gamepadaxis
  -- near the bottom). R2 (triggerright) doubles as the overlay toggle from
  -- the overworld (replaces the old R1/rightshoulder mapping) and, on the
  -- Items screen, still drives C.onPadTrigger for held-item quantity --
  -- see the gamepadaxis wrapper for how those two stay separate.
  local PAD_KEYMAP = {
    y            = "p",         -- Y: Party / Boxes screen
    x            = "i",         -- X: Items screen
    b            = "escape",    -- B: close whichever screen is open (also exits edit mode -- see C.onKeyDown)
    dpleft       = "left",      -- D-pad left/right: cycle box view (Party screen); cycle selected panel in edit mode
    dpright      = "right",
    -- back (Select) intentionally NOT mapped through here -- see the
    -- "Select / touchpad-click button" comment block below (Session 84).
    -- rightstick (R3) intentionally NOT mapped through here anymore --
    -- proactive change 2026-08-19, direct request: a plain R3 tap used to
    -- fire edit mode immediately via this table, same "any button ->
    -- instant keypress" path every other entry uses. Once mid-battle
    -- editing comes back (gen1recomp issue #1285), that would make R3
    -- collide with any other mod that's also listening for a battle-time
    -- R3 press -- kanto would eat the tap before the other mod ever saw
    -- it. Changed to HOLD ~1s instead (see the leftstick/L3 comment just
    -- below for the same "arm on press, decide on release/poll" shape);
    -- a quick tap is now a complete no-op from kanto's side, left free
    -- for whatever else wants it. See C.padPressed/padReleased/pollPad's
    -- own "R3" comments for the actual hold logic.
    dpup         = "up",        -- D-pad up/down: scale selected panel up/down, edit mode only (otherwise unmapped)
    dpdown       = "down",
    -- v2.9.5: L1/R1 were tried here for alphabet jump-to-letter, then
    -- REVERTED same session on direct report -- confirmed against the
    -- real engine source (both src/core/Game.lua:757-762 AND
    -- Game2.lua:1974-1980) that leftshoulder/rightshoulder AND
    -- lefttrigger/righttrigger unconditionally cycle vanilla GAME SPEED,
    -- with no state-stack gating of any kind (Game:gamepadpressed returns
    -- immediately from that branch, regardless of what's on top of
    -- self.stack). That's a real, un-blockable collision, not a
    -- hypothetical one: the sandbox's polling-based input model can only
    -- ever be one of potentially several independent readers of the same
    -- raw button, never a consumer that can suppress another handler (see
    -- C.editOpen's own comment on why R3 couldn't just consume input
    -- either, same underlying limitation) -- so this was never fixable by
    -- gating on C.screen, only by moving off L1/R1 entirely. See
    -- C.padPressed's leftstick/rightstick handling instead: L1/R2 are
    -- also caught by this same vanilla speed binding (rightshoulder OR
    -- righttrigger, leftshoulder OR lefttrigger, per the engine source),
    -- meaning kanto's own pre-existing L2/R2 quantity-adjust/bulk-scale
    -- bindings have almost certainly always collided with it too -- not
    -- something this pass touches (out of the scope of what was
    -- reported), but worth knowing if it ever comes up.
    -- leftstick (L3) intentionally NOT mapped through here anymore.
    -- Session 64 wired it to PANIC_RESET_KEY via this table, same as any
    -- other button -- but that meant it went through the same
    -- unconditional-by-design onKeyDown path as real keyboard F9, so L3
    -- fired the panic reset any time, in any state, including plain
    -- overworld/battle play, not just when actually stuck. An accidental
    -- stick-click during normal play is far more likely than an
    -- accidental F9 keypress. Session 65: handled directly in
    -- love.gamepadpressed instead (see doPanicReset's call site there),
    -- gated on C.overlayEdit.active, so L3 only resets while edit mode
    -- is actually open. Keyboard F9 is unchanged and still works
    -- unconditionally as the real "something's stuck and edit mode
    -- itself won't even open" escape hatch.
  }
  -- Select / touchpad-click button, Gen1Recomp's Tab/Shift keys, and a
  -- touch hot-zone over the hardware Select button used to all trigger this
  -- same screen-cycle too (overlay -> items -> party -> closed). That's been
  -- removed -- the cycle is now driven only by the two on-screen touch-nav
  -- buttons below (TOUCH_NAV_LEFT/RIGHT) and C.onPadCycle.
  --
  -- Session 84 bugfix: gamepad Select (back) got a SECOND thing bound to
  -- it after that removal -- PARTY_STYLE_KEY, a "TEMP TESTING" manual
  -- toggle for the overlay's party density (A/full <-> B/compact),
  -- explicitly labeled as temporary in its own comment. On direct report
  -- (Select not working for *anything* gamepad-side, discovered via
  -- another mod's Select-triggered item-favorite feature not firing) this
  -- turned out to be the actual cause: love.gamepadpressed's own PAD_KEYMAP
  -- lookup (further below) ALWAYS consumes any button with an entry there
  -- -- calling c.onScreenKey(key) unconditionally and returning when a
  -- screen is open (even though onScreenKey never had an "f7" case at
  -- all -- a pure no-op swallow), or onKeyDown(nil,"f7") from the
  -- overworld, which DID match and returned true. Either way, gamepad
  -- Select never reached C.origGamepadpressed -- the real engine (or any
  -- other mod's own Select handling) -- confirmed this matches the
  -- unresolved "Select/touchpad button unresponsive for some controller
  -- users" report from the Discord bug list. Removed outright, not
  -- rebound elsewhere: it was only ever a dev preview toggle, and the
  -- overlay's real collapse mechanism (see levelOf()/setLevel() near
  -- clamp01Scale) now covers that job on Trainer specifically anyway. Real
  -- keyboard F7 press-through is unaffected either way -- it was never
  -- the thing being swallowed (see onKeyDown's own `not c.screen` gate,
  -- which already let keyboard keys pass through untouched whenever a
  -- screen is open; only the gamepad path lacked that same gate).
  -- Party's automatic shrink-to-compact fallback (when a full party
  -- doesn't fit -- see the LEFT/party comment further down) is untouched;
  -- only the manual F7 toggle key is gone. (Session 88: party later grew
  -- a real manual compact control again, through the collapse cycle
  -- instead of a dedicated key -- see SUPPORTS_COMPACT near clamp01Scale.)
  -- Two custom-drawn on-screen buttons (left/right arrows) that step through
  -- the same overlay -> items -> party -> closed cycle Select used to, but
  -- forward OR backward and via touch anywhere on screen -- no reliance on
  -- Gen1Recomp's built-in touch Select ever firing an event we can see. Off
  -- by default; enable via mod options ("TOUCH SCREEN NAV BUTTONS"). Defined
  -- as percent-of-window rectangles so position holds across screen sizes.
  -- These are drawn buttons (see C.drawTouchNav below), so the touch zone
  -- and the visible box are always the same rectangle -- what you see is
  -- exactly what's tappable. Calibrated from a screenshot at 1920x1080:
  -- the Select ("-") and Start ("+") circles centered at roughly x=895 and
  -- x=1023 (y~930) on that device -- these boxes sit centered on those same
  -- x's. Originally placed just above that row (y ~687-765px there); nudged
  -- further up (y ~659-737px) to free a bigger gap underneath for the icon
  -- row (TOUCH_ICON_OVERLAY/ITEMS/PARTY below) to use larger buttons.
  -- Because Select and Start are close together and the boxes are narrow
  -- (~100px) to avoid overlapping each other, this centers precisely
  -- rather than just "roughly above" -- but it's still only confirmed
  -- accurate on that one screenshot's layout. If it's off on your device,
  -- tap where Select/Start actually are with the debug input HUD on, read
  -- the touch percentages off the HUD, and recenter x1/x2 on those (and
  -- nudge y1/y2 the same way to re-tune this offset).
  local TOUCH_NAV_LEFT  = { x1 = 0.4401, y1 = 0.6100, x2 = 0.4922, y2 = 0.6820 }  -- left arrow: previous screen (shifted up from directly over Select to clear the icon row below)
  local TOUCH_NAV_RIGHT = { x1 = 0.5068, y1 = 0.6100, x2 = 0.5589, y2 = 0.6820 }  -- right arrow: next screen (shifted up from directly over Start to clear the icon row below)

  -- Three direct-jump touch buttons (overlay / items / party), one per icon,
  -- as an alternative to the two-arrow cycle above -- each just jumps
  -- straight to its own screen instead of stepping through all of them.
  -- Off by default; enable via mod options ("TOUCH SCREEN ICON BUTTONS").
  -- Both this row and the arrow row can be on at once -- they don't overlap.
  --
  -- Round buttons, sitting low -- in the (now taller) gap between the
  -- arrow row above and Select/Start below, in the same lower band of the
  -- screen A/B occupy on the sides. The arrow row above was nudged up from
  -- its original spot directly over Select/Start specifically to make room
  -- here: a bigger gap means a bigger circle fits without crowding either
  -- neighbor, which is why these are noticeably larger than the first pass
  -- at this row. Centered the same way as the arrows (x=0.5), each zone
  -- here is still a rectangle for hit-testing (same convention as
  -- TOUCH_NAV_LEFT/RIGHT above) -- C.drawTouchIcons just draws a circle
  -- inscribed in it rather than a rounded rect, so the visible button and
  -- the tappable area stay the same shape. Sized roughly square in actual
  -- window pixels (width fraction * window width ~= height fraction *
  -- window height) so the inscribed circle isn't squashed into an oval --
  -- that's why the x fraction here is narrower than the y fraction, unlike
  -- the wider-than-tall arrow zones above.
  --
  -- Like TOUCH_NAV_LEFT/RIGHT, this is only confirmed accurate on that one
  -- 1920x1080 screenshot's layout -- the margins above/below this row are
  -- deliberately kept generous (roughly 15px worth on that device) since
  -- it's squeezed between two other elements on both sides, but a
  -- sufficiently different aspect ratio could still tighten that. If it
  -- lands somewhere awkward on your device, enable DEBUG INPUT HUD, tap
  -- around where you'd expect each button, and read the touch percentages
  -- off the HUD to retune x1/x2/y1/y2 below the same way the README
  -- describes for the arrows.
  local TOUCH_ICON_OVERLAY = { x1 = 0.4038, y1 = 0.6970, x2 = 0.4573, y2 = 0.7920 }  -- left: overlay (o / R2)
  local TOUCH_ICON_ITEMS   = { x1 = 0.4733, y1 = 0.6970, x2 = 0.5268, y2 = 0.7920 }  -- center: items (i / X)
  local TOUCH_ICON_PARTY   = { x1 = 0.5428, y1 = 0.6970, x2 = 0.5963, y2 = 0.7920 }  -- right: party/boxes (p / Y)
  -- v72: on direct request -- the touch-nav arrow pair and touch-icon
  -- triple are now draggable as two whole groups (each moves as one
  -- unit, matching "as a set of two and three respectively") during
  -- edit mode. Position-only, deliberately -- no scale/resize, per
  -- direct confirmation. Kept entirely separate from PANEL_KEYS/
  -- panelCfg/drawEditablePanel rather than folded into that system:
  -- these buttons render in raw window-pixel space (zone fraction *
  -- window size), not the design-unit space every real panel uses, and
  -- have no natural height/content/collapse concept for that machinery
  -- to size itself against -- reusing it would mean fighting its
  -- assumptions at every step rather than actually saving work. A small
  -- parallel drag system instead, mirroring updateDrag/endDrag's own
  -- shape (offsetX/Y captured at grab time, touchId ownership, save on
  -- release) -- the same pattern this file already uses for
  -- updatePinch/updateResize being their own siblings rather than
  -- merged into updateDrag itself.
  local TOUCH_GROUP_KEYS = { "touchNav", "touchIcons" }
  -- v72 FIX: the C.touchGroupPos/C.touchGroupDrag init lines that used to
  -- sit right here were a real bug, not a style choice -- `local C =
  -- _G.__KANTO_INGAME or {}` isn't declared until further down this same
  -- function, so indexing `C.` up here hit an undefined GLOBAL `C`
  -- instead (nil), throwing "attempt to index global 'C'" and taking the
  -- whole mod down on load (confirmed on-device via the Mod Manager's own
  -- FAILED screen, main.lua:227). Moved both lines to right after `local
  -- C = _G.__KANTO_INGAME or {}` below, the only point in this function
  -- where indexing C is actually valid. TOUCH_GROUP_KEYS itself stays
  -- here since it's a plain local list with no C dependency.
  local REF_H      = 1440        -- design reference height; everything scales off this
  local INTERVAL   = 0.12        -- seconds between save reads

  -- The overlay's scale (s, below) is normally just window-height / REF_H, which
  -- keeps proportions consistent across resolutions but doesn't account for
  -- physical screen size. On a small high-DPI panel like the Odin 2 Portal's
  -- 7" 1920x1080 display, that math alone still produces cramped, hard-to-read
  -- text and tight spacing. UI_SCALE_OVERLAY is an extra multiplier on top of
  -- that ratio -- since fonts, padding, margins, and panel sizes all route
  -- through the same scale factor, bumping this one number enlarges and
  -- spaces out everything in the overlay together. Raise it further for more
  -- room to breathe, lower it if things start crowding the screen edges.
  local UI_SCALE_OVERLAY = 1.5
  -- TEMP TESTING OVERRIDE: forces the canvas/dim render path on regardless
  -- of the touch button options, so landscape crash testing doesn't require
  -- also toggling buttons each run -- every test goes through the same
  -- canvas-composited path buttons-on normally uses. Set back to false to
  -- restore real behavior (canvas only when a touch button option is on).
  -- RUN B: flipped to false -- this build never creates overlayCanvas at
  -- all (real touch button options should also be left off), so the
  -- overlay draws straight to the screen every frame, same as Kanto
  -- Companion Lite's approach. Paired against the Run A build (this same
  -- flag = true) to isolate whether the canvas path is the crash cause.
  local FORCE_DIM_OVERLAY = false
  -- v75/v76/v77: multiplier per TOUCH TRANSPARENCY level (see the
  -- option's own definition above), applied to every existing alpha
  -- value in C.drawTouchNav/C.drawTouchIcons's default (non-active/
  -- non-gold) chrome -- background fills, borders, resting-state
  -- glyphs. Direction: higher level = more transparent (mul goes DOWN),
  -- same convention DIM OVERLAY already established, and the reason
  -- this option is named TRANSPARENCY, not "opacity."
  --
  -- v77 restructure, direct report: the original always-on look (mul 1,
  -- today's real default alpha values, untouched) used to sit at the
  -- MAX end of a 4-level range -- meaning there was no way to make the
  -- buttons any MORE transparent than they'd always been, only more
  -- opaque. Now 5 levels, MIN..MAX, with the original centered exactly
  -- in the MIDDLE (MED = mul 1, the option's own default) -- a clean
  -- x2-per-step spread symmetric in both directions: MIN (0, mul 4) is
  -- the most opaque/solid end; MAX (4, mul 0.25) is genuinely new
  -- territory, more transparent than these buttons have ever rendered.
  -- Clamped to 1.0 at the call site for the upper (more-opaque) levels,
  -- since different elements start from different base alphas and would
  -- otherwise overshoot at different levels -- the lower (more-
  -- transparent) levels never need clamping, a multiplier under 1 can
  -- only shrink an already-valid alpha, never push it out of range.
  -- The gold "this is the active screen" highlight is deliberately NOT
  -- scaled by this at any level -- it's a state indicator, not part of
  -- "how faint do these buttons look at rest," and staying at full
  -- strength keeps that signal legible regardless of the chosen level.
  local TOUCH_BTN_TRANSPARENCY_MUL = { [0] = 4, [1] = 2, [2] = 1, [3] = 0.5, [4] = 0.25 }

  -- Same idea, applied to the Items and Party/Boxes modal screens (drawScreen
  -- and its input handlers below). Kept as a separate knob from the overlay's
  -- in case the two ever need different values.
  local UI_SCALE_SCREEN = 1.5
  -- Shown as a small on-screen tag (see C.drawBuildTag below) naming
  -- whichever build is actually installed -- update this string every time
  -- a new zip goes out, to match its filename. Controlled by SHOW_BUILD_TAG
  -- below (a plain code constant, not a mod option) rather than tied to
  -- DEBUG INPUT HUD -- that option also drives its own on-screen readout in
  -- the same corner (see battleDiagText), so tying this tag to the same
  -- toggle means they'd always show together and overlap. drawBuildTag
  -- detects that case live and stacks below it instead.
  local BUILD_TAG = "kanto_companion-2_10_1"
  -- v78: OFF for real this time -- public release, per the comment
  -- above that's been saying "flip off again before any public
  -- release" since v57. This debug banner is dev/test-only; a normal
  -- player shouldn't see a build-tag string in the corner of their
  -- screen. Flip back to true if another active dev/test round starts.
  -- Flipped back ON (2026-08-26): new active dev round for the
  -- cursor_color option. Flip off again before any public release.
  -- OFF again (2026-08-27): that dev round is finished -- cursor_color
  -- shipped with 22 skins in the 2.10.1 build. Flip back to true if
  -- another active dev/test round starts.
  local SHOW_BUILD_TAG = false

  local C = _G.__KANTO_INGAME or {}
  _G.__KANTO_INGAME = C
  if C.visible == nil then C.visible = false end   -- off by default; press 'o' to show
  -- v2.9.5 (ported from the shelved v58/v84/v85 route-panel dex-tally):
  -- per-species KO tally backing the Route panel's battled/caught/defeated
  -- indicators. Lives in save.modData[mod.id] -- the engine's own sanctioned
  -- per-save persistence slot (confirmed real: SaveData.lua/Game.lua/
  -- SaveConvert.lua all handle it, RFC 0003-playthrough-storage.md documents
  -- it), serialized alongside save.pokedex automatically. Split into a pure
  -- read (koCountFor, called every frame the Route panel is visible) and a
  -- mutate-on-write (recordKO, only from battle.fainted) so merely having
  -- the panel open never dirties the save. Attached to C (not new top-level
  -- locals) -- this file already hit its 200-local ceiling once tonight
  -- (see the Undo port), so new helpers go straight to C fields rather than
  -- risking it again.
  C.koCountFor = function(save, species)
    local md = save and save.modData and save.modData[mod.id]
    local ko = md and md.ko
    return (ko and ko[species]) or 0
  end
  C.recordKO = function(species)
    local save = C.game and C.game.save
    if not (save and species) then return end
    save.modData = save.modData or {}
    save.modData[mod.id] = save.modData[mod.id] or {}
    local d = save.modData[mod.id]
    d.ko = d.ko or {}
    d.ko[species] = (d.ko[species] or 0) + 1
  end
  -- Fires once per enemy Pokemon actually KO'd, wild or trainer. Confirmed
  -- directly against the real current engine source that battle.fainted is
  -- genuinely Runtime.emit'd on both generations (BattleState.lua:3876 for
  -- Gen 1, gen2/Battle.lua:3005+3066 for Gen 2) -- a real event, not a hook.
  -- Payload shape DIFFERS by generation though (checked both call sites
  -- directly, not assumed): Gen 1's battler is a wrapper with real
  -- .isPlayer/.mon fields; Gen 2's battler IS the mon itself (the engine's
  -- own comment there: "Gen 2's engine has no battler wrapper") -- no
  -- .isPlayer field at all, side signaled instead via a separate `side`
  -- payload field whose own internal shape wasn't traced. Rather than guess
  -- at an unverified Gen 2 read, this only increments when battler.isPlayer
  -- is the CONFIRMED Gen 1 shape (explicitly false, never just
  -- falsy-because-absent) -- Gen 2 safely degrades to the tally always
  -- reading 0 (defeated-Nx indicator just never lights up there) instead of
  -- risking a wrong read on a guessed field. battled/caught (the other two
  -- of the three route-panel indicators) are unaffected -- they read
  -- save.pokedex flags, already confirmed gen-agnostic elsewhere in this
  -- file. Registration guarded by C.wrappedFainted, matching the love.*
  -- wrapper guards elsewhere in this file: recordKO INCREMENTS, so a
  -- duplicate listener from an F5 hot-reload would over-count and corrupt
  -- the persisted tally on next save.
  if not C.wrappedFainted then
    mod.events:on("battle.fainted", function(p)
      local b = p and p.battler
      if b and b.isPlayer == false and b.mon and b.mon.species then
        C.recordKO(b.mon.species)
      -- v2.9.5 Gen2 bugfix (Tier 5 of the Session-11 audit): the comment
      -- above deliberately left this permanently inert on Gen2 rather
      -- than guess at `side`'s own untraced internal shape -- traced the
      -- real emit call sites this time instead
      -- (src/battle/gen2/Battle.lua:3088 enemy faint, :3160 player
      -- faint): both capture `battler` BEFORE any enemy-replacement
      -- reassignment happens (the swap-in at :3113 runs strictly after
      -- the emit), so the payload's own `battle.enemy` reference is still
      -- exactly the mon that just fainted at the moment this fires.
      -- Comparing the payload's battler against that live reference
      -- unambiguously identifies an enemy faint without needing `side`
      -- at all. `not b.mon` explicitly confirms this is the wrapper-less
      -- Gen2 shape (Gen1's battler ALWAYS has `.mon`, confirmed above),
      -- so this can never accidentally also match a Gen1 payload.
      elseif b and not b.mon and b.species and p.battle and p.battle.enemy == b then
        C.recordKO(b.species)
      end
    end)
    C.wrappedFainted = true
  end
  -- Weather-provider handshake (ported from the 2.9.3/2.9.4 weather-compat
  -- build, direct request for feature parity). A generic, provider-agnostic
  -- slot for ANY mod that wants to describe live encounter odds -- no
  -- specific weather mod is named or required here, and kanto never calls
  -- mod.find on anyone. A provider registers itself by calling one of these
  -- three names on our own mod.exports; whichever fires first wins. Three
  -- names, one function: kept as three because that's the exact contract a
  -- real provider (Weather FX 4.26.0+) already ships expecting, and there's
  -- no way to know in advance which one a given provider mod guessed. The
  -- provider itself is validated on arrival (must be a table with a .route
  -- function) so a malformed registration can't later crash buildState().
  local function registerWeatherProvider(_, provider)
    if type(provider) ~= "table" or type(provider.route) ~= "function" then return false end
    C.weatherProvider = provider
    return true
  end
  mod.exports.registerWeatherProvider = registerWeatherProvider
  mod.exports.setWeatherProvider = registerWeatherProvider
  mod.exports.registerWeatherEncounterProvider = registerWeatherProvider
  -- v72: touch-nav/icon group drag state (see TOUCH_GROUP_KEYS's comment
  -- above for the overall design) -- must live here, after C itself
  -- exists, not up near TOUCH_GROUP_KEYS's own declaration.
  C.touchGroupPos = C.touchGroupPos or { touchNav = false, touchIcons = false }
  -- { which, touchId, offsetX, offsetY } in design units (x/s), same
  -- shape/space as C.overlayEdit.drag -- set on grab, cleared on release.
  C.touchGroupDrag = C.touchGroupDrag or nil
  -- Port of v81 (built after 2.9.0 shipped, never released publicly, direct
  -- request to bring it forward): per-group resize multiplier, mirroring a
  -- real panel's own cfg.scale. 1 = default size; grown/shrunk via the
  -- group's own bottom-corner grip (see tryTouchGroupResizeStart).
  C.touchGroupSize = C.touchGroupSize or { touchNav = 1, touchIcons = 1 }
  -- v2.9.5: parallel side table tagging which orientation each
  -- C.touchGroupSize value was actually set in -- see
  -- updateTouchGroupResize's own comment for why a bare number can't
  -- carry this tag itself the way C.touchGroupPos's table shape can.
  C.touchGroupSizePortrait = C.touchGroupSizePortrait or {}
  -- { which, touchId, corner, anchorX, anchorY, startDist, startSize } --
  -- same shape as C.overlayEdit.resize, one grip owns the pointer at a time.
  C.touchGroupResize = C.touchGroupResize or nil
  -- LIGHT BUILD, Session 46: overlay customization -- edit mode, collapse,
  -- and manual scale per panel. Scoped to the two real architectural units
  -- drawOverlay already composes independently (party on the left; trainer+
  -- items+route/battle bundled as one right-hand stack sharing one auto-fit
  -- scale) rather than five, since splitting the right column into
  -- independently-scaled sub-panels means restructuring how it's stacked
  -- and measured, not just adding a multiplier -- a real next step, not
  -- part of this pass. Touch-drag/reposition and true pinch-to-zoom are
  -- deliberately not attempted here either: both mean turning the overlay
  -- into a new, third input-capturing state alongside "pass through to the
  -- game" and "modal screen input" (see the touchpressed/mousepressed
  -- wrappers), which is real risk to core input handling to take on blind.
  if C.overlayEdit == nil then C.overlayEdit = { active = false, sel = "left", bounds = {}, drag = nil, pinch = nil, touches = {}, resize = nil } end
  -- LIGHT BUILD, Session 50: persist panel collapse/scale state across
  -- restarts. mod.options -- the framework's own settings system, already
  -- used elsewhere in this file -- turned out to have no evidence of a
  -- write path anywhere in this codebase, only :get(); every existing use
  -- reads a value the external mod-manager UI set, never one this mod
  -- writes itself, so it can't be used to persist live in-game edits.
  -- v2.9.1 (sandbox migration): the incoming mod sandbox removes the LOVE
  -- filesystem API (and bans loading executable chunks), so panel state moves
  -- to mod.storage -- the engine's data-only, per-mod persistent store. We now
  -- persist a plain TABLE (no more "return {...}" chunk to serialize + load).
  --   API SIGNATURE CONFIRMED against the real src/mods/Storage.lua (pulled from
  --   a 0.1.80 engine build, which already ships mod.storage even though it
  --   predates the restrictive sandbox itself):
  --     mod.storage:write(game, key, table) -> true | false, code, message
  --     mod.storage:read(game, key)         -> table | nil, code, message
  --   (value must be a plain data table; write can SOFT-FAIL -- return false,
  --   code, message -- without throwing, e.g. "encode_failed" or
  --   "not_in_playthrough"; C.storageWrite below forwards those exact values,
  --   not just whether the call threw -- see its own comment for the bug this
  --   fixed.) STILL UNCONFIRMED: whether the actual restrictive sandbox (which
  --   removes the LOVE filesystem/system modules and privatizes _G) matches the
  --   announcement exactly -- 0.1.80 doesn't have that sandbox yet, only
  --   mod.storage + Gen 2. Both helpers are fully pcall-guarded regardless, so
  --   a signature surprise degrades to "layout not persisted" rather than
  --   taking the
  -- overlay down. SCOPING CONFIRMED from Storage:_scope: the store path is
  -- {mod_storage, save.version, playthroughId, modId} -- genuinely
  -- per-playthrough, so the layout is
  -- now PER-SAVE (the old on-disk save file was a single global one); accepted
  -- as a sandbox constraint -- revisit if a global store is exposed.
  local PANEL_CFG_KEY = "overlay_layout"
  -- Attached to C (field assignments), NOT top-level locals: this factory sits
  -- at Lua's 200-local ceiling, so every new helper here must avoid a local.
  -- v2.9.5 PERSISTENCE FIX (real on-device data loss, root-caused against the
  -- ACTUAL running engine, not a stale checkout): panel-layout persistence
  -- moved OFF mod.storage ONTO save.modData -- the exact bucket C.recordKO/
  -- C.koCountFor above already use, and StatDex/Rogue Bound use, all reliably.
  --   WHY mod.storage failed: it keys its on-disk file by the engine's
  --   playthroughId, which CHURNS on real hardware (one Blue save was observed
  --   under 38 distinct ids). The WRITE landed under whatever id was live at
  --   save time (correct), but the deferred READ ran at boot's game.ready --
  --   during the newGame-skeleton window, before CONTINUE adopts the real save
  --   -- so it resolved a DIFFERENT (throwaway) id, missed the file, and fell
  --   back to defaults every launch. Confirmed by reading the device's real
  --   mod_storage tree: the write is present and correct, the read just never
  --   found it.
  --   WHY save.modData is correct: Game:adoptSave binds save.modData to the
  --   live save (loader.modSave = save.modData), keyed ONLY by modId -- no
  --   playthroughId resolution to get wrong -- so it round-trips for the same
  --   save every time. It's serialized into save_<version>.lua on the next
  --   in-game SAVE (SaveData.save copies every key except `options`, modData
  --   included). Verified against the real engine source, both generations.
  --   TRADEOFF (accepted, matches every other save.modData writer incl. the KO
  --   tally): the layout flushes to disk on the next in-game SAVE, not the
  --   instant of the edit -- an edit made and then quit WITHOUT saving is not
  --   persisted. The paired load-timing half of this fix is the save.loaded
  --   re-fire wired below the game.ready handler.
  function C.storageWrite(data)
    local save = C.game and C.game.save
    if not save then return false, "game/save unavailable" end
    save.modData = save.modData or {}
    save.modData[mod.id] = save.modData[mod.id] or {}
    save.modData[mod.id][PANEL_CFG_KEY] = data
    return true
  end
  function C.storageRead()
    local save = C.game and C.game.save
    local md = save and save.modData and save.modData[mod.id]
    local res = md and md[PANEL_CFG_KEY]
    if type(res) == "table" then return res end
    return nil
  end
  -- LIGHT BUILD, Session 51: the right column splits from one bundled
  -- unit into three independently collapsible/scalable regions --
  -- trainer, items, and the route-or-battle slot at the bottom (still
  -- one region: those two are mutually exclusive, never both on screen
  -- at once, so there's nothing to independently control between them).
  -- Party stays its own region on the left, unchanged. Generic list
  -- instead of hardcoded left/right fields so save/load/init don't need
  -- rewriting again if the panel set changes again later.
  local PANEL_KEYS = { "left", "trainer", "items", "bottom" }
  local function clamp01Scale(v)
    v = tonumber(v) or 1
    if v < 0.4 then v = 0.4 elseif v > 2 then v = 2 end
    return v
  end
  -- v81 port: same clamp contract as clamp01Scale, wider range (touch-nav/
  -- icon groups are small to begin with, so they can afford to grow further).
  local TOUCH_GROUP_SIZE_MIN, TOUCH_GROUP_SIZE_MAX = 0.5, 2.5
  local function clampTouchGroupSize(v)
    v = tonumber(v) or 1
    if v < TOUCH_GROUP_SIZE_MIN then return TOUCH_GROUP_SIZE_MIN end
    if v > TOUCH_GROUP_SIZE_MAX then return TOUCH_GROUP_SIZE_MAX end
    return v
  end
  -- Session 80 added a separate `C.globalScale` multiplier here, layered
  -- into the `s` formula underneath every panel's own cfg.scale, for a
  -- "scale everything at once" control. Session 87 removed it again, on
  -- direct report: it changed the rendered SIZE without changing any
  -- panel's own displayed percentage, which read as a second, disconnected
  -- scaling system rather than "tied in with the existing percentages."
  -- The "-"/"=" / L2-R2 controls (see onKeyDown/love.gamepadaxis) still
  -- exist and still scale everything at once -- they just do it by
  -- bulk-editing every panel's own cfg.scale directly now, the exact same
  -- field Up/Down and pinch/resize already read and write for one panel
  -- at a time. One source of truth per panel, no hidden second multiplier.
  -- Session 82: `collapsed` and `compact` are two separate booleans on
  -- each panel's cfg (see savePanelCfg/the init block above), but for a
  -- panel that supports a real reduced-content view, the two of them
  -- together form one 3-way ladder: 0 = full, 1 = compact, 2 = bar
  -- (fully collapsed). Kept as two plain booleans on disk rather than one
  -- number field -- simpler save-format story (see savePanelCfg's own
  -- comment) -- with these two tiny helpers doing the level<->booleans
  -- conversion in the one place it's needed (onKeyDown's c/i/p handlers
  -- and the touch collapse-icon handler). Panels that don't support
  -- compact (Items/Route-Battle) never set cfg.compact true in the first
  -- place, so levelOf() for them only ever returns 0 or 2 -- the exact
  -- same two states they already had.
  --
  -- Session 88: Trainer (compact = name/money/play time/party count,
  -- Session 82) and Party (compact = the existing style-B density, no
  -- move lists -- previously only reachable automatically when a full
  -- party didn't fit, or via the removed F7 key) both support a real
  -- middle state now -- both listed here so onKeyDown/the touch handler
  -- can check membership instead of hardcoding "trainer" alone, which
  -- would've silently left Party's B view unreachable through the same
  -- cycle even though the rendering support was already there.
  local SUPPORTS_COMPACT = { trainer = true, left = true }
  local function levelOf(cfg) return (cfg.collapsed and 2) or (cfg.compact and 1) or 0 end
  local function setLevel(cfg, lvl)
    lvl = math.max(0, math.min(2, lvl))
    cfg.collapsed = (lvl == 2)
    cfg.compact = (lvl == 1)
  end
  local function savePanelCfg()
    -- Build the same flat table the old on-disk chunk used to `return`, but as
    -- live data handed straight to mod.storage -- no string serialization, and
    -- the load side no longer executes a chunk. Same "missing field = default"
    -- contract: an older stored table lacking compact/touchGroups just keeps the
    -- defaults the load side sets.
    local data = {}
    for _, k in ipairs(PANEL_KEYS) do
      local cfg = C.panelCfg[k]
      data[k] = {
        collapsed = cfg.collapsed and true or false,
        scale     = cfg.scale,
        -- v2.9.5 fix, direct report: this rebuild was dropping cfg.pos's
        -- .portrait tag on every save, the write-side half of the same
        -- bug C.applyLoadedLayout's read side had (see its own comment) --
        -- together they meant the tag never survived a save+reload round
        -- trip at all.
        pos       = cfg.pos and { x = cfg.pos.x, y = cfg.pos.y, portrait = cfg.pos.portrait } or false,
        compact   = cfg.compact and true or false,
      }
    end
    local groups = {}
    for _, k in ipairs(TOUCH_GROUP_KEYS) do
      local pos = C.touchGroupPos[k]
      groups[k] = pos and { x = pos.x, y = pos.y, portrait = pos.portrait } or false
    end
    data.touchGroups = groups
    -- v81 port: per-group resize multipliers, same "missing field = default"
    -- contract as everything else here -- an older stored table simply won't
    -- have this key, and the load side (C.applyLoadedLayout) defaults each to 1.
    local sizes = {}
    for _, k in ipairs(TOUCH_GROUP_KEYS) do
      sizes[k] = C.touchGroupSize[k] or 1
    end
    data.touchGroupSizes = sizes
    -- v2.9.5 fix: C.touchGroupSizePortrait wasn't referenced anywhere in
    -- this function at all before this fix -- the size NUMBER was being
    -- saved correctly, but its orientation tag was silently never written
    -- to disk, so it was always missing/untagged on the next load
    -- regardless of which orientation it was actually resized in. See
    -- C.applyLoadedLayout's matching load-side fix and
    -- updateTouchGroupResize's comment for the full picture.
    local sizesPortrait = {}
    for _, k in ipairs(TOUCH_GROUP_KEYS) do
      sizesPortrait[k] = C.touchGroupSizePortrait[k] or false
    end
    data.touchGroupSizesPortrait = sizesPortrait
    local ok, err = C.storageWrite(data)
    local msg
    if ok then
      msg = string.format("panelCfg saved -- left=%.2f trainer=%.2f items=%.2f bottom=%.2f",
        C.panelCfg.left.scale, C.panelCfg.trainer.scale, C.panelCfg.items.scale, C.panelCfg.bottom.scale)
    else
      msg = "panelCfg save skipped: " .. tostring(err)
    end
    mod.log:info("kanto_companion: %s", msg)
    C.panelCfgDebugMsg, C.panelCfgDebugMsgAt = msg, love.timer.getTime()
  end
  -- EMERGENCY, Session 64: Bhk reported dragging one panel made three
  -- others vanish entirely with no way to recover -- confirmed serious
  -- enough that getting the overlay back had to come before diagnosing
  -- why. v22/v23 unconditionally wiped any saved panel state and
  -- re-saved clean defaults on load, regardless of what's on disk --
  -- every panel came back visible and at its default position the
  -- moment those builds launched, with no menu navigation or working
  -- edit mode required, since the overlay might not have been
  -- renderable at all in the broken state. The out-of-bounds-pos
  -- rejection added at the same time (see the load branch below) stays
  -- in place regardless of this flag, so a future occurrence of the
  -- same underlying bug can't reproduce this exact symptom again via a
  -- stale save file.
  --
  -- Session 65, persistence-fix-v24: turned back OFF. The wipe check
  -- runs on every C.panelCfg == nil, which is every real session, not
  -- just once -- so v22/v23 were silently discarding and overwriting
  -- your saved layout on every single launch, which is why nothing
  -- persisted across play sessions. The actual crash (fnFactory
  -- returning a number instead of a function) is fixed at its root in
  -- v23/v24's drawEditablePanel call sites, so the emergency wipe no
  -- longer has a reason to run continuously. F9 / L3 panic-reset
  -- (below) is left in place as a real recovery path independent of
  -- this flag.
  -- v2.9.1: validation/apply of a loaded layout, extracted so the deferred load
  -- below shares one code path. Same defensive clamping as the old inline load:
  -- a corrupt / hand-edited / older-shape stored table just keeps whatever
  -- default was set, a missing field defaults, and an out-of-bounds pos is
  -- rejected (Session 64). C.* field, not a local (200-local ceiling).
  function C.applyLoadedLayout(loaded)
    if type(loaded) ~= "table" then return end
    for _, k in ipairs(PANEL_KEYS) do
      if type(loaded[k]) == "table" then
        C.panelCfg[k].collapsed = loaded[k].collapsed and true or false
        C.panelCfg[k].compact   = loaded[k].compact and true or false
        C.panelCfg[k].scale     = clamp01Scale(loaded[k].scale)
        local p = loaded[k].pos
        if type(p) == "table" and type(p.x) == "number" and type(p.y) == "number"
           and p.x > -2000 and p.x < 4000 and p.y > -2000 and p.y < 4000 then
          -- v2.9.5 fix, direct report ("not saving/reading position...
          -- believe this is a regression"): this rebuild dropped every
          -- field except x/y, discarding the .portrait tag added earlier
          -- this session even when it WAS saved -- confirmed by reading
          -- savePanelCfg below, which had the identical gap on the write
          -- side. Together the two meant the tag never survived a single
          -- save+reload round trip: a portrait-saved position would read
          -- back as untagged (nil), which the orientation-compare in
          -- drawEditablePanel treats as landscape, so it silently stopped
          -- applying the instant the game was closed and reopened. `or
          -- nil` keeps the same "missing field = landscape" migration
          -- default old saves already relied on -- p.portrait is simply
          -- absent on any save from before this fix existed.
          C.panelCfg[k].pos = { x = p.x, y = p.y, portrait = p.portrait or nil }
        else
          C.panelCfg[k].pos = false
        end
      end
    end
    if type(loaded.touchGroups) == "table" then
      for _, k in ipairs(TOUCH_GROUP_KEYS) do
        local p = loaded.touchGroups[k]
        if type(p) == "table" and type(p.x) == "number" and type(p.y) == "number"
           and p.x > -2000 and p.x < 4000 and p.y > -2000 and p.y < 4000 then
          -- v2.9.5 fix: same tag-preservation as C.panelCfg[k].pos above.
          C.touchGroupPos[k] = { x = p.x, y = p.y, portrait = p.portrait or nil }
        else
          C.touchGroupPos[k] = false
        end
      end
    end
    -- v81 port: per-group resize multipliers, clamped to the valid range,
    -- defaulting to 1 for any missing/invalid entry (older saves, etc.) --
    -- same defensive shape as every other field above.
    if type(loaded.touchGroupSizes) == "table" then
      for _, k in ipairs(TOUCH_GROUP_KEYS) do
        local v = loaded.touchGroupSizes[k]
        C.touchGroupSize[k] = (type(v) == "number") and clampTouchGroupSize(v) or 1
      end
    end
    -- v2.9.5 fix: C.touchGroupSizePortrait is a plain number's orientation
    -- tag, tracked in this parallel table since a bare number can't carry
    -- its own field the way cfg.pos's table shape can (see
    -- updateTouchGroupResize's own comment). This table was never loaded
    -- (or saved -- see savePanelCfg below) at all before this fix, so
    -- every touch-group resize's tag reverted to untagged/false on any
    -- app restart, regardless of which orientation it was actually sized
    -- in -- the exact "landscape vs portrait different sizes, believe
    -- it's a regression" report. Missing/older-save entries stay nil,
    -- same "untagged = landscape" migration default as everywhere else.
    if type(loaded.touchGroupSizesPortrait) == "table" then
      for _, k in ipairs(TOUCH_GROUP_KEYS) do
        local v = loaded.touchGroupSizesPortrait[k]
        C.touchGroupSizePortrait[k] = (v == true) or nil
      end
    end
  end
  -- v2.9.1: the saved layout now lives in mod.storage, keyed by the live
  -- playthrough, so unlike the old global file it can't be read at mod-load time
  -- (no game yet). This runs ONCE, the first frame a playthrough is available
  -- (wired into game.ready + called lazily from drawOverlay), applying the
  -- stored layout over the defaults set below. C.panelCfgLoaded is the one-shot
  -- latch (persists on C across hot-reloads, like everything else on C).
  function C.loadPanelCfgNow()
    if C.panelCfgLoaded or not C.game then return end
    C.panelCfgLoaded = true
    local loaded = C.storageRead()
    local msg
    if loaded then
      C.applyLoadedLayout(loaded)
      msg = string.format("panelCfg loaded -- left=%.2f trainer=%.2f items=%.2f bottom=%.2f",
        C.panelCfg.left.scale, C.panelCfg.trainer.scale, C.panelCfg.items.scale, C.panelCfg.bottom.scale)
    else
      msg = "no saved panelCfg -- using defaults"
    end
    mod.log:info("kanto_companion: %s", msg)
    C.panelCfgDebugMsg, C.panelCfgDebugMsgAt = msg, love.timer.getTime()
  end
  -- EMERGENCY (Session 64/65): when true, skip the deferred load and keep clean
  -- defaults -- a recovery path for a bad stored layout (F9 / L3 panic-reset is
  -- the other). Left OFF; setting C.panelCfgLoaded true here makes
  -- C.loadPanelCfgNow() a no-op so nothing overwrites the defaults.
  local EMERGENCY_WIPE_SAVED_CONFIG = false
  if C.panelCfg == nil then
    C.panelCfg = {}
    for _, k in ipairs(PANEL_KEYS) do
      C.panelCfg[k] = { collapsed = false, scale = 1, pos = false, compact = false }
    end
    C.panelCfgLoaded = EMERGENCY_WIPE_SAVED_CONFIG and true or false
    mod.log:info("kanto_companion: panelCfg fresh init -- defaults set, stored layout loads once the game is ready")
  end
  C.fonts   = C.fonts or {}
  C.sprites = C.sprites or {}
  C.dispHP  = C.dispHP or {}      -- animated HP values keyed by "p1".."p6"/"enemy"
  C.dispSp  = C.dispSp or {}      -- species behind each animated value (reset on change)
  C.triggerDown = C.triggerDown or { triggerleft = false, triggerright = false }  -- L2/R2 latch, Items screen qty

  -- engine modules (same sources the streaming mod uses)
  -- v2.9.3: req() used to be `pcall(require, p)` -- require passed straight
  -- as pcall's own function argument. pcall is a C function, so it sits as
  -- its own stack frame directly between this file and the engine's
  -- require shim, with no Lua source of its own ("=[C]"). The shim's Gen2
  -- adapter routing (src/mods/Loader.lua's callerIsMod) decides "is this a
  -- mod calling?" by reading the source file at a fixed stack depth above
  -- itself -- and it landed on that C frame instead of on this file,
  -- read as "not a mod", and silently skipped the Gen2Compat facade for
  -- EVERY req() call in this whole file. On a Gold boot, C.game (and every
  -- other req()'d engine module) came back as the raw, un-adapted Gen 1
  -- module instead of the live game facade -- inert, never the object the
  -- engine actually calls into. That's why the O key hook installed
  -- against a dead table and never fired: confirmed by loading the real
  -- engine's Loader.lua + Gen2Compat.lua and a real Gen 2 save through the
  -- actual req()/hook-install code path, not a hand-invoked replica.
  -- Routing require() through a NAMED helper (rawReq) whose call is not a
  -- tail call (the result is bound to a local, not returned directly --
  -- tail calls elide their own frame, which silently reproduces the exact
  -- same bug) restores a real Lua stack frame at that depth and fixes the
  -- routing, verified via the same real-engine harness.
  local function rawReq(p) local m = require(p); return m end
  local function req(p) local ok, m = pcall(rawReq, p); return ok and m or nil end
  C.game     = C.game or req("src.core.Game")
  C.TypeChart = C.TypeChart or req("src.battle.TypeChart")
  -- v2.9.2 (Gen 2 correctness fix, ported from the dev build's v93): Catching is
  -- the ONE module among kanto's engine requires that genuinely diverges by
  -- generation -- a real src/battle/gen2/Catching.lua exists (Gen 2's catch-rate
  -- math is different from Gen 1's), but unlike Game/BattleState/Boxes it has NO
  -- entry in the engine's Gen2Compat adapter table, so a plain
  -- req("src.battle.Catching") would silently resolve to the GEN 1 module even
  -- on a Gold/Silver game -- feeding wrong numbers into the overlay's live
  -- catch-odds display (C.Catching.BALLS, used by def() further down). Routed
  -- around here instead of waiting on the engine: GameVersion.generation()
  -- (require("src.core.GameVersion"), not adapter-served -- it's the "which
  -- generation" oracle itself, same module either way) returns 1 or 2 off
  -- GameVersion.current, which the loader captures ONCE when it constructs --
  -- "a run never changes generation underneath one" is the engine's own
  -- comment on Loader.new -- so deciding ONCE here at mod-load, same as every
  -- other req() in this block, is safe and correct, not a race.
  do
    local GameVersion = req("src.core.GameVersion")
    local generation = (GameVersion and GameVersion.generation and GameVersion.generation()) or 1
    C.generation = generation
    C.Catching = C.Catching or req(generation == 2 and "src.battle.gen2.Catching" or "src.battle.Catching")
    -- v2.9.5 (Gen 2 root-cause fix): currentBattle() below identity-checks
    -- the live stack against a real battle-screen CLASS to find the
    -- active battle. On Gen 1 that's C.BattleState (required right
    -- below), the real class. On Gen 2 the object actually pushed onto
    -- the stack is src/ui/gen2/BattleState.lua's own class -- confirmed
    -- against real engine source -- and it is NOT reachable by requiring
    -- the Gen-1-named path: Gen2Compat's facade for
    -- "src.battle.BattleState" is a deliberately empty proxy table (most
    -- of BattleState is documented "absent" on Gen 2 in its own adapter
    -- source), never the real class, so identity against it can never
    -- match a real Gen 2 battle screen -- this was WHY the entire Battle
    -- panel, HP-bar sync, and battle-time auto-adjust were completely
    -- dead on Gen 2 (direct report: "barely working"), not a display bug,
    -- a detection bug. Same "require the Gen-2-named path directly"
    -- pattern as C.Catching just above.
    C.Gen2BattleScreen = (generation == 2) and req("src.ui.gen2.BattleState") or nil
    -- v2.9.5 (Gen 2 Tier-2 audit fix): badges are NOT inventory items on Gen
    -- 2 at all (unlike Gen 1, where this engine genuinely does track each
    -- badge as a `save.inventory[id]` entry, confirmed against the real
    -- imported item data for both games -- the badge item ids just never
    -- appear there, they are entirely separate save fields). Gen 2
    -- stores them as two boolean-flag tables, `save.player.badges` (Johto)
    -- and `save.player.kantoBadges` (Kanto) -- confirmed against real engine
    -- source (src/core/gen2/Save.lua's init/ensure-exists, src/ui/gen2/
    -- TrainerCard.lua's own read of them). src/world/gen2/FieldMoves.lua
    -- exposes the real ordered name lists (JOHTO_BADGES/KANTO_BADGES, short
    -- names like "ZEPHYR"/"BOULDER", no "BADGE" suffix) that this engine's
    -- own badge-granting code writes under -- reused directly rather than
    -- re-hardcoded, same "require the Gen-2-named path directly" pattern as
    -- C.Gen2BattleScreen above.
    C.Gen2FieldMoves = (generation == 2) and req("src.world.gen2.FieldMoves") or nil
  end
  C.Growth   = C.Growth or req("src.pokemon.Growth")
  C.Badges   = C.Badges or req("src.inventory.Badges")
  C.BattleState = C.BattleState or req("src.battle.BattleState")
  C.Boxes    = C.Boxes or req("src.pokemon.Boxes")
  C.Party    = C.Party or req("src.pokemon.Party")
  C.Bag      = C.Bag or req("src.inventory.Bag")
  C.Stats    = C.Stats or req("src.pokemon.Stats")
  -- v2.9.1 (sandbox): the mod sandbox removes the LOVE system module, so mobile
  -- detection goes through the engine's own VideoMode.isMobile() (runs in engine
  -- context, where that OS query still works; permitted by our engine_internals
  -- permission). Consumed by isMobilePlatform() below.
  C.VideoMode = C.VideoMode or req("src.core.VideoMode")
  -- v2.9.1: also pull the saved panel layout the first frame a playthrough is
  -- ready -- mod.storage is keyed by the live game, so it can't be read at
  -- mod-load time (see C.loadPanelCfgNow above).
  mod.events:on("game.ready", function(p)
    -- v2.9.3: on Gen 2 the payload's `.game` is the RAW Game2 instance
    -- (src/core/Game2.lua's own `ModRuntime.emit("game.ready", { game = self
    -- })`), never the Gen2Compat facade -- confirmed against the real
    -- engine source. C.game from req("src.core.Game") above is already the
    -- translated facade (Gen 1's `.overworld` -> Game2's `.world`, etc.);
    -- overwriting it here with the raw instance silently broke every
    -- Gen1-spelled read after this fired, including canOpen()'s
    -- `g.overworld` check -- which is why the overlay drew fine (it never
    -- needed .overworld to already be true) but Items/Party could never
    -- open on Gold. Keep whatever req() already resolved; only fall back
    -- to the raw payload if C.game somehow never resolved at all. On Gen 1
    -- these are the same object either way, so this changes nothing there.
    C.game = C.game or (p and p.game)
    C.loadPanelCfgNow()
  end)
  -- v2.9.5 PERSISTENCE FIX, load-timing half (see C.storageWrite/Read above
  -- for the storage half). game.ready fires ONCE at boot, while the live save
  -- is still the throwaway newGame skeleton -- so that first C.loadPanelCfgNow
  -- reads an empty modData and LATCHES "defaults" (C.panelCfgLoaded = true).
  -- CONTINUE then adopts the real save (Game:adoptSave rebinds save.modData to
  -- the loaded slot) and emits "save.loaded" AFTER the adoption -- verified in
  -- the real engine (Game.lua continueGame: `self.save = loaded; adoptSave;`
  -- then `emit "save.loaded"`; Game2.lua mirrors it, so BOTH generations
  -- fire). Clear the one-shot latch and re-run the load here so the read
  -- finally happens against the REAL save's modData. WITHOUT this, the layout
  -- writes correctly but is never read back on the boot->continue path -- this
  -- re-fire is the actual thing that makes a saved layout reappear on load.
  -- Respects the EMERGENCY_WIPE guard (below) exactly as the boot latch does.
  mod.events:on("save.loaded", function()
    if EMERGENCY_WIPE_SAVED_CONFIG then return end
    C.panelCfgLoaded = false
    C.loadPanelCfgNow()
  end)
  -- v62: captures the engine's own live letterbox rect (real on-screen
  -- position/size of the classic 160x144 game view) every frame, for the
  -- battle-time party auto-move below (see drawOverlay). Read-only --
  -- stores the payload and passes it straight through -- so this can
  -- never change what the engine itself renders, only what kanto_companion
  -- reads. Confirmed against the engine's own Renderer.lua that this hook
  -- fires every frame once any mod wraps it (Runtime.wantsHook flips on
  -- the instant this registers, at mod load), not just during battle.
  -- v2.9.5 (ported from the shelved v82 hardening): guarded so a device/
  -- engine that lacks this hook (or throws on an unrecognized hook name)
  -- can't take the whole mod down. This call sits well before the input
  -- wrappers attach; a bare mod.hooks:wrap(...) throwing here would abort
  -- the ENTIRE mod load -> mod shows FAILED in the Mod Manager -> none of
  -- the mouse/touch/gamepad wrappers below ever attach -> every one of the
  -- mod's touch buttons goes dead at once, not just battle party auto-move.
  -- Two guards: (1) a capability check + pcall around the wrap, so a
  -- missing/incompatible hook degrades gracefully -- on failure C.letterbox
  -- simply stays nil, which enemyHudDesignRect already treats as "no data"
  -- (battle party auto-move just doesn't reposition), everything else
  -- untouched. (2) a C.wrappedLetterbox gate, matching the `if not
  -- C.wrappedMouse` etc. discipline elsewhere in this file, so an F5
  -- hot-reload doesn't stack duplicate letterbox wrappers.
  if not C.wrappedLetterbox and mod.hooks and mod.hooks.wrap then
    C.wrappedLetterbox = pcall(function()
      mod.hooks:wrap("render.letterbox", function(nextFn, payload)
        C.letterbox = payload
        return nextFn(payload)
      end)
    end)
    if not C.wrappedLetterbox and mod.log and mod.log.info then
      pcall(function() mod.log:info("kanto_companion: render.letterbox hook unavailable -- battle party auto-move disabled; mod otherwise unaffected") end)
    end
  end

  -- ---------------------------------------------------------------------
  -- Palette (0..1)
  -- ---------------------------------------------------------------------
  local function hex(s)
    return { tonumber(s:sub(1,2),16)/255, tonumber(s:sub(3,4),16)/255, tonumber(s:sub(5,6),16)/255 }
  end
  local COL = {
    panel = hex("10121a"), border = hex("ffffff"),
    text = hex("ffffff"), dim = hex("b9bdc9"),
    hi = hex("7dd87d"), mid = hex("e6d24a"), lo = hex("e05a5a"),
    xp = hex("5ab0ff"), gold = hex("ffd54a"), money = hex("ffe27a"),
    barbg = hex("ffffff"), threat = hex("ffb38a"),
    super = hex("7dd87d"), resist = hex("e0906a"),
    -- Ported from weather-compat: a dark, high-contrast fill for chip()
    -- badges whose text is informational rather than semantic (the
    -- weather tag) -- chip() always draws its label in COL.text (pure
    -- white), so the fill needs to be genuinely dark for real contrast.
    -- COL.dim (#b9bdc9) is a LIGHT gray-blue -- white-on-light-gray is
    -- weak contrast even at full opacity, and fades further under the
    -- overlay's transparency modes. This is close to COL.panel's own
    -- near-black but a shade lighter, so the tag still reads as its own
    -- distinct pill rather than blending into the panel behind it.
    tag = hex("2a2e3d"),
  }
  -- ---------------------------------------------------------------------
  -- Cursor skins -- the "cursor_color" option defined at the top of this file
  -- ---------------------------------------------------------------------
  -- Redesigned 2026-08-26 against reference art the user supplied directly,
  -- replacing a first pass that was just flat two-tone recolors: each skin
  -- now draws as the actual ball -- real hardware (thick black band, white
  -- button), per-ball patterns at their true proportions, and genuine
  -- protrusions on the two balls whose silhouettes really do break the
  -- circle (Heavy's rivets, Fast's fins).
  --
  -- All geometry here is authored in a DESIGN SPACE where the ball's radius
  -- is C.CURSOR_R (100); C.drawStickCursor applies one scale that maps it
  -- onto the real on-screen radius. Every coordinate below was checked in an
  -- offscreen render before shipping rather than reasoned about blind.
  --
  -- HARD CONSTRAINT -- there is NO clipping. love.graphics has no cheap clip
  -- available here, so every mark must fit inside radius 100 by its own
  -- geometry; anything that overflows renders as a spur poking out of the
  -- ball. (`under`/`over` are the deliberate exceptions -- those ARE the
  -- protrusions, drawn outside the body on purpose.) For a fill that needs
  -- to run all the way to the ball's edge, use C.cursorSeg: it follows the
  -- real arc instead of approximating it with a rectangle.
  --
  -- Marks are authored as explicit polygons rather than
  -- push/rotate/love.graphics.ellipse: a nested transform inside a mark
  -- function is invisible to cursor_render_tools/test_cursor_geometry.lua,
  -- which tracks each mark's real on-screen points.
  --
  -- Nothing here declares a top-level `local` on purpose -- this file's
  -- factory function sits at LuaJIT's 200-local ceiling, so all of this
  -- hangs off C, and every helper's own locals live inside its own scope.
  C.CURSOR_R = 100
  -- Everything that is NOT the rim stroke fills to this radius, not to
  -- CURSOR_R. The rim is `circle("line", 0,0, 95.5, 52)` at width 9, so it
  -- covers r 91..100 opaquely and IS the ball's silhouette. Filling the
  -- hemispheres (and the band, and Fast's side wedges) all the way to 100 as
  -- well put a second, independently-facetted edge at the same radius: the
  -- rim's own anti-aliased outer pixels are part-transparent, so the fill
  -- underneath bled through them, and because the two shapes use different
  -- segment counts (44 vs 52) and phases the bleed varied around the circle.
  -- That is the faint grainy halo of stray light pixels visible just outside
  -- the outline on a real device, worst under the white lower hemisphere.
  -- Stopping the fills at 96 puts them entirely beneath the rim (whose inner
  -- edge dips to 90.8) while leaving the rim's outer 4 units over background
  -- only, so its AA blends black->background cleanly. Nothing moves visibly:
  -- the rim already covered everything past r=91.
  C.CURSOR_FILL_R = 96
  C.cc = function(col, a) love.graphics.setColor(col[1], col[2], col[3], a or 1) end
  -- HSV -> RGB, h in [0,1). Returns the same 0..1 triple hex() produces, so a
  -- computed colour and a literal one are interchangeable at every call site.
  C.hsv = function(h, s, v)
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
    local m = i % 6
    if m == 0 then return v, t, p
    elseif m == 1 then return q, v, p
    elseif m == 2 then return p, v, t
    elseif m == 3 then return p, q, v
    elseif m == 4 then return t, p, v
    else return v, p, q end
  end
  -- Seconds for the RAINBOW skin (slot 20) to travel the full hue circle.
  -- Deliberately long: this sits under the player's thumb during normal play,
  -- and a fast cycle reads as strobing rather than as a colour that drifts.
  -- (A second, identical HSV helper and a rival value of 15 were both present
  -- here briefly on 2026-08-27 -- two passes implemented this independently.
  -- Only one was ever wired to skin 20; the unused pair was removed.)
  C.CURSOR_RAINBOW_SECONDS = 14
  -- CONCAVE FILL. love.graphics.polygon("fill", ...) draws a TRIANGLE FAN
  -- from the first vertex, so it only renders a CONVEX polygon correctly --
  -- a concave one comes out as its fan, i.e. with every notch filled in.
  -- This was measured, not assumed: modelling both fills against two real
  -- on-device screenshots, the fan matched (113 device px vs 111 modelled;
  -- 164 vs 152, bounding box exact) and the outline did not (67 and 92 px).
  -- It is why the Moon crescent had ALWAYS drawn as a solid yellow blob on
  -- hardware, through every earlier attempt to fix that skin by moving its
  -- geometry around -- the shape being drawn was never the shape in the
  -- coordinates. Three skins are affected: Moon's crescent (fan overfills
  -- the real outline by 69%), Fast's bolt (11%, its notches partly close),
  -- and Safari's camo blobs (3-10% each).
  --
  -- love.math is reachable from the mod sandbox -- it denies only
  -- filesystem/thread/system/event and passes everything else through
  -- (src/mods/Sandbox.lua, BLOCKED_LOVE) -- so triangulate once and fill
  -- the triangles, which are convex and therefore fan-exact. Cached on the
  -- polygon table itself: these live in C.CURSOR_PALETTES and are constant,
  -- so each is triangulated once for the life of the process. Weak keys so
  -- a palette that goes away does not pin its cache entry.
  --
  -- Falls back to the plain call if triangulation is unavailable or refuses
  -- the polygon (it requires a simple one) -- that is the old, wrong-but-
  -- harmless rendering rather than a crash mid-draw.
  C.polyTris = setmetatable({}, { __mode = "k" })
  C.fillPoly = function(poly)
    local tris = C.polyTris[poly]
    if tris == nil then
      local ok, res = pcall(function() return love.math.triangulate(poly) end)
      tris = (ok and type(res) == "table" and #res > 0) and res or false
      C.polyTris[poly] = tris
    end
    if not tris then love.graphics.polygon("fill", poly); return end
    for i = 1, #tris do love.graphics.polygon("fill", tris[i]) end
  end
  -- A circular segment: follows the ball's own top arc from x1 to x2, then
  -- closes flat at yBot. Pass nil for x1/x2 to derive them from yBot, giving
  -- a full cap across the top. Returns a vertex table for polygon().
  C.cursorSeg = function(x1, x2, yBot)
    local R = C.CURSOR_FILL_R
    if not x1 then
      x1 = -math.sqrt(math.max(0, R*R - yBot*yBot)); x2 = -x1
    end
    local pts, n = {}, 26
    for i = 0, n do
      local x = x1 + (x2 - x1) * i / n
      pts[#pts+1] = x
      pts[#pts+1] = -math.sqrt(math.max(0, R*R - x*x))
    end
    pts[#pts+1] = x2; pts[#pts+1] = yBot
    pts[#pts+1] = x1; pts[#pts+1] = yBot
    return pts
  end
  -- A circle plus an outward tip -- a teardrop without needing bezier curves.
  C.cursorTear = function(col, cx, cy, rad, dirDeg)
    local a = math.rad(dirDeg)
    local dx, dy = math.cos(a), math.sin(a)
    local px, py = -dy, dx
    C.cc(col)
    love.graphics.circle("fill", cx, cy, rad, 14)
    love.graphics.polygon("fill",
      cx + px*rad, cy + py*rad,
      cx - px*rad, cy - py*rad,
      cx + dx*rad*2.7, cy + dy*rad*2.7)
  end
  -- The two hemisphere fans, built once at load instead of every frame.
  C.buildCursorPolys = function()
    local R, n = C.CURSOR_FILL_R, 44
    local top, bot = {}, {}
    for i = 0, n do
      local a = math.pi + math.pi*i/n
      top[#top+1] = math.cos(a)*R; top[#top+1] = math.sin(a)*R
    end
    for i = 0, n do
      local a = math.pi*i/n
      bot[#bot+1] = math.cos(a)*R; bot[#bot+1] = math.sin(a)*R
    end
    C.cursorTopPoly, C.cursorBotPoly = top, bot
  end
  C.buildCursorPolys()
  -- Shared hardware. Only the top hemisphere and its pattern vary per skin --
  -- band, outline, button and the white underside never do, matching the
  -- reference art (an earlier pass wrongly recolored these per ball).
  C.CURSOR_HW = {
    band = hex("141414"), outline = hex("141414"),
    btnFill = hex("fbfbfb"), btnRing = hex("3a3a3a"),
    bottom = hex("f2f2f2"),
  }
  -- Indices match the cursor_color choice values. Accent colors live on the
  -- entry (a1/a2) rather than being rebuilt by hex() inside a draw call.
  -- Simplified 2026-08-26, direct follow-up: "maybe my expectations were
  -- too high... go with the basic distinguishing colors and then also any
  -- singular marks that are distinguishing and will read as the correct
  -- ball without the 100 percent accuracy I've been chasing." Every entry
  -- below is now at most a base color (occasionally two, where the real
  -- ball's identity IS a color split -- Fast, Moon) plus ONE simple mark.
  -- Dropped entirely: Great/Ultra's extra accent triangles, Master's pink
  -- ovals, Safari's blotch count (5 -> 2), Lure's stripe trio, Heavy's
  -- redundant inset circles (the protruding rivets alone are the mark now),
  -- Love's inner shaded heart, Friend's 4th teardrop, Fast's protruding
  -- fins (replaced with simple in-circle side color, per direct example),
  -- and Moon's jagged wedge (replaced with one clean arc-following panel,
  -- per direct example: "split the top half blue and black... simple
  -- crescent moon").
  -- Rebuilt 2026-08-26 against real official artwork (Ken Sugimori pieces,
  -- downloaded from Bulbagarden Archives and viewed directly), not memory
  -- of images shown earlier in this conversation. Direct correction:
  -- "these images look like someone who has never seen a reference drew
  -- them... map out the different features from their three dimensional
  -- different angled views to our straight on 2d view." Several designs
  -- were structurally wrong, not just imprecise: Great Ball is two
  -- separate red petals (not one band), Ultra Ball is WHITE-dominant with
  -- a black swoosh + gold accent (not black-dominant), Master Ball's pink
  -- ovals are real and were wrongly cut in the prior simplification pass,
  -- Heavy Ball has four blue circles (two protruding, two flush), and
  -- Moon Ball's teal/black split is bigger and jagged, not a thin smooth
  -- sliver. Fast/Level/Lure/Love/Friend/Safari were directionally right
  -- and got proportion/boldness corrections only.
  -- Great Ball's red strips, traced from the user's own gball2.png.
  --
  -- The measurement that decides the whole design: in that artwork the red
  -- reaches r=106 and its own black contour reaches r=114 -- the strips
  -- genuinely BREAK the ball's silhouette, and each wears a contour at
  -- exactly the ball's own rim weight. That, and not any shading trick, is
  -- what reads as "raised". (Verified: neither the reference nor any
  -- candidate has a cast shadow, bevel or lit edge anywhere -- blue next to
  -- a strip differs from blue far from it by under 1/255.)
  --
  -- Nine earlier attempts failed for one reason, and it is worth keeping:
  -- every one of them kept the strips INSIDE R=100. The note that used to
  -- sit here even described clamping the traced points to radius 96 so they
  -- would not "poke past the outline stroke". Poking past the outline stroke
  -- is the entire effect. The must-fit-inside-R=100 rule belongs to `mark`;
  -- `over` exists precisely so a skin can exceed it -- see Heavy Ball's
  -- rivets, and EXPECT_PROTRUDE in cursor_render_tools/
  -- test_cursor_geometry.lua, which now asserts this strip really does leave
  -- the circle (it caught a candidate whose fill peaked at r=98.8).
  --
  -- Traced with a real boundary trace, NOT a convex hull -- a hull bridged
  -- straight across the strip's concave inner edge and rendered chunky --
  -- then resampled by arc length, since resampling at uniform ANGLES rounds
  -- the tapered ends off an elongated shape. Left side only; the right is
  -- mirrored from it below, so the shape has a single source of truth and
  -- cannot drift out of symmetry.
  --
  -- Lifted 11 units above the literal trace. Two reasons, both about our ball
  -- rather than the artwork: our dome is shorter than the reference's (our
  -- equator is a thick band, theirs is a thin seam), so a literally-placed
  -- strip lands lower on OUR ball and its bottom cap welds into the band,
  -- killing the "laid on top" read at exactly the end that is supposed to
  -- show clearance; and at 5 units it still read as sitting too close to the
  -- centre (direct report). Lifting is not free -- it buys ~1.8 of inner
  -- clearance for ~2.2 of extra outer protrusion -- and 14 was tried and
  -- rejected as reading like detached horns rather than strips on a shell.
  --
  -- Then RADIALLY COMPRESSED by k=0.806 to halve how far the strips pop out
  -- of the ball (contour 123 -> 112, i.e. 23 units past the rim down
  -- to 12), on direct request. Compressed with the INNER END PINNED rather
  -- than translated inward or uniformly scaled: all three halve the pop-out,
  -- but translating drags the inner end from 54 to 43 and scaling to 49, and
  -- the strips sitting too close to the centre is a complaint that has
  -- already come up once. Pinning keeps the inner end and the angle exactly
  -- where they were and only pulls the outer end in. Current clearances --
  -- band 7.6, centre button 18.4.
  -- This is the trace adapted to our proportions, not copied blind.
  C.CURSOR_GB_STRIP = { -70.5,-74.3, -66.1,-78.5, -63.6,-80.1, -61.6,-80.4, -59.0,-79.7, -54.6,-76.7, -50.3,-72.4, -41.8,-60.7, -35.5,-48.8, -35.2,-45.5, -39.8,-37.5, -42.2,-34.3, -45.8,-30.7, -47.7,-29.6, -50.5,-29.6, -54.6,-31.4, -58.9,-34.3, -70.0,-45.6, -77.3,-55.9, -78.1,-60.0, -77.1,-63.3, -74.2,-69.0}
  C.cursorMirrorX = function(pts)
    local m = {}
    for i = 1, #pts, 2 do m[i] = -pts[i]; m[i+1] = pts[i+1] end
    return m
  end
  C.CURSOR_GB_STRIP_R = C.cursorMirrorX(C.CURSOR_GB_STRIP)
  C.CURSOR_PALETTES = {
    [0] = { top = hex("ee4b3a") },
    [1] = { top = hex("2f6ecb"), a1 = hex("e0392c"), -- Great: two raised red strips
      -- Drawn in `over`, i.e. AFTER drawStickCursor's rim stroke, so the rim
      -- passes BEHIND the strips instead of cutting across their outer ends.
      -- The old `mark` placement drew them under it, which is exactly what
      -- made them read as flat decals printed on the surface.
      --
      -- Stroke 18 puts 9 units outside the traced edge, matching the ball's
      -- own rim weight (9) -- in the reference those two weights are equal, and
      -- when the rim out-weighs the strip the rim wins the eye and the strip
      -- reads as subordinate to it. A centred stroke puts the other half
      -- inside, which the red fill then covers. Miter joins are safe here:
      -- the sharpest vertex in the trace is 147 degrees, so no join can throw
      -- a spike (a round-join preview would not have revealed that).
      over = function(pal)
        C.cc(C.CURSOR_HW.outline)
        love.graphics.setLineWidth(18)
        love.graphics.polygon("line", C.CURSOR_GB_STRIP)
        love.graphics.polygon("line", C.CURSOR_GB_STRIP_R)
        C.cc(pal.a1)
        love.graphics.polygon("fill", C.CURSOR_GB_STRIP)
        love.graphics.polygon("fill", C.CURSOR_GB_STRIP_R)
      end },
    -- Ultra Ball corrected again 2026-08-26, direct follow-up with 4 new
    -- references: "basically just two vertical yellow lines on the black
    -- top half close to the edge." The prior "white-dominant + black
    -- swoosh" read was wrong -- black IS the dominant top color. Each bar
    -- is a cursorSeg (arc-following outer/top edge, flat inner-bottom
    -- edge), so it naturally tapers near the pole and the two bars can
    -- never touch at the top -- no separate effort needed to avoid the
    -- horizontal "connector" some angled photo references show, which is
    -- a foreshortening artifact of that camera angle, not part of the
    -- flat design.
    [2] = { top = hex("1c1c1c"), a1 = hex("f0bd2e"), -- Ultra: black + two vertical bars near the edges
      barL = C.cursorSeg(-68, -42, -14), barR = C.cursorSeg(42, 68, -14),
      mark = function(pal)
        C.cc(pal.a1)
        love.graphics.polygon("fill", pal.barL)
        love.graphics.polygon("fill", pal.barR)
      end },
    -- Master Ball rebuilt 2026-08-26 from the user's own mball reference, using
    -- the technique that finally worked on the Great Ball. Three real changes:
    --
    -- 1. The marks PROTRUDE. The old ones were flat pink circles peaking at
    --    r=91.2, i.e. wholly inside the ball -- the same flat-decal read the
    --    Great Ball was rejected for nine times. They now live in `over`
    --    (drawn after the rim stroke, so the rim passes behind them), carry
    --    their own black contour at the ball's own rim weight, and reach
    --    r=108 / contour r=117.
    --
    -- 2. The marks are LONG SHALLOW TANGENTIAL LENSES, not circles. Measured
    --    off the reference they sit at r~93 at +/-45deg, sweep ~50deg of arc
    --    and are a thin RIND: 0.81R long by only 0.11R wide, because on a real
    --    ball they wrap around the shoulder. Two failure modes were built and
    --    rejected on sight before this: true circles read as Mickey-Mouse ears
    --    (a circle has no tangential axis at all, and two protruding circles
    --    on the +/-45deg diagonals is also literally Heavy Ball's construction),
    --    and merely elongating a FAT lens stayed ear-like. WIDTH is the
    --    parameter that decides it -- length and angle were reference-accurate
    --    to within 2% long before the shape stopped reading as ears.
    --
    -- 3. The M is a ZIGZAG. The reference M has no vertical stems at all --
    --    bottom tip, peak, valley, peak, bottom tip, four slanted strokes --
    --    where this file previously drew straight vertical legs, i.e. simply
    --    the wrong glyph. Reference measures x[-31,+31] y[-77,-46] stroke 7.8;
    --    scaled x1.20 and dropped 8 units on direct request. Its size and
    --    position are bounded on both sides: at x1.30 the clearance to the
    --    bulbs falls to 1.0 and at x1.40 it collides, while dropping it much
    --    past 8 starts crowding the centre button. Current clearances --
    --    bulbs 8.9, button 6.6.
    --
    -- Mark colour is the reference's measured crimson (#d00c44 at p50), not the
    -- old pink -- "red bulbous" was pointing at exactly this. Dome purple is
    -- left as ours rather than the reference's darker #502d8a.
    [3] = { top = hex("8a4fc4"), a1 = hex("ffffff"), a2 = hex("d00c44"), -- Master: purple + zigzag M + two raised red rinds
      bulbL = { -37.5,-94.0, -40.3,-95.6, -44.2,-95.9, -49.1,-94.9, -54.7,-92.6, -60.8,-89.1, -67.1,-84.6, -73.4,-79.3, -79.3,-73.4, -84.6,-67.1, -89.1,-60.8, -92.6,-54.7, -94.9,-49.1, -95.9,-44.2, -95.6,-40.3, -94.0,-37.5, -91.2,-35.9, -87.3,-35.6, -82.4,-36.6, -76.8,-39.0, -70.7,-42.4, -64.4,-46.9, -58.2,-52.3, -52.3,-58.2, -46.9,-64.4, -42.4,-70.7, -39.0,-76.8, -36.6,-82.4, -35.6,-87.3, -35.9,-91.2 },
      bulbR = { 37.5,-94.0, 40.3,-95.6, 44.2,-95.9, 49.1,-94.9, 54.7,-92.6, 60.8,-89.1, 67.1,-84.6, 73.4,-79.3, 79.3,-73.4, 84.6,-67.1, 89.1,-60.8, 92.6,-54.7, 94.9,-49.1, 95.9,-44.2, 95.6,-40.3, 94.0,-37.5, 91.2,-35.9, 87.3,-35.6, 82.4,-36.6, 76.8,-39.0, 70.7,-42.4, 64.4,-46.9, 58.2,-52.3, 52.3,-58.2, 46.9,-64.4, 42.4,-70.7, 39.0,-76.8, 36.6,-82.4, 35.6,-87.3, 35.9,-91.2 },
      mark = function(pal)
        -- The M only. The bulbs protrude, so they belong in `over`.
        C.cc(pal.a1); love.graphics.setLineWidth(10)
        love.graphics.line(-34,-39, -18,-67, 0,-40, 18,-67, 34,-39)
      end,
      over = function(pal)
        C.cc(C.CURSOR_HW.outline); love.graphics.setLineWidth(18)
        love.graphics.polygon("line", pal.bulbL)
        love.graphics.polygon("line", pal.bulbR)
        C.cc(pal.a2)
        love.graphics.polygon("fill", pal.bulbL)
        love.graphics.polygon("fill", pal.bulbR)
      end },
    -- Safari Ball reworked 2026-08-26 against sball.jfif and the annotated
    -- sheet. It was six plain circles, which read as polka dots however they
    -- are arranged -- the reference is woodland camo: organic interlocking
    -- amoeba shapes in four tones. Each blob here is a radial-noise polygon
    -- (a circle whose radius wobbles on three harmonics) that is then
    -- elongated and rotated, because real camo snakes rather than blobs.
    -- Deliberately NOT a 1:1 copy, per the brief -- just a camo pattern in
    -- the ball's own palette, tones sampled off the reference: tan base with
    -- olive green, rust and dark olive over it. The tan is left showing as a
    -- genuine fourth tone; an earlier denser pass buried it and the result
    -- read as three-colour mush.
    --
    -- Two constraints, both from this file's own rules. `mark` has NO
    -- clipping, so every vertex is clamped PER POINT to r<=96 (never by a
    -- uniform scale, which would distort points that were already inside).
    -- And `mark` draws BEFORE the band, so blobs may run below the equator
    -- and be covered by it -- they are flattened at y=+6, inside the band's
    -- -13..+13 span. Generated with seed 23; regenerating with a different
    -- seed reshuffles the pattern without changing any of the above.
    [4] = { top = hex("cdb37a"), a1 = hex("5e7a48"), a2 = hex("a86f33"), a3 = hex("40482e"), -- Safari: woodland camo
      camoCol = { 3, 1, 2, 3, 2, 1, 3, 2, 1, 3, 1 },
      camoPts = {
        { 44.7,6.0, 49.3,4.1, 36.9,3.8, 33.1,-2.3, 50.1,-11.3, 67.6,-15.6, 77.8,-19.1, 87.7,-23.8, 92.3,-26.4, 92.2,-26.7, 92.6,-25.2, 93.4,-22.0, 94.3,-18.2, 95.0,-13.5, 95.6,-8.5, 92.6,-4.4, 90.6,3.7, 78.9,6.0, 64.5,6.0, 58.8,6.0, 49.0,6.0, 38.7,6.0 },
        { -49.8,-36.5, -52.6,-33.3, -58.9,-31.8, -62.9,-29.7, -64.4,-23.3, -72.8,-18.3, -84.4,-21.4, -91.0,-27.4, -91.5,-28.9, -91.2,-30.0, -90.1,-33.2, -88.8,-36.5, -87.4,-39.7, -85.8,-43.0, -84.3,-46.0, -81.3,-51.0, -76.6,-57.9, -68.9,-57.6, -62.2,-51.6, -55.7,-48.2, -49.0,-44.8, -48.1,-40.3 },
        { 32.5,-71.7, 27.2,-71.0, 25.9,-68.4, 26.6,-62.2, 17.1,-62.9, 5.8,-68.7, -2.1,-73.9, -4.6,-79.0, -7.6,-81.7, -23.7,-86.2, -34.7,-89.5, -30.8,-90.9, -23.9,-93.0, -13.6,-94.8, -4.0,-91.0, -1.6,-93.8, 5.2,-95.9, 14.8,-92.0, 24.0,-87.6, 32.0,-82.6, 31.1,-78.3, 30.6,-75.3 },
        { -39.7,-16.2, -39.2,-24.1, -37.2,-31.7, -34.8,-38.7, -32.9,-45.4, -29.8,-53.2, -25.0,-62.6, -17.7,-74.0, -8.4,-79.6, -4.2,-71.8, -4.0,-63.9, 3.9,-69.2, 14.8,-73.9, 14.8,-66.3, 10.4,-56.8, 9.9,-48.7, 4.6,-38.9, -6.4,-34.8, -13.0,-34.5, -18.6,-25.0, -29.0,-11.7, -37.3,-9.5 },
        { 95.4,-11.1, 76.5,-21.4, 64.4,-28.6, 70.2,-18.2, 65.0,-13.8, 50.5,-21.6, 37.8,-31.4, 31.8,-40.1, 29.6,-45.6, 21.2,-52.3, 20.2,-56.4, 21.8,-58.9, 7.8,-73.0, 8.0,-80.0, 30.8,-65.3, 45.7,-52.8, 52.9,-49.3, 61.7,-45.5, 75.2,-39.5, 89.1,-30.3, 91.9,-23.7, 94.6,-16.4 },
        { 23.6,6.0, 20.3,6.0, 17.5,6.0, 14.4,6.0, 10.4,6.0, 9.4,-0.2, 10.5,-7.4, 7.6,-16.8, 5.7,-30.3, 9.3,-38.9, 15.1,-40.6, 20.7,-34.0, 24.0,-23.4, 26.7,-21.8, 31.3,-22.6, 33.5,-16.1, 34.1,-8.8, 35.8,-1.5, 36.6,6.0, 37.6,6.0, 36.1,6.0, 29.5,6.0 },
        { 25.6,-17.4, 20.0,-21.3, 15.1,-24.6, 11.9,-35.1, 9.0,-40.9, 1.1,-43.6, -5.5,-53.7, -6.8,-65.9, -4.3,-74.9, 4.6,-72.5, 11.1,-66.5, 10.5,-77.3, 12.6,-91.1, 18.9,-92.3, 25.6,-85.9, 28.6,-71.4, 26.2,-58.5, 28.2,-52.4, 33.6,-43.5, 34.3,-34.2, 34.3,-24.2, 32.1,-15.1 },
        { -58.6,6.0, -57.5,6.0, -50.6,-2.6, -43.9,-11.1, -45.9,-13.9, -47.1,-21.7, -39.0,-32.7, -30.7,-35.9, -25.0,-40.0, -17.4,-48.2, -16.1,-44.2, -19.8,-35.4, -12.0,-41.4, -0.1,-48.2, -4.0,-38.4, -16.9,-24.8, -24.1,-17.4, -28.5,-10.5, -34.0,-3.9, -40.2,2.8, -48.1,6.0, -55.2,6.0 },
        { -10.6,-40.3, -13.8,-38.5, -19.2,-39.0, -23.5,-36.2, -32.8,-38.4, -44.6,-48.7, -52.8,-59.9, -56.6,-68.1, -58.3,-73.7, -60.3,-74.7, -61.2,-74.0, -59.0,-75.7, -54.9,-78.7, -51.3,-81.2, -47.5,-83.4, -43.2,-84.9, -35.8,-75.5, -26.4,-71.5, -8.6,-62.3, -0.2,-50.5, -8.0,-47.8, -12.6,-46.3 },
        { -40.4,-1.7, -39.9,2.2, -36.9,6.0, -39.9,6.0, -52.1,6.0, -68.9,6.0, -81.0,4.7, -94.8,2.1, -95.9,-3.4, -95.6,-9.3, -95.1,-12.4, -94.7,-15.9, -93.8,-20.2, -92.9,-24.3, -91.8,-28.1, -87.3,-30.8, -74.1,-32.3, -58.1,-28.4, -52.0,-18.7, -50.7,-12.8, -39.2,-9.2, -34.4,-4.4 },
        { 38.7,-35.1, 34.2,-29.7, 30.3,-34.5, 32.4,-56.7, 34.2,-68.3, 28.4,-71.6, 24.1,-85.2, 26.6,-92.2, 27.7,-91.9, 24.4,-92.8, 24.7,-92.8, 29.9,-91.2, 35.5,-89.2, 39.0,-87.7, 42.6,-86.0, 46.8,-83.8, 51.4,-81.1, 51.6,-70.8, 52.1,-57.4, 52.4,-37.5, 48.7,-22.1, 42.8,-27.0 }
      },
      mark = function(pal)
        local c = { pal.a1, pal.a2, pal.a3 }
        for i = 1, #pal.camoPts do
          C.cc(c[pal.camoCol[i]])
          C.fillPoly(pal.camoPts[i])
        end
      end },
    [5]  = { top = hex("3373cc") },
    [6]  = { top = hex("e06ba0") },
    [7]  = { top = hex("4cad6a") },
    [8]  = { top = hex("9c5ad6") },
    [9]  = { top = hex("e8c93a") },
    [10] = { top = hex("e08a3a") },
    -- Fast Ball, 2026-08-26. Back to the original layout after a wedge-based
    -- rework was rejected as further from the reference; it needed only two
    -- fixes.
    --
    -- 1. The yellow edge bands now run through BOTH hemispheres. The original
    --    used cursorSeg(-100,-68,0), which walks y = -sqrt(R^2-x^2) and so can
    --    only ever cover the TOP half -- the yellow stopped dead at the band.
    --    These are VERTICAL-chord segments instead: the chord at x=+/-68,
    --    closed by the limb arc running round through both halves. `mark`
    --    draws after the bottom hemisphere, so painting into the white half is
    --    fine.
    --
    -- 2. The bolt is the TWO-STEP blocky shape, ROTATED RIGHT 28 degrees,
    --    scaled 0.85, then re-CENTRED horizontally and dropped to y-10 so it
    --    clears the centre button and the rim (r 35..88 against button 30,
    --    rim 91).
    --
    --    ROTATION is what makes it read as a bolt: the reference's arms run
    --    DIAGONALLY, and an axis-aligned version reads as a blocky "S" however
    --    its proportions are tuned. Rotating preserves every interior corner
    --    at 90deg -- straight edges, no tapers, still cube-ish -- it simply is
    --    not axis-ALIGNED. Confusing "right-angled CORNERS" with "edges
    --    parallel to the screen" is what cost several wrong passes here.
    --
    --    Re-centre AFTER rotating, not before: rotating an asymmetric shape
    --    moves its bounding box, so this one drifted +3.4 off-centre at 28deg
    --    even though it was centred at 0deg.
    --
    --    The fit tightens as the bolt returns toward upright: at 28deg its
    --    radial span at full scale exceeds the ~61 units between button and
    --    rim, hence 0.85. Rotating it further upright would need it smaller
    --    again.
    [11] = { top = hex("e0392c"), a1 = hex("f2c22e"), -- Fast: red + full-height yellow edges + blocky bolt
      edgeL = { -68, -67.8, -74.1, -61, -79.2, -54.2, -83.5, -47.4, -87, -40.7, -89.8, -33.9, -92.1, -27.1, -93.8, -20.3, -95, -13.6, -95.8, -6.8, -96, 0, -95.8, 6.8, -95, 13.6, -93.8, 20.3, -92.1, 27.1, -89.8, 33.9, -87, 40.7, -83.5, 47.4, -79.2, 54.2, -74.1, 61, -68, 67.8 },
      edgeR = { 68, -67.8, 74.1, -61, 79.2, -54.2, 83.5, -47.4, 87, -40.7, 89.8, -33.9, 92.1, -27.1, 93.8, -20.3, 95, -13.6, 95.8, -6.8, 96, 0, 95.8, 6.8, 95, 13.6, 93.8, 20.3, 92.1, 27.1, 89.8, 33.9, 87, 40.7, 83.5, 47.4, 79.2, 54.2, 74.1, 61, 68, 67.8 },
      -- Bolt re-cut 2026-08-27 from the reference art (fastball.png), traced
      -- rather than drawn by eye: boundary trace + Douglas-Peucker, 13 points,
      -- minimum interior angle 91.7 degrees. That angle is the whole point --
      -- the reference bolt is STRICTLY BLOCKY, every corner square. The
      -- previous attempt at this replaced it with a tapered ribbon and was
      -- rejected on sight ("the bolt lost its shape"): at the ball's real size
      -- one design unit is ~0.2 px, so a taper's thin end goes sub-pixel and
      -- smears into a blob. Sized to the largest CENTRED placement whose
      -- filled region stays inside r=90 (the rim stroke covers 91..100) and
      -- outside r=31 (the centre button's ring reaches 30), which lands at
      -- 52 x 61 against the old 64 x 55. Note the usable area here is
      -- landscape -- this skin's button sits at the origin, where the
      -- reference art's sits low with its band -- so the reference bolt's own
      -- portrait proportions cannot simply be scaled in.
      bolt  = { 18.3, -87.7, 22.6, -85.6, 25.8, -66.3, 12.9, -63, 5.4, -58.7, 14, -42.6, -6.4, -30.8, -21.5, -26.5, -25.8, -39.4, -17.2, -42.6, -10.7, -48, -19.3, -64.1, -3.2, -78.1 },
      mark = function(pal)
        C.cc(pal.a1)
        love.graphics.polygon("fill", pal.edgeL)
        love.graphics.polygon("fill", pal.edgeR)
        C.fillPoly(pal.bolt)
      end },
    -- Level Ball adjusted 2026-08-26. Three separate problems, all fixed here:
    --
    -- 1. The V sat ENTIRELY in the yellow. Cap bottom was y=-68 and the V
    --    spanned -58..-18, so the two never touched. It is now centred on the
    --    cap edge -- 16 units of it above on the black, 16 below on the
    --    yellow -- which also lands it near the dome's own vertical centre.
    --
    -- 2. The V was never SYMMETRIC. Vertex at x=-4 with arms at -38 and +32:
    --    it leaned ~3 units left and its two arms differed in length (34 vs
    --    36). Now vertex at x=0 with equal +/-28 arms.
    --
    -- 3. Cap depth 32 -> 40. Note a circular segment's AREA grows much faster
    --    than its depth: this is +38% black area, not +25%.
    --
    -- The V is scaled to 0.80 so it touches nothing. Its tips are a STROKED
    -- polyline 19 wide and the geometry test only records the polyline's
    -- POINTS, not the stroke's corners -- so the test CANNOT catch a collision
    -- here and the corners are computed explicitly instead. At full size the
    -- tips reach r=95 against the rim's inner edge of 91 and read as chopped
    -- off. Current clearances: rim 6.1, band 21.5, centre button 7.5.
    [12] = { top = hex("f0bd2e"), a1 = hex("2a2a2a"), a2 = hex("e0432e"), -- Level: yellow + black cap + big red chevron
      seg = C.cursorSeg(nil, nil, -60),
      mark = function(pal)
        C.cc(pal.a1); love.graphics.polygon("fill", pal.seg)
        C.cc(pal.a2); love.graphics.setLineWidth(19)
        love.graphics.line(-28,-76, 0,-44, 28,-76)
      end },
    -- Lure Ball, built from the two STRAIGHT-ON references (Downloads/
    -- lball1.jpg, lball2.jpg). An earlier pass off the 3/4-rotated sheet got
    -- two things wrong and both had the same cause -- ROTATION SHEAR:
    --   * it read the stripes as tilted 17 degrees. All three agreed (17.0 /
    --     17.4 / 17.5), which made it look verified, but they shared a common
    --     distortion. Straight-on they measure +3.6 / +0.3 / -1.2, i.e.
    --     VERTICAL. Never take an ANGLE off a rotated reference.
    --   * it read the red as a diamond. It is a SECTOR: straight sides
    --     radiating from the ball's centre. Half-angle measures 47.2 (lball1)
    --     and 57.9 (lball2), both dead symmetric; 48 here.
    --
    -- The wedge's outer edge is NOT concentric with the ball -- the teal
    -- sliver between red and rim TAPERS. Measured gap (ball radius minus red
    -- outer radius) by angle:
    --     lball1   0 across -115..-65,  2.1 @-120,  6.0 @-130,  7.8 @-40
    --     lball2   0 across -105..-75,  2.4 @-120,  4.5 @-130,  6.8 @-40
    -- i.e. nil at the top, opening toward the shoulders, widest at the
    -- panel's corner. Modelled as r(t) = 90 - 11 * (|t+90|/48)^2.0,
    -- giving a 1-unit sliver at the top and 12 at the shoulders. (An even-
    -- width ring was built first and rejected -- it reads as a uniform halo,
    -- not the pinched corners the artwork has.)
    --
    -- Stripes sit in the MIDDLE of the red by construction: equal 16-unit
    -- margins to the wedge's outer edge and to the centre button, so they
    -- touch neither. Their measured width in the refs is 4.3-7.1 and is
    -- deliberately not matched -- under a pixel at true cursor size.
    [13] = { top = hex("45b6c4"), a1 = hex("e04a4a"), a2 = hex("eebb29"), -- Lure: teal + red wedge + 3 vertical gold stripes
      wedge = { 0,0, -59,-53, -57,-57, -55,-60, -53,-64, -50,-67, -47,-70, -44,-73, -41,-76, -37,-79, -34,-81, -30,-83, -26,-85, -22,-86, -18,-88, -13,-89, -9,-89, -4,-90, 0,-90, 4,-90, 9,-89, 13,-89, 18,-88, 22,-86, 26,-85, 30,-83, 34,-81, 37,-79, 41,-76, 44,-73, 47,-70, 50,-67, 53,-64, 55,-60, 57,-57, 59,-53 },
      mark = function(pal)
        C.cc(pal.a1); love.graphics.polygon("fill", pal.wedge)
        C.cc(pal.a2); love.graphics.setLineWidth(9)
        love.graphics.line(-15,-74, -15,-46)
        love.graphics.line(0,-74, 0,-46)
        love.graphics.line(15,-74, 15,-46)
      end },
    -- Real artwork has FOUR blue circles, not two: two big ones near the
    -- top corners that genuinely protrude past the silhouette, and two
    -- smaller ones flush on the surface lower down. Top color corrected
    -- from flat grey to the warmer taupe/grey-brown the art actually uses.
    -- Heavy Ball reworked 2026-08-26 against the annotated reference sheet
    -- (Pictures/Capture.PNG), which shows Heavy and Master side by side.
    --
    -- The outer marks are the SAME construction as Master's -- a tangential
    -- lens in `over` with its own contour at rim weight -- but deliberately
    -- smaller (30x13 against Master's 40x15) and further round the side
    -- (-146deg against Master's -135deg). That is exactly how the reference
    -- sheet separates the two balls, and it keeps them distinguishable at
    -- 27px where colour alone is not enough to tell them apart.
    -- How far down the side is capped by the equator band: past about -146deg
    -- the lens's own contour runs into it (at -150 the clearance goes
    -- negative). Current band clearance 4.2.
    --
    -- The two flush circles were genuinely mismatched before -- r=17 at y=-32
    -- on the left against r=15 at y=-36 on the right, so they differed in BOTH
    -- size and height and read as lopsided. They are now identical (r=16) on a
    -- shared baseline (y=-34) and pushed out from +/-30/32 to +/-40. They stay in
    -- `mark`: they are flush in the reference, and `mark` shapes must fit
    -- inside R=100 -- these reach 68.
    [14] = { top = hex("978c7d"), a1 = hex("3a7fd0"), -- Heavy: taupe + 2 flush circles + 2 raised blue rinds
      rindL = { -60.3,-76.9, -62.9,-77.8, -66.2,-77.7, -69.9,-76.4, -73.9,-74.0, -78.0,-70.7, -82.2,-66.6, -86.1,-61.8, -89.6,-56.6, -92.5,-51.2, -94.8,-45.9, -96.3,-40.8, -97.0,-36.2, -96.8,-32.2, -95.8,-29.2, -93.9,-27.1, -91.3,-26.2, -88.0,-26.3, -84.3,-27.6, -80.3,-30.0, -76.2,-33.3, -72.0,-37.4, -68.1,-42.2, -64.6,-47.4, -61.7,-52.8, -59.4,-58.1, -57.9,-63.2, -57.2,-67.9, -57.4,-71.8, -58.5,-74.8 },
      rindR = { 60.3,-76.9, 62.9,-77.8, 66.2,-77.7, 69.9,-76.4, 73.9,-74.0, 78.0,-70.7, 82.2,-66.6, 86.1,-61.8, 89.6,-56.6, 92.5,-51.2, 94.8,-45.9, 96.3,-40.8, 97.0,-36.2, 96.8,-32.2, 95.8,-29.2, 93.9,-27.1, 91.3,-26.2, 88.0,-26.3, 84.3,-27.6, 80.3,-30.0, 76.2,-33.3, 72.0,-37.4, 68.1,-42.2, 64.6,-47.4, 61.7,-52.8, 59.4,-58.1, 57.9,-63.2, 57.2,-67.9, 57.4,-71.8, 58.5,-74.8 },
      mark = function(pal)
        C.cc(pal.a1)
        love.graphics.circle("fill", -40, -34, 16, 18)
        love.graphics.circle("fill", 40, -34, 16, 18)
      end,
      over = function(pal)
        C.cc(C.CURSOR_HW.outline); love.graphics.setLineWidth(18)
        love.graphics.polygon("line", pal.rindL)
        love.graphics.polygon("line", pal.rindR)
        C.cc(pal.a1)
        love.graphics.polygon("fill", pal.rindL)
        love.graphics.polygon("fill", pal.rindR)
      end },
    -- Love Ball reworked 2026-08-26. The heart is an OUTLINE, not a solid.
    -- The sheet's Love ball carries THREE tones on the dome: #f0b0c0 light
    -- pink (the heart's INTERIOR), #f0f0f0 white (its OUTLINE) and #d050a0
    -- magenta (the dome). Ours drew one solid white heart, losing the outline
    -- entirely, on a dome lighter than the reference's magenta.
    --
    -- Drawn as two nested hearts -- outer white, inner light pink -- scaled
    -- about the glyph's own centre (0,-38) so it shrinks in place, leaving
    -- about 6 units of white showing.
    --
    -- Plus the white HIGHLIGHT STROKE inside the heart, drawn as a CAPSULE
    -- (circles at both ends plus a quad) because LOVE's `line` has butt caps
    -- and the reference's stroke is round-ended.
    --
    -- It is VERTICAL and dead centre (x=0), NOT angled. The sheet shows it
    -- tilted 19deg and off to one side, but that sheet is a 3/4 view and this
    -- cursor is drawn straight-on -- the tilt is perspective shear, not
    -- design. This is the same trap that produced a bogus 17deg tilt on the
    -- Lure Ball's stripes: never take an ANGLE off a rotated reference.
    -- Length 26 rather than the measured 38: at full size the capsule's ends
    -- spill out of the inner pink heart and merge into the white outline.
    -- The reference's large oval highlight blob beside it is deliberately NOT
    -- reproduced -- same specular reflection removed from every skin earlier.
    [15] = { top = hex("d84a9c"), a1 = hex("ffffff"), a2 = hex("f0b0c0"), -- Love: magenta + outlined heart + highlight
      mark = function(pal)
        C.cc(pal.a1)
        love.graphics.circle("fill", -23, -54, 26, 18)
        love.graphics.circle("fill", 23, -54, 26, 18)
        love.graphics.polygon("fill", -48,-44, 48,-44, 0,4)
        C.cc(pal.a2)
        love.graphics.circle("fill", -18, -50, 20, 18)
        love.graphics.circle("fill", 18, -50, 20, 18)
        love.graphics.polygon("fill", -37,-43, 37,-43, 0,-5)
        C.cc(pal.a1)
        love.graphics.circle("fill", 0, -32, 4, 12)
        love.graphics.circle("fill", 0, -58, 4, 12)
        love.graphics.polygon("fill", 4,-32, 4,-58, -4,-58, -4,-32)
      end },
    -- Friend Ball reworked 2026-08-26. Four red seeds and a gold dot, where
    -- the reference has FOUR teardrops (ours drew three).
    --
    -- The seeds point INWARD -- tips toward the ball's centre. They pointed
    -- outward at first, which read as a starburst rather than seeds sitting on
    -- the shell.
    --
    -- Placed polar on an arc across the upper dome so all four stay readable.
    -- An earlier scatter put two of them at y=-13/-17 against a band top of
    -- -13, i.e. essentially swallowed. `cursorTear` extends 2.7x its radius in
    -- the pointed direction, so with the tips inward it is d - 2.7*rad that
    -- has to clear the centre button while d + rad clears the rim. Current:
    -- bulbs reach 86 against the rim's 91, tips stop at 36 against the button's
    -- 30, lowest seed clears the band by 9.
    --
    -- The gold mark is a true CIRCLE. It was a wide oval, and a first retry
    -- put it at r=13 centred (0,-78) -- which reaches exactly r=91 and would
    -- have been clipped by the outline.
    [16] = { top = hex("4aa34e"), a1 = hex("e05a3a"), a2 = hex("f0c828"), -- Friend: green + 4 inward seeds + gold dot
      mark = function(pal)
        C.cursorTear(pal.a1, -57, -33, 11, 30)
        C.cursorTear(pal.a1, -31, -58, 11, 62)
        C.cursorTear(pal.a1, 31, -58, 11, 118)
        C.cursorTear(pal.a1, 57, -33, 11, 150)
        C.cc(pal.a2); love.graphics.circle("fill", 0, -74, 12, 20)
      end },
    -- Moon Ball. Design rationale that still holds from the 2026-08-26 pass;
    -- its specific numbers are gone because the 2026-08-27 rework below
    -- replaced every one of them.
    --
    -- CREATIVE LIBERTY on the moon's placement, and the reason matters: on the
    -- real ball the yellow moon sits on the TOP of the sphere, so from this
    -- cursor's straight-on SIDE view it would be a foreshortened sliver along
    -- the top edge and unreadable. It is relocated onto the face of the dome,
    -- above the centre button. This is the one skin where copying the
    -- reference's placement would destroy the design.
    --
    -- The crescent is a POLYGON, not a gold disc with a `pal.top`-coloured
    -- bite circle painted over it. That older trick only works while
    -- everything under the bite is the dome colour -- once the teal reached
    -- mid-dome the bite painted dome-colour over teal and ate the split's
    -- point. Do not reintroduce it.
    -- Moon reworked 2026-08-27 against the reference art (moon2.png), three
    -- changes, all measured rather than guessed:
    --
    -- 1. Dome off near-black. The reference's dark half measures #525154;
    --    #1c1c26 is about three times darker. It also matched COL.panel
    --    (#10121a) closely enough that the ball dissolved into the options
    --    corner preview's own backdrop.
    -- 2. Crescent TRACED from the art, not fitted. A two-circle lune -- what
    --    this skin used to be -- misses that art by ~35% of its own area from
    --    independent starts, because the reference hooks the upper horn. The
    --    old crescent was also only ~60% of the reference's width at the same
    --    height, which is why an earlier proportional +22% enlarge changed
    --    nothing anyone could see: it preserved the wrong aspect ratio.
    --    Scaled about the ball centre to r=90 so the rim stroke does not eat
    --    its outer edge.
    -- 3. The teal/dark split is now a STRAIGHT vertical edge down x=0, not
    --    the reference's zigzag chevron (direct request, 2026-08-27: "its too
    --    small to read the zigzag"). At 40.5 px across, one design unit is
    --    ~0.2 px, so the chevron's teeth were a few pixels each and read as
    --    mush. The panel runs to y=5, past the band's top edge at y=-13, so
    --    the band covers the seam; the vertical edge below y=-30 is covered
    --    by the centre button, both drawn after `mark`.
    [17] = { top = hex("4a4a52"), a1 = hex("2eb8b8"), a2 = hex("f0d43a"), -- Moon: teal/dark split + traced crescent
      moonPanel = { 0, -96, -11.1, -95.4, -22.1, -93.4, -32.7, -90.3, -42.9, -85.9, -52.6, -80.3, -61.5, -73.7, -69.6, -66.1, -76.8, -57.6, -83, -48.3, -88, -38.4, -91.8, -28, -94.5, -17.2, -95.8, -6.1, -95.9, 5, 0, 5 },
      crescent = { 6.7, -89.6, 23.1, -87, 40.7, -80.1, 16.8, -85.9, -3.4, -83.3, -11.4, -73.7, -10.9, -66.2, -3.4, -56.7, 7.7, -50.3, 24.7, -46.6, 54, -50.8, 35.9, -37.6, 10.4, -31.2, -15.6, -33.8, -37.4, -43.9, -38, -72.1, -27.3, -71, -16.2, -82.7 },
      mark = function(pal)
        C.cc(pal.a1); love.graphics.polygon("fill", pal.moonPanel)
        C.cc(pal.a2); C.fillPoly(pal.crescent)
      end },
    [18] = { top = hex("2ec8d6") },
    [19] = { top = hex("8fd43a") },
    -- Slot 20 was CORAL until 2026-08-27, dropped on direct report that it
    -- read as a variant of DEFAULT. The comment this replaces had already
    -- measured exactly that risk and shipped anyway: coral scored CIE76 dE
    -- 17.7 from DEFAULT, against the >25 that normally keeps two domes from
    -- reading as the same skin at this size. Reusing the slot rather than
    -- adding a new one keeps a saved cursor_color of 20 valid instead of
    -- silently falling back to DEFAULT.
    --
    -- Rainbow cycles the dome's HUE rather than naming one colour, which is
    -- also why it cannot collide with anything: it is only ever momentarily
    -- near another skin. Saturation and value are pinned close to the plain-
    -- colour family's own means (0.68 / 0.84) so it belongs with them instead
    -- of glowing next to them.
    --
    -- Driven from `under`, which C.drawStickCursor calls immediately BEFORE
    -- it reads pal.top -- so the table is always current for the frame being
    -- drawn, with no per-frame plumbing and no signature change anywhere.
    -- love.timer is the same clock the rock animation already uses, so the
    -- two stay in step and neither needs a dt passed in. The initial literal
    -- is what hue 0 evaluates to, so a still frame taken before the first
    -- draw still shows a sane colour.
    [20] = { top = { 0.88, 0.246, 0.246 },
      under = function(pal)
        local h = (love.timer.getTime() / C.CURSOR_RAINBOW_SECONDS) % 1
        pal.top[1], pal.top[2], pal.top[3] = C.hsv(h, 0.72, 0.88)
      end },
    [21] = { top = hex("1c1c1c"), a1 = hex("e0392c"), -- Rocket: black top + red R
      mark = function(pal)
        C.cc(pal.a1)
        love.graphics.rectangle("fill", -24, -84, 15, 48)
        love.graphics.rectangle("fill", -9, -84, 31, 26)
        love.graphics.polygon("fill", -3,-58, 9,-58, 24,-36, 12,-36)
        C.cc(pal.top)
        love.graphics.rectangle("fill", -9, -76, 17, 10)
      end },
  }
  local TYPE = {
    NORMAL=hex("9a9a80"), FIRE=hex("e0632c"), WATER=hex("3a86e8"), ELECTRIC=hex("e0b330"),
    GRASS=hex("5fb04a"), ICE=hex("5fc7c7"), FIGHTING=hex("b23a2e"), POISON=hex("8a3a9a"),
    GROUND=hex("c8a84a"), FLYING=hex("7a8fe0"), PSYCHIC=hex("e0508a"), BUG=hex("8a9a20"),
    ROCK=hex("a89440"), GHOST=hex("5a4a8a"), DRAGON=hex("5a4ae0"),
  }

  -- ---------------------------------------------------------------------
  -- Cheap caches: scaled fonts + species sprites
  -- ---------------------------------------------------------------------
  local function getFont(sizePx)
    sizePx = math.max(8, math.floor(sizePx))
    local f = C.fonts[sizePx]
    if not f then f = love.graphics.newFont(sizePx); C.fonts[sizePx] = f end
    return f
  end
  local function getSprite(speciesId, dPoke)
    if C.sprites[speciesId] ~= nil then return C.sprites[speciesId] or nil end
    local def = dPoke[speciesId]
    local rel = def and def.spriteFront
    local img = false
    if rel then local ok, i = pcall(love.graphics.newImage, rel); if ok then img = i end end
    C.sprites[speciesId] = img
    return img or nil
  end

  -- Gym-badge spritesheet (16px wide; each gym badge tile is at (0, i*32+16),
  -- in the same gym order as Badges.list). Cached; nearest-filtered for crisp
  -- pixels when scaled up.
  --
  -- v2.9.2 (Gen 2): VERIFIED, not just hoped, that this needs no code change.
  -- v2.9.x-sandbox: the badge sheet used to load straight from the player's
  -- ROM-derived cache, which the mod sandbox forbids referencing from mod code
  -- (MK301). Instead transforms.lua (see the manifest's assets_transforms) runs
  -- once at install, reads the player's OWN cache, and writes the same sheet to
  -- this mod's derived space; we load it from there. The path is
  -- save/mod-derived/<mod id>/<same relative path the transform wrote>. Nothing
  -- changes visually on Gen 1 -- it's the exact same pixels, just routed through
  -- the sanctioned derive path. On a Gen 2 save (Johto cache has no Kanto badge
  -- sheet) the transform simply writes nothing, this load fails, and the draw
  -- call site (further down) already reads `sheet and b.owned and
  -- sheet.quads[i-1]`, falling back to a plain diamond glyph -- so Gen 2 shows
  -- badge NAME + owned/unowned with text glyphs, exactly as before. A real
  -- Johto badge sheet is still future scope.
  local BADGE_DERIVED = "save/mod-derived/kanto_companion/trainer_card/badges.png"
  local function badgeSheet()
    if C.badgeSheet == nil then
      local ok, img = pcall(love.graphics.newImage, BADGE_DERIVED)
      if ok and img then
        img:setFilter("nearest", "nearest")
        local iw, ih = img:getDimensions()
        local q = {}
        for i = 0, 7 do q[i] = love.graphics.newQuad(0, i * 32 + 16, 16, 16, iw, ih) end
        C.badgeSheet = { img = img, quads = q }
      else
        C.badgeSheet = false
      end
    end
    return C.badgeSheet or nil
  end

  -- Item classification for the Items panel (Gen 1 has no bag pockets, so we
  -- sort by id ourselves). Balls = anything with BALL; Healing = HP/PP/status.
  local HEAL_IDS = {
    POTION=true, SUPER_POTION=true, HYPER_POTION=true, MAX_POTION=true, FULL_RESTORE=true,
    FULL_HEAL=true, ANTIDOTE=true, BURN_HEAL=true, ICE_HEAL=true, AWAKENING=true, PARLYZ_HEAL=true,
    REVIVE=true, MAX_REVIVE=true, ETHER=true, MAX_ETHER=true, ELIXER=true, MAX_ELIXER=true,
    FRESH_WATER=true, SODA_POP=true, LEMONADE=true,
  }
  local function isBallItem(id) return id:find("BALL", 1, true) ~= nil end
  local function isHealItem(id, def)
    if HEAL_IDS[id]
      or id:find("POTION", 1, true) or id:find("HEAL", 1, true) or id:find("REVIVE", 1, true)
      or id:find("RESTORE", 1, true) or id:find("ETHER", 1, true) or id:find("ELIXER", 1, true) then
      return true
    end
    -- v2.9.5 Gen2 bugfix (Tier 4 of the Session-11 audit): Gen2-exclusive
    -- berries (Bitter/Burnt/Ice/Mint/Miracle/Mystery/PRZCure/PSNCure
    -- Berry, Berry, Gold Berry) don't exist as Gen1 item ids at all, so
    -- none of the checks above ever matched them -- silently dropped
    -- from this panel. Gen1's own real item data has no heldEffect field
    -- at all (confirmed: a real Gen1 POTION entry has only id/index/
    -- name/price/source), so this branch is a pure Gen2 addition, zero
    -- Gen1 behavior change. Verified against every real Gen2 berry in
    -- the imported data, not guessed: status-cure berries use
    -- HELD_HEAL_<status>, HP-restore berries use HELD_BERRY, the
    -- PP-restoring MysteryBerry uses HELD_RESTORE_PP.
    local he = def and def.heldEffect
    return he ~= nil and (he:find("HEAL", 1, true) or he:find("RESTORE", 1, true) or he == "HELD_BERRY") or false
  end

  -- ---------------------------------------------------------------------
  -- STATE: read game.save into a small table we can draw (ported/trimmed
  -- from the streaming snapshot; no JSON, keeps species ids for sprites).
  -- ---------------------------------------------------------------------
  local function currentBattle()
    local g = C.game; local stk = g and g.stack
    if not (stk and stk.states) then return nil end
    -- v2.9.5 (Gen 2 root-cause fix, see C.Gen2BattleScreen's own comment
    -- above for the full explanation of why the old single-check version
    -- was always false on Gen 2).
    if C.Gen2BattleScreen then
      for i = #stk.states, 1, -1 do
        local st = stk.states[i]
        if getmetatable(st) == C.Gen2BattleScreen then
          local b = st.battle
          if not b then return nil end
          -- Gen 2's real object shape is TWO levels removed from Gen 1's:
          -- the pushed screen (st) is not the battle logic (st.battle),
          -- and even there .player/.enemy ARE the mon directly -- no
          -- Gen-1-style {mon=...} wrapper (confirmed against
          -- src/battle/gen2/Battle.lua) -- the same "no battler wrapper"
          -- shape C.recordKO already navigates correctly for
          -- battle.fainted elsewhere in this file, just not here before
          -- now. Normalized into the SAME shape Gen 1's real BattleState
          -- already has (kind/trainer/player.mon/enemy.mon), so every
          -- existing downstream read keeps working unmodified for both
          -- generations instead of scattering a gen-check into every
          -- call site. Read-only view -- kanto never writes back to a
          -- currentBattle() result anywhere in this file (checked).
          -- Deliberately does NOT synthesize .shownHP (Gen 1's own
          -- per-frame HP-bar-animation field, no real Gen 2 equivalent
          -- found) or the growInScale/introSlide/introBalls/
          -- enemySendingOut animation-timing fields (Gen-1-only concepts,
          -- confirmed absent from Gen 2's real source) -- every consumer
          -- of those already treats a missing value as "skip this specific
          -- check/fall back to the independent animation" by design (see
          -- enemyHudVisible's own existence guards and the HP-sync's
          -- `and battle.enemy.shownHP` checks), so leaving them absent is
          -- a safe degrade, not a guess.
          return {
            kind = b.wild and "wild" or "trainer",
            trainer = b.trainer,
            showEnemyTrainer = st.showEnemyTrainer,
            player = b.player and { mon = b.player } or nil,
            enemy = b.enemy and { mon = b.enemy } or nil,
          }
        end
      end
      return nil
    end
    if not C.BattleState then return nil end
    for i = #stk.states, 1, -1 do
      if getmetatable(stk.states[i]) == C.BattleState then return stk.states[i] end
    end
    return nil
  end

  -- v62: pure helpers for the battle-time party auto-move (see
  -- drawOverlay). Split out and kept argument-only (no C./love reads) so
  -- they're independently testable in a plain Lua runtime, same
  -- verification approach as every other feature this session.
  local function rectsOverlap(aL, aT, aR, aB, bL, bT, bR, bB)
    return aL < bR and aR > bL and aT < bB and aB > bT
  end
  -- The vanilla enemy HUD (name/level/HP box) is a fixed GB-pixel box,
  -- expressed here as a FRACTION of the viewport rather than trusting
  -- any particular GB-pixel-to-LOVE-unit scale field, so it's correct
  -- regardless of how the engine derives vpw/vph internally. Two real
  -- layouts exist, confirmed directly against the engine's own source --
  -- not just the classic one:
  --  - classic (BattleState:drawHUDs): (0,0) to (88,32) of a 160x144
  --    screen -- 88/160 = 55% width, 32/144 = 22.2% height.
  --  - wide (src/battle/WideBattle.lua's own drawHUDs, active whenever
  --    the player has the VANILLA "BATTLE LAYOUT: WIDE" save option on,
  --    `battle:isWideBattleLayout()` -- unrelated to this mod's own
  --    widescreen overlay): drawStatusPanel's box is 16 tiles = 128px of
  --    a 304x144 screen -- 128/304 = 42.1% width, height fraction is
  --    unchanged (still 32/144, both screens are 144 tall). Only width
  --    differs between the two; passing the wrong one previously made
  --    the collision box ~13 points too wide whenever a player had wide
  --    battle layout on, which never failed to move when it should have,
  --    just moved a bit more readily than strictly necessary.
  -- Returns the box in this file's own design-unit space (divided by s,
  -- matching every other coordinate in drawOverlay) so it compares
  -- directly against panelCfg positions; nil if letterbox data isn't
  -- available yet (e.g. the very first frame, before render.letterbox
  -- has fired once).
  --
  -- v2.9.2 (Gen 2): CONFIRMED accurate for Gen 2 too, against real current
  -- source (src/ui/gen2/BattleState.lua + BattleHud.lua) -- Gen 2 has NO "wide
  -- battle layout" concept at all (only ever draws in the classic 160x144
  -- space), and its enemy HUD frame (`drawFrame(1,3,10,false)` fallback path)
  -- is 10 tiles wide starting at column 1 -> x:[8,88] of 160, y:[0,32] of 144
  -- -- right edge and height are an EXACT match to the classic fraction below
  -- (88/160=0.55, 32/144=0.2222); the left edge differs by one tile (8px),
  -- which only makes this box a touch more conservative on Gen 2, never less
  -- -- safe either way for a "don't overlap this" check. The call site passes
  -- `false` for `wideLayout` on Gen 2 (that option doesn't exist there), which
  -- is exactly correct, not a fallback guess.
  local function enemyHudDesignRect(lb, s, wideLayout)
    if not (lb and lb.vpw and lb.vph and lb.vpw > 0 and lb.vph > 0 and s and s > 0) then
      return nil
    end
    local wFrac = wideLayout and (128 / 304) or 0.55
    local left, top = lb.ox / s, lb.oy / s
    return left, top, left + (wFrac * lb.vpw) / s, top + (0.2222 * lb.vph) / s
  end
  -- v86: the vanilla PLAYER HUD (name/level/HP box) -- the mirror of the
  -- enemy one above, at the BOTTOM-RIGHT of the viewport. Positions confirmed
  -- directly against the engine's own drawHUDs (classic BattleState:5070-5091
  -- draws it at ~x72..160, y56..96 of a 160x144 screen; wide WideBattle
  -- drawStatusPanel(...,184,56,true) is a 15x5-tile box at x184..304, y56..96
  -- of a 304x144 screen) -- not guessed. Both hug the viewport's right edge,
  -- so `right` is always the viewport right edge; only the left fraction and
  -- viewport width differ between the two layouts. Attached to C (not a new
  -- top-level local) because this factory function is at Lua's 200-local
  -- ceiling (see the v85 route-icon note). Same design-unit space and
  -- nil-until-letterbox contract as enemyHudDesignRect.
  -- v2.9.3 (Gen 2 safety): callers pass wideLayout only after existence-checking
  -- liveBattle.isWideBattleLayout (a Gen 1-only method), same guard the enemy
  -- dodge uses -- so this never receives a call that would have crashed on Gen 2.
  C.playerHudDesignRect = function(lb, s, wideLayout)
    if not (lb and lb.vpw and lb.vph and lb.vpw > 0 and lb.vph > 0 and s and s > 0) then
      return nil
    end
    local lFrac  = wideLayout and (184 / 304) or (72 / 160)
    local left   = (lb.ox + lFrac * lb.vpw) / s
    local right  = (lb.ox + lb.vpw) / s
    local top    = (lb.oy + (56 / 144) * lb.vph) / s
    local bottom = (lb.oy + (96 / 144) * lb.vph) / s
    return left, top, right, bottom
  end
  -- v66: on direct request -- the party auto-compact/move used to fire
  -- the instant st.battle went true, well before the vanilla enemy HUD
  -- actually appears (there's an ~80-frame intro slide, then a 12-frame
  -- grow-in scale animation, before it draws at all), which could read
  -- as the overlay reacting to nothing and confuse a player into
  -- fiddling with it early. Rather than guess a delay, this mirrors the
  -- ENGINE'S OWN gate for when it draws that HUD, field for field --
  -- confirmed directly against BattleState:drawHUDs's real condition and
  -- the fields it reads (BattleState.lua ~4984-4989), not inferred:
  --   self.enemy and not self.showEnemyTrainer and not self.enemySendingOut
  --   and not self:growInScale(self.enemy) and slide == 0
  --   and not self.introBalls and not self.enemy.fainted
  -- `slide` itself isn't a stored field, but its source is (`local slide
  -- = (self.introSlide or 0) * 2` in drawClassic) -- so `slide == 0` is
  -- exactly `self.introSlide` being nil or 0, checked directly here.
  -- `battle` is the real, live BattleState instance from currentBattle()
  -- (this file's own accessor, same one buildState() already uses) --
  -- every field/method below is read from that same object the engine
  -- itself is about to draw from this frame, not a guess or a copy.
  local function enemyHudVisible(battle)
    if not (battle and battle.enemy) then return false end
    if battle.showEnemyTrainer then return false end
    if battle.enemySendingOut then return false end
    -- v2.9.5 (Gen 2 crash guard): growInScale/introSlide/introBalls/
    -- enemySendingOut are Gen-1-only concepts -- confirmed absent from Gen
    -- 2's real battle/screen source, no equivalent field or method found
    -- anywhere in src/battle/gen2 or src/ui/gen2. An unguarded
    -- battle:growInScale(...) call would be "attempt to call a nil value"
    -- the instant a real Gen 2 battle starts, now that currentBattle() can
    -- actually return something non-nil there (see its own comment).
    -- Existence-guarded, the same defensive shape this file already uses
    -- for isWideBattleLayout elsewhere -- Gen 2 simply doesn't gate on
    -- these (no data to gate with, so the HUD is treated as immediately
    -- visible rather than waiting out an animation this file can't see),
    -- Gen 1 keeps its exact existing precise animation-timing gate
    -- unchanged.
    if battle.growInScale and battle:growInScale(battle.enemy) then return false end
    if battle.introSlide and battle.introSlide ~= 0 then return false end
    if battle.introBalls then return false end
    if battle.enemy.fainted then return false end
    return true
  end

  local function buildState()
    local game = C.game
    local save = game and game.save
    if not save then return nil end
    local data  = game.data or {}
    local dPoke = data.pokemon or {}
    local dMove = data.moves or {}
    local dItem = data.items or {}
    C.dPoke = dPoke

    local function dispTypes(raw)
      local o = {}
      for _, t in ipairs(raw or {}) do o[#o+1] = (C.TypeChart and C.TypeChart.displayName(t)) or t end
      return o
    end
    local function brief(mon)
      if not mon then return nil end
      local d = dPoke[mon.species]
      return {
        name = mon.nickname or (d and d.name) or tostring(mon.species),
        species = mon.species, level = mon.level, hp = mon.hp,
        maxhp = mon.stats and mon.stats.hp, status = mon.status or "OK",
        types = dispTypes(d and d.types),
      }
    end

    local battle = currentBattle()
    local activeMon = battle and battle.player and battle.player.mon or nil
    local teamTypes = {}

    -- party
    local party = {}
    for i, mon in ipairs(save.party or {}) do
      local def = dPoke[mon.species]
      local moves = {}
      for _, mv in ipairs(mon.moves or {}) do
        local md = dMove[mv.id]
        moves[#moves+1] = { name = (md and md.name) or mv.id, pp = mv.pp, maxpp = md and md.pp }
      end
      local raw = (def and def.types) or {}
      if #raw > 0 then teamTypes[#teamTypes+1] = raw end
      local xpProg, xpNext
      if C.Growth and def and def.growthRate and mon.exp and mon.level then
        local rates = data.growth_rates
        local cur = C.Growth.expForLevel(def.growthRate, mon.level, rates)
        local nxt = C.Growth.expForLevel(def.growthRate, mon.level + 1, rates)
        if mon.level >= 100 or nxt <= cur then xpProg, xpNext = 1, 0
        else xpProg = math.max(0, math.min(1, (mon.exp - cur)/(nxt - cur))); xpNext = math.max(0, nxt - mon.exp) end
      end
      party[i] = {
        slot = i, name = mon.nickname or (def and def.name) or tostring(mon.species),
        species = mon.species, level = mon.level, hp = mon.hp,
        maxhp = mon.stats and mon.stats.hp, status = mon.status or "OK",
        types = dispTypes(raw), moves = moves, exp = mon.exp,
        xpProgress = xpProg, xpToNext = xpNext,
        active = (activeMon ~= nil and mon == activeMon) or nil,
      }
    end

    -- trainer
    local badges, badgeCount = {}, 0
    if C.Gen2FieldMoves then
      -- Gen 2: real 16 Johto+Kanto badges, two boolean-flag stores -- see
      -- C.Gen2FieldMoves's own init comment for the full why. A save may key
      -- either store by name OR by its 1-8 position (TrainerCard.lua's own
      -- drawBadgeSprites tolerates both: "a save may key the array either
      -- way"), so this checks both forms too rather than assuming one.
      local player = save.player or {}
      local function addBadgeGroup(store, names)
        local ownedT = player[store]
        for idx, name in ipairs(names) do
          local owned = (type(ownedT) == "table") and (ownedT[name] == true or ownedT[idx] == true) or false
          if owned then badgeCount = badgeCount + 1 end
          badges[#badges + 1] = { name = name:sub(1,1)..name:sub(2):lower(), owned = owned }
        end
      end
      addBadgeGroup("badges", C.Gen2FieldMoves.JOHTO_BADGES)
      addBadgeGroup("kantoBadges", C.Gen2FieldMoves.KANTO_BADGES)
    elseif C.Badges and data then
      for i, e in ipairs(C.Badges.list(data)) do
        local owned = save.inventory[C.Badges.itemFor(e)] and true or false
        if owned then badgeCount = badgeCount + 1 end
        local id = e.id or ("BADGE"..i); local base = id:gsub("BADGE$", "")
        badges[i] = { name = e.name or (base:sub(1,1)..base:sub(2):lower()), owned = owned }
      end
    end
    local dex = save.pokedex or {}
    -- v2.9.5 (Gen 2 Tier-2 audit fix): the caught-species flag table is
    -- `dex.owned` on Gen 1 but `dex.caught` on Gen 2 -- confirmed against
    -- the real engine's own save init/scrub code (src/core/SaveData.lua's
    -- `pokedex = { seen = {}, owned = {} }` vs src/core/gen2/Save.lua's
    -- `pokedex = { seen = {}, caught = {} }`, and SaveData.lua's own
    -- continue-screen summary already branches on `gen2` to read the right
    -- one). `dex.owned` was previously read unconditionally, so every
    -- caught-ball/dex-count display silently stayed at 0/false on Gen 2.
    -- Normalized once here so every reader below stays generation-agnostic.
    local dexCaughtTbl = dex.owned or dex.caught or {}
    local function countTrue(t) local n=0; if t then for _,v in pairs(t) do if v then n=n+1 end end end; return n end
    local dexTotal = 0
    for _, d in pairs(dPoke) do if d.dex and d.dex > dexTotal then dexTotal = d.dex end end
    local trainer = {
      -- v2.9.2 (Gen 2): save.money moved to save.player.money on Gold -- confirmed
      -- against the real Gen2Compat.lua "moved fields" table (raw source, not the
      -- announcement). Read both; Gen 1 still only ever has the flat field.
      name = (save.player and save.player.name) or "",
      money = save.money or (save.player and save.player.money) or 0,
      -- v2.9.2 (Gen 2): save.playTime is a {hours,minutes,seconds,frames}
      -- table on Gold, not a flat number like Gen 1 -- confirmed against a
      -- real Gen2 save file. math.floor() on the raw table threw an
      -- uncaught error here, which silently killed buildState() every
      -- frame (pcall-caught in C.onFrame, logged only via mod.log with no
      -- discoverable file) -- the actual cause of the Gen2 blank-overlay
      -- bug. Converts to total seconds first, matching what fmtTime()
      -- already expects on both generations.
      version = save.version or "", playTime = math.floor(type(save.playTime) == "table"
        and ((save.playTime.hours or 0) * 3600 + (save.playTime.minutes or 0) * 60 + (save.playTime.seconds or 0))
        or (save.playTime or 0)),
      badges = badges, badgeCount = badgeCount, dexSeen = countTrue(dex.seen),
      dexOwned = countTrue(dexCaughtTbl), dexTotal = dexTotal > 0 and dexTotal or nil,
      partyCount = #(save.party or {}),
    }

    -- route (grass + surf)
    local BK = (data.constants and data.constants.encounterBuckets)
      or { 51,102,141,166,191,216,229,242,253,256 }
    local function encTable(part)
      if not part or not part.slots or (part.rate or 0) == 0 then return nil end
      local bk = part.buckets or BK
      local agg, order, prev = {}, {}, 0
      for i, slot in ipairs(part.slots) do
        local top = bk[i] or 256; local w = top - prev; prev = top
        if slot and slot.species then
          local a = agg[slot.species]
          if not a then a = { species = slot.species, weight = 0, minL = slot.level, maxL = slot.level }; agg[slot.species]=a; order[#order+1]=a end
          a.weight = a.weight + w; a.minL = math.min(a.minL, slot.level); a.maxL = math.max(a.maxL, slot.level)
        end
      end
      -- Ported from weather-compat (display redesign): pct is now the TRUE
      -- absolute per-step chance of this exact species, not the old
      -- conditional-on-an-encounter number -- P(species) = P(any
      -- encounter) * P(species | encounter) = (part.rate/256) *
      -- (a.weight/256). Computed from the raw 0-256 values and rounded
      -- once at the end, not by multiplying two already-rounded
      -- percentages together (compounds rounding error for no reason).
      -- This is what let the separate "X% / step" line go away entirely
      -- -- one honest number per species instead of two different kinds
      -- of percentage that looked identical on screen.
      local list = {}
      for _, a in ipairs(order) do
        local d = dPoke[a.species]
        list[#list+1] = { name = (d and d.name) or tostring(a.species), species = a.species,
          pct = math.floor((part.rate or 0) * a.weight / 65536 * 100 + 0.5),
          minLevel = a.minL, maxLevel = a.maxL,
          -- v2.9.5: battled/caught read straight off the same save.pokedex
          -- flags the Trainer panel's dex-seen/dex-owned counts already use
          -- (global per-save, same as vanilla's own Pokedex -- seeing/
          -- catching this species on ANY route marks it here too, not just
          -- this one). koCount is the mod's own tally, see
          -- C.koCountFor/C.recordKO up top.
          battled = (dex.seen and dex.seen[a.species]) and true or false,
          caught = (dexCaughtTbl[a.species]) and true or false,
          koCount = C.koCountFor(save, a.species) }
      end
      table.sort(list, function(x,y) return x.pct > y.pct end)
      -- No top-level `rate` field anymore -- nothing reads it now that
      -- each species already carries its own true absolute percentage.
      return { species = list }
    end
    local route
    local ov = game.overworld
    local mapId = ov and ov.map and ov.map.id
    if mapId then
      route = { name = (mapId:lower():gsub("_"," "):gsub("(%a)(%w*)", function(a,b) return a:upper()..b end)) }
      local encRoot = data.encounters or {}
      local enc = encRoot[mapId]
      -- v2.9.5 Gen2 bugfix, 3rd attempt -- the real root cause, found via
      -- an on-device diagnostic HUD after 2 blind fixes both failed:
      -- `map=ROUTE_29 enc=false` proved `mapId` was correct all along but
      -- `data.encounters[mapId]` itself was never finding anything on
      -- Gen2 -- the previous two attempts both assumed Gen2 used the SAME
      -- map-keyed-then-kind organization as Gen1 (data.encounters[mapId]
      -- .grass/.slots), just with a different per-map shape. Confirmed
      -- against the real mod-facing schema instead of the raw ROM-export
      -- file this time (src/mods/Schemas.lua's own gen2GrassRow/
      -- gen2WaterRow + its own comment: "Gold keys wild encounters by
      -- encounter KIND first and by map second... there is no per-map
      -- record to key the registry by"): Gen2 mod data is
      -- data.encounters.grass[mapId] / data.encounters.water[mapId] --
      -- KIND-keyed-then-map, not map-keyed at all. This is exactly why
      -- water worked and grass didn't: `encRoot.water[mapId]` (written
      -- for the water fallback below) happens to already be the correct
      -- Gen2 access pattern, while `encRoot[mapId]` (this line, inherited
      -- from Gen1's actual shape) was never going to find a Gen2 route.
      if enc and (enc.grass or enc.water) then
        route.grass = encTable(enc.grass); route.water = encTable(enc.water)
      else
        local grassRow = encRoot.grass and encRoot.grass[mapId]
        if grassRow and grassRow.slots then
          -- Time-of-day picking (schema-confirmed: gen2GrassRow.rates/
          -- .slots are both maps of MORN/DAY/NITE -> data, exactly the
          -- shape already coded below). `os.date` confirmed sandbox-safe
          -- (src/mods/Sandbox.lua's own SAFE_OS allowlist includes
          -- "date"). Mirrors the real engine's Clock.hour (host clock +
          -- this save's stored RTC offset) and Palettes.clockDaytime's
          -- exact 4/10/18-hour MORN/DAY/NITE thresholds verbatim.
          local hHour, hMin = tonumber(os.date("%H")) or 0, tonumber(os.date("%M")) or 0
          local hostMin = (hHour * 60 + hMin) % 1440
          local offset = (save.rtc and tonumber(save.rtc.startMinute)) or 0
          local gameHour = math.floor(((hostMin + offset) % 1440) / 60)
          local daytime = (gameHour < 4) and "NITE" or (gameHour < 10) and "MORN" or (gameHour < 18) and "DAY" or "NITE"
          local part = grassRow.slots[daytime]
            and { rate = grassRow.rates and grassRow.rates[daytime], slots = grassRow.slots[daytime] }
          route.grass = encTable(part)
        end
      end
      -- Gen2 water/surf: same kind-keyed-then-map organization as grass
      -- above, already correctly written this way from the start (see
      -- the schema comment above for why) -- already in the exact
      -- {rate,slots} shape encTable expects, no time-of-day split.
      if not route.water and encRoot.water and encRoot.water[mapId] then
        route.water = encTable(encRoot.water[mapId])
      end
      -- Warm the sprite cache for everything that can wild-encounter on this
      -- route, while we're just standing in the overworld -- not at the
      -- moment a battle actually starts. getSprite() is the only place that
      -- calls love.graphics.newImage(); without this, the very first time
      -- that runs for a given species is mid battle-transition, which
      -- stacks a fresh texture upload on top of whatever the base game is
      -- already doing to enter battle. Doing it here instead means by the
      -- time a wild battle triggers, every possible opponent on the current
      -- route already has its sprite decoded and cached, so battle() (line
      -- ~774) just looks it up -- no image load happens on that frame.
      -- Cheap to call every buildState refresh: getSprite no-ops once an
      -- id is cached.
      local function preloadRouteSprites(encResult)
        if not (encResult and encResult.species) then return end
        for _, sp in ipairs(encResult.species) do getSprite(sp.species, dPoke) end
      end
      preloadRouteSprites(route.grass)
      preloadRouteSprites(route.water)

      -- Weather-provider read (ported from weather-compat). Entirely
      -- optional -- with no provider registered this whole block is a
      -- no-op and route.grass/route.water stay exactly the plain vanilla
      -- data above, same as every prior kanto release. pcall-wrapped
      -- because the provider is third-party code we don't control; a bad
      -- or crashing provider degrades to plain vanilla display, it never
      -- takes the overlay down with it.
      if C.weatherProvider then
        local ok, result = pcall(C.weatherProvider.route, C.weatherProvider, mapId)
        if ok and type(result) == "table" then
          -- The weather tag is set unconditionally, independent of
          -- whether this map even has a grass/water table -- a city with
          -- "No wild encounters here" still shows current weather, same
          -- as a route does. route()'s draw function reads this.
          --
          -- result.weather is the provider's own internal code
          -- (RAIN_HEAVY, DUSTSTORM, ...), not something a player should
          -- ever see -- mapped through a clean-name table, built once and
          -- cached on C (not rebuilt every buildState() frame). Sourced
          -- directly from Weather FX 4.26.0's own lib/Types.lua id list,
          -- not guessed. A weather id this table doesn't recognize (a
          -- future addition on their side we haven't mapped yet) falls
          -- back to the raw code rather than showing nothing.
          C.weatherNames = C.weatherNames or {
            CLEAR = "Clear", SUNNY = "Sunny", HARSH_SUN = "Harsh Sunlight",
            RAIN_LIGHT = "Rain", RAIN_HEAVY = "Heavy Rain", HEAVY_RAIN = "Torrential Rain",
            STORM = "Thunderstorm", SNOW_LIGHT = "Snow", BLIZZARD = "Blizzard",
            HAIL = "Hail", SANDSTORM = "Sandstorm", STRONG_WINDS = "Strong Winds",
            PLAIN_FRONT = "Overcast", VERDANT_RAIN = "Verdant Rain", BRAWL_WIND = "Fighting Gale",
            SMOG = "Smog", DUSTSTORM = "Duststorm", FLOCKSTORM = "Flock Storm",
            SWARM = "Swarm", HAUNTED_MIST = "Haunted Mist", DRAGONSTORM = "Dragonstorm",
            SLEET = "Sleet", THUNDERSNOW = "Thundersnow", ASHFALL = "Ashfall",
            HEATWAVE = "Heatwave", GALE = "Gale", PSYSTORM = "Psystorm",
            MIST = "Mist", FOG = "Fog",
          }
          route.weatherTag = result.weather and (C.weatherNames[result.weather] or result.weather)
          -- Converts a provider "forecast" part (species/pct/minLevel/
          -- maxLevel -- pct here is CONDITIONAL, the chance it's this
          -- species given an encounter already happened, same convention
          -- our own weather-side code uses; rate is the raw 0-256-scale
          -- overall step rate) into kanto's own species list shape, with
          -- pct converted to the TRUE absolute per-step chance -- same
          -- redesign as encTable() above, so both sources (plain vanilla
          -- and weather-biased) always speak the same one-number-per-
          -- species language by the time drawEncSection sees them.
          local function fromForecast(part)
            if not part or not part.species then return nil end
            local rate = part.rate or 0
            local list = {}
            for _, sp in ipairs(part.species) do
              list[#list + 1] = {
                name = (dPoke[sp.species] and dPoke[sp.species].name) or tostring(sp.species),
                species = sp.species, pct = math.floor(rate * (sp.pct or 0) / 256 + 0.5),
                minLevel = sp.minLevel, maxLevel = sp.maxLevel,
              }
            end
            return { species = list }
          end
          if result.forecast then
            if result.forecast.grass then route.grass = fromForecast(result.forecast.grass) end
            if result.forecast.water then route.water = fromForecast(result.forecast.water) end
          end
          -- Weather-only species (e.g. a storm-form variant) merge into
          -- whichever list is currently active -- the forecast-biased one
          -- above if present, else the plain vanilla one -- so they're
          -- never a separate, unlabeled bucket. Deliberately no visual
          -- marker distinguishing a variant row yet (matching icons are
          -- a separate follow-up); its own distinct name already reads
          -- as unusual on the list. v.encounterPct is ALSO conditional
          -- (base species' conditional pct times the variant's own
          -- chance), so it needs the same rate multiply as fromForecast
          -- above -- rate is passed in explicitly since target no longer
          -- carries a .rate field to read it back from.
          local function mergeVariants(target, variants, rate)
            if not (target and target.species and variants) then return end
            for _, v in ipairs(variants) do
              target.species[#target.species + 1] = {
                name = v.name or tostring(v.species), species = v.species,
                pct = math.floor((rate or 0) * (v.encounterPct or 0) / 256 + 0.5),
                minLevel = v.minLevel, maxLevel = v.maxLevel,
              }
            end
            table.sort(target.species, function(a, b) return a.pct > b.pct end)
          end
          if result.variants then
            -- Prefer the forecast's own rate (weather-adjusted, when a
            -- bias is active); fall back to the plain vanilla rate this
            -- map already had, since variants can exist even when
            -- result.forecast itself is nil (no active type bias, but a
            -- weather-only species can still be configured for this map).
            local grassRate = (result.forecast and result.forecast.grass and result.forecast.grass.rate)
              or (enc and enc.grass and enc.grass.rate) or 0
            local waterRate = (result.forecast and result.forecast.water and result.forecast.water.rate)
              or (enc and enc.water and enc.water.rate) or 0
            mergeVariants(route.grass, result.variants.grass, grassRate)
            mergeVariants(route.water, result.variants.water, waterRate)
          end
        end
      end
    end

    -- battle + matchup + catch
    local battleBlock
    if battle then
      local pMon, eMon = battle.player and battle.player.mon, battle.enemy and battle.enemy.mon
      local myTypes = (pMon and dPoke[pMon.species] and dPoke[pMon.species].types) or {}
      local enTypes = (eMon and dPoke[eMon.species] and dPoke[eMon.species].types) or {}
      local matchup
      if C.TypeChart and pMon and eMon then
        if not C.tcReady then C.tcReady = pcall(C.TypeChart.load, data) end
        local ok, res = pcall(function()
          local eff, disp, cat = C.TypeChart.effectiveness, C.TypeChart.displayName, C.TypeChart.category
          local function has(l,t) for _,x in ipairs(l) do if x==t then return true end end return false end
          local myMoves, bi, bs = {}, nil, -1
          for _, mv in ipairs(pMon.moves or {}) do
            local md = dMove[mv.id]
            if md then
              local pow = md.power or 0
              local st = (md.category == "status") or pow == 0
              local mult = eff(md.type, enTypes); local stab = has(myTypes, md.type)
              myMoves[#myMoves+1] = { name = md.name or mv.id, type = disp(md.type),
                power = pow > 0 and pow or nil, pp = mv.pp, maxpp = md.pp,
                mult = mult, stab = stab or nil, status = st or nil }
              if not st and mult > 0 then local sc = mult*pow*(stab and 15 or 10); if sc > bs then bs=sc; bi=#myMoves end end
            end
          end
          if bi then myMoves[bi].best = true end
          local threats = {}
          for _, mv in ipairs(eMon.moves or {}) do
            local md = dMove[mv.id]
            if md and md.category ~= "status" and (md.power or 0) > 0 then
              local mult = eff(md.type, myTypes)
              if mult > 10 then threats[#threats+1] = { name = md.name or mv.id, type = disp(md.type), mult = mult } end
            end
          end
          table.sort(threats, function(a,b) return a.mult > b.mult end)
          local mS, eS = pMon.stats and pMon.stats.speed, eMon.stats and eMon.stats.speed
          local faster; if mS and eS then faster = (mS>eS) and "you" or ((eS>mS) and "them" or "tie") end
          return { speed = { faster = faster }, myMoves = myMoves, threats = threats }
        end)
        if ok then matchup = res end
      end
      -- catch odds (wild)
      local catch
      if battle.kind == "wild" and eMon then
        local okc, res = pcall(function()
          local eDef = dPoke[eMon.species]; local rate = eDef and eDef.catchRate
          local maxhp = eMon.stats and eMon.stats.hp; local hp = eMon.hp
          if not (rate and maxhp and hp) then return nil end
          local s = eMon.status
          local sb = (s=="SLP" or s=="FRZ") and 25 or (s and 12 or 0)
          local bd = data.balls
          local function def(id) return (bd and bd[id]) or (C.Catching and C.Catching.BALLS and C.Catching.BALLS[id]) end
          local function odds(d)
            if not d then return nil end
            if d.autoCatch then return 100 end
            local rm, hf = d.randMax, d.hpFactor; if not (rm and hf) then return nil end
            local N = rm + 1; local hq = math.max(1, math.floor(hp/4))
            local f = math.min(255, math.floor(math.floor(maxhp*255/hf)/hq))
            local p1 = sb/N; local hi = math.min(rm, rate+sb)
            local pp = math.max(0, hi-sb+1)/N; return (p1 + pp*(f+1)/256)*100
          end
          local list = {}
          for _, id in ipairs({ "POKE_BALL","GREAT_BALL","ULTRA_BALL","SAFARI_BALL","MASTER_BALL" }) do
            local qty = (save.inventory and save.inventory[id]) or 0; local d = def(id)
            if d and qty > 0 then local it = dItem[id]; list[#list+1] = { name = (it and it.name) or id, pct = odds(d), qty = qty } end
          end
          if #list == 0 then local d = def("POKE_BALL"); if d then local it = dItem["POKE_BALL"]; list[1] = { name = (it and it.name) or "POKE_BALL", pct = odds(d), qty = 0 } end end
          return (#list > 0) and list or nil
        end)
        if okc then catch = res end
      end
      -- v2.9.5: caught shown next to the opponent's name on the BATTLE
      -- panel -- distinct from the route panel's own battled/caught/
      -- koCount tally above (that's the encounter-list view; this is the
      -- live battle screen). Reuses the exact same dexCaughtTbl the route
      -- tally and the Trainer panel's dex-owned count read. Scoped to the
      -- enemy only -- caught is always trivially true for your own active
      -- party mon, not worth showing. Reads the normalized dexCaughtTbl
      -- local (dex.owned on Gen 1, dex.caught on Gen 2 -- see its own
      -- definition up top), not dex.owned directly.
      -- v2.10.0, shelved on direct request: a shiny indicator here used
      -- to also exist, going through the base engine's own DV-derived
      -- Stats.isShiny() -- removed because the real intent was for this
      -- to eventually integrate with a separate shiny-Pokemon mod's own
      -- notion of "shiny" once one is installed, not the base engine's
      -- (mostly invisible, ~1/8192) mechanic. Caught is unaffected.
      local enemyBrief = brief(eMon)
      if enemyBrief and eMon then
        enemyBrief.caught = (dexCaughtTbl[eMon.species]) and true or false
      end
      battleBlock = { kind = battle.kind, trainer = battle.trainer and battle.trainer.name or nil,
        enemy = enemyBrief, active = brief(pMon), matchup = matchup, catch = catch }
    end

    -- Items: Balls + Healing (for the right-column items panel), in bag order.
    local balls, heals, seen = {}, {}, {}
    local function addItem(id)
      local qty = save.inventory[id]; if not qty or qty <= 0 then return end
      local nm = (dItem[id] and dItem[id].name) or id
      if isBallItem(id) then balls[#balls + 1] = { name = nm, qty = qty }
      elseif isHealItem(id, dItem[id]) then heals[#heals + 1] = { name = nm, qty = qty } end
    end
    local ord = save.bagOrder
    if ord then for _, id in ipairs(ord) do if save.inventory[id] and not seen[id] then seen[id] = true; addItem(id) end end end
    for id in pairs(save.inventory or {}) do if not seen[id] then seen[id] = true; addItem(id) end end

    return { active = true, party = party, trainer = trainer, route = route,
      battle = battleBlock, items = { balls = balls, heals = heals } }
  end

  -- ---------------------------------------------------------------------
  -- Per-frame: throttled save read + HP animation easing
  -- ---------------------------------------------------------------------
  local function easeHP(key, target, dt)
    local cur = C.dispHP[key]
    if cur == nil then cur = target end
    cur = cur + (target - cur) * math.min(1, (dt or 0) * 7)
    if math.abs(cur - target) < 0.5 then cur = target end
    C.dispHP[key] = cur
    return cur
  end

  C.onFrame = function(dt)
    -- v2.9.5: fires the long-press-to-edit gesture once it's actually
    -- held long enough (see the input.pointer hook's own comment for the
    -- full design and why touch needed this at all). Armed on press
    -- there, without consuming the event; this is the per-frame poll
    -- that turns "still armed after enough time" into actually opening
    -- edit mode -- a press/move/release event alone can't detect elapsed
    -- time on its own, only a per-frame check can. Re-checks the same
    -- gating conditions at fire time (not just at arm time), in case
    -- something changed mid-hold (e.g. the overlay got toggled off by
    -- some other means) -- if they no longer hold, this just quietly
    -- drops the attempt instead of opening edit mode somewhere it
    -- shouldn't.
    if C.longPressStart then
      local c = _G.__KANTO_INGAME
      if love.timer.getTime() - C.longPressStart.t >= C.LONG_PRESS_DURATION then
        C.longPressStart = nil
        if c and c.visible and not C.overlayEdit.active and not c.screen and C.canEditHere and C.canEditHere() and C.editOpen then
          C.editOpen(c)
        end
      end
    end
    -- v2.9.5: touch-only "hold to reset everything" -- same per-frame-poll
    -- split as the long-press-to-edit check just above and the same
    -- reason (a press/release event alone can't measure elapsed hold
    -- time). Re-checks C.overlayEdit.active at fire time, same as L3's
    -- own hold -- if edit mode somehow closed mid-hold, this just quietly
    -- drops the attempt instead of resetting from outside edit mode.
    if C.resetAllHoldStart then
      local c = _G.__KANTO_INGAME
      if love.timer.getTime() - C.resetAllHoldStart.t >= C.LONG_PRESS_DURATION then
        C.resetAllHoldStart = nil
        if c and C.overlayEdit.active and C.doPanicReset then
          C.doPanicReset(c)
        end
      end
    end
    -- Transient footer message (see C.setStatus): reverts to the normal
    -- hint text on its own after a few seconds instead of sitting there
    -- until the screen is closed -- previously nothing ever cleared it.
    if C.status and C.statusAt and (love.timer.getTime() - C.statusAt) > 4 then
      C.status, C.statusAt = nil, nil
    end
    C.acc = (C.acc or 0) + (dt or 0)
    if not C.state or C.acc >= INTERVAL then
      C.acc = 0
      local ok, st = pcall(buildState)
      if ok then C.state = st
      elseif st ~= C.buildErr then C.buildErr = st; mod.log:error("kanto_ingame build: %s", tostring(st)) end
    end
    -- advance HP eases toward the freshest values every frame
    local st = C.state
    if st then
      -- Ported from the old v91 dev branch (v87, "Issue 3", never carried
      -- into the sandbox rewrite -- shelved the same way touch-resize/Undo
      -- were, direct report caught it): sync the overlay's HP bars to the
      -- VANILLA animation. The overlay used to run its own ease toward the
      -- already-applied final hp, so its bar jumped the instant damage was
      -- calculated (move selected), out of step with the vanilla bar
      -- draining later. The engine stores its own animated value in
      -- battler.shownHP -- so for whichever mon is actually IN battle we
      -- mirror that directly, and the two bars move in lockstep. Non-active
      -- party mons (and the whole overworld) keep the local ease, which is
      -- a no-op there anyway since their hp isn't animating.
      local battle = currentBattle()
      local pBattler = battle and battle.player
      local activeMon = pBattler and pBattler.mon
      local sv = C.game and C.game.save
      for i = 1, 6 do
        local m = st.party and st.party[i]
        local key = "p" .. i
        if m then
          if C.dispSp[key] ~= m.species then C.dispSp[key] = m.species; C.dispHP[key] = m.hp end
          local raw = sv and sv.party and sv.party[i]
          if activeMon and raw == activeMon and pBattler.shownHP then
            C.dispHP[key] = pBattler.shownHP   -- lockstep with the vanilla player HUD bar
          else
            easeHP(key, m.hp or 0, dt or 0)
          end
        else C.dispHP[key] = nil; C.dispSp[key] = nil end
      end
      local en = st.battle and st.battle.enemy
      if en then
        if C.dispSp.enemy ~= en.species then C.dispSp.enemy = en.species; C.dispHP.enemy = en.hp end
        if battle and battle.enemy and battle.enemy.shownHP then
          C.dispHP.enemy = battle.enemy.shownHP   -- lockstep with the vanilla enemy HUD bar
        else
          easeHP("enemy", en.hp or 0, dt or 0)
        end
      else C.dispHP.enemy = nil; C.dispSp.enemy = nil end
    end
    C.updateStickCursor(dt)
    -- Session 93: C.driveStickEditMode is defined later in the file
    -- (after updateDrag/updateResize exist, which it needs as upvalues)
    -- and looked up dynamically through C here, same reason
    -- C.updateStickCursor itself is called before its own definition
    -- textually -- both are assigned to C.* once, at the bottom of a
    -- long chain of local helper definitions, and only ever actually
    -- invoked per-frame, by which point the whole file has already run
    -- once and every C.* field is set.
    if C.driveStickEditMode then C.driveStickEditMode() end
    if C.updateScrollHold then C.updateScrollHold(dt or 0) end
  end

  -- ---------------------------------------------------------------------
  -- Draw helpers (all inputs in DESIGN units; multiplied by C.s)
  -- ---------------------------------------------------------------------
  local s = 1
  -- Offscreen canvas the overlay is rendered to when it needs to be dimmed
  -- (see C.drawOverlay) -- cached and only rebuilt if the window size changes.
  local overlayCanvas
  -- TEMP DIAGNOSTIC (battle-entry crash on Pixel 10 Pro): logs real window
  -- size + canvas footprint exactly once per battle-entry transition, so we
  -- can compare portrait vs landscape numbers instead of guessing. Safe to
  -- remove once we've confirmed the cause.
  local wasInBattle = false
  -- LÖVE's built-in Vera font lacks these glyphs (they'd draw a missing-glyph
  -- box), so swap them for safe equivalents before printing. ♀/♂ come straight
  -- from Nidoran's name; the rest are battle-panel decorations.
  local SUB = {
    ["\226\153\128"] = " (F)",  -- ♀ U+2640
    ["\226\153\130"] = " (M)",  -- ♂ U+2642
    ["\226\152\133"] = "*",    -- ★ U+2605 (STAB)
    ["\226\154\160"] = "!",    -- ⚠ U+26A0 (threat)
    ["\226\150\186"] = ">",    -- ► U+25BA (you first)
    ["\226\151\132"] = "<",    -- ◄ U+25C4 (enemy first)
    ["\226\151\134"] = "*",    -- ◆ U+25C6 (badge earned)
    ["\226\151\135"] = "·",    -- ◇ U+25C7 (badge not earned)
  }
  local function sanitize(str)
    if type(str) ~= "string" then str = tostring(str) end
    for k, v in pairs(SUB) do str = str:gsub(k, v) end
    return str
  end
  local function setc(c, a) love.graphics.setColor(c[1], c[2], c[3], a or 1) end
  local function rrect(mode, x, y, w, h, r)
    -- Position/size were already snapped to whole device pixels (math.floor
    -- above); the radius wasn't, and stayed a fractional value (r*s). At
    -- small radii (a few px at typical mobile scale) that fractional
    -- leftover means the corner curve lands at a different sub-pixel phase
    -- depending on the shape's exact y-position -- enough, at this size, to
    -- make an otherwise-identical rounded rect look crisp in one row and
    -- almost square in another (see chip()'s type-badge pills). Rounding
    -- the radius the same way position/size already are removes that
    -- phase-dependence. Still scales with s like before -- just snapped to
    -- a whole pixel instead of left as a fraction of one.
    local rad = math.floor((r or 0) * s + 0.5)
    love.graphics.rectangle(mode, math.floor(x*s), math.floor(y*s), math.floor(w*s), math.floor(h*s),
      rad, rad)
  end
  local function txt(str, x, y, size, col, align, a)
    str = sanitize(str)
    local f = getFont(size*s); love.graphics.setFont(f); setc(col or COL.text, a)
    local X = x*s
    if align == "right" then X = X - f:getWidth(str)
    elseif align == "center" then X = X - f:getWidth(str)/2 end
    love.graphics.print(str, math.floor(X), math.floor(y*s))
  end
  local function textW(str, size) return getFont(size*s):getWidth(str) / s end
  -- break `str` into lines that each fit within `maxW` (design units) at
  -- font `size`, wrapping on spaces; a single word wider than maxW is left
  -- on its own line rather than split mid-word.
  local function wrapText(str, size, maxW)
    local lines, line = {}, ""
    for word in str:gmatch("%S+") do
      local cand = line == "" and word or (line .. " " .. word)
      if textW(cand, size) <= maxW then
        line = cand
      else
        if line ~= "" then lines[#lines+1] = line end
        line = word
      end
    end
    if line ~= "" then lines[#lines+1] = line end
    return lines
  end
  -- shrink a string with ".." until it fits maxW (design units)
  local function ellipsize(str, size, maxW)
    if textW(str, size) <= maxW then return str end
    local s2 = str
    while #s2 > 1 and textW(s2 .. "..", size) > maxW do s2 = s2:sub(1, #s2 - 1) end
    return s2 .. ".."
  end
  local function panel(x, y, w, h, activeGold)
    setc(COL.panel, 0.98); rrect("fill", x, y, w, h, 14)
    love.graphics.setLineWidth(math.max(1, s))
    if activeGold then setc(COL.gold, 0.9) else setc(COL.border, 0.12) end
    rrect("line", x, y, w, h, 14)
  end
  local function bar(x, y, w, h, frac, col)
    setc(COL.barbg, 0.15); rrect("fill", x, y, w, h, h/2)
    if frac and frac > 0 then setc(col, 1); rrect("fill", x, y, w*math.min(1,frac), h, h/2) end
  end
  local function hpCol(f) return f > 0.5 and COL.hi or (f > 0.2 and COL.mid or COL.lo) end
  -- Split out from chip() so any caller that needs to reserve space for a
  -- pill -- not just draw one -- can ask this directly instead of
  -- hardcoding a guess. That guess is exactly what went stale the first
  -- time (measureMon's old "hasTypes and 26", see below): chip() itself
  -- got fixed to derive its height from the font, but every caller that
  -- reserves *layout* space for a chip row was still written against the
  -- old, hardcoded ~17px pill and never revisited, so on a floored-font
  -- window the pill can now render taller than the space callers set
  -- aside for it -- into whatever's drawn right after (an HP bar, the
  -- next party row). Routing both chip() and every caller through this
  -- one function is what makes that impossible from here on: there's
  -- only one place pill height is computed, full stop.
  local function chipH()
    local f = getFont(11*s)
    local fhDesign = f:getHeight() / s
    return fhDesign * 1.6
  end
  local function chip(x, y, label, col)
    -- Pill height is derived from the font's own real, rendered height --
    -- not an independent hardcoded constant (was 17 design units) that
    -- had no knowledge of getFont()'s own 8px minimum-size floor
    -- (math.max(8, math.floor(sizePx))). On a small enough window, the
    -- font hits that floor and stops shrinking while a hardcoded pill
    -- height keeps shrinking right past it -- explains why PC (large
    -- windows, font request never near the floor) always looked
    -- correct while mobile (small windows, font genuinely floored)
    -- never did, no matter how many times the text's *position* within
    -- the pill was retuned (Sections 1w-1ac): the pill's *size* was
    -- wrong, not the text's position within it. Deriving pill height
    -- from the same font object txt() actually uses means the two can
    -- never diverge again, on any window size, without needing to know
    -- in advance whether the floor will trigger.
    -- Padding fraction (0.6 = 60% of font height, split evenly above and
    -- below) calibrated against PC's own already-correct rendering,
    -- where this reproduces the old hardcoded pill height almost
    -- exactly (~19.2px vs ~19.1px at typical desktop scale) rather than
    -- picking a number and hoping it matches.
    local pillH = chipH()
    local padTotal = pillH * (0.6 / 1.6)
    local w = textW(label, 11) + 12
    -- Radius must scale with pillH, not stay fixed. This chip-scale-fix
    -- branch made pillH dynamic (derived from the real font height,
    -- ~28.83 design units at typical mobile scale) but left the corner
    -- radius as the old hardcoded 5 -- a value tuned against the old
    -- fixed 17-unit pillH (5/17 ~= 0.294 of the height). Against the
    -- new, taller pillH that same fixed 5 is only ~0.17 of the height,
    -- which is why v3 measured out at a ~1px corner recede versus old
    -- 2.8.1/t9's ~4px at typical mobile scale (confirmed by direct pixel
    -- comparison of a v3 screenshot against a t9 screenshot on the same
    -- device) -- a real, visible regression toward square corners, not
    -- a screenshot artifact. Deriving the radius from pillH with the
    -- same ratio the original hardcoded 5/17 pair had preserves the
    -- exact proportions of the original, already-correct design at any
    -- pillH this function ever computes, the same reasoning chipH()
    -- itself already applies to height.
    local pillR = pillH * (5 / 17)
    setc(col, 1); rrect("fill", x, y, w, pillH, pillR)
    txt(label, x + 6, y + padTotal/2, 11, COL.text)
    return w + 5, pillH
  end
  local function money(n) local s2 = tostring(math.floor(n or 0)); local o = s2:reverse():gsub("(%d%d%d)","%1,"):reverse():gsub("^,",""); return "¥"..o end
  local function fmtTime(sec) sec = sec or 0; return string.format("%d:%02d", math.floor(sec/3600), math.floor(sec/60)%60) end
  local function pct(p) if p == nil then return "—" end; if p >= 100 then return "100%" end; if p < 1 then return (p < 0.1 and "<0.1%") or (string.format("%.1f%%", p)) end; return math.floor(p+0.5).."%" end
  local EFFLBL = { [0]="×0", [2]="×¼", [5]="×½", [10]="×1", [20]="×2", [40]="×4" }
  local function effText(m) return EFFLBL[m] or ("×"..(m/10)) end

  -- ---------------------------------------------------------------------
  -- Panel renderers. Each returns the height it drew (design units).
  -- ---------------------------------------------------------------------
  local COLW = 468        -- side column width (design units)
  local PAD = 16

  -- Party rows are BOXLESS (thin dividers between mons). Two styles toggled
  -- with F7: 1 = full (types, HP, XP, moves), 2 = compact (no moves, tighter).
  local function moveRows(m) return math.ceil(math.max(1, #(m.moves or {})) / 2) end
  local function measureMon(m, style)
    if style == 2 then return 54 end
    local hasTypes = m.types and #m.types > 0
    local hasXP = m.xpProgress ~= nil
    -- Was a flat 26 (the old ~17px pill plus a 9-unit gap before the HP
    -- bar) -- now chipH() + that same 9-unit gap, so this can never fall
    -- short of what drawMonRow's FULL style actually advances by below.
    local typesH = hasTypes and (chipH() + 9) or 0
    local bodyH = 30 + typesH + 36 + (hasXP and 32 or 0) + 6 + moveRows(m)*20
    return math.max(72, bodyH)
  end

  local function drawMonRow(m, x, y, w, key, style)
    local rowH = measureMon(m, style)
    local dispHp = C.dispHP[key] or m.hp or 0
    local frac = math.max(0, math.min(1, dispHp / (m.maxhp or 1)))
    local sp = (style == 2) and 52 or 72
    local bodyX = sp + 14
    local bodyW = w - bodyX

    local img = getSprite(m.species, C.dPoke)
    if img then
      local iw, ih = img:getDimensions(); local sc = (sp / math.max(iw, ih)) * s
      setc(COL.text, dispHp <= 0 and 0.5 or 1)
      love.graphics.draw(img, math.floor(x*s), math.floor((y + (rowH-sp)/2)*s), 0, sc, sc)
    end
    if style == 2 then
      -- COMPACT: name + types + Lv on one line, HP bar w/ inline number, thin XP
      local cy = y + 2
      txt(m.name, x + bodyX, cy, 20, COL.text)
      local tx = x + bodyX + textW(m.name, 20) + 8
      local hasChip = (m.types and #m.types > 0) or (m.status and m.status ~= "OK")
      if m.types then for _, t in ipairs(m.types) do tx = tx + chip(tx, cy + 1, t, TYPE[t] or COL.dim) end end
      if m.status and m.status ~= "OK" then tx = tx + chip(tx, cy + 1, m.status, COL.lo) end
      txt("Lv " .. (m.level or "?"), x + w, cy + 2, 15, COL.dim, "right")
      -- Same stale-constant risk as the FULL style above, just less severe
      -- since 24 was sized for the 20pt name text on this line, not the
      -- chip -- previously always the taller of the two anyway (old pill
      -- ~17px). Only grow past 24 if an actual chip is on this line and
      -- its real height (drawn 1 unit down, so +1) plus a small landing
      -- gap would exceed it.
      cy = cy + (hasChip and math.max(24, chipH() + 1 + 4) or 24)
      local numStr = string.format("%d/%d", math.floor(dispHp + 0.5), m.maxhp or 0)
      local numW = textW(numStr, 15) + 10
      bar(x + bodyX, cy + 2, bodyW - numW, 10, frac, hpCol(frac))
      txt(numStr, x + w, cy, 15, COL.text, "right", 0.9)
      cy = cy + 18
      if m.xpProgress ~= nil then bar(x + bodyX, cy, bodyW, 6, m.xpProgress, COL.xp) end
      return rowH
    end

    -- FULL
    local cy = y
    txt(m.name, x + bodyX, cy, 24, COL.text)
    txt("Lv " .. (m.level or "?"), x + w, cy + 4, 16, COL.dim, "right")
    local cx = x + bodyX + textW(m.name, 24) + 8
    if m.active then
      local ow = textW("OUT", 12)
      setc(COL.gold, 1); rrect("fill", cx, cy + 2, ow + 12, 18, 5)
      txt("OUT", cx + 6, cy + 3, 12, {0.1, 0.08, 0})
      cx = cx + ow + 20
    end
    if m.status and m.status ~= "OK" then chip(cx, cy + 2, m.status, COL.lo) end
    cy = cy + 30
    if m.types and #m.types > 0 then
      local tx = x + bodyX; for _, t in ipairs(m.types) do tx = tx + chip(tx, cy, t, TYPE[t] or COL.dim) end
      -- Was a flat 26 (matches the same stale constant in measureMon
      -- above, now fixed the same way) -- advance by the pill's real
      -- height plus the same 9-unit gap the old constant implied, so
      -- the HP bar below can never land inside a taller-than-expected
      -- pill on a floored-font window.
      cy = cy + chipH() + 9
    end
    bar(x + bodyX, cy, bodyW, 12, frac, hpCol(frac)); cy = cy + 16
    txt(string.format("%d / %d HP", math.floor(dispHp + 0.5), m.maxhp or 0), x + bodyX, cy, 16, COL.text, nil, 0.9); cy = cy + 20
    if m.xpProgress ~= nil then
      bar(x + bodyX, cy, bodyW, 8, m.xpProgress, COL.xp); cy = cy + 12
      local lbl = (m.xpToNext and m.xpToNext > 0) and (money(m.xpToNext):gsub("¥","") .. " XP to Lv " .. ((m.level or 0)+1))
        or (((m.exp and money(m.exp):gsub("¥","")) or "0") .. " XP · Max")
      txt(lbl, x + bodyX, cy, 14, COL.dim); cy = cy + 20
    end
    cy = cy + 6
    local colW2 = bodyW / 2
    local mf = 14
    for i, mv in ipairs(m.moves or {}) do
      local col = (i-1) % 2; local row = math.floor((i-1)/2)
      local mx = x + bodyX + col*colW2; local my = cy + row*20
      local pp = (mv.pp ~= nil and mv.maxpp ~= nil) and (mv.pp.."/"..mv.maxpp) or (mv.pp and tostring(mv.pp) or "")
      local ppW = textW(pp, mf)
      txt(ellipsize(mv.name, mf, colW2 - ppW - 12), mx, my, mf, COL.text, nil, 0.92)
      txt(pp, mx + colW2 - 8, my, mf, COL.dim, "right")
    end
    return rowH
  end

  local function party(st, x, y, styleOverride, measureOnly, maxVisibleH, scrollY, totalScale)
    -- Session 88: every real call site always passes styleOverride
    -- explicitly (see drawOverlay) -- the old `or C.partyStyle or 1`
    -- fallback was unreachable dead code even before C.partyStyle itself
    -- was removed.
    local w = COLW; local style = styleOverride
    local list = st.party or {}
    local h = PAD + 34 + 8
    for _, m in ipairs(list) do h = h + measureMon(m, style) + 14 end
    h = h + PAD - 14
    if measureOnly then return h end
    -- v2.9.5 portrait fix, direct request: "adjust the size of the party
    -- screen to not be so long, sit nicely in the top, add a grabbable
    -- scroll bar." Landscape's fix for a too-tall party was always
    -- auto-SHRINK (see pScale in drawOverlay) -- fine there, where the
    -- panel has the whole column height to itself, but shrinking a full
    -- 6-mon party small enough to fit portrait's much shorter band makes
    -- the text genuinely unreadable rather than just smaller. maxVisibleH
    -- being non-nil switches to a fixed-height, SCROLLABLE window instead
    -- of a shrink -- landscape never passes it, so this whole branch is
    -- unreachable there and that call path is untouched, byte-for-byte.
    local viewH = maxVisibleH and math.min(h, maxVisibleH) or h
    panel(x, y, w, viewH, false)
    txt("Active Party", x + PAD, y + PAD, 28, COL.text)
    -- v63: on direct request, the leading "A"/"B" density-style letter
    -- (style 1 = full, style 2 = compact) is dropped from this readout --
    -- didn't serve a purpose to a player, who has no other reference for
    -- what "A"/"B" mean. `style` itself is untouched and still drives
    -- measureMon/drawMonRow below exactly as before -- only this one
    -- display string changed.
    txt(#list .. "/6", x + w - PAD, y + PAD + 10, 14, COL.dim, "right")
    local scrolling = maxVisibleH and h > maxVisibleH
    local scy = scrolling and math.max(0, math.min(h - maxVisibleH, scrollY or 0)) or 0
    -- v2.9.5 fix, direct report (round 2): "not a true scroll... one
    -- Pokemon disappears and then the next appears, not smooth or
    -- fluid." The previous round's fix for a partial row at the cut edge
    -- (skip drawing it entirely unless it fits whole) traded that for
    -- this snap-to-whole-row jump, which reads as worse, not better --
    -- reverted. A partially-visible row cleanly clipped at the edge is
    -- normal, expected scrolling behavior (how virtually every scrolling
    -- list works, this file's own Items screen included) -- the scissor
    -- clip alone is the correct fix, doing the clipping is its actual
    -- job, not a fallback for something else supposed to catch it first.
    local visTop, visBottom = y + PAD + 34 + 8, y + viewH
    if scrolling then
      -- v2.9.5 fix, direct report + screenshot ("scrollable party view
      -- extends past the panel bottom"): love.graphics.setScissor takes
      -- ABSOLUTE SCREEN pixels -- unlike every other draw call in this
      -- function, it does NOT go through the active graphics transform,
      -- so it has to be converted by hand. This line only ever multiplied
      -- by the shared `s` -- never by `totalScale` (this panel's own
      -- pivot+scale factor, see drawEditablePanel's own comment on
      -- cfg.scale/pFitScale) -- so in portrait, where totalScale is never
      -- 1, the clip rectangle was sized as though the panel were BIGGER
      -- than it's actually drawn, letting content keep drawing past the
      -- real, visually-scaled-down bottom edge instead of being cut there.
      -- Same root-cause CLASS as the scrollbar hit-test fix above (a raw-
      -- pixel calculation that skipped totalScale), just hitting a draw
      -- call instead of a hit-test this time. Mapped through the same
      -- pivot(x,y)+totalScale formula the scrollbar fix already
      -- established: the left edge and top-left pivot coincide (X=x), so
      -- only Y needs the pivot offset; width/height are direct scales.
      local ts = totalScale or 1
      local scisY = y + ts * (visTop - y)
      local scisH = ts * (visBottom - visTop)
      love.graphics.setScissor(math.floor(x*s), math.floor(scisY*s), math.ceil(ts*w*s), math.ceil(scisH*s))
    end
    local cy = visTop - scy
    for i, m in ipairs(list) do
      local rh = measureMon(m, style)
      if m.active then setc(COL.gold, 0.10); rrect("fill", x + PAD - 6, cy - 6, w - PAD*2 + 12, rh + 12, 8) end
      drawMonRow(m, x + PAD, cy, w - PAD*2, "p" .. i, style)
      if i < #list then
        setc(COL.border, 0.10); love.graphics.setLineWidth(math.max(1, s))
        love.graphics.line((x+PAD)*s, math.floor((cy+rh+7)*s), (x+w-PAD)*s, math.floor((cy+rh+7)*s))
      end
      cy = cy + rh + 14
    end
    if scrolling then
      love.graphics.setScissor()
      local maxScroll = h - maxVisibleH
      -- v2.9.5 fix, direct report ("no idea if the scroll bar works or how
      -- to use it" -- not a bug, a discoverability miss). Widened and
      -- switched to the SAME gold accent this file already uses
      -- everywhere else to mean "interactive/active" (the active-party
      -- highlight above, every edit-mode highlight) instead of a muted
      -- COL.dim thumb on a near-invisible 10%-alpha track.
      local tx, tw = x + w - 14, 10
      setc(COL.border, 0.25); rrect("fill", tx, y, tw, viewH, 5)
      local thumbH = math.max(36, viewH * (viewH / h))
      local thumbY = y + (scy / maxScroll) * (viewH - thumbH)
      setc(COL.gold, 0.85); rrect("fill", tx, thumbY, tw, thumbH, 5)
      -- Recorded every frame this draws, same "single source of truth" the
      -- touch groups' own rect functions already establish -- the drag
      -- handler below reads this instead of recomputing the geometry.
      -- v2.9.5 fix, direct report ("scroll bar doesn't work"): this whole
      -- panel draws inside drawEditablePanel's drawScaled pivot-transform
      -- (pivot (x,y), factor totalScale = pFitScale*cfg.scale -- see
      -- drawEditablePanel's own comment on cfg.scale). A point at this
      -- function's own local coordinate V lands on screen at
      -- pivot + totalScale*(V-pivot), NOT at V itself. Every OTHER stored
      -- hit-box in this file (C.overlayEdit.bounds, the touch groups)
      -- either sits exactly at its own pivot already or is drawn outside
      -- this transform entirely, so tryPartyScrollbarStart's plain `x/s`
      -- compare (correct for those) was never checked against this
      -- panel's actual transform -- it compared raw local coordinates to
      -- a totalScale-shrunk real target. In portrait totalScale is never
      -- 1 (PORTRAIT_SAFE_SCALE alone guarantees that), so the stored box
      -- was consistently offset from the visible thumb by however far
      -- cfg.scale/pFitScale pushed it away from the panel's own pivot --
      -- which is why grabbing it never worked. Applying the same
      -- pivot+scale mapping here, once, at the source, means
      -- tryPartyScrollbarStart/updatePartyScrollbarDrag need no changes at
      -- all -- their existing `x/s` compare becomes correct for free.
      local ts = totalScale or 1
      C.partyScrollbar = {
        x = x + ts * (tx - x), y = y, w = ts * tw, h = ts * viewH,
        thumbH = ts * thumbH, thumbY = y + ts * (thumbY - y), maxScroll = maxScroll,
      }
    else
      C.partyScrollbar = nil
    end
    return viewH
  end

  -- Trainer panel
  local function trainer(st, x, y, measureOnly, compact)
    local t = st.trainer; if not t then return 0 end
    local w = COLW
    -- Session 82: reduced view -- name, money, play time, party count
    -- only, the middle rung of the new full/compact/bar ladder (see
    -- levelOf()/setLevel() near clamp01Scale). Reuses the exact same
    -- label-above-value cell convention the full row grid below already
    -- draws (12pt dim uppercase label, 24pt colored value) rather than
    -- inventing a new visual language for three fewer rows and no badge
    -- grid.
    --
    -- Session 91: on direct report, the original 2-column layout put 3
    -- cells into 2 columns (Money/Play Time on row one, Party alone on
    -- row two) -- exactly the "wraps to another line" the compact view
    -- was supposed to avoid. All 3 stats now sit in one 3-column row
    -- instead, so nothing wraps; COLW (468) comfortably fits three
    -- ~145-unit columns for values this short. Height formula simplified
    -- to match -- exactly one row's worth (46), not
    -- ceil(#crows/2)*46 -- since there's now only ever one row.
    if compact then
      local crows = {
        { "Money", money(t.money), COL.money }, { "Play Time", fmtTime(t.playTime), COL.text },
        { "Party", (t.partyCount or 0).."/6", COL.text },
      }
      local titleH = 34
      local h = PAD + titleH + 46 + PAD
      if measureOnly then return h end
      panel(x, y, w, h, false)
      local cy = y + PAD
      txt(t.name ~= "" and t.name or "—", x + PAD, cy, 24, COL.text)
      cy = cy + titleH
      local colW3c = (w - PAD*2) / #crows
      for i, r in ipairs(crows) do
        local rx = x + PAD + (i-1)*colW3c
        txt(r[1]:upper(), rx, cy, 12, COL.dim)
        txt(r[2], rx, cy + 16, 24, r[3])
      end
      return h
    end
    local den = t.dexTotal and ("/"..t.dexTotal) or ""
    local rows = {
      { "Money", money(t.money), COL.money }, { "Play Time", fmtTime(t.playTime), COL.text },
      { "Badges", (t.badgeCount or 0).."/"..#(t.badges or {}), COL.text }, { "Party", (t.partyCount or 0).."/6", COL.text },
      { "Pokédex Owned", (t.dexOwned or 0)..den, COL.text }, { "Pokédex Seen", (t.dexSeen or 0)..den, COL.text },
    }
    local badgeRows = math.ceil(#(t.badges or {}) / 4)
    local badgeBoxH, badgeRowPitch = 55, 67   -- box height + gap (was 40 + 12); pitch keeps the same 12px gap
    local h = PAD + 30 + 18 + (math.ceil(#rows/2))*46 + 24 + badgeRows*badgeRowPitch + PAD
    if measureOnly then return h end
    panel(x, y, w, h, false)
    local cy = y + PAD
    txt(t.name ~= "" and t.name or "—", x + PAD, cy, 30, COL.text); cy = cy + 32
    txt((t.version or ""):upper() .. " VERSION", x + PAD, cy, 13, COL.dim); cy = cy + 20
    local colW2 = (w - PAD*2) / 2
    for i, r in ipairs(rows) do
      local col = (i-1)%2; local row = math.floor((i-1)/2)
      local rx = x + PAD + col*colW2; local ry = cy + row*46
      txt(r[1]:upper(), rx, ry, 12, COL.dim)
      txt(r[2], rx, ry + 16, 24, r[3])
    end
    cy = cy + math.ceil(#rows/2)*46 + 8
    txt("GYM BADGES", x + PAD, cy, 12, COL.dim); cy = cy + 20
    local sheet = badgeSheet()
    local bw = (w - PAD*2 - 3*8) / 4
    for i, b in ipairs(t.badges or {}) do
      local col = (i-1)%4; local row = math.floor((i-1)/4)
      local bx = x + PAD + col*(bw+8); local by = cy + row*badgeRowPitch
      setc(b.owned and COL.xp or COL.border, b.owned and 0.22 or 0.05); rrect("fill", bx, by, bw, badgeBoxH, 8)
      local q = sheet and b.owned and sheet.quads[i-1]
      if q then
        local size = 22; local sc = (size/16)*s; setc(COL.text, 1)
        love.graphics.draw(sheet.img, q, math.floor((bx + bw/2 - size/2)*s), math.floor((by + 9)*s), 0, sc, sc)
      else
        txt(b.owned and "◆" or "◇", bx + bw/2, by + 11, 15, b.owned and COL.gold or COL.dim, "center")
      end
      txt(b.name, bx + bw/2, by + 34, 11, b.owned and COL.text or COL.dim, "center")
    end
    return h
  end

  -- Route panel
  -- v2.9.5 (ported from the shelved v85): Route-panel indicators drawn as
  -- love.graphics primitives. Crossed scimitars = battled, Poké Ball =
  -- caught, trophy + xN = defeated; full colour when earned, a dim/greyed
  -- placeholder when not, so every row shows all three slots and reads at
  -- a glance. Attached to C (field assignments) rather than new top-level
  -- locals -- this file is at/near Lua's 200-locals-per-function ceiling
  -- (hit it once already tonight, see the Undo port). Only polygon/circle/
  -- line/transform calls are used, all already exercised elsewhere in this
  -- file -- no new engine dependency.
  C.rtScimPoly  = { -1.6,7, 2,7, 4.58,2.86, 6.55,-2.13, 7.40,-8.05, 6.6,-15, 5.24,-9.88, 3.48,-4.75, 1.23,0.75 }
  C.rtTrophyCup = { -5.5,-7, 5.5,-7, 4,-1.5, 0,0.25, -4,-1.5 }
  -- Crossed pair centred at design (cx,cy); k scales the local blade; earned
  -- toggles steel+gold vs greyed. Two blades: one rotated +34°, the other its
  -- mirror. Steel {0.80,0.82,0.86}, dark grip {0.23,0.16,0.10}, gold guard/pommel.
  C.drawRouteScimitars = function(cx, cy, k, earned)
    local a = earned and 1 or 0.42
    local function blade()
      if earned then love.graphics.setColor(0.80, 0.82, 0.86, a)
      else love.graphics.setColor(COL.dim[1], COL.dim[2], COL.dim[3], a) end
      love.graphics.polygon("fill", C.rtScimPoly)
      if earned then love.graphics.setColor(COL.gold[1], COL.gold[2], COL.gold[3], a)
      else love.graphics.setColor(COL.dim[1], COL.dim[2], COL.dim[3], a) end
      love.graphics.setLineWidth(2.6); love.graphics.line(-4.7,7.4, 0,6.35, 4.7,7.4)
      if earned then love.graphics.setColor(0.23, 0.16, 0.10, a)
      else love.graphics.setColor(COL.dim[1], COL.dim[2], COL.dim[3], a) end
      love.graphics.setLineWidth(2.8); love.graphics.line(0.3,8, -0.53,10.8, -0.4,13.2)
      if earned then love.graphics.setColor(COL.gold[1], COL.gold[2], COL.gold[3], a); love.graphics.circle("fill", -0.4,13.6, 1.7) end
    end
    love.graphics.push(); love.graphics.translate(cx*s, cy*s); love.graphics.scale(k*s, k*s)
    love.graphics.push(); love.graphics.rotate(math.rad(34)); love.graphics.translate(-1, 1); blade(); love.graphics.pop()
    love.graphics.push(); love.graphics.scale(-1, 1); love.graphics.rotate(math.rad(34)); love.graphics.translate(-1, 1); blade(); love.graphics.pop()
    love.graphics.pop(); love.graphics.setColor(1,1,1,1); love.graphics.setLineWidth(1)
  end
  -- Poké Ball centred at (cx,cy), design radius r. Caught = red top / light
  -- bottom / centre button; not caught = a dim outline placeholder. Halves are
  -- polygon fans (no love.graphics.arc dependency).
  C.drawRouteBall = function(cx, cy, r, caught)
    love.graphics.push(); love.graphics.translate(cx*s, cy*s); love.graphics.scale(s, s)
    if caught then
      local top, bot, n = {}, {}, 14
      for i = 0, n do local a = math.pi + math.pi*i/n; top[#top+1] = math.cos(a)*r; top[#top+1] = math.sin(a)*r end
      for i = 0, n do local a = math.pi*i/n;          bot[#bot+1] = math.cos(a)*r; bot[#bot+1] = math.sin(a)*r end
      love.graphics.setColor(COL.lo[1], COL.lo[2], COL.lo[3]); love.graphics.polygon("fill", top)
      love.graphics.setColor(0.92, 0.93, 0.96); love.graphics.polygon("fill", bot)
      love.graphics.setColor(COL.text[1], COL.text[2], COL.text[3]); love.graphics.setLineWidth(1.1); love.graphics.circle("line", 0, 0, r)
      love.graphics.setLineWidth(1.4); love.graphics.line(-r, 0, r, 0)
      love.graphics.setColor(COL.panel[1], COL.panel[2], COL.panel[3]); love.graphics.circle("fill", 0, 0, r*0.34)
      love.graphics.setColor(COL.text[1], COL.text[2], COL.text[3]); love.graphics.setLineWidth(1.1); love.graphics.circle("line", 0, 0, r*0.34)
    else
      love.graphics.setColor(COL.dim[1], COL.dim[2], COL.dim[3], 0.42); love.graphics.setLineWidth(1.2)
      love.graphics.circle("line", 0, 0, r); love.graphics.line(-r, 0, r, 0); love.graphics.circle("line", 0, 0, r*0.34)
    end
    love.graphics.pop(); love.graphics.setColor(1,1,1,1); love.graphics.setLineWidth(1)
  end
  -- Trophy centred at (cx,cy); k scales local units. Won = gold filled; else a
  -- dim outline placeholder.
  C.drawRouteTrophy = function(cx, cy, k, won)
    love.graphics.push(); love.graphics.translate(cx*s, cy*s); love.graphics.scale(k*s, k*s)
    if won then
      love.graphics.setColor(COL.gold[1], COL.gold[2], COL.gold[3])
      love.graphics.polygon("fill", C.rtTrophyCup)
      love.graphics.rectangle("fill", -1.2, 1, 2.4, 3); love.graphics.rectangle("fill", -4, 4, 8, 2, 1, 1)
    else
      love.graphics.setColor(COL.dim[1], COL.dim[2], COL.dim[3], 0.42); love.graphics.setLineWidth(1.3)
      love.graphics.polygon("line", C.rtTrophyCup)
      love.graphics.rectangle("fill", -1.2, 1, 2.4, 3); love.graphics.rectangle("fill", -4, 4, 8, 2, 1, 1)
    end
    love.graphics.pop(); love.graphics.setColor(1,1,1,1); love.graphics.setLineWidth(1)
  end
  -- v2.9.5: Poké Ball-shaped stick cursor, replacing the plain gold ring +
  -- dot everywhere it drew (Edit Mode and the Items/Party screens both
  -- reuse this one function -- see its two call sites). Direct request:
  -- the old ring wasn't always easily visible, so this is both a real
  -- Poké Ball glyph (same red/white/band/button shape and colours as
  -- C.drawRouteBall's "caught" state above, for visual consistency across
  -- the mod) AND a constant slow rock side-to-side to draw the eye,
  -- whenever the cursor is on screen at all -- not gated on stick
  -- movement, so it reads as "alive" even while aimed and held still.
  --
  -- Rotation only -- (cx, cy) is drawn at is the exact same point the old
  -- ring centred on, every frame; nothing about the cursor's actual
  -- position/hit-testing changes, only what's drawn at it. Requested
  -- motion: oscillate about +-60 degrees, slowing near each extreme. A
  -- plain sine drive gives exactly that for free -- angle = 60deg *
  -- sin(t*speed) -- because sine's own rate of change (its cosine
  -- derivative) is already zero right at +-60 deg and fastest through the
  -- middle, i.e. a real pendulum-like ease-at-the-ends with no separate
  -- easing curve needed. ~2.4s per full left-right-return cycle.
  --
  -- Radius 9 (vs the old ring's radius 10) keeps roughly the same on-
  -- screen footprint instead of suddenly claiming more space. The ball's
  -- own centre button is already the shape's natural rotation pivot AND
  -- already sits exactly at local (0,0) -- so rotating in place keeps the
  -- real click/grab hotspot (cx, cy) dead centre on the button the whole
  -- time, matching how a real Poké Ball's latch is its focal point.
  C.CURSOR_ROCK_SPEED = 2 * math.pi / 2.4
  C.drawStickCursor = function(cx, cy)
    -- Direct request 2026-08-20: size +100% (r 9 -> 18), rock angle -30%
    -- (60deg -> 42deg). Everything else below is already expressed as a
    -- multiple of r (button/band proportions) or scales with the shared
    -- UI scale s (line widths), so this one number is the only touch
    -- point for "bigger ball" -- proportions stay correct automatically.
    local angle = math.rad(42) * math.sin(love.timer.getTime() * C.CURSOR_ROCK_SPEED)
    local r = 18
    local pal = C.CURSOR_PALETTES[mod.options:get("cursor_color")] or C.CURSOR_PALETTES[0]
    local hw, R = C.CURSOR_HW, C.CURSOR_R
    -- Animated skins refresh their own colours here, before anything reads
    -- pal.top. Deliberately NOT reusing `under`/`over` for this: those are
    -- draw hooks with a protrusion contract that test_cursor_geometry.lua
    -- enforces (it fails any skin declaring one that does not actually leave
    -- the circle), so an update hook wearing that name would either break the
    -- test or force a hole in it.
    if pal.tick then pal.tick(pal) end
    love.graphics.push()
    love.graphics.translate(cx*s, cy*s)
    love.graphics.rotate(angle)
    -- Everything from here down is authored at radius R (=100) in
    -- C.CURSOR_PALETTES, so this one scale maps that design space onto the
    -- real on-screen radius r. Two things fall out of doing it this way:
    -- the coordinates up there can be used verbatim from the offscreen
    -- render they were checked in, and "make the cursor bigger" stays a
    -- one-number change to r, with line widths and every proportion
    -- following automatically.
    love.graphics.scale(s * r / R, s * r / R)
    -- Explicit segment counts throughout (here and in the palettes' own
    -- circle() calls): LÖVE's auto segment-count heuristic only sees the
    -- pre-scale radius, never the actual on-screen pixel size it will
    -- render at through an active transform, so left to itself it under-
    -- tessellates and the ball comes out visibly faceted.
    if pal.under then pal.under(pal) end
    C.cc(pal.top);   love.graphics.polygon("fill", C.cursorTopPoly)
    C.cc(hw.bottom); love.graphics.polygon("fill", C.cursorBotPoly)
    if pal.mark then pal.mark(pal) end
    -- No specular gloss. There used to be a white ellipse at (-42,-52) here,
    -- removed 2026-08-26 on direct request after it was cut from Great and
    -- Master individually. It never earned its place: it sits LEFT-ONLY so it
    -- broke the ball's left/right symmetry, any skin whose mark reaches that
    -- corner clipped it into a hard-edged wedge that read as a smudge rather
    -- than a highlight, and at 27px it was a grey blob competing with the
    -- mark for the little ink the dome has.
    C.cc(hw.band);    love.graphics.rectangle("fill", -96, -13, 192, 26)
    C.cc(hw.outline); love.graphics.setLineWidth(9); love.graphics.circle("line", 0, 0, 95.5, 52)
    C.cc(hw.btnFill); love.graphics.circle("fill", 0, 0, 27, 28)
    C.cc(hw.btnRing); love.graphics.setLineWidth(6); love.graphics.circle("line", 0, 0, 27, 28)
    if pal.over then pal.over(pal) end
    love.graphics.pop()
    love.graphics.setColor(1,1,1,1); love.graphics.setLineWidth(1)
  end
  -- v2.10.1: live preview while picking a skin in the vanilla mod-options
  -- menu (Options -> Mods -> Kanto Companion -> CURSOR COLOR). That screen
  -- is the engine's own fixed bitmap-font OptionRows viewport (src/ui/
  -- OptionRows.lua, confirmed by reading it directly) -- each row's value
  -- is just a text string, no icon/image slot and no hook for a mod to draw
  -- into a row, so the preview can't live INSIDE that list. Instead: poll
  -- cursor_color every frame (already the same read C.drawStickCursor
  -- itself does above) and, on change, flash a small corner window through
  -- the render.hud hook below -- that hook already proves it fires every
  -- frame over the finished composite regardless of what's on top of the
  -- state stack (this mod's whole R2 overlay depends on exactly that), so
  -- it works here too even though the options menu is a totally different
  -- engine state kanto doesn't own. ManagerState's choice-row `step` (the
  -- only writer of cursor_color) calls setOption immediately on every Left/
  -- Right press, before the player ever backs out, so this reflects the
  -- in-progress pick live, not just the confirmed one.
  C.CURSOR_PREVIEW_SECONDS = 2.0
  C.pollCursorPreview = function()
    local cur = mod.options:get("cursor_color")
    if C.cursorPreviewLast == nil then
      -- First read since load: baseline only, don't flash on boot.
      C.cursorPreviewLast = cur
      return
    end
    if cur ~= C.cursorPreviewLast then
      C.cursorPreviewLast = cur
      C.cursorPreviewUntil = love.timer.getTime() + C.CURSOR_PREVIEW_SECONDS
    end
  end
  -- Deliberately does NOT reuse the shared `s` upvalue as-is: `s` only gets
  -- a fresh value when C.drawOverlay/C.drawScreen actually run, which they
  -- don't while the vanilla options menu owns the screen -- the exact
  -- stale-scale trap this file already hit once for the touch-nav buttons
  -- (see the comment above `local function touchGroupZones`). Fixed the
  -- same way that comment describes: compute an independent, freshly-
  -- correct scale here (the exact formula C.drawScreen itself uses) instead
  -- of trusting whatever `s` was last left at. C.drawStickCursor is hard-
  -- wired to the shared upvalue (its own translate/scale both multiply by
  -- `s`), so rather than touch its signature -- used from many other call
  -- sites -- this pins `s` to the fresh value for the one call and restores
  -- it immediately after.
  C.drawCursorPreview = function(viewport)
    if not (C.cursorPreviewUntil and love.timer.getTime() < C.cursorPreviewUntil) then return end
    if not viewport then return end
    local freshS = math.max(0.0001, (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN)
    local r = 18 -- matches C.drawStickCursor's own on-screen radius constant
    local ballR = freshS * r
    local pad = 16
    local boxR = ballR + 14
    local cx = (viewport.gameX or 0) + (viewport.gameWidth or 0) - pad - boxR
    local cy = (viewport.gameY or 0) + pad + boxR
    C.cc(COL.panel, 0.82)
    love.graphics.circle("fill", cx, cy, boxR, 48)
    C.cc(COL.border, 0.9)
    love.graphics.setLineWidth(2)
    love.graphics.circle("line", cx, cy, boxR, 48)
    love.graphics.setLineWidth(1)
    local savedS = s
    s = freshS
    C.drawStickCursor(cx / freshS, cy / freshS)
    s = savedS
  end
  local function drawEncSection(title, tab, x, y, w, col)
    if not tab or not tab.species or #tab.species == 0 then return 0 end
    local cy = y
    -- Ported from weather-compat (display redesign): the separate "X% /
    -- step" rate line is gone -- each species row's own pct is now the
    -- true absolute per-step chance already, so this header is just the
    -- section label, not a second (differently-scoped) percentage next
    -- to a list of percentages that meant something else.
    txt(title, x, cy, 13, COL.dim); cy = cy + 22
    for _, sp in ipairs(tab.species) do
      local img = getSprite(sp.species, C.dPoke)
      if img then local iw, ih = img:getDimensions(); local sc = (36/math.max(iw,ih))*s
        setc(COL.text, 1); love.graphics.draw(img, math.floor(x*s), math.floor((cy-4)*s), 0, sc, sc) end
      txt(sp.name, x + 44, cy, 18, COL.text)
      -- v2.9.5: hand-drawn indicators (see C.drawRouteScimitars/
      -- C.drawRouteBall/C.drawRouteTrophy above). Crossed scimitars =
      -- battled, Poké Ball = caught, trophy + xN = defeated. Full colour
      -- when earned, greyed placeholder when not, so all three slots show
      -- on every row and columns stay stable species to species.
      local iy = cy + 9
      -- v2.9.5 bugfix (on-device report, screenshot): a species name
      -- containing the raw gender-symbol bytes (Nidoran (F)/(M), see SUB
      -- near sanitize()) measured narrower via textW() here than it
      -- actually drew via txt() above -- txt() sanitizes the string
      -- before measuring/drawing internally (♀/♂ -> the 4-char " (F)"/
      -- " (M)"), but this raw textW(sp.name, ...) call never did, so the
      -- icons started well before the real (longer, substituted) text
      -- actually ended and overlapped its tail. Measuring the SAME
      -- sanitized string txt() draws fixes it for every substitution in
      -- SUB, not just this one case.
      local ix = x + 44 + textW(sanitize(sp.name), 18) + 16
      C.drawRouteScimitars(ix, iy, 0.58, sp.battled); ix = ix + 24
      C.drawRouteBall(ix, iy, 7.5, sp.caught); ix = ix + 21
      local won = (sp.koCount or 0) > 0
      C.drawRouteTrophy(ix, iy, 0.95, won); ix = ix + 15
      if won then txt("×" .. sp.koCount, ix, cy, 13, COL.dim, nil, 0.85) end
      local lv = (sp.minLevel == sp.maxLevel) and ("Lv "..sp.minLevel) or ("Lv "..sp.minLevel.."-"..sp.maxLevel)
      txt(lv, x + w - 60, cy, 15, COL.dim, "right")
      txt(sp.pct .. "%", x + w, cy, 18, COL.text, "right")
      bar(x + 44, cy + 24, w - 44, 5, sp.pct/100, col); cy = cy + 36
    end
    return cy - y
  end
  local function route(st, x, y, measureOnly)
    local r = st.route; if not r then return 0 end
    local w = COLW
    -- measure
    local function secH(tab) if not tab or not tab.species or #tab.species==0 then return 0 end return 22 + #tab.species*36 end
    local h = PAD + 30 + secH(r.grass) + (r.grass and 10 or 0) + secH(r.water) + PAD
    if not r.grass and not r.water then h = PAD + 30 + 24 + PAD end
    if measureOnly then return h end
    panel(x, y, w, h, false)
    local cy = y + PAD
    txt(r.name, x + PAD, cy, 26, COL.text)
    -- Weather tag (ported from weather-compat): drawn inline next to the
    -- name, not as its own row, so it shows on a city ("No wild
    -- encounters here") exactly the same as on a route -- it's a status
    -- readout for the location, not something tied to whether wildlife
    -- exists here. Same offset convention the battle panel already uses
    -- for a smaller label beside a larger name (see battle()'s enemy Lv
    -- tag). COL.tag, not COL.dim -- chip()'s label always draws in
    -- COL.text (white), and COL.dim is too light a fill for that to read
    -- clearly, especially once the overlay goes semi-transparent.
    if r.weatherTag and r.weatherTag ~= "" then
      chip(x + PAD + textW(r.name, 26) + 10, cy + 7, r.weatherTag, COL.tag)
    end
    cy = cy + 34
    local used = 0
    used = drawEncSection("Grass", r.grass, x + PAD, cy, w - PAD*2, COL.hi)
    cy = cy + used + (used > 0 and 10 or 0)
    used = drawEncSection("Surfing", r.water, x + PAD, cy, w - PAD*2, COL.xp)
    if not r.grass and not r.water then txt("No wild encounters here", x + PAD, cy, 16, COL.dim, nil, 0.6) end
    return h
  end

  -- Battle panel
  local function battle(st, x, y, measureOnly)
    local b = st.battle; if not b then return 0 end
    local w = COLW; local en = b.enemy or {}; local m = b.matchup or {}
    local nMoves = #(m.myMoves or {}); local nThreat = math.max(1, #(m.threats or {}))
    local nCatch = b.catch and #b.catch or 0
    -- Move/threat rows both draw a chip() at cy+1, so their row spacing has
    -- the same font-floor-vs-fixed-constant risk measureMon/drawMonRow were
    -- already fixed for (see chipH() and its callers above) but this panel
    -- was never audited for: the old flat 26 was sized for the pre-fix
    -- ~17px pill, and chipH() now returns a taller, font-derived pillH on a
    -- floored mobile font. Deriving the row height from chipH() the same
    -- way drawMonRow's compact style already does (chipH() + 1 landing gap
    -- + 4 breathing room, never shrinking below the original 26) keeps a
    -- chip from a row ever crowding into the row below it or, on the last
    -- move row, into the THREATS header right after it.
    local moveRowH = math.max(26, chipH() + 1 + 4)
    local h = PAD + 20 + 66 + 40 + 22 + (nMoves*moveRowH) + 30 + (nThreat*moveRowH) + (nCatch > 0 and (30 + nCatch*26) or 0) + PAD
    if measureOnly then return h end
    panel(x, y, w, h, false)
    local cy = y + PAD
    local title = b.kind == "trainer" and (b.trainer and (b.trainer.."'s Pokémon") or "Trainer Battle") or "Wild Battle"
    txt(title:upper(), x + PAD, cy, 13, COL.dim); cy = cy + 20
    -- enemy
    local img = getSprite(en.species, C.dPoke)
    if img then local iw, ih = img:getDimensions(); local sc = (60/math.max(iw,ih))*s
      setc(COL.text,1); love.graphics.draw(img, math.floor((x+PAD)*s), math.floor(cy*s), 0, sc, sc) end
    local nameX = x + PAD + 72
    txt(en.name or "?", nameX, cy, 24, COL.text)
    -- v2.9.5: caught, Poké Ball, always shown -- same dual-state glyph the
    -- route panel's dex-tally already uses.
    local badgeX = nameX + textW(en.name or "?", 24) + 12
    C.drawRouteBall(badgeX + 8, cy + 12, 8, en.caught); badgeX = badgeX + 20
    txt("Lv " .. (en.level or "?"), badgeX, cy + 6, 16, COL.dim)
    local tx = x + PAD + 72
    for _, t in ipairs(en.types or {}) do tx = tx + chip(tx, cy + 30, t, TYPE[t] or COL.dim) end
    cy = cy + 66
    local eh = C.dispHP.enemy or en.hp or 0
    local ef = math.max(0, math.min(1, eh / (en.maxhp or 1)))
    bar(x + PAD, cy, w - PAD*2, 12, ef, hpCol(ef)); cy = cy + 16
    txt(string.format("%d / %d HP", math.floor(eh+0.5), en.maxhp or 0), x + PAD, cy, 16, COL.text, nil, 0.9); cy = cy + 24
    if m.speed and m.speed.faster then
      local sp = m.speed.faster == "you" and "► You move first" or (m.speed.faster == "them" and "◄ Enemy moves first" or "= Speed tie")
      txt(sp, x + PAD, cy, 16, COL.gold);
    end
    cy = cy + 22
    txt("YOUR MOVES", x + PAD, cy, 13, COL.dim); cy = cy + 22
    do
      local myMoves = m.myMoves or {}
      -- Size the right-hand stat column from what this battle's moves
      -- actually need, instead of a fixed 120px gap: a wide "120 pow ·
      -- 40/40" (or "STATUS 30/30") string would previously run right into
      -- the effectiveness multiplier next to it. Measuring first guarantees
      -- the two never collide, however long the numbers get.
      local powW = 0
      for _, mv in ipairs(myMoves) do
        local powStr = mv.status
          and ("STATUS " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"))
          or ((mv.power and (mv.power.." pow") or "—") .. " · " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"))
        powW = math.max(powW, textW(powStr, 13))
      end
      local powX = x + w - PAD
      local effX = powX - powW - 14
      for _, mv in ipairs(myMoves) do
        if mv.best then setc(COL.hi, 0.12); rrect("fill", x + PAD - 6, cy - 2, w - PAD*2 + 12, moveRowH - 2, 6) end
        local cx = x + PAD
        cx = cx + chip(cx, cy + 1, mv.type, TYPE[mv.type] or COL.dim)
        local nameStr = mv.name .. (mv.stab and " ★" or "")
        txt(ellipsize(nameStr, 16, effX - 14 - cx), cx, cy, 16, COL.text)
        if mv.status then
          txt("STATUS " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"), powX, cy, 13, COL.dim, "right")
        else
          local tier = mv.mult == 0 and COL.lo or (mv.mult > 10 and COL.super or (mv.mult == 10 and COL.dim or COL.resist))
          txt(effText(mv.mult), effX, cy, 16, tier, "right")
          txt((mv.power and (mv.power.." pow") or "—") .. " · " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"), powX, cy, 13, COL.dim, "right")
        end
        cy = cy + moveRowH
      end
    end
    cy = cy + 6
    txt("THREATS", x + PAD, cy, 13, COL.dim); cy = cy + 22
    if m.threats and #m.threats > 0 then
      for _, t in ipairs(m.threats) do
        local cx = x + PAD; setc(COL.threat, 1)
        txt("⚠", cx, cy, 16, COL.threat); cx = cx + 22
        cx = cx + chip(cx, cy + 1, t.type, TYPE[t.type] or COL.dim)
        txt(ellipsize(t.name .. "  " .. effText(t.mult), 16, x + w - PAD - cx), cx, cy, 16, COL.threat)
        cy = cy + moveRowH
      end
    else
      txt("No super-effective moves from its set.", x + PAD, cy, 15, COL.dim, nil, 0.6); cy = cy + 26
    end
    if nCatch > 0 then
      cy = cy + 4; txt("CATCH ODDS", x + PAD, cy, 13, COL.dim); cy = cy + 22
      for _, c in ipairs(b.catch) do
        local a = c.qty > 0 and 1 or 0.45
        local pctStr = pct(c.pct)
        local pctW = textW(pctStr, 16) + 10
        local nameStr = c.name .. (c.qty > 0 and (" ×"..c.qty) or " (none)")
        txt(ellipsize(nameStr, 16, w - PAD*2 - pctW), x + PAD, cy, 16, COL.text, nil, a)
        local pcol = c.pct >= 60 and COL.hi or (c.pct >= 25 and COL.mid or COL.resist)
        txt(pctStr, x + w - PAD, cy, 16, pcol, "right", a)
        cy = cy + 26
      end
    end
    return h
  end

  -- Items panel: two fixed columns (Balls | Healing), capped with "+N more".
  local ITEM_CAP = 6
  local function items(st, x, y, measureOnly)
    local it = st.items
    if not it or (#it.balls == 0 and #it.heals == 0) then return 0 end
    local w = COLW; local colGap = 18
    local cw = (w - PAD*2 - colGap) / 2
    local nB = math.min(ITEM_CAP, #it.balls); local nH = math.min(ITEM_CAP, #it.heals)
    local moreB, moreH = #it.balls - nB, #it.heals - nH
    local rows = math.max(nB, nH, 1)
    local extra = (moreB > 0 or moreH > 0) and 18 or 0
    local h = PAD + 34 + 22 + rows*22 + extra + PAD
    if measureOnly then return h end
    panel(x, y, w, h, false)
    txt("Items", x + PAD, y + PAD, 26, COL.text)
    local lcx = x + PAD; local rcx = x + PAD + cw + colGap
    local hy = y + PAD + 34
    txt("BALLS", lcx, hy, 13, COL.dim)
    txt("HEALING", rcx, hy, 13, COL.dim)
    local cy0 = hy + 22
    for i = 1, nB do local b = it.balls[i]; local ry = cy0 + (i-1)*22
      txt(b.name, lcx, ry, 16, COL.text); txt("×" .. b.qty, lcx + cw, ry, 16, COL.dim, "right") end
    for i = 1, nH do local hh = it.heals[i]; local ry = cy0 + (i-1)*22
      txt(hh.name, rcx, ry, 16, COL.text); txt("×" .. hh.qty, rcx + cw, ry, 16, COL.dim, "right") end
    if #it.balls == 0 then txt("—", lcx, cy0, 16, COL.dim, nil, 0.5) end
    if #it.heals == 0 then txt("—", rcx, cy0, 16, COL.dim, nil, 0.5) end
    if moreB > 0 then txt("+" .. moreB .. " more", lcx, cy0 + nB*22, 12, COL.dim, nil, 0.7) end
    if moreH > 0 then txt("+" .. moreH .. " more", rcx, cy0 + nH*22, 12, COL.dim, nil, 0.7) end
    return h
  end

  -- =====================================================================
  -- Interactive management screens (i = items, p = party/boxes).
  -- Mouse-driven: click to pick up, click a highlighted target to drop.
  -- A lightweight state is pushed onto game.stack so the engine routes ALL
  -- keys to it (Game:keypressed -> top.onKeyPressed) and freezes the world
  -- (stack:update only ticks the top). We draw in raw window coords here.
  -- Milestone 1: open/close/freeze/cursor/capture + read-only panels + hover.
  -- =====================================================================
  if C.screen == nil then C.screen = false end   -- false | "items" | "party"
  C.held    = C.held or nil        -- what the cursor is carrying (later milestones)
  -- v2.9.5 (Gen 2 category reordering): a SEPARATE state from C.held, not
  -- reused -- C.held is deeply typed as "an item stack" throughout this
  -- file (qty/max/from/id, dropBlockedReason, doTransfer, drawHeldItem...),
  -- and overloading it for "a pocket header" would mean auditing every one
  -- of those call sites for a case they were never written to expect.
  -- Kept fully parallel instead: {side, cat, mode="pending"/"drag",
  -- downX, downY}. Only 2 modes (no "armed"/tap-then-tap stage like C.held
  -- has) -- headers are a same-side-only, always-visible, at-most-4-item
  -- reorder, so a plain press-drag-release covers the real use case
  -- without needing the tap-to-arm convenience that matters more for a
  -- long scrolling item list.
  C.heldHeader = C.heldHeader or nil
  C.boxView = C.boxView or nil     -- which box is shown on the right
  C.hit     = C.hit or {}          -- clickable regions recorded each draw
  C.status  = C.status or nil      -- transient footer message
  C.statusAt = C.statusAt or nil   -- when it was set -- see setStatus below and its auto-expire in C.onFrame
  -- Centralizes setting the transient footer message so every caller gets
  -- the auto-expire timestamp for free instead of only some of them
  -- remembering to set it -- see the expiry check in C.onFrame.
  C.setStatus = function(msg)
    C.status = msg
    C.statusAt = love.timer.getTime()
  end
  C.mx, C.my = C.mx or 0, C.my or 0
  C.iv      = C.iv or nil           -- item view order: { bag={ids}, pc={ids} }
  C.isort   = C.isort or { bag = { mode = "custom", dir = 1 }, pc = { mode = "custom", dir = 1 } }
  C.iscroll = C.iscroll or { bag = 0, pc = 0 }
  C.iFocus  = C.iFocus or "bag"      -- which side (bag/pc) D-pad up/down scrolls, controller-only
  C.iCursor = C.iCursor or { bag = 1, pc = 1 }  -- D-pad row highlight per side, controller-only
  C.iCursorVis = C.iCursorVis or {}  -- per-side: is the row cursor highlight currently visible -- true after any scroll (pad or touch), cleared by an outside tap
  C.iLayout = C.iLayout or {}        -- per-side panel geometry, for drop hit-testing
  C.iPanelRect = C.iPanelRect or {}  -- per-side full panel box (header+list+footer), for the held-item darken overlay
  C.iArrowRect = C.iArrowRect or {}  -- per-side scroll-arrow vertical band, for the held-item nudge to avoid
  C.savedFlash = C.savedFlash or {}  -- per-side "Saved!" flash timestamps
  C.pLayout = C.pLayout or {}        -- party/box slot + rail geometry, for drop hit-testing
  -- Ported from the old v80 dev branch (never released publicly, shelved
  -- when the sandbox rewrite happened): multi-level Undo for the Items/
  -- Party screens. A stack of state snapshots (most-recent last), pushed by
  -- each committing edit (doTransfer/sortSide/applyOrder/doMonPlace) and
  -- popped by C.doUndo. IN-MEMORY ONLY, never written to the save file, and
  -- cleared the moment any screen opens/closes/switches (see
  -- C.openScreen/closeScreen/onScreenKey) -- while a screen is open it's
  -- modal, so this mod is the only thing changing inventory/party, which is
  -- exactly what keeps a snapshot valid to restore. Persisting it across a
  -- close would risk reverting legitimate later in-game changes, so the
  -- lifetime is deliberately tight. See the snapshot/restore helpers near
  -- sortSide (items) and doMonPlace (party).
  C.undoStack = C.undoStack or {}
  -- v2.9.5: replaces the old L3/R3/[]/"A-Z >" alphabet jump-to-letter --
  -- direct request, the cycle-one-letter-at-a-time approach "isn't good
  -- enough." Real starts-with search + live filtering instead, via a
  -- drawn Pokemon-naming-screen-style letter grid (touch tap or D-pad+A --
  -- the native mobile OS keyboard isn't reachable from mod space, and the
  -- vanilla game's own text entry doesn't use it either, see
  -- C.searchGrid's own drawing code) plus real typing when a physical
  -- keyboard is present (see SEARCH_KEY_POLL/C.pollSearchKeys). Query
  -- state is per-side for Bag/PC (independent searches), one flat string
  -- for Boxes (spans all boxes, not per-box). C.searchGrid is transient
  -- UI state for whichever grid is currently open, nil when closed.
  C.searchQuery = C.searchQuery or { bag = "", pc = "" }
  C.searchQueryBox = C.searchQueryBox or ""
  C.searchGrid = C.searchGrid or nil   -- { target = "bag"|"pc"|"box", cursor = 1 }

  -- item categories (same buckets as the Pocket PC app) -> a colour swatch
  local HEAL_IDS = {
    POTION=1,SUPER_POTION=1,HYPER_POTION=1,MAX_POTION=1,FULL_RESTORE=1,FULL_HEAL=1,ANTIDOTE=1,
    BURN_HEAL=1,ICE_HEAL=1,AWAKENING=1,PARLYZ_HEAL=1,REVIVE=1,MAX_REVIVE=1,ETHER=1,MAX_ETHER=1,
    ELIXER=1,MAX_ELIXER=1,FRESH_WATER=1,SODA_POP=1,LEMONADE=1,
  }
  local BATTLE_IDS = { X_ATTACK=1,X_DEFEND=1,X_SPEED=1,X_SPECIAL=1,X_ACCURACY=1,DIRE_HIT=1,GUARD_SPEC=1,POKE_DOLL=1 }
  local KEY_IDS = { BICYCLE=1,TOWN_MAP=1,ITEMFINDER=1,OLD_ROD=1,GOOD_ROD=1,SUPER_ROD=1,S_S_TICKET=1,
    BIKE_VOUCHER=1,GOLD_TEETH=1,CARD_KEY=1,LIFT_KEY=1,SILPH_SCOPE=1,POKE_FLUTE=1,OAKS_PARCEL=1,
    SECRET_KEY=1,EXP_ALL=1,COIN_CASE=1,DOME_FOSSIL=1,HELIX_FOSSIL=1,OLD_AMBER=1 }
  local function itemCat(id, def)
    if (def and def.ball) or id:find("BALL", 1, true) then return "BALLS" end
    if (def and def.machine) or id:match("^TM") or id:match("^HM") then return "TM" end
    if HEAL_IDS[id] or id:find("POTION",1,true) or id:find("HEAL",1,true) or id:find("REVIVE",1,true)
      or id:find("RESTORE",1,true) or id:find("ETHER",1,true) or id:find("ELIXER",1,true) then return "HEALING" end
    if BATTLE_IDS[id] then return "BATTLE" end
    if KEY_IDS[id] or (def and def.keyItem) or (def and def.pocket == "KEY_ITEM") or (def and def.canToss == false) then return "KEY" end
    return "OTHER"
  end
  local CATCOL = {
    BALLS = hex("e05a5a"), HEALING = hex("7dd87d"), BATTLE = hex("e0b330"),
    KEY = hex("7a8fe0"), TM = hex("b06fd0"), OTHER = hex("9a9a80"),
  }
  local CATORD = { BALLS = 1, HEALING = 2, BATTLE = 3, TM = 4, OTHER = 5, KEY = 6 }
  -- v2.9.5 (Gen 2 item-pocket categories, direct request): Gen 2's real
  -- PACK is 4 independently-ordered pockets, not one flat bag -- kanto's
  -- own 6-category itemCat() taxonomy above doesn't line up with them
  -- (HEALING/BATTLE/OTHER are all really just the one ITEM pocket), and the
  -- drag-reorder + "Save order" flow used to write kanto's own flat,
  -- potentially cross-pocket-interleaved view straight into save.bagOrder
  -- -- which the real engine's own PACK reads back FILTERED PER POCKET
  -- (Bag.move only ever reorders within the one pocket it's given), so a
  -- kanto-side sort/drag that mixes pockets together silently scrambled
  -- each real pocket's own in-game order in a way the player had no way to
  -- see or intend from kanto's unified list. GEN 2 ONLY (gated at every
  -- call site on C.generation == 2): category = the item's real pocket via
  -- C.Bag.pocketOf, the list is ALWAYS grouped by pocket (not just when
  -- Sort > Type is picked -- that button is hidden on Gen 2, GEN2_SORTS
  -- below), and applyOrder stably regroups by pocket before writing
  -- save.bagOrder so it's always valid no matter how the live view got
  -- there. Gen 1 (itemCat/CATORD/CATCOL/the Type sort button) is completely
  -- untouched -- every one of these is read only where C.generation == 2
  -- is already true.
  -- Order + labels verified against the real cart's own tab strip
  -- (src/ui/gen2/PackMenu.lua's own POCKETS table, the literal list that
  -- draws the pocket name across the top of the real PACK screen -- NOT the
  -- same file's header comment about ROM constant order, which names a
  -- different order used elsewhere on the ROM, not what a player sees here).
  -- Hung off C, not new locals: this factory sits at Lua's 200-local
  -- ceiling (same established pattern as C.storageWrite/C.applyLoadedLayout/
  -- C.claimStickAPress elsewhere in this file).
  -- v2.9.5: was a fixed lookup table (canonical cart order only). Direct
  -- request: let the player drag pocket headers to set their OWN order
  -- instead. Now an ORDERED ARRAY (the canonical order is just the
  -- fallback default), with the player's customization persisted in
  -- save.modData[mod.id] -- the engine's own sanctioned per-save slot
  -- (same one C.koCountFor/C.recordKO already use, see that comment for
  -- why it's safe/correct), read fresh every call rather than cached, so
  -- there's no load-timing dance to get wrong (unlike the panel-layout
  -- persistence, which caches into C fields at boot, before a real save
  -- exists -- this only ever runs while the Items screen is open, always
  -- well after a real save is loaded).
  C.GEN2_DEFAULT_POCKET_ORDER = { "ITEM", "BALL", "KEY_ITEM", "TM_HM" }
  function C.gen2PocketOrder()
    local save = C.game and C.game.save
    local md = save and save.modData and save.modData[mod.id]
    local custom = md and md.gen2PocketOrder
    if type(custom) == "table" and #custom == 4 then
      -- validate it's a genuine permutation of the real 4 pockets before
      -- trusting it -- defensive against a foreign/corrupted save value,
      -- not a scenario expected in practice.
      local seen = {}
      for _, p in ipairs(custom) do
        if not C.GEN2_DEFAULT_POCKET_ORDER_SET[p] or seen[p] then return C.GEN2_DEFAULT_POCKET_ORDER end
        seen[p] = true
      end
      return custom
    end
    return C.GEN2_DEFAULT_POCKET_ORDER
  end
  C.GEN2_DEFAULT_POCKET_ORDER_SET = { ITEM = true, BALL = true, KEY_ITEM = true, TM_HM = true }
  function C.gen2SavePocketOrder(order)
    local save = C.game and C.game.save
    if not save then return end
    save.modData = save.modData or {}
    save.modData[mod.id] = save.modData[mod.id] or {}
    save.modData[mod.id].gen2PocketOrder = order
  end
  -- Moves `cat` to just before `beforeCat` in the persisted pocket order
  -- (or to the end if beforeCat is nil/not found) -- the header-drag
  -- equivalent of C.insertBefore, but over the 4-element pocket order
  -- itself rather than an item list, so no pocket-boundary clamping is
  -- needed here (there IS no "wrong pocket" to cross at this level).
  function C.reorderPocketOrder(cat, beforeCat)
    if cat == beforeCat then return end
    local order = C.copyArray(C.gen2PocketOrder())
    for i, p in ipairs(order) do if p == cat then table.remove(order, i); break end end
    local inserted = false
    if beforeCat then
      for i, p in ipairs(order) do
        if p == beforeCat then table.insert(order, i, cat); inserted = true; break end
      end
    end
    if not inserted then order[#order+1] = cat end
    C.gen2SavePocketOrder(order)
    -- v2.9.5 bugfix, direct report ("you let go and they just dont move"):
    -- persisting the new order alone changes nothing the player can SEE --
    -- C.iv[side]'s current item order (what disp/rows actually render) is
    -- built once at screen-open / last sort / last save, and nothing else
    -- re-derives it from C.gen2PocketOrder() on its own. Re-apply the new
    -- order to BOTH panels' live views immediately (the order is shared
    -- across bag/pc), the same regroup used at screen-open and Save-order
    -- time, so the drag's result is visible the instant it lands instead
    -- of only after the screen is closed and reopened.
    if C.iv then
      if C.iv.bag then C.iv.bag = C.gen2RegroupByPocket(C.iv.bag) end
      if C.iv.pc  then C.iv.pc  = C.gen2RegroupByPocket(C.iv.pc)  end
    end
  end
  C.GEN2_POCKET_LABEL = { ITEM = "Items", BALL = "Poke Balls", KEY_ITEM = "Key Items", TM_HM = "TM/HM" }
  -- Reuses kanto's own existing hues where there's a natural match (BALL <-
  -- BALLS, KEY_ITEM <- KEY, TM_HM <- TM); ITEM gets OTHER's neutral grey
  -- rather than HEALING's green, since the real ITEM pocket is everything
  -- from Potions to Repels to Apricorns, not mostly-healing items.
  C.GEN2_POCKET_COL = {
    ITEM = CATCOL.OTHER, BALL = CATCOL.BALLS, KEY_ITEM = CATCOL.KEY, TM_HM = CATCOL.TM,
  }
  -- v2.9.5: "Type" restored on direct request, matching Gen 1's own button
  -- v2.9.5: "Type" removed AGAIN, direct request -- confirmed redundant
  -- with "A-Z" once grouping is unconditional on Gen 2 (groupedView above):
  -- both sort pocket-first, then by name, so the two buttons produced
  -- identical results. Replaced by direct category reordering instead (see
  -- C.gen2PocketOrder/C.reorderPocketOrder below) -- the player drags a
  -- pocket header itself to set its position, rather than picking a sort
  -- mode that happens to group things.
  C.GEN2_SORTS = { {"name","A-Z"}, {"qty","Qty"} }
  function C.gen2Pocket(id)
    return (C.Bag and C.Bag.pocketOf and C.Bag.pocketOf(id, C.game and C.game.data)) or "ITEM"
  end
  -- Display category: real Gen 2 pocket when on Gen 2, kanto's own
  -- itemCat() taxonomy otherwise. NOT used for the multi-select toss-guard
  -- (itemCat(id,def)=="KEY" below) -- that's a distinct, already-correct
  -- concern (Tier-1 fix) this deliberately leaves untouched.
  function C.dispCat(id, def)
    if C.generation == 2 then return C.gen2Pocket(id) end
    return itemCat(id, def)
  end
  function C.catOrd(cat)
    if C.generation == 2 then
      for i, p in ipairs(C.gen2PocketOrder()) do if p == cat then return i end end
      return 9
    end
    return CATORD[cat] or 9
  end
  function C.catCol(cat)
    return (C.generation == 2 and C.GEN2_POCKET_COL[cat]) or CATCOL[cat] or CATCOL.OTHER
  end
  function C.catLabel(cat)
    if C.generation == 2 then return C.GEN2_POCKET_LABEL[cat] or cat end
    return cat:sub(1,1) .. cat:sub(2):lower()
  end
  function C.groupedView(side, st)
    return C.generation == 2 or st.mode == "type"
  end
  -- STABLE sort of an id array by real Gen 2 pocket, preserving each
  -- pocket's own input relative order exactly (the explicit `i` tiebreaker
  -- forces stability -- table.sort itself isn't guaranteed stable). Used
  -- everywhere a Gen-2 item-id array needs to be presented/committed
  -- already grouped: applyOrder's save.bagOrder write, and buildItemView's
  -- initial bag/pc view construction (so the FIRST time the screen opens --
  -- not just after a manual sort/drag -- it's already cleanly grouped).
  function C.gen2RegroupByPocket(order)
    local withPos = {}
    for i, id in ipairs(order) do
      withPos[i] = { id = id, i = i, ord = C.catOrd(C.gen2Pocket(id)) }
    end
    table.sort(withPos, function(a, b)
      if a.ord ~= b.ord then return a.ord < b.ord end
      return a.i < b.i
    end)
    local out = {}
    for i, e in ipairs(withPos) do out[i] = e.id end
    return out
  end
  -- v2.9.5 (Gen 2 item-pocket categories, direct request: "make it so you
  -- cant bring an item outside of its category" -- a live drag/transfer
  -- crossing a pocket's visual boundary was creating a duplicate header for
  -- that pocket further down the list). Redirects a same-side drag or
  -- cross-side transfer's drop target so `id` can never land in a
  -- different real Gen 2 pocket than its own -- the real cart's own PACK
  -- never allows this either (Bag.move only ever reorders within the one
  -- pocket it's given). If beforeId's pocket differs from id's own, snaps
  -- to whichever edge of id's own pocket's CURRENT run is nearest the
  -- direction beforeId was dragged toward: past the end of the run if
  -- beforeId's pocket sorts later, before the start if it sorts earlier.
  -- v is assumed to already be validly pocket-grouped (an invariant this
  -- function itself preserves as long as every insert goes through it) --
  -- C.gen2RegroupByPocket above is the belt-and-suspenders backstop for
  -- save.bagOrder specifically in case anything still slips past this.
  function C.gen2ClampInsert(v, id, beforeId)
    local pocket = C.gen2Pocket(id)
    local ownOrd = C.catOrd(pocket)
    local beforeOrd = beforeId and C.catOrd(C.gen2Pocket(beforeId)) or math.huge
    if beforeOrd == ownOrd then return beforeId end   -- same pocket, always a valid target
    -- id's own pocket's current run, excluding id itself (still present in
    -- v at this point for some callers, absent for others -- safe either way).
    local firstOwn, lastOwn
    for i, vid in ipairs(v) do
      if vid ~= id and C.gen2Pocket(vid) == pocket then
        firstOwn = firstOwn or i; lastOwn = i
      end
    end
    if not firstOwn then
      -- id's own pocket is currently empty in v -- find where it belongs by
      -- canonical pocket order instead: right before the first item whose
      -- pocket sorts AFTER id's own (nil if none -- append).
      for i, vid in ipairs(v) do
        if vid ~= id and C.catOrd(C.gen2Pocket(vid)) > ownOrd then return vid end
      end
      return nil
    end
    if beforeOrd > ownOrd then
      -- dragged past id's own group into a LATER one -- snap to the end of
      -- id's own run (whatever currently follows its last other member).
      local after = v[lastOwn + 1]
      return (after == id) and v[lastOwn + 2] or after
    end
    -- dragged before id's own group into an EARLIER one -- snap to the start.
    return v[firstOwn]
  end
  -- Was a bare local -- promoted to C.insertBefore (not renamed in place)
  -- so it's callable from itemRows below, which is declared earlier in this
  -- factory than insertBefore's own old position was; a bare local would
  -- have been an unresolved forward reference there (nil global at call
  -- time), the same class of bug this file's own history has hit before.
  function C.insertBefore(v, id, beforeId)
    if C.generation == 2 then beforeId = C.gen2ClampInsert(v, id, beforeId) end
    if beforeId and beforeId ~= id then
      for i, vid in ipairs(v) do if vid == beforeId then table.insert(v, i, id); return end end
    end
    v[#v+1] = id
  end
  local PC_ITEM_CAP = 50
  -- Design-unit height of one item row in the Items screen list. Shared
  -- constant (rather than the old inline "50" local to itemPanel) so the
  -- page-arrow paging math in C.onPadPage can compute "how many rows are
  -- currently visible" using the exact same number the draw loop uses --
  -- letting the two drift out of sync would make paging over/undershoot.
  local ITEM_ROW_H = 50
  -- Reads the bag capacity through the actual documented registry API
  -- (mod.content.constants:get, the read side of the same :patch call a
  -- bag-capacity mod like Bottomless Bag uses to raise it) rather than
  -- guessing at an internal Bag.* field -- an earlier attempt guessing
  -- "Bag.capacity" based on a comment in that mod's own source turned out
  -- to be wrong (the display kept showing the base 20 with the mod
  -- active) after ALSO briefly causing a crash by assuming a type that
  -- wasn't there. :get reads the current MERGED value regardless of which
  -- mod, if any, patched it -- not specific to any one bag-expansion mod.
  -- Every step is pcall/type-guarded so a wrong guess here can only ever
  -- fall back to a safe default, never throw.
  local function bagCapacity()
    local ok, v = pcall(function() return mod.content.constants:get("bagSize") end)
    if ok and type(v) == "number" then return v end
    v = C.Bag and (C.Bag.capacity or C.Bag.CAPACITY)
    if type(v) == "number" then return v end
    return 20
  end
  -- Fewer than 255 distinct item IDs exist in Gen 1 at all (per the
  -- Bottomless Bag mod's own reasoning for choosing that number), so a
  -- capacity at or above that is effectively unlimited -- shown as an
  -- infinity symbol instead of a slot count that could never actually be
  -- reached.
  local BAG_EFFECTIVELY_UNLIMITED = 255

  local function itemName(id)
    local d = C.game and C.game.data and C.game.data.items and C.game.data.items[id]
    return (d and d.name) or tostring(id)
  end
  local function monMax(mon, def)
    if mon.stats and mon.stats.hp then return mon.stats.hp end
    -- v2.9.5 Gen2 bugfix (Tier 5 of the Session-11 audit): the engine's own
    -- Stats.calc (src/pokemon/Stats.lua, real engine code -- not ours to
    -- edit, per the standing "isn't ours, don't touch it" rule) computes
    -- all five stats in one pass, {hp, attack, defense, speed, special} in
    -- that order, with no per-stat isolation -- reading baseStats.special
    -- (Gen1-only; Gen2's real species data splits it into
    -- specialAttack/specialDefense instead, confirmed against the real
    -- imported Gen2 pokemon.lua) throws, discarding the ALREADY-VALID hp
    -- result computed earlier in the same pass along with it. The old
    -- pcall here only ever caught this as an all-or-nothing failure,
    -- silently falling back to the mon's CURRENT hp as a wrong "max" on
    -- Gen2 -- not a crash, but a wrong number, whenever this less-common
    -- path (a box/daycare mon with no cached .stats yet) is actually hit.
    -- Since this function only ever needs .hp, and HP's own formula reads
    -- only baseStats.hp (present identically on both generations,
    -- confirmed), computing it directly here sidesteps the engine's
    -- Gen1-only Special read entirely. Formula mirrors Stats.lua's own
    -- documented CalcStat exactly (its own top-of-file comment).
    if def and def.baseStats and def.baseStats.hp then
      local dv = (mon.dvs and mon.dvs.hp) or 0
      local se = (mon.statExp and mon.statExp.hp) or 0
      local ev = math.floor(math.min(255, math.ceil(math.sqrt(se))) / 4)
      local level = mon.level or 1
      return math.floor(((def.baseStats.hp + dv) * 2 + ev) * level / 100) + level + 10
    end
    return mon.hp or 1
  end
  local function bagList()
    local save = C.game and C.game.save; if not save then return {} end
    local inv, order = save.inventory or {}, save.bagOrder
    local list, seen = {}, {}
    local function add(id)
      if inv[id] and inv[id] > 0 and not seen[id]
        and not (C.Bag and C.Bag.isBadge and C.Bag.isBadge(id)) then
        seen[id] = true; list[#list+1] = { id = id, name = itemName(id), qty = inv[id] }
      end
    end
    if order then for _, id in ipairs(order) do add(id) end end
    for id in pairs(inv) do add(id) end
    return list
  end
  local function pcItemList()
    local save = C.game and C.game.save; if not save then return {} end
    local pc, order = save.pcItems or {}, save.pcOrder
    local list, seen = {}, {}
    local function add(id)
      if pc[id] and pc[id] > 0 and not seen[id] then
        seen[id] = true; list[#list+1] = { id = id, name = itemName(id), qty = pc[id] }
      end
    end
    if order then for _, id in ipairs(order) do add(id) end end
    for id in pairs(pc) do add(id) end
    return list
  end

  -- v2.9.5, portrait page-scroll: while the Items/Party panel stack draws
  -- inside a scrolled viewport, each panel sits at its SCROLLED position --
  -- so the panel below the fold registers hit regions outside the visible
  -- viewport (down in the footer / engine D-pad strip), where a stray tap
  -- would land on an invisible row. Anything registered while this clip is
  -- set gets trimmed to the visible band, exactly the way setScissor trims
  -- the drawing, so hit-testing and what's actually on screen can never
  -- disagree. nil (the default) everywhere else, so landscape and every
  -- other screen are completely unaffected. Lives on C rather than as a
  -- local because this function already sits at LuaJIT's hard 200-local
  -- ceiling -- one more local here is a load-time error, not a style call.
  -- record a clickable region (design units) + report hover
  local function region(x, y, w, h, tag, data)
    if C.regionClip then
      local y1 = math.max(y, C.regionClip.y1)
      local y2 = math.min(y + h, C.regionClip.y2)
      if y2 <= y1 then return false end   -- entirely scrolled out of view: not drawn, so not clickable
      C.hit[#C.hit+1] = { x = x, y = y1, w = w, h = y2 - y1, tag = tag, data = data }
      return C.mx >= x and C.mx <= x+w and C.my >= y1 and C.my <= y2
    end
    C.hit[#C.hit+1] = { x = x, y = y, w = w, h = h, tag = tag, data = data }
    return C.mx >= x and C.mx <= x+w and C.my >= y and C.my <= y+h
  end
  local function listPanel(px, py, pw, ph, title, sub, rows, sideTag)
    panel(px, py, pw, ph, false)
    txt(title, px+PAD, py+14, 22, COL.text)
    if sub then txt(sub, px+pw-PAD, py+18, 15, COL.dim, "right") end
    local ry, rh = py+56, 40
    local maxRows = math.max(1, math.floor((ph - 70) / rh))
    for i = 1, math.min(#rows, maxRows) do
      local r = rows[i]; local y = ry + (i-1)*rh
      local hov = region(px+8, y, pw-16, rh-4, sideTag, i)
      if hov then setc(COL.gold, 0.13); rrect("fill", px+8, y, pw-16, rh-4, 8) end
      txt(ellipsize(r.name, 18, pw - PAD*2 - 70), px+PAD, y+5, 18, COL.text)
      if r.right then txt(r.right, px+pw-PAD, y+6, 15, COL.dim, "right") end
    end
    if #rows == 0 then txt("- empty -", px+PAD, ry, 16, COL.dim, nil, 0.6) end
    if #rows > maxRows then txt("+"..(#rows-maxRows).." more", px+PAD, py+ph-26, 13, COL.dim) end
  end

  local function invOf(side)
    local save = C.game and C.game.save; if not save then return {} end
    return side == "bag" and (save.inventory or {}) or (save.pcItems or {})
  end
  local function isBadgeItem(id) return C.Bag and C.Bag.isBadge and C.Bag.isBadge(id) end
  local function buildItemView()
    C.iv = { bag = {}, pc = {} }
    for _, r in ipairs(bagList()) do C.iv.bag[#C.iv.bag+1] = r.id end
    -- the in-game PC always shows items A-Z, so open the PC view that way to match
    local pcRows = pcItemList()
    table.sort(pcRows, function(a, b) return a.name < b.name end)
    for _, r in ipairs(pcRows) do C.iv.pc[#C.iv.pc+1] = r.id end
    C.isort.pc = { mode = "name", dir = 1 }
    -- v2.9.5 (Gen 2 item-pocket categories): regroup both views by real
    -- pocket right away, so the FIRST time the screen opens -- not just
    -- after the player manually sorts or drags -- it's already cleanly
    -- grouped rather than showing whatever interleaving save.bagOrder (or,
    -- for PC, the fresh A-Z order above) happens to be in. PC has no real
    -- persisted order to protect, but gets the same treatment for display
    -- consistency with the Bag panel right next to it.
    if C.generation == 2 then
      C.iv.bag = C.gen2RegroupByPocket(C.iv.bag)
      C.iv.pc = C.gen2RegroupByPocket(C.iv.pc)
    end
  end
  local function itemRows(side)
    if not C.iv then buildItemView() end
    local inv, seen, rows = invOf(side), {}, {}
    for _, id in ipairs(C.iv[side] or {}) do
      if inv[id] and inv[id] > 0 and not seen[id] and not (side == "bag" and isBadgeItem(id)) then
        seen[id] = true
        rows[#rows+1] = { id = id, name = itemName(id), qty = inv[id], cat = C.dispCat(id, C.game.data.items[id]) }
      end
    end
    for id, q in pairs(inv) do   -- newly-acquired items not yet in the view order
      if q > 0 and not seen[id] and not (side == "bag" and isBadgeItem(id)) then
        seen[id] = true; C.insertBefore(C.iv[side], id, nil)
        rows[#rows+1] = { id = id, name = itemName(id), qty = q, cat = C.dispCat(id, C.game.data.items[id]) }
      end
    end
    return rows
  end
  -- v2.9.5: case-insensitive starts-with match for the new search feature.
  -- Compares against the SANITIZED name (the form txt() actually draws,
  -- not the raw string) -- the dex-tally name-width bug earlier this
  -- project was exactly this class of mismatch (measuring/matching a raw
  -- string that draws differently after gender-symbol substitution), so
  -- this is deliberate, not an oversight. query is always already
  -- uppercase (built that way by C.searchAppendLetter), so only name
  -- needs uppercasing here.
  C.searchMatch = function(name, query)
    if query == "" then return true end
    local s = sanitize(name):upper()
    return s:sub(1, #query) == query
  end
  -- v2.9.5: the filtered view itemPanel/the D-pad nav functions actually
  -- draw/navigate, layered OVER itemRows rather than baked into it --
  -- itemRows itself stays untouched and keeps returning the TRUE full
  -- list, because sortSide rebuilds C.iv[side] FROM itemRows' return
  -- value, and filtering that would silently drop non-matching items to
  -- the end of the custom order on the next sort while a search is
  -- active. itemPanel's own "N/cap slots" count also needs the true
  -- count, not the filtered one. So: itemRows = truth, C.visibleRows =
  -- what's currently shown/reachable, and each call site picks whichever
  -- it actually needs.
  C.visibleRows = function(side)
    local rows = itemRows(side)
    local q = C.searchQuery[side]
    if q == "" then return rows end
    local out = {}
    for _, r in ipairs(rows) do
      if C.searchMatch(r.name, q) then out[#out+1] = r end
    end
    return out
  end
  -- Pixel offset (within the scrollable content, ignoring current scroll) of
  -- row `idx` in `side`'s list, plus its height. Mirrors the disp/header
  -- layout built in itemPanel below, so the D-pad cursor can figure out
  -- where a row will land and scroll it into view before that row is drawn.
  local function itemContentOffset(side, idx)
    local rows = C.visibleRows(side)
    local headH, itemH = 26, ITEM_ROW_H   -- itemH bumped from 38 -- bigger, easier-to-grab touch targets on small screens (fewer rows visible at once, ~12 instead of ~16). Must match itemPanel's own headH/itemH below.
    if not C.groupedView(side, C.isort[side]) then return (idx-1)*itemH, itemH end
    local prev, offset = nil, 0
    for i, r in ipairs(rows) do
      if r.cat ~= prev then offset = offset + headH; prev = r.cat end
      if i == idx then return offset, itemH end
      offset = offset + itemH
    end
    return offset, itemH
  end
  -- Undo, shared low-level helpers (ported from v80). Attached to C (field
  -- assignments), NOT top-level locals: this factory sits at Lua's 200-local
  -- ceiling, so every new helper here must avoid a local (see C.storageWrite/
  -- C.applyLoadedLayout/C.claimStickAPress elsewhere in this file for the
  -- same pattern already established).
  -- Generic one-level copies. Item maps are { id = qty } (number values) and
  -- item/order/party arrays hold ids or unchanged mon-object references, so a
  -- single level is a full, faithful copy in every case here -- no deep copy,
  -- and no aliasing back to the live table the mutators edit in place.
  function C.copyArray(a) local t = {}; if a then for i = 1, #a do t[i] = a[i] end end; return t end
  function C.copyMap(m)   local t = {}; if m then for k, v in pairs(m) do t[k] = v end end; return t end
  -- Restore a { id = qty } map IN PLACE onto the SAME table object the engine
  -- reads (save.inventory / save.pcItems), rather than reassigning the field
  -- -- the whole file already mutates these in place, so this can't get out of
  -- sync with a reference the game cached.
  function C.restoreMap(tbl, key, snapMap)
    local live = tbl[key]
    if type(live) ~= "table" then live = {}; tbl[key] = live end
    for k in pairs(live) do live[k] = nil end
    for k, v in pairs(snapMap or {}) do live[k] = v end
  end
  -- Restore an array IN PLACE onto the same object (save.party / a box array),
  -- same reasoning as C.restoreMap -- doMonPlace edits these arrays in place.
  function C.restoreArray(live, snapArr)
    for i = #live, 1, -1 do live[i] = nil end
    for i = 1, #(snapArr or {}) do live[i] = snapArr[i] end
  end
  -- Bounds memory; a single screen session never nears this. Inlined as a
  -- literal (not its own local/field) since it's only ever read here.
  function C.pushUndo(snap)
    if not snap then return end
    local st = C.undoStack
    st[#st + 1] = snap
    if #st > 50 then table.remove(st, 1) end
  end
  -- Items snapshot: every field an Items-screen edit can touch. inventory/
  -- pcItems are the real game state; bagOrder/pcOrder are the saved in-game
  -- order; iv is this mod's view order; isort is the sort header state (so
  -- undoing a Sort restores the header too, not just the row order).
  function C.snapshotItems()
    local save = C.game and C.game.save
    if not save then return nil end
    return {
      kind = "items",
      inventory = C.copyMap(save.inventory),
      pcItems   = C.copyMap(save.pcItems),
      bagOrder  = save.bagOrder and C.copyArray(save.bagOrder) or nil,
      pcOrder   = save.pcOrder  and C.copyArray(save.pcOrder)  or nil,
      ivBag = C.iv and C.copyArray(C.iv.bag) or nil,
      ivPc  = C.iv and C.copyArray(C.iv.pc)  or nil,
      isortBag = C.isort and { mode = C.isort.bag.mode, dir = C.isort.bag.dir } or nil,
      isortPc  = C.isort and { mode = C.isort.pc.mode,  dir = C.isort.pc.dir  } or nil,
      -- v2.9.5 (Gen 2 category reordering): captured here too so undoing a
      -- header drag doesn't leave save.modData's pocket order out of sync
      -- with everything else this same undo entry restores.
      gen2PocketOrder = C.generation == 2 and C.copyArray(C.gen2PocketOrder()) or nil,
    }
  end
  function C.restoreItems(snap)
    local save = C.game and C.game.save
    if not save then return end
    C.restoreMap(save, "inventory", snap.inventory)
    C.restoreMap(save, "pcItems",   snap.pcItems)
    -- `... or nil` faithfully restores a field that was ABSENT at snapshot
    -- time back to nil (e.g. undoing the very first applyOrder, which had
    -- created bagOrder from nothing).
    save.bagOrder = snap.bagOrder and C.copyArray(snap.bagOrder) or nil
    save.pcOrder  = snap.pcOrder  and C.copyArray(snap.pcOrder)  or nil
    if C.iv then
      C.iv.bag = snap.ivBag and C.copyArray(snap.ivBag) or C.iv.bag
      C.iv.pc  = snap.ivPc  and C.copyArray(snap.ivPc)  or C.iv.pc
    end
    if C.isort then
      if snap.isortBag then C.isort.bag.mode, C.isort.bag.dir = snap.isortBag.mode, snap.isortBag.dir end
      if snap.isortPc  then C.isort.pc.mode,  C.isort.pc.dir  = snap.isortPc.mode,  snap.isortPc.dir  end
    end
    if snap.gen2PocketOrder then C.gen2SavePocketOrder(snap.gen2PocketOrder) end
  end
  -- --------------------------------------------------------------------------
  local function sortSide(side, mode)
    local snap = C.snapshotItems()   -- capture before st/iv change; a sort always flips order and/or the header dir, so it's always undoable
    local st = C.isort[side]
    if st.mode == mode then st.dir = -st.dir else st.dir, st.mode = 1, mode end
    local rows, dir = itemRows(side), st.dir
    table.sort(rows, function(a, b)
      -- v2.9.5 (Gen 2 item-pocket categories): the list is ALWAYS grouped
      -- by real pocket on Gen 2 (groupedView), so every sort mode -- not
      -- just "type" (hidden from the UI on Gen 2 anyway, GEN2_SORTS) --
      -- must sort by pocket FIRST or it would flatten the grouping right
      -- back out. Pocket order itself never reverses with dir -- only the
      -- ordering WITHIN a pocket does -- so the header order stays fixed
      -- (Items/Balls/Key Items/TM's) no matter which sort direction is active.
      if C.generation == 2 then
        local ga, gb = C.catOrd(a.cat), C.catOrd(b.cat)
        if ga ~= gb then return ga < gb end
      end
      local pa, pb
      if mode == "type" then pa, pb = C.catOrd(a.cat), C.catOrd(b.cat)
      elseif mode == "qty" then pa, pb = a.qty, b.qty
      else pa, pb = a.name, b.name end
      if pa == pb then return a.name < b.name end
      if dir < 0 then return pa > pb else return pa < pb end
    end)
    C.iv[side] = {}; for _, r in ipairs(rows) do C.iv[side][#C.iv[side]+1] = r.id end
    C.setStatus(side == "bag"
      and ("Sorted Bag view by "..mode.."  -  press Save order to keep it in-game")
      or  ("Sorted PC view by "..mode.."  -  browsing only (the in-game PC is always A-Z)"))
    C.pushUndo(snap)
  end
  local function orderIds(list, inv)
    local out = {}
    for _, id in ipairs(list or {}) do if inv[id] and inv[id] > 0 then out[#out+1] = id end end
    return out
  end
  local function viewIds(side)  return orderIds(C.iv[side], invOf(side)) end
  local function savedIds(side)
    local save = C.game.save
    return orderIds(side == "bag" and save.bagOrder or save.pcOrder, invOf(side))
  end
  local function isDirty(side)
    local a, b = viewIds(side), savedIds(side)
    if #a ~= #b then return true end
    for i = 1, #a do if a[i] ~= b[i] then return true end end
    return false
  end
  local function applyOrder(side)
    local snap = C.snapshotItems()
    local order = viewIds(side)
    if C.generation == 2 and side == "bag" then
      -- v2.9.5 (Gen 2 item-pocket categories): the real cart's PACK is 4
      -- independently-ordered pockets (Bag.move only ever reorders within
      -- the ONE pocket it's given), so the flat view this mod drags/sorts
      -- around in could still be cross-pocket-interleaved at the moment
      -- Save is pressed (a drag or a PC->Bag transfer can cross a pocket's
      -- visual boundary; nothing in the live view forbids it, deliberately
      -- -- see C.gen2RegroupByPocket's own comment for why that's fine).
      -- Regrouping here guarantees save.bagOrder is always validly
      -- pocket-grouped no matter how the live view got here, while still
      -- preserving each pocket's own relative order -- what the player
      -- actually arranged. C.iv[side] is updated to the same regrouped
      -- order so the view immediately after Save matches what was actually
      -- saved (otherwise isDirty(side) would read true again the instant
      -- they saved).
      order = C.gen2RegroupByPocket(order)
      C.iv[side] = C.copyArray(order)
    end
    if side == "bag" then C.game.save.bagOrder = order else C.game.save.pcOrder = order end
    C.savedFlash[side] = love.timer.getTime()
    C.setStatus("Saved this order to your in-game "..(side=="bag" and "Bag" or "PC"))
    C.pushUndo(snap)
  end
  -- insert `id` before `beforeId` (or append if nil/not found) -- see
  -- C.insertBefore up top for the real implementation (Gen 2 pocket-clamped,
  -- promoted off a bare local to dodge a forward-reference from itemRows).
  local function reorderView(side, id, beforeId)
    if beforeId == id then return end   -- dropping "before itself" is a no-op
    local v = C.iv[side]
    for i, vid in ipairs(v) do if vid == id then table.remove(v, i); break end end
    C.insertBefore(v, id, beforeId)
  end
  -- v2.9.5: `skipUndo` lets a bulk caller (see C.doMultiTransfer) take ONE
  -- snapshot up front and push ONE combined undo entry after N of these
  -- calls, instead of N separate entries a player would need N presses to
  -- fully revert. Every existing single-item call site omits it (defaults
  -- false), so their own undo behavior is completely unchanged.
  local function doTransfer(fromSide, id, qty, toSide, beforeId, skipUndo)
    local save = C.game.save
    qty = math.max(1, math.floor(qty or 1))
    if fromSide == toSide then   -- same-side reorder; only undoable if it actually moved
      local snap = C.snapshotItems()
      local before = table.concat(C.iv[fromSide] or {}, ",")
      reorderView(fromSide, id, beforeId)
      if not skipUndo and table.concat(C.iv[fromSide] or {}, ",") ~= before then C.pushUndo(snap) end
      return true
    end
    local snap = C.snapshotItems()   -- captured before the cross-side move; pushed only on the success path below (failure returns discard it)
    if fromSide == "bag" then
      local inv = save.inventory or {}
      qty = math.min(qty, inv[id] or 0)
      if qty <= 0 then return false, "Nothing to move" end
      local pc = save.pcItems or {}; save.pcItems = pc
      if not pc[id] then local n=0; for _ in pairs(pc) do n=n+1 end
        if n >= PC_ITEM_CAP then return false, "PC is full" end end
      C.Bag.remove(save, id, qty); pc[id] = (pc[id] or 0) + qty
    else
      local pc = save.pcItems or {}
      qty = math.min(qty, pc[id] or 0)
      if qty <= 0 then return false, "Nothing to move" end
      if not C.Bag.add(save, id, qty) then return false, "Bag can't hold more" end
      pc[id] = pc[id] - qty; if pc[id] <= 0 then pc[id] = nil end
    end
    if not (invOf(fromSide)[id] and invOf(fromSide)[id] > 0) then
      for i, vid in ipairs(C.iv[fromSide]) do if vid == id then table.remove(C.iv[fromSide], i); break end end
    end
    local inDest = false
    for _, vid in ipairs(C.iv[toSide]) do if vid == id then inDest = true; break end end
    if not inDest then C.insertBefore(C.iv[toSide], id, beforeId) end
    if not skipUndo then C.pushUndo(snap) end
    return true
  end
  -- v2.9.5: discard an item's ENTIRE stack outright, direct request
  -- (multi-select bulk toss). Respects the same "KEY" category itemCat()
  -- already uses to hide badge/plot items from other flows -- refuses to
  -- toss those rather than silently allowing something no other part of
  -- this mod treats as disposable. Same skipUndo contract as doTransfer.
  C.doToss = function(side, id, skipUndo)
    local def = C.game.data.items[id]
    if itemCat(id, def) == "KEY" then return false, "Can't toss a key item" end
    local save = C.game.save
    local snap = C.snapshotItems()
    if side == "bag" then
      local inv = save.inventory or {}
      local qty = inv[id] or 0
      if qty <= 0 then return false, "Nothing to toss" end
      C.Bag.remove(save, id, qty)
    else
      local pc = save.pcItems or {}
      if not (pc[id] and pc[id] > 0) then return false, "Nothing to toss" end
      pc[id] = nil
    end
    for i, vid in ipairs(C.iv[side]) do if vid == id then table.remove(C.iv[side], i); break end end
    if not skipUndo then C.pushUndo(snap) end
    return true
  end
  -- resolve a cursor position to { side, beforeId } from the recorded row geometry
  local function dropTarget(dx, dy)
    for _, side in ipairs({ "bag", "pc" }) do
      local L = C.iLayout[side]
      if L and dx >= L.x and dx <= L.x+L.w and dy >= L.y-30 and dy <= L.y+L.h+40 then
        for _, it in ipairs(L.items or {}) do
          if dy < it.y + it.h/2 then return side, it.id end
        end
        return side, nil   -- past the last row -> append
      end
    end
    return nil
  end
  -- v2.9.5 (Gen 2 category reordering): header-row equivalent of
  -- dropTarget, scoped to the ONE side the drag started on (headers on the
  -- other side represent the same shared order, but dropping "onto" a
  -- different panel than the one you're dragging in isn't a spatially
  -- sensible gesture, so this doesn't scan both sides the way dropTarget
  -- does). Returns the pocket id the drop lands before, or nil for "past
  -- the last visible header" (append at the end of the persisted order).
  local function headerDropTarget(side, dx, dy)
    local L = C.iLayout[side]
    if not (L and dx >= L.x and dx <= L.x+L.w) then return nil, false end
    for _, hd in ipairs(L.headers or {}) do
      if dy < hd.y + hd.h/2 then return hd.cat, true end
    end
    return nil, true   -- past the last header -> append
  end
  -- why a drop onto `toSide` would be refused (nil = it's fine). Mirrors doTransfer.
  local function dropBlockedReason(fromSide, id, qty, toSide)
    if fromSide == toSide then return nil end     -- same-side reorder is always ok
    local save = C.game.save
    if toSide == "pc" then
      local pc = save.pcItems or {}
      if not pc[id] then
        local n = 0; for _ in pairs(pc) do n = n + 1 end
        if n >= PC_ITEM_CAP then return "PC is full" end
      end
    else
      local inv = save.inventory or {}
      -- v2.9.5 (Gen 2 Tier-2 audit fix): was comparing slots summed across
      -- ALL of Gen 2's 4 item pockets (Bag.slots(save) with no pocket arg)
      -- against ONE pocket's capacity (bagCapacity(), the flat ITEM-pocket
      -- number) -- false "Bag is full" refusals blocking a legit PC->Bag
      -- transfer into a pocket that still had plenty of room. The real
      -- doTransfer path just below already delegates to the engine's own
      -- Bag.add(), which is correctly pocket-scoped (Bag.lua: a distinct
      -- item occupies a slot of ITS OWN pocket, and each of the 4 pockets
      -- has its own real capacity -- ITEM 20/BALL 12/KEY_ITEM 25/TM_HM 64).
      -- This pre-flight check now mirrors that exact logic via the same
      -- Bag.pocketOf/slots/capacity, instead of reimplementing a flat,
      -- non-pocket-aware version. No behavior change on Gen 1: the real
      -- imported Gen 1 item data never sets a `.pocket` field at all, so
      -- Bag.pocketOf's fallback resolves every Gen 1 item to "ITEM"
      -- uniformly, same single-bag-cap result as before.
      local pocket = C.Bag and C.Bag.pocketOf and C.Bag.pocketOf(id, C.game.data)
      local slots = (C.Bag and C.Bag.slots and C.Bag.slots(save, C.game.data, pocket)) or 0
      local cap = (C.Bag and C.Bag.capacity and C.Bag.capacity(C.game.data, pocket)) or bagCapacity()
      if not inv[id] and slots >= cap then return "Bag is full" end
      if (inv[id] or 0) + (qty or 1) > 99 then return "Stack maxed (99)" end
    end
    return nil
  end

  local SORTS = { {"type","Type"}, {"name","A-Z"}, {"qty","Qty"} }
  local function triangle(cx, cy, up, d)
    d = d or 4
    if up then love.graphics.polygon("fill", cx*s, (cy-d)*s, (cx-d)*s, (cy+d)*s, (cx+d)*s, (cy+d)*s)
    else       love.graphics.polygon("fill", (cx-d)*s, (cy-d)*s, (cx+d)*s, (cy-d)*s, cx*s, (cy+d)*s) end
  end
  local function itemPanel(side, px, py, pw, ph, isPortraitScreen)
    -- v2.9.5: trueCount is the real inventory count (capacity display must
    -- reflect it even mid-search, or "3/20 slots" would look like the bag
    -- shrank); rows is the search-filtered view everything else in this
    -- function -- drawing, cursor clamping -- should actually respect.
    local trueCount = #itemRows(side)
    local rows = C.visibleRows(side)
    local padHeld = C.held and C.held.pad
    -- Normally the cursor can only sit ON a row. While this side is focused
    -- during a pad pickup -- source side included, now that the D-pad can
    -- reorder in place as well as transfer -- it can also sit one past the
    -- last row, an "append to the end of the list" slot.
    local isDropSide = padHeld and side == C.iFocus
    local maxCur = isDropSide and (#rows + 1) or #rows
    C.iCursor[side] = maxCur > 0 and math.max(1, math.min(maxCur, C.iCursor[side] or 1)) or 1
    local cap = side == "bag" and bagCapacity() or PC_ITEM_CAP
    -- Where the item would land: the D-pad's focused side for a pad pickup,
    -- otherwise wherever the mouse cursor is (drag / click-then-click).
    local ds = padHeld and C.iFocus or dropTarget(C.mx, C.my)
    local isTarget = C.held and C.held.from ~= side and ds == side
    local blocked = isTarget and dropBlockedReason(C.held.from, C.held.id, C.held.qty, side)
    -- Gold panel border: the D-pad's focused side, before OR during a pad
    -- pickup (so it never disappears once you pick something up), or the
    -- classic "not holding anything" focus for keyboard/mouse users.
    local focused = C.iFocus == side and (padHeld or not C.held)
    panel(px, py, pw, ph, (isTarget and not blocked) or focused)   -- gold glow when droppable, or D-pad focused
    if blocked then
      setc(COL.lo, 0.08); rrect("fill", px, py, pw, ph, 14)
      love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.lo, 0.85); rrect("line", px, py, pw, ph, 14)
    end
    txt(side == "bag" and "BAG" or "PC ITEMS", px+PAD, py+12, 22, COL.text)
    local capStr = cap >= BAG_EFFECTIVELY_UNLIMITED and "\226\136\158" or tostring(cap)
    txt(trueCount.."/"..capStr.." slots", px+pw-PAD, py+16, 14, trueCount>=cap and COL.lo or COL.dim, "right")
    -- controls: Sort [Type][A-Z][Qty]   Save
    local st = C.isort[side]
    local sy, sx = py+46, px+PAD
    txt("Sort", sx, sy+5, 13, COL.dim); sx = sx + textW("Sort", 13) + 8
    -- v2.9.5 (Gen 2 item-pocket categories): "Type" is hidden on Gen 2 --
    -- grouping is always on there (groupedView below), so a mode that
    -- toggles it no longer means anything; A-Z/Qty still sort WITHIN each
    -- pocket (sortSide's own comparator).
    for _, m in ipairs(C.generation == 2 and C.GEN2_SORTS or SORTS) do
      local active = st.mode == m[1]
      local bw = textW(m[2], 13) + (active and 30 or 16)
      region(sx, sy, bw, 26, "sort", { side = side, mode = m[1] })
      setc(active and COL.gold or COL.panel, active and 0.92 or 0.6); rrect("fill", sx, sy, bw, 26, 6)
      txt(m[2], sx+8, sy+5, 13, active and COL.panel or COL.dim)
      if active then setc(COL.panel, 1); triangle(sx+bw-12, sy+13, st.dir > 0) end
      sx = sx + bw + 6
    end
    if side == "bag" then  -- Save order: dim when clean, gold when dirty, green flash on save
      local flash = C.savedFlash[side] and (love.timer.getTime() - C.savedFlash[side] < 1.3)
      local dirty = isDirty(side)
      local lbl = flash and "Saved!" or (dirty and "Save order" or "Saved")
      local bw = textW(lbl, 13) + 18
      local bx = px+pw-PAD-bw
      if dirty and not flash then region(bx, sy, bw, 26, "apply", side) end
      local lit = dirty or flash
      setc(flash and COL.hi or (dirty and COL.gold or COL.panel), lit and 0.9 or 0.45); rrect("fill", bx, sy, bw, 26, 6)
      if C.iFocus == "bag" and C.iOnSave and not C.held then
        love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95); rrect("line", bx, sy, bw, 26, 6)
      end
      txt(lbl, bx+9, sy+5, 13, lit and COL.panel or COL.dim, nil, lit and 1 or 0.6)
    else  -- PC order can't be saved: the in-game PC always displays A-Z.
      -- v2.9.5 bugfix (on-device screenshot report): this used to share
      -- sy+32 with the new multi-select row below, and the two overlapped
      -- into unreadable garbled text on any panel not wide enough for
      -- both a left-aligned "Tap rows to select"/action-bar AND this
      -- right-aligned note on the same line -- confirmed on a real
      -- screenshot, not just in theory. Own row now (sy+64), below the
      -- select row instead of sharing it with it.
      txt("view only - PC is always A-Z in-game", px+pw-PAD, sy+64, 12, COL.dim, "right", 0.7)
    end
    -- v2.9.5: multi-select, direct request. Own row (sy+32, the extra
    -- headroom below reserves this unconditionally on BOTH sides -- see
    -- the ry comment below) rather than squeezing onto the already-tight
    -- sort-button row, which risked overlap on a narrow panel. The action
    -- buttons only appear once 1+ rows are actually selected; the Select
    -- toggle itself is always there once a screen is open.
    do
      local sy2 = sy + 32
      local sx2 = px + PAD
      local active = C.selectMode
      local hf = C.headerFocus[side]
      -- v2.9.5: D-pad focus ring, direct request -- gold outline on
      -- whichever header button C.headerFocus currently points at, drawn
      -- AFTER that button's own fill so it's never hidden underneath.
      -- idx must stay in lockstep with C.headerButtons' own ordering.
      local idx = 1
      local function focusRing(bx2, w)
        if hf == idx then
          love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95)
          rrect("line", bx2, sy2, w, 24, 6)
          love.graphics.setLineWidth(1)
        end
        idx = idx + 1
      end
      -- v2.9.5: replaces the old "A-Z >" jump-letter button -- opens the
      -- letter-grid search modal (C.searchGrid). Label doubles as the
      -- active-query indicator so there's no separate readout needed;
      -- tapping it while a query is active reopens the grid to refine or
      -- backspace it, same as tapping it fresh.
      local squery = C.searchQuery[side]
      local slbl = squery ~= "" and ("Search: " .. squery) or "Search"
      local sw = textW(slbl, 13) + 18
      region(sx2, sy2, sw, 24, "search", side)
      setc(squery ~= "" and COL.gold or COL.panel, squery ~= "" and 0.85 or 0.55); rrect("fill", sx2, sy2, sw, 24, 6)
      txt(slbl, sx2+9, sy2+4, 13, squery ~= "" and COL.panel or COL.dim)
      focusRing(sx2, sw)
      sx2 = sx2 + sw + 8
      local lbl = active and "Selecting" or "Select"
      local bw = textW(lbl, 13) + 18
      region(sx2, sy2, bw, 24, "selectmode")
      setc(active and COL.gold or COL.panel, active and 0.9 or 0.55); rrect("fill", sx2, sy2, bw, 24, 6)
      txt(lbl, sx2+9, sy2+4, 13, active and COL.panel or COL.dim)
      focusRing(sx2, bw)
      sx2 = sx2 + bw + 8
      if active then
        local n = 0; for _ in pairs(C.multiSelect[side]) do n = n + 1 end
        if n > 0 then
          local tlbl = "Transfer (" .. n .. ")"
          local tw = textW(tlbl, 13) + 16
          region(sx2, sy2, tw, 24, "multitransfer", side)
          setc(COL.hi, 0.85); rrect("fill", sx2, sy2, tw, 24, 6)
          txt(tlbl, sx2+8, sy2+4, 13, COL.panel)
          focusRing(sx2, tw)
          sx2 = sx2 + tw + 8
          local dlbl = "Discard (" .. n .. ")"
          local dw = textW(dlbl, 13) + 16
          region(sx2, sy2, dw, 24, "multitoss", side)
          setc(COL.lo, 0.75); rrect("fill", sx2, sy2, dw, 24, 6)
          txt(dlbl, sx2+8, sy2+4, 13, COL.panel)
          focusRing(sx2, dw)
        else
          txt("Tap rows to select", sx2, sy2+4, 12, COL.dim, nil, 0.6)
        end
      end
    end
    -- build display list (category headers when sorted by Type, or always
    -- on Gen 2 -- see groupedView's own comment up top for the why)
    local grouped = C.groupedView(side, st)
    local disp = {}
    if grouped then
      local counts = {}; for _, r in ipairs(rows) do counts[r.cat] = (counts[r.cat] or 0)+1 end
      local prev
      for _, r in ipairs(rows) do
        if r.cat ~= prev then disp[#disp+1] = { head = true, cat = r.cat, n = counts[r.cat] }; prev = r.cat end
        disp[#disp+1] = { r = r }
      end
    else
      for _, r in ipairs(rows) do disp[#disp+1] = { r = r } end
    end
    local headH, itemH = 26, ITEM_ROW_H   -- bumped from 38 -- bigger, easier-to-grab touch targets on small screens; ~12 rows visible at once instead of ~16. Must match itemContentOffset above.
    -- Extra headroom (was 84) so the PC panel's "view only" note has its own
    -- line below the sort buttons without crowding the item list; applied to
    -- both sides so the two panels' lists still start at the same height.
    -- v2.9.5: +50 (was 96) for the new multi-select row (Select toggle +
    -- Transfer/Discard once something's selected) PLUS the PC-only "view
    -- only" note's own now-separate row below it (moved off sy+32 to fix
    -- the overlap above) -- unconditional on both sides so the list's
    -- start height never shifts between select mode on/off or bag/pc,
    -- same "reserve it either way" reasoning the PC note always used.
    local ry = py + 146
    -- v2.9.5 fix, direct report + screenshot (portrait, stacked panels): a
    -- panel's ph is now roughly HALF what it used to be once two panels
    -- share the screen's height instead of one owning all of it -- this
    -- subtraction could go zero or negative, and a non-positive-height
    -- love.graphics.setScissor rect clips away EVERYTHING inside it, not
    -- just some rows -- confirmed exactly this on a real screenshot (the
    -- whole Bag list vanished, header still drawing fine since that's
    -- unclipped). Already a real scroll+scissor list (unlike partyPanel's
    -- fixed-6-rows math, fixed separately) -- it just needed a floor so
    -- the viewport itself can't collapse to nothing; the list still
    -- genuinely scrolls to reach everything beyond whatever height that
    -- floor leaves available.
    -- v2.9.5 CORRECTION (2026-08-23): this was `math.max(ITEM_ROW_H * 2.5,
    -- ...)` -- a floor, which was the wrong medicine and made things worse
    -- in a way a screenshot caught immediately. The floor stopped the list
    -- VANISHING (a non-positive scissor clips away everything inside it),
    -- but it did it by forcing a viewport taller than the panel had room
    -- for: `ry` was already at the panel's bottom edge, so the list simply
    -- rendered OUTSIDE its own panel, floating loose over the game world.
    -- Clamped to what the panel actually has instead -- a list can never
    -- draw outside its panel now, and if there's genuinely no room it
    -- draws nothing rather than spilling. The real cure for the height
    -- itself is the portrait page scroll (see C.drawPanelPage).
    local listH = math.max(0, ph - (ry - py) - 40)
    local contentH = 0
    for _, e in ipairs(disp) do contentH = contentH + (e.head and headH or itemH) end
    local maxScroll = math.max(0, contentH - listH)
    C.iscroll[side] = math.max(0, math.min(maxScroll, C.iscroll[side] or 0))
    -- Continues an in-progress drag of this list's scrollbar. Polled every
    -- frame this panel draws rather than driven by a move event, for the
    -- reason partyPanel's own scrollbar poll spells out: a single press/
    -- release pair can't track continuous movement on its own.
    if C.iScrollDrag and C.iScrollDrag.side == side then
      if maxScroll > 0 and C.pointerHeld() then
        local d = C.iScrollDrag
        local track = listH - d.thumbH
        local frac = track > 0 and ((C.my - d.startY) / track) or 0
        C.iscroll[side] = math.max(0, math.min(maxScroll, d.startScroll + frac * maxScroll))
      else
        C.iScrollDrag = nil
      end
    end
    -- Auto-scroll THIS list while carrying an item and holding near its top
    -- or bottom edge. Setting C.listAutoConsumed tells C.drawPanelPage's
    -- page-level auto-scroll to stand down this frame -- so the list under
    -- your finger scrolls first, and the page only takes over once this
    -- list has run out (the chaining Bhk asked for). Gated on C.held: an
    -- edge hold with empty hands is just a press, and must stay one.
    -- v2.9.5 (Gen 2 category reordering): same gate now also covers
    -- dragging a pocket header on this exact side -- direct request to
    -- reuse this exact edge-scroll behavior for header reordering too.
    local draggingHeaderHere = C.heldHeader and C.heldHeader.side == side
    local holdingSomething = C.held or draggingHeaderHere
    local edge, dt = 44, love.timer.getDelta()
    local cur = C.iscroll[side]
    local zone
    if maxScroll > 0 and C.mx >= px and C.mx <= px+pw then
      if C.my > ry + listH - edge and C.my <= ry + listH and cur < maxScroll then zone = "bottom"
      elseif C.my < ry + edge and C.my >= ry and cur > 0 then zone = "top" end
    end
    -- v2.9.5, REMOVED (direct report, Session 14 -- correcting an earlier
    -- same-session fix that only removed this feature's 0.5s debounce, not
    -- the feature itself): plain stick-browsing (cursor moved near an edge
    -- with nothing held) no longer auto-scrolls at all -- using stick
    -- POSITION near an edge to trigger a scroll was the actual complaint,
    -- not the timing of it. Auto-scroll near an edge is back to its
    -- pre-Session-13 shape: only while actively holding/dragging something
    -- (item or header) with the pointer down, for every input method
    -- (mouse/touch/stick+A-hold) alike.
    -- v2.9.5 bugfix, direct report+correction (Session 14 -- this is the
    -- THIRD placement of this exact "pause the edge-scroll" ask; the first
    -- two both targeted the wrong mechanism): dragging an item from Bag to
    -- PC (or back) in portrait passes near THIS panel's own top/bottom
    -- edge on the way -- the item's real destination is the OTHER panel,
    -- not "scroll this list for more room" -- so firing instantly made an
    -- ordinary cross-panel drag also scroll the panel out from under it.
    -- Debounced to a genuine ~1/3s CONTINUOUS hold in the same zone
    -- (tuned down from an initial 0.5s, direct request), portrait only --
    -- landscape's side-by-side layout has no adjacent-panel-crossing
    -- ambiguity here (the other panel is beside it, not above/below), so
    -- its own holding-edge-scroll stays instant, unchanged, exactly as
    -- it's always been. C.itemEdgeHold tracks which side/zone is currently
    -- being timed; cleared on zone change, leaving the zone, or releasing,
    -- so a stale timer can never carry over.
    local scrollNow = false
    if zone and holdingSomething and C.pointerHeld() then
      if isPortraitScreen then
        local hold = C.itemEdgeHold
        if hold and hold.side == side and hold.zone == zone then
          hold.t = hold.t + dt
          scrollNow = hold.t >= (1/3)
        else
          C.itemEdgeHold = { side = side, zone = zone, t = 0 }
        end
      else
        scrollNow = true
      end
    elseif C.itemEdgeHold and C.itemEdgeHold.side == side then
      C.itemEdgeHold = nil
    end
    if scrollNow then
      if zone == "bottom" then C.iscroll[side] = math.min(maxScroll, cur + 700*dt)
      else C.iscroll[side] = math.max(0, cur - 700*dt) end
      C.listAutoConsumed = true
    end
    local scroll = C.iscroll[side]
    local items = {}
    local headers = {}   -- v2.9.5 (Gen 2 category reordering): header row positions, for headerDropTarget
    -- listH > 0 guard: these two empty-state strings draw OUTSIDE the list's
    -- scissor, so on a panel too short to host a list at all they would be
    -- the one thing still painting below the panel's own bottom edge --
    -- precisely the "content escaping its panel" failure this pass exists
    -- to end. No room for a list means no room for its placeholder either.
    if listH > 0 and #rows == 0 and trueCount > 0 and C.searchQuery[side] ~= "" then
      txt("No matches for \"" .. C.searchQuery[side] .. "\"", px+PAD, ry, 15, COL.dim, nil, 0.6)
    end
    local prevSc = C.pushScissor(math.floor(px*s), math.floor(ry*s), math.ceil(pw*s), math.ceil(listH*s))
    local yy = ry - scroll
    local itemIdx = 0   -- running index into `rows`, skipping headers -- lines up with C.iCursor[side]
    for _, e in ipairs(disp) do
      if e.head then
        -- v2.9.5 (Gen 2 category reordering, direct request): the header
        -- itself is now a drag source on Gen 2 -- mirrors the item row
        -- region just below (same hit-rect shape, same "hov"-tint
        -- convention), tracked in `headers` for headerDropTarget the same
        -- way `items` feeds dropTarget. Gen 1's own Sort>Type headers stay
        -- pure display, not draggable -- there's no persisted category
        -- ORDER to reorder on Gen 1 (CATORD is a fixed constant, and
        -- Gen 1's whole category system is untouched by this feature).
        local isGen2Header = C.generation == 2
        local draggedAway = isGen2Header and C.heldHeader and C.heldHeader.side == side and C.heldHeader.cat == e.cat
        if yy + headH > ry and yy < ry + listH then
          local hov = isGen2Header and region(px+8, yy, pw-16, headH-3, "headerrow", { side = side, cat = e.cat })
          if isGen2Header then
            setc(C.catCol(e.cat), draggedAway and 0.05 or (hov and 0.14 or 0.03))
            rrect("fill", px+8, yy, pw-16, headH-3, 6)
          end
          setc(C.catCol(e.cat), draggedAway and 0.4 or 0.95); rrect("fill", px+PAD, yy+headH-11, 10, 10, 2)
          local cname = C.catLabel(e.cat)
          txt(cname, px+PAD+16, yy+3, 13, COL.dim, nil, draggedAway and 0.5 or 1)
          txt("("..e.n..")", px+PAD+18+textW(cname, 13), yy+4, 12, COL.dim, nil, draggedAway and 0.3 or 0.65)
          setc(COL.border, 0.09); love.graphics.setLineWidth(math.max(1, s))
          love.graphics.line((px+PAD)*s, (yy+headH-1)*s, (px+pw-PAD)*s, (yy+headH-1)*s)
        end
        if isGen2Header then headers[#headers+1] = { y = yy, h = headH, cat = e.cat } end
        yy = yy + headH
      else
        local r = e.r
        itemIdx = itemIdx + 1
        -- v2.9.5 bugfix, direct report: entering header-focus (Select/
        -- Transfer/Discard, see C.headerFocus) left whatever row iCursor
        -- was still sitting on ALSO showing the gold row-highlight, same
        -- class of "two things highlighted at once" bug this exact line
        -- already guards against for C.iOnSave -- just never extended to
        -- cover the newer header-focus state too.
        local isCursor = C.iFocus == side and not (side == "bag" and C.iOnSave) and C.headerFocus[side] == 0 and (C.iCursor[side] or 1) == itemIdx and C.iCursorVis[side]
        if yy + itemH > ry and yy < ry + listH then
          local held = C.held and C.held.from == side and C.held.id == r.id
          local selected = C.selectMode and C.multiSelect[side][r.id]
          local hov = region(px+8, yy, pw-16, itemH-3, "itemrow", { side = side, id = r.id })
          local cc = C.catCol(r.cat)
          if selected then setc(COL.gold, 0.22) elseif held then setc(COL.gold, 0.06) elseif hov then setc(cc, 0.16) else setc(cc, 0.06) end
          rrect("fill", px+8, yy, pw-16, itemH-3, 7)
          if isCursor and not held and not isDropSide then
            love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.9)
            rrect("line", px+8, yy, pw-16, itemH-3, 7)
          end
          -- v2.9.5: multi-select checkbox, replaces the plain category-color
          -- square while in select mode -- gold + a check glyph when this
          -- row is selected, a dim empty box when it isn't, so it reads as
          -- a real checkbox rather than the row just changing background.
          if C.selectMode then
            setc(selected and COL.gold or COL.dim, selected and 0.95 or 0.35)
            rrect(selected and "fill" or "line", px+PAD, yy+itemH/2-7, 12, 12, 3)
            if selected then
              setc(COL.panel, 1); love.graphics.setLineWidth(math.max(2, 1.6*s))
              love.graphics.line((px+PAD+2.5)*s, (yy+itemH/2)*s, (px+PAD+5)*s, (yy+itemH/2+3.5)*s, (px+PAD+9.5)*s, (yy+itemH/2-3.5)*s)
              love.graphics.setLineWidth(1)
            end
          else
            setc(cc, held and 0.4 or 1); rrect("fill", px+PAD, yy+itemH/2-7, 12, 12, 3)
          end
          txt(ellipsize(r.name, 17, pw - PAD*3 - 96), px+PAD+22, yy+13, 17, held and COL.dim or COL.text)
          -- While this exact row is the held item's origin, show what's left
          -- behind rather than the stack's full original size -- the real
          -- inventory count (r.qty) doesn't change until the item is
          -- actually dropped, so without this the row would just sit at the
          -- old total the whole time the qty stepper/L2-R2/wheel are being
          -- used to trim the carried amount, which reads as those controls
          -- doing nothing. C.held.qty is the amount currently in the
          -- floating bubble; C.held.max is the original stack size, so the
          -- remainder is always max - qty -- moves opposite the bubble's
          -- own displayed count by construction, no separate tracking needed.
          local rowQty = (held and C.held.max) and (C.held.max - C.held.qty) or r.qty
          txt("x"..rowQty, px+pw-PAD, yy+14, 16, COL.dim, "right")
        end
        items[#items+1] = { y = yy, h = itemH, id = r.id }
        yy = yy + itemH
      end
    end
    -- insertion line while holding over this side (not when the drop is blocked,
    -- and not on the source side for a pad pickup -- that side no longer drops)
    if C.held and ds == side and not blocked then
      local ly = ry + listH
      if #items == 0 then
        ly = ry   -- nothing here yet: line goes at the top, where the first item will land
      elseif padHeld then
        local it = items[C.iCursor[side] or 0]
        if it then ly = it.y
        else ly = items[#items].y + items[#items].h end
      else
        local _, bId = dropTarget(C.mx, C.my)
        for _, it in ipairs(items) do if it.id == bId then ly = it.y; break end end
      end
      ly = math.max(ry+1, math.min(ly, ry + listH - 1))
      setc(COL.gold, 0.95); love.graphics.setLineWidth(math.max(2, 3*s))
      love.graphics.line((px+PAD)*s, ly*s, (px+pw-PAD-8)*s, ly*s)
    end
    C.popScissor(prevSc)
    C.iLayout[side] = { x = px, y = ry, w = pw, h = listH, items = items, headers = headers, contentH = contentH }
    C.iPanelRect[side] = { x = px, y = py, w = pw, h = ph }
    if listH > 0 and #rows == 0 then
      txt(C.held and "drop items here" or "No items - drag some here", px+PAD, ry+8, 16, COL.dim, nil, 0.6)
    end
    -- List scrollbar. v2.9.5: was decorative (drawn but not registered as a
    -- region, so it could not be grabbed) -- now a real draggable thumb on
    -- BOTH orientations, per direct request, matching the portrait overlay
    -- Party panel's scrollbar in look and in wiring: gold thumb on a thin
    -- track, registered as a region/tag so the press is caught by
    -- C.onScreenMouse's existing tag dispatch rather than a bespoke
    -- hit-test. Grab area is padded well beyond the drawn bar -- 8 design
    -- units is far too thin a finger target on a phone.
    C.iScrollTrack = C.iScrollTrack or {}
    if maxScroll > 0 then
      local tx, tw = px+pw-14, 8
      setc(COL.border, 0.25); rrect("fill", tx, ry, tw, listH, 4)
      local thumbH = math.max(30, listH * (listH / contentH))
      local thumbY = ry + (scroll / maxScroll) * (listH - thumbH)
      setc(COL.gold, 0.85); rrect("fill", tx, thumbY, tw, thumbH, 4)
      region(tx - 10, ry, tw + 20, listH, "iscrollbar", side)
      C.iScrollTrack[side] = { thumbH = thumbH, y = ry, h = listH }
    else
      C.iScrollTrack[side] = nil
    end
    -- Touch scroll arrows: one pair per side, each always just moving that
    -- side's cursor -- quantity now has its own dedicated stepper next to
    -- the held-item bubble (see drawHeldItem/C.onScreenMouse's "qtyarrow"
    -- tag), so these no longer need to double-check C.held to decide what
    -- they mean. Sits to the right of the bag panel / left of the PC panel,
    -- in the gap the two panels already widen for the nav/icon buttons.
    -- v2.9.5, direct request: LANDSCAPE ONLY now. Portrait has real
    -- draggable scrollbars instead (this list's own, plus the page
    -- scrollbar) -- they do the same job in a fraction of the space, and
    -- dropping the stack in portrait also reclaims the width it was
    -- awkwardly clamped into and retires the "not necessarily the final
    -- ideal spot" placement flagged when that clamp went in. Landscape has
    -- the room and the arrows work well there, so they stay untouched.
    local ww0, wh0 = love.graphics.getDimensions()
    if (ww0 >= wh0) and (mod.options:get("touch_nav_buttons") or mod.options:get("touch_icon_buttons")) then
      -- Sized up again (58x52/58x38 -> 64x58/64x46) and with wider gaps
      -- between all four buttons -- still too tight to comfortably avoid
      -- accidental presses on a small screen.
      local aw, ah, agap = 64, 58, 18
      -- Page arrows: same width/column as the scroll arrows, shorter and
      -- fixed-size like the scroll arrows (not derived from row height or
      -- panel height -- see ITEM_ROW_H comment on why paging math is kept
      -- separately in sync instead). Sit directly above the scroll-up arrow
      -- and directly below the scroll-down arrow, same stack.
      local paw, pah, pgap = 64, 46, 16
      -- Landscape-only now (see the gate above), so this is simply the
      -- original side-by-side placement: the stack sits in the gap the two
      -- panels already widen for the nav/icon buttons. The portrait
      -- special-case that used to live here retired along with the arrows.
      local ax = side == "bag" and (px + pw + 14) or (px - 14 - aw)
      local stackH = pah + pgap + ah + agap + ah + pgap + pah
      -- Vertically centered in the list by default (same reasoning as
      -- before -- avoid the held-item bubble near the first row), but
      -- pulled up further if that would put it too close to the persistent
      -- nav/icon button row below the panels. That row's position is only
      -- known as a percentage of the window (TOUCH_NAV_LEFT/TOUCH_ICON_*
      -- near the top of the file), so it's converted into this screen's
      -- design-space units the same way the panel-gap widening above does
      -- -- self-detecting like the rest of this stack's placement, not a
      -- hardcoded offset that could drift out of sync with those buttons.
      local ay = ry + listH/2 - stackH/2
      local ww, wh = love.graphics.getDimensions()
      if wh > 0 and s > 0 then
        local navTopFrac
        if mod.options:get("touch_nav_buttons") then navTopFrac = TOUCH_NAV_LEFT.y1 end
        if mod.options:get("touch_icon_buttons") then
          navTopFrac = navTopFrac and math.min(navTopFrac, TOUCH_ICON_OVERLAY.y1) or TOUCH_ICON_OVERLAY.y1
        end
        if navTopFrac then
          local navPad = 24   -- design-space breathing room above the nav/icon row
          local maxBottomY = navTopFrac * (wh / s) - navPad
          if ay + stackH > maxBottomY then ay = maxBottomY - stackH end
        end
      end
      ay = math.max(ay, ry)   -- safety floor: never push above the list's own top edge
      -- Recorded so drawHeldItem's nav/icon-zone nudge can also steer clear
      -- of the whole stack, not just the scroll-arrow portion of it.
      C.iArrowRect[side] = { y = ay, h = stackH }
      -- Disabled (visually dimmed, not tappable) while something's held via
      -- touch -- the touch drop flow is "tap a destination row directly",
      -- these scroll/page buttons don't do anything useful mid-hold and were
      -- just extra tap targets cluttering the screen right where the
      -- transfer arrow/bubble/qty stepper are trying to draw attention.
      -- Pad users are unaffected (padHeld skips this whole disable).
      local disabled = C.held and not padHeld
      local function arrowBtn(y, up)
        if not disabled then region(ax, y, aw, ah, "scrollarrow", { dir = up and 1 or -1, side = side }) end
        setc(COL.panel, disabled and 0.35 or 0.82); rrect("fill", ax, y, aw, ah, 8)
        love.graphics.setLineWidth(math.max(1.5, s)); setc(COL.border, disabled and 0.25 or 0.6); rrect("line", ax, y, aw, ah, 8)
        setc(COL.text, disabled and 0.3 or 0.95); triangle(ax+aw/2, y+ah/2, up, 9)
      end
      -- Fast-forward/rewind-style double chevron, shorter than the single-
      -- step arrows so the two are visually distinct at a glance.
      local function pageBtn(y, up)
        if not disabled then region(ax, y, paw, pah, "pagearrow", { dir = up and 1 or -1, side = side }) end
        setc(COL.panel, disabled and 0.35 or 0.82); rrect("fill", ax, y, paw, pah, 8)
        love.graphics.setLineWidth(math.max(1.5, s)); setc(COL.border, disabled and 0.25 or 0.6); rrect("line", ax, y, paw, pah, 8)
        setc(COL.text, disabled and 0.3 or 0.95)
        local cx, cy = ax+paw/2, y+pah/2
        triangle(cx, cy - 5, up, 6)
        triangle(cx, cy + 5, up, 6)
      end
      local scrollUpY, scrollDnY = ay + pah + pgap, ay + pah + pgap + ah + agap
      pageBtn(ay, true)
      arrowBtn(scrollUpY, true)
      arrowBtn(scrollDnY, false)
      pageBtn(scrollDnY + ah + pgap, false)
    else
      C.iArrowRect[side] = nil
    end
    bar(px+PAD, py+ph-22, pw-PAD*2, 8, #rows/cap, #rows>=cap and COL.lo or COL.hi)
    if blocked then          -- big "FULL" warning badge over the panel
      local bw = textW(blocked, 22) + 56
      local bx, by = px+pw/2 - bw/2, py + ph*0.42
      setc(COL.lo, 0.95); rrect("fill", bx, by, bw, 46, 12)
      txt(blocked, px+pw/2, by+11, 22, COL.panel, "center")
    end
  end
  -- v2.9.5, portrait redesign, direct request after 2 screenshots + a
  -- clarifying round ("stack vertically, both together"): side-by-side in
  -- landscape (unchanged); stacked top/bottom in portrait so each panel
  -- keeps the screen's FULL width instead of half of it. contentW already
  -- correctly shrinks to fit portrait's narrower window (confirmed on the
  -- actual screenshot -- nothing was off-screen), so the real problem
  -- wasn't geometry going wrong, it was each of the two LANDSCAPE-width
  -- columns becoming too narrow to read once halved again -- box-grid
  -- cells and item names were the two visibly worst-hit. Both panels stay
  -- SIMULTANEOUSLY visible either way (just stacked, not tabbed) --
  -- dragging an item/Pokemon between the two sides is core to how both
  -- screens work, and a tab/swipe-between-them redesign would have broken
  -- that (you can't drag to a side you can't see). Shared by
  -- drawItemsPanels/drawPartyPanels so the split logic exists in exactly
  -- one place -- the stacking gap is its own small constant, not G (G is
  -- sized to clear the touch-nav button ROW horizontally, a landscape-only
  -- concern that has nothing to do with vertical spacing between two
  -- stacked panels).
  local function pairedPanelRects(isPortraitScreen, ox, py, contentW, ph, G)
    if isPortraitScreen then
      local stackGap = 16
      local panelH = math.floor((ph - stackGap) / 2)
      return ox, py, contentW, panelH,
             ox, py + panelH + stackGap, contentW, ph - panelH - stackGap
    else
      local pw = (contentW - G) / 2
      return ox, py, pw, ph,
             ox + pw + G, py, pw, ph
    end
  end
  -- v2.9.5 portrait PAGE SCROLL (direct design call by Bhk, after two
  -- rounds of on-device screenshots proved the stacked layout below simply
  -- could not be made to fit). The measurement that forced it: portrait
  -- leaves ~470 design units for BOTH panels, while a single itemPanel
  -- needs ~186 before it draws one row. Shrinking them further was a dead
  -- end -- so instead the stack is deliberately made TALLER than the
  -- viewport and the viewport scrolls over it. Each panel is viewport
  -- height minus a peek strip, so the next panel always peeks in at the
  -- edge: that peek IS the affordance that there's more below, which is
  -- why it's a constant and not zero. Both panels still exist at once
  -- (just not both fully visible), so dragging between them still works --
  -- the drag simply scrolls the page to reach the other one (see the
  -- auto-scroll block below). Landscape is completely untouched: side by
  -- side, nothing taller than the viewport, nothing to scroll.
  -- PAGE_PEEK/PAGE_GAP are folded in here rather than being their own
  -- locals, and these three helpers hang off C, for the 200-local reason
  -- documented on C.regionClip above.
  function C.pageMetrics(ph)
    local PAGE_PEEK = 40
    local panelH  = math.max(140, ph - PAGE_PEEK)
    local contentH = panelH * 2 + 16   -- 16 = gap between the two stacked panels
    return panelH, contentH, math.max(0, contentH - ph)
  end
  -- True only while a touch/mouse pointer is actually held down. Touch
  -- specifically via C.touchScreenPos, not love.mouse.isDown alone: this
  -- file's touch path deliberately bypasses LOVE's synthesized mouse-from-
  -- touch (see the input.pointer hook), so isDown would miss a finger drag
  -- entirely -- the same trap partyPanel's scrollbar poll documents.
  -- v2.9.5 bugfix, direct report (Gen 2 category reordering: "scroll...
  -- works for touch and mouse but not for gamepad/controlstick+a"): also
  -- missed C.padDown, the left-stick virtual cursor's own "A is currently
  -- held" flag (set/cleared alongside real gamepad A press/release,
  -- distinct from both real touch and love.mouse.isDown, which stay false
  -- throughout a stick+A hold) -- this is exactly the gap that already
  -- correctly gates the pending->drag PROMOTION checks just below
  -- (`love.mouse.isDown(1) or C.padDown`) but was never extended to this
  -- function, which the auto-scroll-near-edge blocks (for both items and
  -- headers) depend on. A real pre-existing gap surfaced by testing header
  -- drags via stick specifically, not something new this feature caused.
  function C.pointerHeld()
    return (C.touchScreenPos ~= nil) or love.mouse.isDown(1) or C.padDown == true
  end
  -- v2.9.5: the panels each clip their own scrolling list, and they used to
  -- do it with a bare setScissor + a bare setScissor() to clear. That was
  -- fine while nothing enclosed them -- but the portrait page scroll now
  -- draws them INSIDE a viewport scissor, and a bare clear would throw that
  -- viewport away for everything drawn afterwards (partyPanel clears
  -- mid-draw, so boxPanel and the rest of the page would have escaped the
  -- clip entirely and drawn over the header/footer). These intersect with
  -- whatever is already active and restore it exactly, so an inner clip can
  -- only ever be tighter than its outer one -- never wider.
  function C.pushScissor(x, y, w, h)
    local sx, sy, sw, sh = love.graphics.getScissor()
    love.graphics.intersectScissor(x, y, w, h)
    return { sx, sy, sw, sh }
  end
  function C.popScissor(prev)
    if prev and prev[1] then love.graphics.setScissor(prev[1], prev[2], prev[3], prev[4])
    else love.graphics.setScissor() end
  end
  function C.drawPanelPage(key, ox, py, contentW, ph, drawBoth)
    local panelH, contentH, maxScroll = C.pageMetrics(ph)
    C.pageScroll = C.pageScroll or {}
    -- Continues an in-progress page-scrollbar drag. Polled every frame this
    -- draws rather than driven by a move event, for exactly the reason
    -- partyPanel's own scrollbar documents: a single press/release pair
    -- can't track continuous movement on its own.
    if C.pageScrollDrag and C.pageScrollDrag.key == key then
      if maxScroll > 0 and C.pointerHeld() then
        local d = C.pageScrollDrag
        local track = ph - d.thumbH
        local frac = track > 0 and ((C.my - d.startY) / track) or 0
        C.pageScroll[key] = math.max(0, math.min(maxScroll, d.startScroll + frac * maxScroll))
      else
        C.pageScrollDrag = nil
      end
    end
    C.pageScroll[key] = math.max(0, math.min(maxScroll, C.pageScroll[key] or 0))
    local sc = C.pageScroll[key]
    -- Cleared here and set by whichever panel auto-scrolls its OWN list this
    -- frame; the page-level auto-scroll below then stands down. That's the
    -- scroll chaining Bhk described: the list under your finger scrolls
    -- first, and only once it has nothing left to give does the page itself
    -- move on to the other panel.
    C.listAutoConsumed = false
    local prevSc = C.pushScissor(math.floor(ox*s), math.floor(py*s), math.ceil(contentW*s), math.ceil(ph*s))
    C.regionClip = { y1 = py, y2 = py + ph }
    drawBoth(ox, py - sc,                   contentW, panelH,
             ox, py + panelH + 16 - sc,     contentW, panelH)
    C.regionClip = nil
    C.popScissor(prevSc)
    -- Auto-scroll the page while carrying something and holding near the
    -- viewport's top/bottom edge -- the "drag past the panel edge and the
    -- view comes with you" half of the gesture. Deliberately gated on
    -- C.held: an edge hold means nothing when you aren't carrying anything,
    -- and making it scroll then would make a plain press near a list edge
    -- ambiguous with picking a row up. v2.9.5, direct correction: NOT where
    -- the edge-scroll pause belongs (that's each individual panel's own
    -- list, see itemPanel) -- this is page-level navigation BETWEEN Bag and
    -- PC, deliberately left instant/undebounced.
    if C.held and maxScroll > 0 and C.pointerHeld() and not C.listAutoConsumed then
      local edge = 60
      local dt = love.timer.getDelta()
      if C.my > py + ph - edge then
        C.pageScroll[key] = math.min(maxScroll, sc + 900 * dt)
      elseif C.my < py + edge then
        C.pageScroll[key] = math.max(0, sc - 900 * dt)
      end
    end
    -- Page scrollbar. Lives in the screen's own right MARGIN (outside
    -- contentW) so it costs the panels no width at all -- they're the thing
    -- starved for space here. Same visual language and same
    -- region/tag-dispatch wiring as every other scrollbar in this file.
    if maxScroll > 0 then
      local barW = 10
      local tx = ox + contentW + 6
      setc(COL.border, 0.25); rrect("fill", tx, py, barW, ph, 5)
      local thumbH = math.max(36, ph * (ph / contentH))
      local thumbY = py + (C.pageScroll[key] / maxScroll) * (ph - thumbH)
      setc(COL.gold, 0.85); rrect("fill", tx, thumbY, barW, thumbH, 5)
      region(tx - 14, py, barW + 28, ph, "pagescrollbar", key)
      C.pageTrack = { key = key, thumbH = thumbH, y = py, h = ph }
    else
      C.pageTrack = nil
    end
  end
  local function drawItemsPanels(isPortraitScreen, ox, py, contentW, ph, G)
    if isPortraitScreen then
      C.drawPanelPage("items", ox, py, contentW, ph, function(ax, ay, aw, ah, bx, by, bw, bh)
        itemPanel("bag", ax, ay, aw, ah, true)
        itemPanel("pc",  bx, by, bw, bh, true)
      end)
      return
    end
    local ax, ay, aw, ah, bx, by, bw, bh = pairedPanelRects(isPortraitScreen, ox, py, contentW, ph, G)
    itemPanel("bag", ax, ay, aw, ah, false)
    itemPanel("pc",  bx, by, bw, bh, false)
  end
  -- Extra darkening (not a true blur -- LOVE has no built-in blur, and a
  -- real Gaussian blur would need a shader pass over the rendered frame,
  -- a bigger separate task) over everything outside the two item panels
  -- while something's held via touch: the background game world (already
  -- dimmed once for the whole screen elsewhere) gets darker still, so the
  -- two panels and the transfer UI (bubble/arrow/qty stepper, all drawn
  -- after this) stand out more clearly against it. Pad holds are
  -- unaffected -- padHeld already has its own clear gold focus border.
  local function drawHeldDarken(fullW, fullH)
    local h = C.held
    if not h or h.pad then return end
    -- Touch-only embellishment: only makes sense as a visual aid alongside
    -- the persistent touch nav/icon buttons this dim otherwise matches (see
    -- C.drawOverlay's identical touchButtonsOn gate) -- with both off, the
    -- player is driving pickup/drag via mouse/pad instead, and darkening
    -- the whole screen for that read as an unexplained dim with nothing
    -- touch-specific to justify it.
    if not (mod.options:get("touch_nav_buttons") or mod.options:get("touch_icon_buttons")) then return end
    local bag, pc = C.iPanelRect.bag, C.iPanelRect.pc
    if not (bag and pc) then return end
    local topY = math.min(bag.y, pc.y)
    local botY = math.max(bag.y + bag.h, pc.y + pc.h)
    local leftX = math.min(bag.x, pc.x)
    local rightX = math.max(bag.x + bag.w, pc.x + pc.w)
    setc({0,0,0}, 0.5)
    love.graphics.rectangle("fill", 0, 0, fullW*s, topY*s)                              -- above both panels
    love.graphics.rectangle("fill", 0, botY*s, fullW*s, (fullH-botY)*s)                 -- below both panels
    love.graphics.rectangle("fill", 0, topY*s, leftX*s, (botY-topY)*s)                  -- left of both
    love.graphics.rectangle("fill", rightX*s, topY*s, (fullW-rightX)*s, (botY-topY)*s)  -- right of both
    -- v2.9.5, portrait redesign: the strip BETWEEN the two panels used to
    -- assume side-by-side (a vertical strip, bag.x+bag.w to pc.x) -- now
    -- that they can also stack top/bottom in portrait, that same formula
    -- would compute a NEGATIVE width there (pc.x is bag.x, not to its
    -- right). Picks the horizontal-vs-vertical gap based on which axis the
    -- two panels are ACTUALLY separated on, rather than assuming, so this
    -- stays correct in both layouts.
    if bag.x + bag.w <= pc.x or pc.x + pc.w <= bag.x then
      local gapL, gapR = math.min(bag.x + bag.w, pc.x + pc.w), math.max(bag.x, pc.x)
      love.graphics.rectangle("fill", gapL*s, topY*s, (gapR-gapL)*s, (botY-topY)*s)
    elseif bag.y + bag.h <= pc.y or pc.y + pc.h <= bag.y then
      local gapT, gapB = math.min(bag.y + bag.h, pc.y + pc.h), math.max(bag.y, pc.y)
      love.graphics.rectangle("fill", leftX*s, gapT*s, (rightX-leftX)*s, (gapB-gapT)*s)
    end
  end
  -- v70: shared by drawHeldItem's finger-offset below and drawEditHUD's
  -- content further down -- both need to know "is this a mobile/touch
  -- platform" and both used to check it independently (drawEditHUD's own
  -- inline check was the only one, until now); factored out to a single
  -- place so a future change to how this is detected can't update one
  -- copy and miss the other, same "two places that can drift apart"
  -- concern this file already flags repeatedly elsewhere. v2.9.1: now delegates
  -- to the engine's own VideoMode.isMobile() (see below) rather than
  -- reimplementing its Android/iOS OS check inline.
  local function isMobilePlatform()
    -- v2.9.1 (sandbox): the LOVE system module is removed from a mod's
    -- environment, so ask the engine's own VideoMode.isMobile() (captured above
    -- via req; it runs in engine context where that OS query still works).
    -- Guarded so a missing module or throwing call degrades to "not mobile".
    if C.VideoMode and C.VideoMode.isMobile then
      local ok, res = pcall(C.VideoMode.isMobile)
      if ok then return res and true or false end
    end
    return false
  end
  -- v72: geometry for the draggable touch-nav/icon groups (see
  -- TOUCH_GROUP_KEYS's own comment near its declaration for the overall
  -- design). Placed here (right after isMobilePlatform, before
  -- drawHeldItem) rather than down by C.drawTouchNav where they're used
  -- most -- drawHeldItem's own nav/icon-zone-avoidance nudge (below) also
  -- needs touchGroupOffset, and drawHeldItem is a `local function`
  -- defined well before C.drawTouchNav in this file. Lua's `local`
  -- only binds from its declaration point forward, so touchGroupOffset
  -- has to exist before EVERY closure that reads it, not just the ones
  -- it was originally written for -- the same ordering bug already found
  -- and fixed twice this session, this time avoided up front instead of
  -- discovered after shipping. (touchGroupOffset itself needs `s`, so
  -- this whole block also has to stay after `local s = 1` above -- it
  -- can't move any earlier than this.)
  local function touchGroupZones(which)
    if which == "touchNav" then return { TOUCH_NAV_LEFT, TOUCH_NAV_RIGHT } end
    return { TOUCH_ICON_OVERLAY, TOUCH_ICON_ITEMS, TOUCH_ICON_PARTY }
  end
  -- The group's default (undragged) bounding box, in raw window pixels --
  -- the union of every button's own zone rect. Also serves as the anchor
  -- reference point: C.touchGroupPos, when set, stores where this
  -- bounding box's top-left corner should be INSTEAD, in design units
  -- (x/s), matching the same space C.panelCfg[x].pos already uses for
  -- the real panels -- consistent with how the rest of this file treats
  -- a dragged position, and what savePanelCfg below already knows how to
  -- serialize with only a small extension.
  local function touchGroupDefaultRect(which, ww, wh)
    local minX, minY, maxX, maxY = math.huge, math.huge, -math.huge, -math.huge
    for _, z in ipairs(touchGroupZones(which)) do
      minX = math.min(minX, z.x1 * ww); minY = math.min(minY, z.y1 * wh)
      maxX = math.max(maxX, z.x2 * ww); maxY = math.max(maxY, z.y2 * wh)
    end
    return minX, minY, maxX - minX, maxY - minY
  end
  -- v76 fix, direct report: after a fresh reload, the buttons briefly
  -- rendered "far down and to the right" of their saved position, then
  -- snapped back the instant any menu button was pressed. Root cause:
  -- `saved.x/.y` are stored in "design units" (divided by the shared `s`
  -- upvalue at drag time, matching C.panelCfg[x].pos's own convention),
  -- but `s` only gets a fresh, correct value when C.drawOverlay or
  -- C.drawScreen actually runs -- and on the very first rendered
  -- frame(s) after a reload, before either has run even once, `s` is
  -- still sitting at its cold-start default (`local s = 1`, see its own
  -- declaration far above). C.drawTouchNav/drawTouchIcons draw every
  -- frame independent of whether the overlay/a screen has rendered yet,
  -- so reading `s` here could use that stale default -- exactly the
  -- risk C.drawTouchNav/drawTouchIcons's own drawing code already avoids
  -- by working entirely in raw window pixels instead of routing through
  -- `s` (see their own comments) -- this function reintroduced that same
  -- dependency for the save-file unit conversion specifically. Fixed by
  -- computing an independent scale here, matching C.drawOverlay's own
  -- formula but derived fresh from the `wh` already passed in, never
  -- reading the shared, possibly-stale `s`. Any position saved before
  -- this fix was still saved correctly (dragging only happens in edit
  -- mode, which requires the overlay to already be visibly rendering, so
  -- `s` really was correct at THAT moment) -- this only changes when the
  -- conversion is unreliable, not the conversion's own math, so existing
  -- saved positions still read back the same result.
  local function touchGroupScale(wh)
    return (wh / REF_H) * UI_SCALE_OVERLAY
  end
  -- The pixel offset to add to every button's own default-computed rect
  -- for this group -- (0,0) if never dragged, otherwise the delta
  -- between the saved anchor and the default one. Single source every
  -- consumer (drawTouchNav/drawTouchIcons, tryTouchNavButtons,
  -- drawHeldItem's nudge below) reads from -- can't drift apart from
  -- each other the way this file's own history already warns about
  -- elsewhere.
  local function touchGroupOffset(which, ww, wh)
    local saved = C.touchGroupPos[which]
    -- v2.9.5 fix, direct report: a resize/drag attempted in one
    -- orientation was found "very very large" (or entirely missing) when
    -- checked in the other. Root cause: saved was being honored whenever
    -- it existed at all, with no regard for which orientation it was
    -- actually saved in -- exactly the same cross-orientation leak
    -- C.panelCfg[x].pos had, fixed there with the same tag/compare
    -- pattern (see drawEditablePanel's own comment). TOUCH_NAV_LEFT/RIGHT
    -- and TOUCH_ICON_OVERLAY/ITEMS/PARTY's zone fractions were also only
    -- ever tuned against one landscape screenshot, so even the DEFAULT
    -- (untagged/never-dragged) case still needs its own portrait target
    -- rather than trusting that fraction blindly -- unchanged from the
    -- original portrait fix below, just now reached whenever there's no
    -- MATCHING-orientation saved position, not just no position at all.
    -- v2.9.5 fix, direct report ("in one position on the title screen, jumps
    -- to the saved spot only after a button press"): this used to compare
    -- against the SHARED `C.isPortrait` -- but that flag is only ever set
    -- inside C.drawOverlay (see its own `C.isPortrait = isPortrait` line),
    -- which doesn't run at all until C.visible is true (off by default,
    -- "press 'o' to show") AND a party exists -- while C.drawTouchNav/
    -- drawTouchIcons draw every frame regardless, title screen included
    -- (same "runs independent of drawOverlay's cadence" fact the v76 fix
    -- above already root-caused for `s`, just a different piece of shared
    -- state hitting the same structural gap). Until something finally
    -- makes drawOverlay run once, C.isPortrait sits at its cold-start nil
    -- (reads as landscape via `or false`) even on an actual portrait
    -- device, so a portrait-tagged saved position never matched -- exactly
    -- the reported "jumps once you press a button" (whatever press first
    -- makes the overlay visible is what finally lets drawOverlay set it).
    -- Computed fresh here instead, from the ww/wh already passed in --
    -- same fix shape as the v76 comment above, never trust shared state
    -- this function doesn't control the timing of.
    local isPortrait = wh > ww
    if not (saved and (saved.portrait or false) == isPortrait) then
      if isPortrait then
        local defX, defY = touchGroupDefaultRect(which, ww, wh)
        local targetY = (which == "touchNav") and (wh * 0.40) or (wh * 0.47)
        return 0, targetY - defY
      end
      return 0, 0
    end
    local scale = touchGroupScale(wh)
    local defX, defY = touchGroupDefaultRect(which, ww, wh)
    return (saved.x * scale) - defX, (saved.y * scale) - defY
  end
  -- v81 port: the group's whole on-screen bounding box (offset + resize
  -- size), for the edit-mode highlight, the resize grip's position, and the
  -- group-level drag hit-test. Same anchor/scale math as touchGroupButtonRect
  -- below -- both scale from the group's own default top-left, not each
  -- element's own position, so growing/shrinking keeps every button's
  -- relative spacing correct instead of drifting apart.
  local function touchGroupRect(which, ww, wh)
    local bx, by, bw, bh = touchGroupDefaultRect(which, ww, wh)
    local ox, oy = touchGroupOffset(which, ww, wh)
    -- v2.9.5 fix: proper tag-compare now, matching touchGroupOffset's own
    -- fix just above (this file's earlier pass here only compared "was it
    -- ever resized at all", not "was it resized in THIS orientation" --
    -- confirmed insufficient by direct report: a resize done in one
    -- orientation was still being applied, wrongly, in the other).
    local g = C.touchGroupSize[which]
    -- v2.9.5 fix: same "don't trust C.isPortrait's timing" fix as
    -- touchGroupOffset above, applied here for the same reason -- this
    -- runs from the same title-screen-visible draw/hit-test path.
    if not (g and (C.touchGroupSizePortrait[which] or false) == (wh > ww)) then
      g = 1
    end
    return bx + ox, by + oy, bw * g, bh * g
  end
  -- v81 port: one button's own on-screen rect within a resized/offset group
  -- -- same anchor (the group's default top-left) and scale (C.touchGroupSize)
  -- touchGroupRect uses, applied per-button instead of to the whole bounding
  -- box, so drawing and hit-testing a single button always agree with where
  -- the group itself is currently drawn.
  local function touchGroupButtonRect(which, zone, ww, wh)
    local bx, by = touchGroupDefaultRect(which, ww, wh)
    local ox, oy = touchGroupOffset(which, ww, wh)
    -- v2.9.5 fix: this is the function C.drawTouchNav/drawTouchIcons
    -- actually call to draw the REAL buttons. Same proper tag-compare as
    -- touchGroupRect just above, not just "was it ever resized."
    local g = C.touchGroupSize[which]
    -- v2.9.5 fix: same "don't trust C.isPortrait's timing" fix as
    -- touchGroupOffset above, applied here for the same reason -- this
    -- runs from the same title-screen-visible draw/hit-test path.
    if not (g and (C.touchGroupSizePortrait[which] or false) == (wh > ww)) then
      g = 1
    end
    local ax, ay = bx + ox, by + oy
    local x = ax + (zone.x1 * ww - bx) * g
    local y = ay + (zone.y1 * wh - by) * g
    local w = (zone.x2 - zone.x1) * ww * g
    local h = (zone.y2 - zone.y1) * wh * g
    return x, y, w, h
  end
  local function drawHeldItem()
    local h = C.held; if not h then return end
    local cat = C.dispCat(h.id, C.game.data.items[h.id])
    local padHeld = h.pad
    local dsz = padHeld and C.iFocus or dropTarget(C.mx, C.my)
    local blk = dsz and dsz ~= h.from and dropBlockedReason(h.from, h.id, h.qty, dsz)
    -- Computed early (used by both the finger-offset below and the box
    -- itself further down) so the offset can account for the box's actual
    -- width, not just its anchor point -- see the offset comment below for
    -- why that matters.
    local qtyStr = (h.max and h.max > 1) and ("  x"..h.qty) or ""
    local label = itemName(h.id) .. qtyStr
    local w = textW(label, 17) + 46
    -- ghost chip: rides the D-pad cursor's row for a pad pickup (so it doesn't
    -- float at a stale mouse position), or the cursor itself for drag/click.
    -- No row at the cursor means it's past the last one -- the "append to
    -- the end" slot -- so anchor near the bottom of the visible list instead.
    local gx, gy = C.mx, C.my
    if padHeld then
      local L = C.iLayout[C.iFocus]
      if L then
        local it = L.items[C.iCursor[C.iFocus] or 0]
        if it then
          gx, gy = L.x + L.w/2 - 30, it.y + it.h/2 - 17
        elseif #L.items > 0 then   -- past the last row: hover over the phantom end-of-list slot
          local last = L.items[#L.items]
          gx, gy = L.x + L.w/2 - 30, last.y + last.h + last.h/2 - 17
        else                       -- side is empty: hover near the top, where the line is
          gx, gy = L.x + L.w/2 - 30, L.y + 2
        end
      end
    elseif h.mode == "armed" then
      -- Armed via touch (tap-to-pick-up, waiting for a second tap to drop):
      -- stay put at the original pickup spot instead of following every
      -- subsequent touch -- otherwise tapping the scroll arrows (or
      -- anything else) to adjust quantity drags this bubble along with it.
      gx, gy = h.downX, h.downY
    end
    local ww, wh = love.graphics.getDimensions()
    local fullW, fullH = ww / s, wh / s
    -- Offset away from the fingertip -- a touch hold/drag sits right at the
    -- read point, which otherwise puts the bubble directly under/behind the
    -- finger. Always up, and toward whichever half of the screen has more
    -- room (left-side touches offset up+right, right-side up+left) --
    -- tested against the CURRENT anchor every frame, so an active drag
    -- flips sides automatically the moment it crosses the horizontal
    -- middle, rather than being locked to whichever side it started on.
    -- No finger involved in a pad hold, so that case is left alone.
    -- v70: on direct request -- the whole point of the HORIZONTAL half of
    -- this offset is clearing a real fingertip, which doesn't exist for a
    -- mouse pointer (a thin arrow doesn't obscure the bubble the way a
    -- finger does), so that half now also skips on desktop
    -- (isMobilePlatform() false).
    --
    -- v2.9.5 bugfix, direct report: the VERTICAL half used to skip on
    -- desktop right alongside it (v70 folded both into the same "finger
    -- doesn't exist here" reasoning) -- but the vertical offset does a
    -- SECOND, unrelated job the v70 comment didn't separate out: for an
    -- armed pickup, gx/gy are PINNED at the original press point (h.downX/
    -- downY, set below), which sits directly on the very row this bubble
    -- is drawn over -- and that row shows the live "remaining qty" text
    -- while held (see itemPanel's rowQty). Skipping the vertical offset on
    -- desktop meant the bubble sat exactly on top of that row there,
    -- hiding the one piece of live feedback the qty stepper is for. That
    -- problem exists on every platform (any pinned bubble the same size as
    -- the row it sits on covers it identically), not just mobile-without-
    -- a-finger, so it's no longer bundled with the finger-clearing check.
    if not padHeld then
      gy = gy - 60
      if isMobilePlatform() then
        local offX = 46
        if gx < fullW/2 then
          gx = gx + offX   -- left side: box already grows further right from here, so this alone clears the touch point
        else
          gx = gx - offX - w   -- right side: box grows right from its anchor too, so without subtracting its own width here, the box's far/right edge would still land back near the touch point instead of clearing it -- this is the fix for that
        end
      end
    end
    -- v73: nudge-away-from-the-nav/icon-zone, REINTRODUCED on direct
    -- request after v71 removed it outright. v71's reasoning
    -- (`heldBlocksNav` already makes the nav/icon zone fully inert
    -- while an item is held, so an accidental PRESS there was already
    -- impossible) is still true, but doesn't cover the separate
    -- complaint this was brought back for: those buttons draw on top of
    -- everything else, so a bubble that visually overlaps them looks
    -- wrong even though tapping through to them can't actually do
    -- anything. Gated to mobile only this time, on direct request --
    -- those buttons are touch-only and desktop has no reason to enable
    -- them, same reasoning already used for the finger-offset above.
    --
    -- v73 also fixes what would otherwise be a second problem: v72 made
    -- both groups draggable in edit mode, so the OLD static zone
    -- (0.6100*fullH to 0.7920*fullH, the two groups' shared DEFAULT
    -- span) would silently go stale the moment either one gets moved --
    -- clearing a spot the buttons don't even occupy anymore, or missing
    -- them entirely at their new spot. Now reads each group's CURRENT
    -- rect via touchGroupOffset (the same single source of truth
    -- drawTouchNav/drawTouchIcons/tryTouchNavButtons already use, so
    -- this can't drift out of sync with where they're actually drawn)
    -- and spans the union of both groups' current top/bottom -- same
    -- "vertical-only, spans nav through icons as one band" simplification
    -- the original had (see its own reasoning below), just computed live
    -- instead of hardcoded. If the two groups are ever dragged far apart
    -- this ends up wider than strictly necessary, the same tradeoff the
    -- original already accepted for the default (undragged) layout.
    --
    -- The persistent nav-cycle/icon buttons draw on top of this whole
    -- screen, not under it -- so if the bubble would land in that same
    -- region, nothing drawn here can cover it back up. Nudge upward to
    -- clear it instead. Vertical-only check, on purpose: the zone sits
    -- dead center and near enough to a wide range of row positions that
    -- a horizontal carve-out would be fragile, and nudging a bubble that
    -- wasn't actually going to overlap horizontally is a much smaller
    -- cost than missing a real one. Only bothers with any of this if the
    -- source panel's own box actually reaches down into that zone on
    -- this device/resolution in the first place -- on a layout where the
    -- panels sit well clear of it, no row in that panel could ever land
    -- there, so the nudge would just be confusing motion for a collision
    -- that was never possible. Runs AFTER the finger offset above, so
    -- it's checking (and can correct) the bubble's actual final
    -- position, not the raw touch point.
    -- v75 fix, direct report: this ran regardless of whether the touch
    -- nav/icon buttons were even turned on -- a leftover from the
    -- original v70 code (which had the same gap, unconditional on
    -- those two mod options) that carried straight through the v73
    -- reintroduction without being reconsidered. Nothing to clear when a
    -- group's own option is off (it isn't drawn at all, see
    -- C.drawTouchNav/drawTouchIcons's own `mod.options:get` guards), so
    -- each group now only contributes to the avoided zone while its
    -- option is actually on, and the whole check is skipped outright if
    -- neither is.
    local navOn = mod.options:get("touch_nav_buttons")
    local iconOn = mod.options:get("touch_icon_buttons")
    if isMobilePlatform() and (navOn or iconOn) then
      local zoneY1, zoneY2
      if navOn then
        local navX, navY, navW, navH = touchGroupDefaultRect("touchNav", ww, wh)
        local navOX, navOY = touchGroupOffset("touchNav", ww, wh)
        zoneY1, zoneY2 = (navY + navOY) / s, (navY + navOY + navH) / s
      end
      if iconOn then
        local iconX, iconY, iconW, iconH = touchGroupDefaultRect("touchIcons", ww, wh)
        local iconOX, iconOY = touchGroupOffset("touchIcons", ww, wh)
        local iTop, iBot = (iconY + iconOY) / s, (iconY + iconOY + iconH) / s
        zoneY1 = zoneY1 and math.min(zoneY1, iTop) or iTop
        zoneY2 = zoneY2 and math.max(zoneY2, iBot) or iBot
      end
      local panelRect = C.iPanelRect[h.from]
      local panelReachesZone = panelRect and panelRect.y < zoneY2 and (panelRect.y + panelRect.h) > zoneY1
      if panelReachesZone and gy > zoneY1 - 50 and gy < zoneY2 + 10 then
        gy = zoneY1 - 50
        -- That target can land right on top of this same side's scroll
        -- arrows (vertically centered in the list -- see C.iArrowRect),
        -- which is exactly what was happening before this check existed.
        -- If so, push above them too instead.
        local arrowRect = C.iArrowRect[h.from]
        if arrowRect and gy > arrowRect.y - 14 and gy < arrowRect.y + arrowRect.h + 14 then
          gy = arrowRect.y - 14
        end
      end
    end
    -- Keep the bubble from overflowing off-screen. While actively dragging
    -- (mode == "drag"), contained to the whole screen width -- that's the
    -- point, it needs to be free to follow the finger over to the
    -- destination side, flipping which side its finger-offset leans toward
    -- as it crosses the middle (see above). Once armed/pinned (or a pad
    -- hold), contained to just the source panel instead -- e.g. a long
    -- item name pushing it into the other panel, or off-screen entirely,
    -- with nothing left actively moving it back on-screen. Only clamps if
    -- the container is actually wide enough for the label at all -- an
    -- unavoidably long name in a narrow panel is left alone rather than
    -- forced into an inverted (max < min) range.
    do
      local containRect = (h.mode == "drag") and { x = 0, w = fullW } or C.iPanelRect[h.from]
      if containRect then
        local margin = 10
        local minGx = containRect.x + margin - 16
        local maxGx = containRect.x + containRect.w - margin - 16 - w
        if maxGx >= minGx then gx = math.max(minGx, math.min(maxGx, gx)) end
      end
    end
    -- Box height matches the new row height (50, up from 34) for visual
    -- consistency now that rows are taller -- same vertical center as
    -- before (gy+1), just taller, so the icon dot/text get re-centered
    -- within it, and the hint/blocked text below shifts down to keep the
    -- same small gap under the now-lower box bottom edge.
    setc(COL.panel, 0.97); rrect("fill", gx+16, gy-24, w, 50, 8)
    setc(blk and COL.lo or COL.gold, 0.9); love.graphics.setLineWidth(math.max(1, s)); rrect("line", gx+16, gy-24, w, 50, 8)
    setc(C.catCol(cat), 1); rrect("fill", gx+26, gy-5, 12, 12, 3)
    txt(label, gx+46, gy-11, 17, COL.text)
    -- No small "blocked" text here anymore -- the panel itself already
    -- shows a big red "FULL" badge plus a red border for the same
    -- condition (see `blocked` in itemPanel), so this was a redundant
    -- second copy of the same message in miniature. Qty stepper/drop-hint
    -- below is unrelated to whether the CURRENT hover position is
    -- blocked, so it's no longer gated behind blk being false either.
    if h.max and h.max > 1 then
      if padHeld then
        txt("L2/R2 = qty", gx+16, gy+30, 12, COL.gold, nil, 0.85)
      elseif h.mode ~= "drag" then
        -- v2.9.5 bugfix, direct report: "no way for the user, on any
        -- platform, to change the quantity of a grabbed item, without
        -- enabling touch nav or touch icons." Was gated on those two mod
        -- options being on, under the belief that "without them, mouse
        -- wheel / L2-R2 already cover quantity adjustment" -- both halves
        -- of that turned out to be wrong for the common case: mouse wheel
        -- has been completely unreadable since the sandbox migration (no
        -- sandbox-legal wheel hook exists yet -- see the love.wheelmoved
        -- comment near the input.pointer hook, gen1recomp issue #1285),
        -- and L2/R2 needs an actual physical gamepad, which most touch/
        -- mouse players don't have connected. That left mouse-only and
        -- touch-without-those-options players with literally no way to
        -- adjust quantity at all. Un-gated: this stepper is a region()-
        -- based button like any other in this file, so it's already
        -- reachable by mouse, touch, AND the left-stick virtual cursor
        -- (which substitutes for C.mx/C.my the same way it does
        -- everywhere else) with zero extra work -- it only ever needed to
        -- not be hidden. padHeld (literal D-pad, no on-screen cursor to
        -- click this with) keeps its own separate "L2/R2 = qty" text hint
        -- above, unchanged -- that's the one case a button here would
        -- actually be unreachable.
        --
        -- Separate from the scroll arrows now that there are two scroll
        -- pairs on screen (bag/PC), so one pair could no longer
        -- unambiguously double as "adjust qty". Same size/style as the
        -- scroll arrows for consistency (gold tint instead of white to
        -- signal it's a different function). Sits beside the bubble --
        -- toward the side the item DIDN'T come from, so a bag pickup gets
        -- its stepper to the right (toward the gap/PC side) and a PC
        -- pickup gets it to the left (toward the gap/bag side) -- and the
        -- bubble itself is pinned to the pickup spot, so this stays put
        -- too, no more chasing taps around the screen.
        local qw, qh, qgap = 52, 46, 10
        local qy = (gy + 1) - (qh*2 + qgap)/2
        local qx = (h.from == "bag") and (gx+16+w+12) or (gx+16-12-qw)
        local function qtyBtn(y, up)
          -- C.onPadTrigger uses dir=1 to DECREASE (matching L2's physical
          -- trigger sense) and dir=-1 to increase -- opposite of what the
          -- up/down triangle icons imply, so it's inverted here: the up
          -- arrow passes -1 (increase) and the down arrow passes 1 (decrease).
          region(qx, y, qw, qh, "qtyarrow", { dir = up and -1 or 1 })
          setc(COL.panel, 0.9); rrect("fill", qx, y, qw, qh, 8)
          love.graphics.setLineWidth(math.max(1.5, s)); setc(COL.gold, 0.75); rrect("line", qx, y, qw, qh, 8)
          setc(COL.gold, 0.95); triangle(qx+qw/2, y+qh/2, up, 9)
        end
        qtyBtn(qy, true)
        qtyBtn(qy + qh + qgap, false)
      end
    elseif padHeld then txt("A drops here  --  B cancels", gx+16, gy+30, 12, COL.dim, nil, 0.85) end
  end
  -- v2.9.5 (Gen 2 category reordering): the floating chip for a header
  -- being dragged. Deliberately much simpler than drawHeldItem above --
  -- no quantity stepper, no drop-blocked state (there's no "full" concept
  -- for reordering 4 fixed categories), no D-pad/pad-cursor positioning
  -- (headers have no pad-pickup mode, see C.heldHeader's own init comment).
  local function drawHeldHeaderChip()
    local h = C.heldHeader
    if not (h and h.mode == "drag") then return end
    local label = C.catLabel(h.cat)
    local w = textW(label, 13) + 34
    local gx, gy = C.mx + 14, C.my - 12
    setc(COL.panel, 0.97); rrect("fill", gx, gy, w, 24, 8)
    love.graphics.setLineWidth(math.max(1.5, s)); setc(COL.gold, 0.85); rrect("line", gx, gy, w, 24, 8)
    setc(C.catCol(h.cat), 1); rrect("fill", gx+8, gy+7, 10, 10, 2)
    txt(label, gx+24, gy+5, 13, COL.text)
  end
  -- ===================== Party / Boxes screen =========================
  local NBOX = (C.Boxes and C.Boxes.COUNT) or 12
  local BCAP = (C.Boxes and C.Boxes.CAPACITY) or 20
  local PMAX = (C.Party and C.Party.MAX) or 6
  local function boxesEnsure()
    if C.Boxes then C.Boxes.ensure(C.game.save) end
    return C.game.save.boxes or {}
  end
  local function arrayOf(loc, boxN)
    if loc == "party" then return C.game.save.party or {} end
    return boxesEnsure()[boxN] or {}
  end
  local function targetMonAt(t) return (t and t.index) and arrayOf(t.loc, t.box)[t.index] or nil end
  -- reason a MOVE (not a swap) onto `tgt` would fail (nil = fine / it's a swap)
  local function isHealthy(m)
    if not m then return false end
    local hp = m.hp
    return hp == nil or hp > 0            -- box mons may store nil hp = full
  end
  local function partyHealthy()
    local n = 0
    for _, m in ipairs(arrayOf("party")) do if isHealthy(m) then n = n + 1 end end
    return n
  end
  -- reason a placement (MOVE or SWAP) would be refused (nil = allowed)
  local function placeBlocked(src, tgt)
    if not (src and tgt) then return nil end
    local sMon = arrayOf(src.loc, src.box)[src.index]
    local tMon = targetMonAt(tgt)
    local isSwap = tMon and tMon ~= sMon
    if not isSwap then         -- capacity + can't-empty-party apply to moves only
      if src.loc == "party" and tgt.loc ~= "party" and #arrayOf("party") <= 1 then return "Can't deposit your last Pokemon" end
      if tgt.loc == "party" and #arrayOf("party") >= PMAX then return "Party is full (6/6)" end
      if tgt.loc == "box" and #arrayOf("box", tgt.box) >= BCAP then return ("Box %d is full"):format(tgt.box) end
    end
    -- the party must always keep >=1 non-fainted Pokemon. Work out how many
    -- healthy mons the party would have AFTER this op; block only if it drops
    -- from >=1 to 0 (so an all-fainted party can still be rescued by a swap-in).
    local cur, res = partyHealthy(), partyHealthy()
    if src.loc == "party" and tgt.loc ~= "party" then           -- a party mon leaves
      if isHealthy(sMon) then res = res - 1 end
      if isSwap and isHealthy(tMon) then res = res + 1 end       -- swap brings a box mon in
    elseif src.loc ~= "party" and tgt.loc == "party" and isSwap then  -- party mon out, box mon in
      if isHealthy(tMon) then res = res - 1 end
      if isHealthy(sMon) then res = res + 1 end
    end
    if cur >= 1 and res < 1 then return "Keep a healthy Pokemon in your party" end
    return nil
  end
  -- Undo, party side (ported from v80) ---------------------------------------
  -- A move only ever changes array MEMBERSHIP/ORDER of unchanged mon objects,
  -- so a one-level array copy is a faithful snapshot. Boxes are few and small,
  -- so snapshotting all of them keeps this dead simple -- box->box and in-box
  -- moves are covered without having to work out which box was touched.
  function C.snapshotParty()
    local save = C.game and C.game.save
    if not save then return nil end
    local boxesCopy = {}
    for n, arr in pairs(boxesEnsure()) do boxesCopy[n] = C.copyArray(arr) end
    return { kind = "party", party = C.copyArray(save.party), boxes = boxesCopy }
  end
  function C.restoreParty(snap)
    local save = C.game and C.game.save
    if not save then return end
    if type(save.party) == "table" then C.restoreArray(save.party, snap.party)
    else save.party = C.copyArray(snap.party) end
    local boxes = boxesEnsure()
    for n, arr in pairs(snap.boxes) do
      if type(boxes[n]) == "table" then C.restoreArray(boxes[n], arr)
      else boxes[n] = C.copyArray(arr) end
    end
  end
  function C.restoreSnapshot(snap)
    if not snap then return end
    if snap.kind == "items" then C.restoreItems(snap)
    elseif snap.kind == "party" then C.restoreParty(snap) end
  end
  -- Pops and restores the most recent Items/Party edit. Wired to the on-screen
  -- Undo button (region tag "undo", reachable by touch/mouse or the gamepad
  -- left-stick cursor + A) and keyboard "u". No dedicated gamepad button --
  -- L1/R1 are gen1recomp's own game-speed controls, left alone. Safe no-op on
  -- an empty stack.
  C.doUndo = function()
    local snap = table.remove(C.undoStack)
    if not snap then C.setStatus("Nothing to undo"); return false end
    C.restoreSnapshot(snap)
    C.held = nil   -- an in-progress pickup would point at a now-stale slot/row
    C.heldHeader = nil   -- v2.9.5: same, for an in-progress header drag
    if C.screen == "items" and C.iCursor then C.iCursor.bag, C.iCursor.pc = 1, 1 end
    local left = #C.undoStack
    C.setStatus(left > 0 and ("Undo  -  "..left.." more") or "Undo  -  nothing more to undo")
    return true
  end
  -- --------------------------------------------------------------------------
  -- v2.9.5: `skipUndo`, same reasoning/contract as doTransfer's own -- lets
  -- a bulk caller batch N moves under one undo entry instead of N.
  local function doMonPlace(src, tgt, skipUndo)
    if not tgt then return true end
    local sArr = arrayOf(src.loc, src.box); local sMon = sArr[src.index]
    if not sMon then return false, "Nothing to move" end
    if src.loc == tgt.loc and src.box == tgt.box and src.index == tgt.index then return true end
    local blk = placeBlocked(src, tgt); if blk then return false, blk end
    local snap = C.snapshotParty()   -- captured just before the real mutation (after the no-op/blocked early-returns)
    local tArr = arrayOf(tgt.loc, tgt.box); local tMon = tgt.index and tArr[tgt.index]
    if tMon and tMon ~= sMon then                -- SWAP
      sArr[src.index], tArr[tgt.index] = tMon, sMon; if not skipUndo then C.pushUndo(snap) end; return true
    end
    table.remove(sArr, src.index)
    local at = tgt.index
    if src.loc == tgt.loc and src.box == tgt.box and at and at > src.index then at = at - 1 end
    if at and at >= 1 and at <= #tArr + 1 then table.insert(tArr, at, sMon) else tArr[#tArr+1] = sMon end
    if not skipUndo then C.pushUndo(snap) end
    return true
  end
  -- v2.9.5: release a box Pokemon outright, direct request (multi-select
  -- bulk release). Party-scoped release was deliberately never built --
  -- multi-select for Pokemon only ever operates on box slots (see
  -- C.multiSelectBox/the Boxes-only "Select" button below), so there's no
  -- "last healthy party member" rule to worry about here at all; a box
  -- mon is never the save's only Pokemon in any reachable state.
  C.doRelease = function(box, index, skipUndo)
    local boxes = boxesEnsure()
    local arr = boxes[box]
    if not (arr and arr[index]) then return false, "Nothing to release" end
    local snap = C.snapshotParty()
    table.remove(arr, index)
    if not skipUndo then C.pushUndo(snap) end
    return true
  end
  -- v2.9.5: multi-select state + bulk actions, direct request. Selection
  -- is a plain id/slot-keyed set, scoped to whichever screen/side it was
  -- built for -- reset on screen open/close/switch below, same lifetime
  -- as C.undoStack and C.held (a stale selection surviving a screen
  -- switch would be genuinely confusing, e.g. Bag rows still "selected"
  -- after switching to the Party screen).
  C.multiSelect = C.multiSelect or { bag = {}, pc = {} }   -- [side][itemId] = true
  C.multiSelectBox = C.multiSelectBox or {}                -- ["box:index"] = { box = N, index = I }
  C.selectMode = C.selectMode or false   -- true while Bag/PC/Boxes rows tap-to-toggle instead of pick-up-to-drag
  -- v2.9.5: D-pad access to the Select/Transfer/Discard/Move/Release
  -- header row, direct request ("the dpad needs to be able to navigate
  -- to the select button and press it with A as well as the transfer
  -- and discard button"). 0 = normal (list cursor for items, nothing for
  -- boxes); N = focused on the Nth header button, left to right, per
  -- C.headerButtons/C.headerButtonsBox below. Mirrors the shape of the
  -- pre-existing C.iOnSave (Bag's own up-from-row-1 Save-order focus,
  -- untouched) rather than replacing it -- see C.onPadScroll's own
  -- comment for how the two now chain together on Bag specifically.
  C.headerFocus = C.headerFocus or { bag = 0, pc = 0 }
  C.headerFocusBox = C.headerFocusBox or 0
  -- v2.9.5: D-pad grid-cursor for the box contents, direct request ("keep
  -- the left/right to change boxes but add down to go and freely select
  -- pokemon in the box"). 0 = not active; 1-20 = which grid slot (same
  -- index C.pLayout.grid/boxPanel's own drawing loop already uses, so no
  -- separate coordinate system to keep in sync). Left/right is
  -- deliberately left doing exactly what it already did (box-view cycle)
  -- -- up/down move through all 20 slots in reading order (row-major)
  -- instead, the only way to reach every slot without touching left/
  -- right's existing meaning at all.
  C.boxCursor = C.boxCursor or 0
  -- v2.9.5: rubber-band/marquee drag-select, direct request ("similarly
  -- to how you draw a selection box on a Windows PC interface"). A
  -- SEPARATE, parallel state from C.held (which means "carrying a single
  -- item/mon") -- select mode and holding are already mutually exclusive,
  -- and keeping this its own concept avoids any risk of confusing the
  -- large amount of existing C.held-checking code elsewhere in this file.
  -- C.marqueeStart: armed on press, not yet a drag (mirrors C.held's own
  -- "pending" stage). C.marquee: promoted once the cursor moves past the
  -- same distance threshold C.held's pending->drag promotion already uses
  -- (see C.drawScreen) -- from THAT point on this is a real marquee,
  -- updated every frame, resolved into a bulk ADD-to-selection on
  -- release. Never promoted = release resolves it as a plain tap-toggle
  -- instead, exactly the behavior a plain tap already had -- this doesn't
  -- change single-tap behavior at all, only adds what happens once you
  -- drag far enough first. Works for mouse/touch AND stick-cursor+hold-A,
  -- for free, the same way C.held's own pending/drag/armed already does:
  -- both funnel through this same onScreenMouse/C.mx-My/onScreenRelease
  -- pipeline, only the position source and "is the button still down"
  -- check differ per input style (see C.drawScreen's own promotion
  -- comment).
  C.marqueeStart = C.marqueeStart or nil   -- { x, y, side }
  C.marquee = C.marquee or nil             -- { x0, y0, x1, y1, side }
  -- Destructive actions (toss, release) need a confirm step -- there's no
  -- modal/dialog system anywhere in this file to reuse, so this follows
  -- the same lightweight "tap again within a short window" pattern the
  -- Bag's own "Save order" button already uses for its flash state,
  -- rather than inventing new screen-stack plumbing for one confirm box.
  -- `tag` distinguishes which action is pending so a stale confirm from a
  -- different button can't be silently consumed by the wrong one.
  -- v2.9.5, replaced same session with a real popup (direct request: "a
  -- pop up window basically asking if you're sure" instead of the
  -- original tap-again-to-confirm pattern). C.confirmPopup, set here,
  -- is read by drawConfirmPopup (see C.drawScreen for the draw order) and
  -- by the input interceptors at the top of
  -- onScreenMouse/padPressed/onScreenKey -- while it's set, NOTHING else
  -- on the Items/Party screen can receive input, true modal behavior,
  -- not just a relabeled button. `tag` says which execute-function to
  -- call if confirmed; `text` is what the popup shows.
  C.confirmPopup = C.confirmPopup or nil   -- { tag, text }
  C.doMultiTransfer = function(side)
    local sel = C.multiSelect[side]
    local ids = {}; for id in pairs(sel) do ids[#ids+1] = id end
    if #ids == 0 then return end
    local toSide = side == "bag" and "pc" or "bag"
    local snap = C.snapshotItems()
    local moved, failed = 0, 0
    for _, id in ipairs(ids) do
      if doTransfer(side, id, 999, toSide, nil, true) then moved = moved + 1 else failed = failed + 1 end
    end
    -- v2.9.5, direct request: select mode closes on a completed action
    -- instead of persisting with nothing left selected -- only on actual
    -- success (moved > 0), so a fully-failed attempt (e.g. destination
    -- full) leaves you in select mode to adjust the selection and retry
    -- rather than kicking you out after nothing happened.
    if moved > 0 then C.pushUndo(snap); C.exitSelectMode() else C.multiSelect[side] = {} end
    C.setStatus(moved .. " moved" .. (failed > 0 and (", " .. failed .. " couldn't move") or ""))
  end
  -- Opens the confirm popup; doesn't touch the save at all until
  -- C.executeMultiToss actually runs (see the popup's Yes dispatch).
  C.doMultiToss = function(side)
    local sel = C.multiSelect[side]
    local n = 0; for _ in pairs(sel) do n = n + 1 end
    if n == 0 then return end
    C.confirmPopup = { tag = "toss:" .. side, text = "Discard " .. n .. " item" .. (n > 1 and "s" or "") .. "?", focus = "confirm" }
  end
  C.executeMultiToss = function(side)
    local sel = C.multiSelect[side]
    local ids = {}; for id in pairs(sel) do ids[#ids+1] = id end
    if #ids == 0 then return end
    local snap = C.snapshotItems()
    local tossed, failed = 0, 0
    for _, id in ipairs(ids) do
      if C.doToss(side, id, true) then tossed = tossed + 1 else failed = failed + 1 end
    end
    -- v2.9.5, direct request: same "exit select mode on real success"
    -- rule as C.doMultiTransfer's own comment.
    if tossed > 0 then C.pushUndo(snap); C.exitSelectMode() else C.multiSelect[side] = {} end
    C.setStatus(tossed .. " discarded" .. (failed > 0 and (", " .. failed .. " couldn't be tossed") or ""))
  end
  -- Destination is whichever box is currently being VIEWED (C.boxView) --
  -- select mons (possibly from several different source boxes), navigate
  -- to the box you want them in using the ordinary box-tab controls
  -- (completely unaffected by selection), then confirm here. Keeps this
  -- feature to exactly what was asked (move BETWEEN boxes) without
  -- overloading what a rail-tab tap means while selecting.
  C.doMultiMoveBox = function()
    local items = {}
    for _, v in pairs(C.multiSelectBox) do items[#items+1] = v end
    if #items == 0 then return end
    local destBox = C.boxView or 1
    -- Process highest index first within each source box: table.remove
    -- shifts every later index down by one, so removing a lower index
    -- FIRST would silently invalidate a higher, still-pending index in
    -- that same box (it'd now point at whatever slid into that spot).
    -- Sorting descending means every remove happens strictly above
    -- whatever's left to process, so no pending index is ever affected
    -- by an earlier removal in this same loop.
    table.sort(items, function(a, b)
      if a.box ~= b.box then return a.box > b.box end
      return a.index > b.index
    end)
    local snap = C.snapshotParty()
    local moved, failed = 0, 0
    for _, it in ipairs(items) do
      if it.box ~= destBox then
        if doMonPlace({ loc = "box", box = it.box, index = it.index }, { loc = "box", box = destBox }, true) then
          moved = moved + 1
        else
          failed = failed + 1
        end
      end
    end
    -- v2.9.5, direct request: same "exit select mode on real success"
    -- rule as C.doMultiTransfer's own comment.
    if moved > 0 then C.pushUndo(snap); C.exitSelectMode() else C.multiSelectBox = {} end
    C.setStatus(moved .. " moved to Box " .. destBox .. (failed > 0 and (", " .. failed .. " couldn't move") or ""))
  end
  C.doMultiRelease = function()
    local n = 0; for _ in pairs(C.multiSelectBox) do n = n + 1 end
    if n == 0 then return end
    C.confirmPopup = { tag = "release", text = "Release " .. n .. " Pokemon?", focus = "confirm" }
  end
  C.executeMultiRelease = function()
    local items = {}
    for _, v in pairs(C.multiSelectBox) do items[#items+1] = v end
    if #items == 0 then return end
    table.sort(items, function(a, b)
      if a.box ~= b.box then return a.box > b.box end
      return a.index > b.index
    end)
    local snap = C.snapshotParty()
    local released = 0
    for _, it in ipairs(items) do
      if C.doRelease(it.box, it.index, true) then released = released + 1 end
    end
    -- v2.9.5, direct request: same "exit select mode on real success"
    -- rule as C.doMultiTransfer's own comment.
    if released > 0 then C.pushUndo(snap); C.exitSelectMode() else C.multiSelectBox = {} end
    C.setStatus(released .. " released")
  end
  -- v2.9.5: the Select/Transfer/Discard (Items) or Select/Move/Release
  -- (Boxes) header buttons currently visible, left to right -- MUST match
  -- what itemPanel/boxPanel actually draw on that row, since C.headerFocus
  -- is just an index into this same list. Transfer/Discard (or Move/
  -- Release) only exist once select mode is on AND something's selected,
  -- same condition the drawing code already gates on.
  -- v2.9.5: shared select-mode exit, direct request ("this feels more
  -- natural over the select mode persisting after a transfer") -- used
  -- by B/Esc (see onScreenKey) AND by all 4 bulk actions once they
  -- actually complete (C.doMultiTransfer/doMultiMoveBox/executeMultiToss/
  -- executeMultiRelease), so a finished bulk action always drops you back
  -- to normal browsing instead of leaving you in select mode with nothing
  -- left selected. Applied to all four for consistency, not just Transfer
  -- -- the same "feels unfinished" reasoning applies equally to Discard/
  -- Move/Release, and leaving 3 of 4 inconsistent seemed worse than
  -- generalizing; flagged in case only Transfer was actually wanted.
  C.exitSelectMode = function()
    C.selectMode = false
    C.multiSelect.bag, C.multiSelect.pc, C.multiSelectBox = {}, {}, {}
    C.confirmPopup = nil
    C.headerFocus.bag, C.headerFocus.pc, C.headerFocusBox = 0, 0, 0
    C.marqueeStart, C.marquee = nil, nil
  end
  C.headerButtons = function(side)
    local btns = { "search", "selectmode" }
    if C.selectMode then
      local n = 0; for _ in pairs(C.multiSelect[side]) do n = n + 1 end
      if n > 0 then btns[#btns+1] = "multitransfer"; btns[#btns+1] = "multitoss" end
    end
    return btns
  end
  C.headerButtonsBox = function()
    local btns = { "searchbox", "selectmode" }
    if C.selectMode then
      local n = 0; for _ in pairs(C.multiSelectBox) do n = n + 1 end
      if n > 0 then btns[#btns+1] = "multimovebox"; btns[#btns+1] = "multirelease" end
    end
    return btns
  end
  -- Same effect as tapping/clicking that header button directly (mirrors
  -- onScreenMouse's own tag dispatch for these exact tags verbatim, so
  -- D-pad+A and tap/click can never drift apart in what they do).
  C.activateHeaderButton = function(tag, side)
    if tag == "selectmode" then
      C.selectMode = not C.selectMode
      if not C.selectMode then C.multiSelect.bag, C.multiSelect.pc, C.multiSelectBox = {}, {}, {} end
      C.confirmPopup = nil
    elseif tag == "search" then C.openSearchGrid(side)
    elseif tag == "searchbox" then C.openSearchGrid("box")
    elseif tag == "multitransfer" then C.doMultiTransfer(side)
    elseif tag == "multitoss" then C.doMultiToss(side)
    elseif tag == "multimovebox" then C.doMultiMoveBox()
    elseif tag == "multirelease" then C.doMultiRelease()
    end
  end
  -- v2.9.5: D-pad up/down header-focus entry/exit for Boxes (mirrors
  -- Items' own C.onPadScroll chain, minus the Save-order step that's
  -- Bag-only) -- up from "nothing focused" enters the Select row, down
  -- from it exits; up while already in the row does nothing further
  -- (there's nothing above it on Boxes, unlike Bag's Save-order).
  C.onPadScrollBox = function(dy)
    if C.screen ~= "party" then return end
    -- Grid-cursor active: down moves forward (+1) through all 20 slots in
    -- reading order, clamped at the last one; up moves back (-1), except
    -- from the top row (1-4), where up EXITS to header-focus instead --
    -- chains with the header row exactly like Items' own list<->header
    -- chain (see C.onPadScroll's comment).
    if C.boxCursor > 0 then
      if dy > 0 then
        if C.boxCursor <= 4 then C.boxCursor = 0; C.headerFocusBox = 1
        else C.boxCursor = C.boxCursor - 1 end
      else
        C.boxCursor = math.min(20, C.boxCursor + 1)
      end
      return
    end
    if C.headerFocusBox > 0 then
      -- down from the header row now chains INTO the grid (at slot 1)
      -- instead of just dropping to a vague "neutral" state -- there's
      -- always something concrete below the header to land on now.
      if dy < 0 then C.headerFocusBox = 0; C.boxCursor = 1 end
      return
    end
    if dy > 0 then C.headerFocusBox = 1
    elseif dy < 0 then C.boxCursor = 1 end
  end
  -- D-pad+A while header-focused activates whichever button is focused;
  -- a plain no-op otherwise, matching this screen's behavior before this
  -- feature existed (confirmed no prior D-pad+A meaning on Boxes at all).
  C.onPadSelectBox = function()
    if C.screen ~= "party" then return end
    -- Grid-cursor active: A toggles the checkbox on whatever's at that
    -- slot while select mode is on -- same tap-to-toggle rule mouse/
    -- touch/stick-cursor already use in onScreenMouse, just reached via
    -- D-pad this time. Not select mode: a plain no-op for now (Boxes
    -- never had a D-pad-driven single-mon pick-up/move at all before this
    -- feature, so this isn't a regression -- just not built yet).
    if C.boxCursor > 0 then
      if C.selectMode then
        local box = boxesEnsure()[C.boxView or 1] or {}
        if box[C.boxCursor] then
          local key = (C.boxView or 1) .. ":" .. C.boxCursor
          if C.multiSelectBox[key] then C.multiSelectBox[key] = nil
          else C.multiSelectBox[key] = { box = C.boxView or 1, index = C.boxCursor } end
        end
      end
      return
    end
    if C.headerFocusBox <= 0 then return end
    local btns = C.headerButtonsBox()
    -- Clamped rather than indexed raw: if focus was left on Move/Release
    -- (index 2/3) and the selection then dropped to zero via a DIFFERENT
    -- input method (e.g. mouse/touch deselecting rows while D-pad focus
    -- was still parked on the header from earlier), those buttons stop
    -- being drawn and the stored index would point past the real list --
    -- clamping resolves it to the last real button instead of indexing
    -- nil and silently doing nothing.
    C.activateHeaderButton(btns[math.min(C.headerFocusBox, #btns)], nil)
  end
  -- Respects regionClip for the same reason region() does (see its comment):
  -- a row scrolled below the fold must not report itself as hovered/droppable.
  local function ptIn(x, y, w, h)
    if C.mx < x or C.mx > x+w then return false end
    local y1, y2 = y, y + h
    if C.regionClip then
      y1 = math.max(y1, C.regionClip.y1)
      y2 = math.min(y2, C.regionClip.y2)
      if y2 <= y1 then return false end
    end
    return C.my >= y1 and C.my <= y2
  end
  local function railAt(dx, dy)
    for _, r in ipairs(C.pLayout.rail or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return r end end
  end
  local function monSlotAt(dx, dy)
    for _, r in ipairs(C.pLayout.party or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="party", index=r.index, mon=r.mon } end end
    for _, r in ipairs(C.pLayout.grid or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="box", box=C.pLayout.curBox, index=r.index, mon=r.mon } end end
  end
  local function dropTargetMon(dx, dy)
    local t = railAt(dx, dy); if t then return { loc="box", box=t.box } end   -- rail tab -> append to that box
    for _, r in ipairs(C.pLayout.party or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="party", index=r.index } end end
    for _, r in ipairs(C.pLayout.grid or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="box", box=C.pLayout.curBox, index=r.index } end end
  end
  local function drawSpriteIn(img, x, y, bw, bh, alpha)
    if not img then return end
    local iw, ih = img:getDimensions()
    img:setFilter("nearest", "nearest")
    local sc = math.min(bw/iw, bh/ih)
    love.graphics.setColor(1, 1, 1, alpha or 1)
    love.graphics.draw(img, (x+bw/2)*s, (y+bh/2)*s, 0, sc*s, sc*s, iw/2, ih/2)
  end
  local function heldIsAt(loc, box, index)
    local h = C.held and C.held.src
    return h and h.loc == loc and h.box == box and h.index == index
  end
  local function partyPanel(px, py, pw, ph)
    local dPoke = C.game.data.pokemon
    local party = C.game.save.party or {}
    local hs = C.held and C.held.src
    panel(px, py, pw, ph, false)
    txt("PARTY", px+PAD, py+12, 22, COL.text)
    txt(#party.."/6", px+pw-PAD, py+16, 14, COL.dim, "right")
    local ry = py + 54
    -- v2.9.5 fix, direct report + screenshot (portrait, stacked panels):
    -- `rh` used to be `math.min(150, (ph-64)/6)` -- shrinking indefinitely
    -- with NO floor once ph shrank (each stacked panel now gets roughly
    -- half the height it used to), producing rows a few pixels tall with
    -- sprite/name/level/HP-bar/HP-text all overlapping into an unreadable
    -- mess -- confirmed exactly this on a real screenshot. Party never
    -- needed to scroll before (6 rows always fit), so unlike itemPanel's
    -- list there was no floor/scroll fallback to begin with -- added one,
    -- same shape as itemPanel's own scroll+scissor list and the overlay's
    -- OWN party panel (fixed for portrait earlier this session): a real
    -- minimum row height, clip+scroll instead of shrinking past readable.
    local MIN_RH = 62
    local viewH = math.max(0, ph - 64)
    local rh = math.max(MIN_RH, math.min(150, viewH / 6))
    local contentH = rh * 6
    local scrolling = contentH > viewH
    local maxScroll = scrolling and (contentH - viewH) or 0
    C.pScrollY = scrolling and math.max(0, math.min(maxScroll, C.pScrollY or 0)) or 0
    -- Continues an in-progress scrollbar drag (started via the "pscrollbar"
    -- region/tag below, grabbed in C.onScreenMouse) -- polled every frame
    -- this panel draws rather than needing a separate "moved" event,
    -- mirroring how C.held's own pending-to-drag promotion is polled in
    -- C.onFrame for the same reason (a single press/release pair can't
    -- track continuous movement on its own). C.touchScreenPos specifically
    -- (not love.mouse.isDown alone) because this file's own touch path
    -- deliberately bypasses LOVE's synthesized mouse-from-touch (see the
    -- input.pointer hook's own comment) -- love.mouse.isDown alone would
    -- miss a touch-driven drag entirely.
    if C.pScrollDrag then
      if scrolling and ((C.touchScreenPos ~= nil) or love.mouse.isDown(1)) then
        local d = C.pScrollDrag
        local track = viewH - d.thumbH
        local frac = track > 0 and ((C.my - d.startY) / track) or 0
        C.pScrollY = math.max(0, math.min(maxScroll, d.startScroll + frac * maxScroll))
      else
        C.pScrollDrag = nil
      end
    end
    -- Auto-scroll this list while carrying a Pokemon and holding near its
    -- top/bottom edge; C.listAutoConsumed stands the page-level auto-scroll
    -- down for the frame. Same chaining as itemPanel's -- see its comment.
    if C.held and scrolling and C.pointerHeld() and C.mx >= px and C.mx <= px+pw then
      local edge, dt = 44, love.timer.getDelta()
      local cur = C.pScrollY
      if C.my > ry + viewH - edge and C.my <= ry + viewH and cur < maxScroll then
        C.pScrollY = math.min(maxScroll, cur + 700*dt); C.listAutoConsumed = true
      elseif C.my < ry + edge and C.my >= ry and cur > 0 then
        C.pScrollY = math.max(0, cur - 700*dt); C.listAutoConsumed = true
      end
    end
    local scy = C.pScrollY
    C.pLayout.party = {}
    local prevSc
    if scrolling then
      prevSc = C.pushScissor(math.floor(px*s), math.floor(ry*s), math.ceil(pw*s), math.ceil(viewH*s))
    end
    for i = 1, 6 do
      local y = ry + (i-1)*rh - scy
      local mon = party[i]
      C.pLayout.party[#C.pLayout.party+1] = { x=px+8, y=y, w=pw-16, h=rh-6, index=i, mon=mon }
      local held = heldIsAt("party", nil, i)
      local hov = ptIn(px+8, y, pw-16, rh-6)
      local tgt = hs and hov
      local blk = tgt and placeBlocked(hs, { loc="party", index=i })
      if held then setc(COL.gold, 0.05)
      elseif tgt and blk then setc(COL.lo, 0.16)
      elseif tgt then setc(COL.hi, 0.14)
      elseif hov and mon then setc(COL.gold, 0.10)
      else setc(COL.border, mon and 0.03 or 0.012) end
      rrect("fill", px+8, y, pw-16, rh-6, 8)
      if mon then
        local def = dPoke[mon.species]
        local ss = math.min(rh-6-16, 96)
        drawSpriteIn(getSprite(mon.species, dPoke), px+PAD, y+(rh-6-ss)/2, ss, ss)
        local nx = px+PAD+ss+14
        local mx = monMax(mon, def); local hp = mon.hp or mx
        local frac = mx > 0 and hp/mx or 0
        -- v2.9.5 bugfix, direct report + screenshots (portrait, both Odin
        -- and S23 Ultra): the level text's offset under the name was a
        -- FLAT +28 that never shrank with rh, while the HP bar's position
        -- (rh*0.63) DOES shrink with rh -- once rh got small enough (the
        -- portrait MIN_RH=62 floor, added last session for a DIFFERENT
        -- overflow bug), the two landed on top of each other. Fix:
        -- interpolate between a tight, hand-verified non-overlapping
        -- stack (at rh==MIN_RH, the floor) and the ORIGINAL proportional
        -- layout (at rh==150, the cap, which landscape always uses and
        -- which must look EXACTLY the same as before). Linear
        -- interpolation between two gaps that are each individually
        -- positive is itself guaranteed positive at every point in
        -- between (a convex combination of two positive numbers can't go
        -- negative), so this can't reintroduce the bug at some untested
        -- in-between row height -- not just patched at the two endpoints.
        local t = math.max(0, math.min(1, (rh - 62) / (150 - 62)))
        local nameOff  = 5  + t*(rh*0.16 - 5)
        local levelOff = nameOff + 18 + t*10   -- 18px gap at the floor, 28px (the original) at the cap
        local barOff   = math.max(levelOff + 18, rh*0.63)
        txt(sanitize(mon.nickname or (def and def.name) or mon.species), nx, y + nameOff, 20, held and COL.dim or COL.text)
        txt("Lv"..(mon.level or 1), nx, y + levelOff, 15, COL.dim)
        bar(nx, y + barOff, pw - (nx-px) - PAD, 10, frac, hpCol(frac))
        txt(hp.."/"..mx, px+pw-PAD, y + barOff - 18, 14, COL.dim, "right")
      else
        txt("- empty -", px+PAD, y+(rh-6)/2-10, 15, COL.dim, nil, 0.4)
      end
    end
    if scrolling then
      C.popScissor(prevSc)
      -- v2.9.5: grabbable scrollbar, same visual language + geometry
      -- shape as itemPanel's own list scrollbar just below in this same
      -- file (gold thumb, thin border track) -- registered as a real
      -- region/tag so a press on it is caught by C.onScreenMouse's
      -- existing tag dispatch (see the "pscrollbar" case added there),
      -- not a bespoke hit-test system.
      local tx, tw = px+pw-14, 8
      setc(COL.border, 0.25); rrect("fill", tx, ry, tw, viewH, 4)
      local thumbH = math.max(30, viewH * (viewH / contentH))
      local thumbY = ry + (scy / maxScroll) * (viewH - thumbH)
      setc(COL.gold, 0.85); rrect("fill", tx, thumbY, tw, thumbH, 4)
      region(tx - 10, ry, tw + 20, viewH, "pscrollbar")
      C.pScrollTrack = { thumbH = thumbH, thumbY = thumbY, y = ry, h = viewH }
    else
      C.pScrollTrack = nil
    end
  end
  local function boxPanel(px, py, pw, ph)
    local save = C.game.save
    local boxes = boxesEnsure()
    local cur = C.boxView or save.currentBox or 1
    C.pLayout.curBox = cur
    local hs = C.held and C.held.src
    panel(px, py, pw, ph, false)
    txt("BOXES", px+PAD, py+12, 22, COL.text)
    local curCount = #(boxes[cur] or {})
    txt("Box "..cur.."   "..curCount.."/"..BCAP, px+pw-PAD, py+16, 14, curCount>=BCAP and COL.lo or COL.dim, "right")
    -- v2.9.5: multi-select, direct request. Own row, same reasoning as the
    -- Bag/PC panels' own Select row -- ry0 below is pushed down to
    -- unconditionally reserve it. Boxes-only (see C.doRelease's comment
    -- for why Party never got multi-select).
    do
      local sy2, sx2 = py + 38, px + PAD
      local active = C.selectMode
      local hf = C.headerFocusBox
      -- v2.9.5: D-pad focus ring, same convention as the Bag/PC panels'
      -- own (see their comment) -- idx must stay in lockstep with
      -- C.headerButtonsBox's own ordering.
      local idx = 1
      local function focusRing(bx2, w)
        if hf == idx then
          love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95)
          rrect("line", bx2, sy2, w, 24, 6)
          love.graphics.setLineWidth(1)
        end
        idx = idx + 1
      end
      -- v2.9.5: replaces the old "A-Z >" jump-letter button -- see the
      -- Bag/PC panels' own identical comment on this same pattern.
      -- Boxes' query is one flat string (spans every box, not per-box --
      -- see C.searchQueryBox's own comment).
      local sqbox = C.searchQueryBox
      local sblbl = sqbox ~= "" and ("Search: " .. sqbox) or "Search"
      local sbw = textW(sblbl, 13) + 18
      region(sx2, sy2, sbw, 24, "searchbox")
      setc(sqbox ~= "" and COL.gold or COL.panel, sqbox ~= "" and 0.85 or 0.55); rrect("fill", sx2, sy2, sbw, 24, 6)
      txt(sblbl, sx2+9, sy2+4, 13, sqbox ~= "" and COL.panel or COL.dim)
      focusRing(sx2, sbw)
      sx2 = sx2 + sbw + 8
      local lbl = active and "Selecting" or "Select"
      local bw = textW(lbl, 13) + 18
      region(sx2, sy2, bw, 24, "selectmode")
      setc(active and COL.gold or COL.panel, active and 0.9 or 0.55); rrect("fill", sx2, sy2, bw, 24, 6)
      txt(lbl, sx2+9, sy2+4, 13, active and COL.panel or COL.dim)
      focusRing(sx2, bw)
      sx2 = sx2 + bw + 8
      if active then
        local n = 0; for _ in pairs(C.multiSelectBox) do n = n + 1 end
        if n > 0 then
          local mlbl = "Move (" .. n .. ") here"
          local mw = textW(mlbl, 13) + 16
          region(sx2, sy2, mw, 24, "multimovebox")
          setc(COL.hi, 0.85); rrect("fill", sx2, sy2, mw, 24, 6)
          txt(mlbl, sx2+8, sy2+4, 13, COL.panel)
          focusRing(sx2, mw)
          sx2 = sx2 + mw + 8
          local rlbl = "Release (" .. n .. ")"
          local rw = textW(rlbl, 13) + 16
          region(sx2, sy2, rw, 24, "multirelease")
          setc(COL.lo, 0.75); rrect("fill", sx2, sy2, rw, 24, 6)
          txt(rlbl, sx2+8, sy2+4, 13, COL.panel)
          focusRing(sx2, rw)
        else
          txt("Tap Pokemon to select", sx2, sy2+4, 12, COL.dim, nil, 0.6)
        end
      end
    end
    -- rail: all NBOX boxes, laid out in rows of 6 so each tab has room for its
    -- number + count (a single row of 12 got too narrow, especially for the
    -- two-digit box numbers 10-12).
    -- v2.9.3: tRows used to be hardcoded to 2 (exactly Gen 1's 12 boxes /
    -- 6 columns). Gold has 14 boxes (C.Boxes.COUNT, confirmed against real
    -- src/core/gen2/Boxes.lua), so boxes 13-14 landed in an implied 3rd
    -- row that this fixed row count never reserved space for -- gy0 below
    -- (which the box-content grid starts at) was computed assuming only 2
    -- tab rows, so that 3rd row visually collided with the grid under it.
    -- Deriving tRows from NBOX keeps Gen 1 at exactly 2 rows (unchanged)
    -- and gives Gold the 3rd row of space it actually needs.
    -- v2.9.5: +28 (was 46) to also reserve the new multi-select row above,
    -- unconditionally so the rail/grid never shifts between select mode
    -- on/off.
    C.pLayout.rail = {}
    local ry0 = py + 74
    local tCols, tRows = 6, math.ceil(NBOX / 6)
    local tgap = 6
    local tw = (pw - PAD*2 - (tCols-1)*tgap) / tCols
    local th = 40
    local trowGap = 6
    for n = 1, NBOX do
      local cnt = #(boxes[n] or {})
      local empty = cnt == 0
      local col = (n-1) % tCols
      local row = math.floor((n-1) / tCols)
      local tx = px+PAD + col*(tw+tgap)
      local ty = ry0 + row*(th+trowGap)
      local sel = n == cur
      local hov = ptIn(tx, ty, tw, th)
      C.pLayout.rail[#C.pLayout.rail+1] = { x=tx, y=ty, w=tw, h=th, box=n }
      local dropHi = hs and hov
      local blk = dropHi and placeBlocked(hs, { loc="box", box=n })
      setc(sel and COL.gold or (dropHi and (blk and COL.lo or COL.hi) or COL.panel), sel and 0.9 or (empty and 0.35 or 0.72))
      rrect("fill", tx, ty, tw, th, 5)
      txt(tostring(n), tx+tw/2, ty+4, 16, sel and COL.panel or (empty and COL.dim or COL.text), "center")
      txt(empty and "-" or (cnt.."/"..BCAP), tx+tw/2, ty+22, 11, sel and COL.panel or COL.dim, "center", empty and 0.5 or 0.9)
    end
    -- 4x5 grid of the current box
    local box = boxes[cur] or {}
    local gcols, grows, gap = 4, 5, 10
    local gy0 = ry0 + tRows*(th+trowGap) - trowGap + 16
    local cwd = (pw - PAD*2 - (gcols-1)*gap) / gcols
    -- v2.9.5 FIX, screenshot-confirmed (2026-08-23): chh was
    -- `math.min((ph - (gy0-py) - PAD - 6) / grows - gap, cwd*1.1)` with no
    -- floor at all. Once two panels shared the screen's height that
    -- subtraction went NEGATIVE -- and a negative cell height makes
    -- `ty = gy0 + row*(chh+gap)` step BACKWARD, stacking every grid row on
    -- top of the one above it. That is exactly the unreadable pile of
    -- overlapping sprites and names in the report. Same class of bug
    -- partyPanel's rows had; this function was never re-tested after that
    -- one was fixed, which is why it survived. Real minimum cell height
    -- plus scroll+clip now, like the other two panels, rather than
    -- shrinking past legible (or past zero).
    local MIN_CHH = 56
    local gviewH = math.max(0, ph - (gy0 - py) - PAD - 6)
    local chh = math.min(cwd*1.1, math.max(MIN_CHH, gviewH / grows - gap))
    local gcontentH = grows * (chh + gap) - gap
    local bscroll = gcontentH > gviewH
    local bmax = bscroll and (gcontentH - gviewH) or 0
    C.bScrollY = bscroll and math.max(0, math.min(bmax, C.bScrollY or 0)) or 0
    if C.bScrollDrag then
      if bscroll and C.pointerHeld() then
        local d = C.bScrollDrag
        local track = gviewH - d.thumbH
        local frac = track > 0 and ((C.my - d.startY) / track) or 0
        C.bScrollY = math.max(0, math.min(bmax, d.startScroll + frac * bmax))
      else
        C.bScrollDrag = nil
      end
    end
    if C.held and bscroll and C.pointerHeld() and C.mx >= px and C.mx <= px+pw then
      local edge, dt = 44, love.timer.getDelta()
      local cur = C.bScrollY
      if C.my > gy0 + gviewH - edge and C.my <= gy0 + gviewH and cur < bmax then
        C.bScrollY = math.min(bmax, cur + 700*dt); C.listAutoConsumed = true
      elseif C.my < gy0 + edge and C.my >= gy0 and cur > 0 then
        C.bScrollY = math.max(0, cur - 700*dt); C.listAutoConsumed = true
      end
    end
    local bscy = C.bScrollY
    -- Clip the grid to its own viewport, and narrow the region clip to
    -- match, so a slot scrolled out of sight can't still be tapped or act
    -- as a drop target. Intersected with whatever the page scroll already
    -- set -- an inner clip is only ever tighter (see C.pushScissor).
    local prevClipB, prevScB = C.regionClip, nil
    if bscroll then
      local c1, c2 = gy0, gy0 + gviewH
      if prevClipB then c1 = math.max(c1, prevClipB.y1); c2 = math.min(c2, prevClipB.y2) end
      C.regionClip = { y1 = c1, y2 = c2 }
      prevScB = C.pushScissor(math.floor(px*s), math.floor(gy0*s), math.ceil(pw*s), math.ceil(gviewH*s))
    end
    C.pLayout.grid = {}
    for i = 1, gcols*grows do
      local col, row = (i-1)%gcols, math.floor((i-1)/gcols)
      local tx = px+PAD + col*(cwd+gap)
      local ty = gy0 + row*(chh+gap) - bscy
      local mon = box[i]
      C.pLayout.grid[#C.pLayout.grid+1] = { x=tx, y=ty, w=cwd, h=chh, index=i, mon=mon }
      local held = heldIsAt("box", cur, i)
      local hov = ptIn(tx, ty, cwd, chh)
      local tgt = hs and hov
      local blk = tgt and placeBlocked(hs, { loc="box", box=cur, index=i })
      if held then setc(COL.gold, 0.05)
      elseif tgt and blk then setc(COL.lo, 0.16)
      elseif tgt then setc(COL.hi, 0.14)
      elseif hov and mon then setc(COL.gold, 0.12)
      else setc(COL.border, mon and 0.04 or 0.02) end
      rrect("fill", tx, ty, cwd, chh, 8)
      -- v2.9.5: D-pad grid-cursor highlight (see C.boxCursor/
      -- C.onPadScrollBox) -- persistent while active, unlike the jump
      -- flash above which fades after 2s; this is a real navigable
      -- position, not a one-off landing callout.
      if C.boxCursor == i and cur == (C.boxView or 1) then
        setc(COL.gold, 0.9); love.graphics.setLineWidth(math.max(2, 2*s)); rrect("line", tx, ty, cwd, chh, 8)
        love.graphics.setLineWidth(1)
      end
      if mon then
        local def = C.game.data.pokemon[mon.species]
        local nm = sanitize(mon.nickname or (def and def.name) or mon.species)
        -- v2.9.5: search dims (not hides) non-matching slots -- Boxes is a
        -- fixed 20-slot spatial grid, unlike Bag/PC's scrolling list, so
        -- actually hiding a slot would leave a confusing hole where a mon
        -- used to be instead of just filtering the view. See
        -- C.searchJumpBoxIfNeeded for the "current box has zero matches"
        -- case, handled separately by switching C.boxView.
        local dim = C.searchQueryBox ~= "" and not C.searchMatch(nm, C.searchQueryBox)
        local a = dim and 0.3 or 1
        drawSpriteIn(getSprite(mon.species, C.game.data.pokemon), tx+6, ty+2, cwd-12, chh-42, a)
        txt(ellipsize(nm, 13, cwd-8), tx+cwd/2, ty+chh-37, 13, held and COL.dim or COL.text, "center", a)
        txt("Lv"..(mon.level or 1), tx+cwd/2, ty+chh-19, 12, COL.dim, "center", a)
        -- v2.9.5: multi-select checkbox, top-right corner of the slot,
        -- same gold-fill-plus-check-glyph convention as the Bag/PC rows'
        -- own checkbox above.
        if C.selectMode then
          local selKey = cur .. ":" .. i
          local sel = C.multiSelectBox[selKey]
          setc(sel and COL.gold or COL.dim, sel and 0.95 or 0.4)
          rrect(sel and "fill" or "line", tx+cwd-20, ty+6, 14, 14, 3)
          if sel then
            setc(COL.panel, 1); love.graphics.setLineWidth(math.max(2, 1.6*s))
            love.graphics.line((tx+cwd-17)*s, (ty+13)*s, (tx+cwd-14)*s, (ty+16.5)*s, (tx+cwd-8)*s, (ty+8.5)*s)
            love.graphics.setLineWidth(1)
          end
        end
      end
    end
    if bscroll then
      C.popScissor(prevScB)
      C.regionClip = prevClipB
      -- Boxes' own grid scrollbar -- same look and same region/tag wiring
      -- as the Bag/PC and Party ones, per the direct request that every
      -- panel carry one.
      local tx, tw = px+pw-14, 8
      setc(COL.border, 0.25); rrect("fill", tx, gy0, tw, gviewH, 4)
      local thumbH = math.max(30, gviewH * (gviewH / gcontentH))
      local thumbY = gy0 + (bscy / bmax) * (gviewH - thumbH)
      setc(COL.gold, 0.85); rrect("fill", tx, thumbY, tw, thumbH, 4)
      region(tx - 10, gy0, tw + 20, gviewH, "bscrollbar")
      C.bScrollTrack = { thumbH = thumbH, y = gy0, h = gviewH }
    else
      C.bScrollTrack = nil
    end
  end
  local function drawPartyPanels(isPortraitScreen, ox, py, contentW, ph, G)
    C.pLayout = C.pLayout or {}
    if isPortraitScreen then
      C.drawPanelPage("party", ox, py, contentW, ph, function(ax, ay, aw, ah, bx, by, bw, bh)
        partyPanel(ax, ay, aw, ah)
        boxPanel(bx, by, bw, bh)
      end)
      return
    end
    local ax, ay, aw, ah, bx, by, bw, bh = pairedPanelRects(isPortraitScreen, ox, py, contentW, ph, G)
    partyPanel(ax, ay, aw, ah)
    boxPanel(bx, by, bw, bh)
  end
  local function drawHeldMon()
    local h = C.held; if not h or not h.mon then return end
    local def = C.game.data.pokemon[h.mon.species]
    local blk = placeBlocked(h.src, dropTargetMon(C.mx, C.my))
    local gx, gy = C.mx, C.my
    local w = 214
    setc(COL.panel, 0.97); rrect("fill", gx+16, gy-28, w, 58, 8)
    setc(blk and COL.lo or COL.gold, 0.9); love.graphics.setLineWidth(math.max(1, s)); rrect("line", gx+16, gy-28, w, 58, 8)
    drawSpriteIn(getSprite(h.mon.species, C.game.data.pokemon), gx+20, gy-26, 54, 54)
    txt(sanitize(h.mon.nickname or (def and def.name) or h.mon.species), gx+80, gy-20, 16, COL.text)
    txt("Lv"..(h.mon.level or 1), gx+80, gy+4, 13, COL.dim)
    if blk then txt(blk, gx+16, gy+34, 13, COL.lo)
    else txt("drop on a slot or box", gx+16, gy+34, 12, COL.gold, nil, 0.85) end
  end

  -- ---- open / close + input --------------------------------------------
  local function canOpen()
    local g = C.game
    if not (g and g.stack and g.save and g.save.party and #g.save.party > 0) then return false end
    -- v2.9.3: Gen 1's stack always has the overworld PUSHED as its base
    -- (src/core/Game.lua's `self.stack:push(self.overworld, ...)` at save
    -- load), so `stack:top() == overworld` is a real "nothing else is
    -- open" test there. Gold's stack (the shared src/core/StateStack.lua)
    -- starts and stays EMPTY until something is pushed -- confirmed
    -- against the real source, `top()` returns `self.states[#self.states]`,
    -- which is nil on an empty array -- it never carries an overworld
    -- placeholder at all. The old check compared that nil to a real table
    -- and could never pass, so Items/Party could never open on Gold even
    -- once C.game itself pointed at the right facade. `top == nil` covers
    -- Gen 2's "nothing open" shape; `top == g.overworld` keeps Gen 1
    -- working exactly as before.
    local top = g.stack:top()
    return top == nil or top == g.overworld
  end
  local function ensureModalState()
    if not C.modalState then
      C.modalState = {
        isOpaque = false, screenId = "KantoManageScreen",
        -- Present but a no-op: the engine's stack keyboard dispatch to the top
        -- state's onKeyPressed proved UNRELIABLE here (screens/edit wouldn't
        -- close via keyboard when we routed through it), so all kanto keyboard
        -- handling is done by C.pollKeys instead. Keeping the field means the
        -- engine still calls this and returns, which consumes the key at the
        -- engine level so its own hotkeys (F10 manager, F1 save) don't fire over
        -- our screen. Gamepad never comes this way (no top-state gamepad
        -- dispatch exists); it's polled in C.pollPad.
        onKeyPressed = function() end,
        update = function() end,
        draw = function() end,
      }
    end
    return C.modalState
  end
  C.openScreen = function(kind)
    if not canOpen() then return end
    C.screen = kind
    C.undoStack = {}   -- fresh screen session = fresh undo history
    C.held, C.status = nil, nil
    C.boxView = C.game.save.currentBox or 1
    C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
    -- v2.9.5 portrait page scroll: always open at the top of the page (Bag /
    -- Party), never wherever the previous session happened to be left
    -- scrolled to -- opening the Items screen already looking at PC Items
    -- would read as the wrong screen having opened. Same one-screen-session
    -- lifetime as C.undoStack and the multi-select state above. Any
    -- in-progress scrollbar drags are dropped for the same reason.
    C.pageScroll = { items = 0, party = 0 }
    C.pageScrollDrag, C.iScrollDrag, C.bScrollDrag, C.pScrollDrag = nil, nil, nil, nil
    C.itemEdgeHold = nil
    C.pScrollY, C.bScrollY = 0, 0
    -- v2.9.5: multi-select is scoped to one screen-open session, same
    -- lifetime as C.undoStack above -- a selection surviving a screen
    -- switch (e.g. still-selected Bag rows after switching to Party)
    -- would be confusing, and this already runs on every switch, not
    -- just a fresh open (see onScreenKey's ITEMS_KEY/PARTY_KEY cases).
    C.exitSelectMode()
    C.boxCursor = 0   -- v2.9.5: the D-pad grid-cursor, same "don't survive a screen switch" reasoning as everything exitSelectMode resets
    -- v2.9.5: search is scoped to one screen-open session too, same
    -- reasoning as multi-select/undo above -- a filtered Bag surviving a
    -- switch to Party and back would be confusing, not helpful.
    C.searchQuery = { bag = "", pc = "" }; C.searchQueryBox = ""; C.searchGrid = nil
    if kind == "items" then buildItemView(); C.iscroll = { bag = 0, pc = 0 }; C.iCursor = { bag = 1, pc = 1 }; C.iOnSave = false end
    C.game.stack:push(ensureModalState())
    C.cursorWas = love.mouse.isVisible()
    love.mouse.setVisible(true)
  end
  C.closeScreen = function()
    if C.game and C.game.stack and C.game.stack:top() == C.modalState then C.game.stack:pop() end
    C.screen, C.held = false, nil
    C.undoStack = {}   -- undo history is scoped to a single screen session
    C.stickActive, C.padDown = false, false
    C.padScrollHold, C.touchArrowHold = nil, nil
    C.searchQuery = { bag = "", pc = "" }; C.searchQueryBox = ""; C.searchGrid = nil
    if C.cursorWas ~= nil then love.mouse.setVisible(C.cursorWas) end
  end
  -- Edit mode reuses the SAME pushed modal as the screens (they never overlap).
  -- v2.9.x-sandbox: pre-sandbox, edit mode CONSUMED the D-pad/stick/arrow keys
  -- via the love.* wrappers so they couldn't walk the character. The sandbox
  -- bans that, and polling (how gamepad/keyboard are read now) can't consume.
  -- The clean stand-in is to PAUSE the overworld while editing by pushing a
  -- modal -- the engine only updates the top state, so the character can't move
  -- and polled input is safe. Gated to the overworld (canEditHere): we won't
  -- push a modal over a live battle (that would freeze it), so edit mode is
  -- overworld-only for now. When the input.gamepad/input.key CONSUME hooks land
  -- (gen1recomp issue #1285) this pause goes away and mid-battle editing returns.
  local function canEditHere()
    local g = C.game
    if not (g and g.stack) then return false end
    local top = g.stack:top()
    if top ~= nil and top ~= g.overworld then return false end
    -- v2.9.5: portrait edit mode was blocked here entirely at first, since
    -- a drag's cfg.pos always won over the computed band position the
    -- instant it existed, in ANY orientation. Root-caused and fixed
    -- properly instead (cfg.pos.portrait tag, see drawEditablePanel's own
    -- comment) rather than leaving it blocked -- direct request to restore
    -- drag/resize/collapse in portrait via the same long-press entry point
    -- landscape already uses. No orientation gate needed here anymore.
    return true
  end
  C.canEditHere = canEditHere
  C.editOpen = function(c)
    if C.overlayEdit.active or not canEditHere() then return end
    C.overlayEdit.active = true
    c.visible = true   -- edit mode can never be active without being visible
    local modal = ensureModalState()
    if C.game and C.game.stack and C.game.stack:top() ~= modal then
      C.game.stack:push(modal)
    end
    C.cursorWas = love.mouse.isVisible()
    love.mouse.setVisible(true)
  end
  C.editClose = function(c)
    if not C.overlayEdit.active then return end
    C.overlayEdit.active = false
    -- don't leave a stale drag/pinch/resize responding to input after edit off
    C.overlayEdit.drag = nil
    C.overlayEdit.pinch = nil
    C.overlayEdit.touches = {}
    C.overlayEdit.resize = nil
    -- v81 port: same "don't leave a stale drag/resize live" contract for the
    -- touch-nav/icon groups.
    C.touchGroupDrag = nil
    C.touchGroupResize = nil
    C.editStickX, C.editStickY = 0, 0
    if C.game and C.game.stack and C.game.stack:top() == C.modalState then C.game.stack:pop() end
    if C.cursorWas ~= nil then love.mouse.setVisible(C.cursorWas) end
  end
  -- The screen cycle (used to also be reachable via Select/touchpad/Tab-
  -- Shift/a touch hot-zone) derives
  -- the next step from whatever's actually showing right now (rather than a
  -- separate counter), so it stays correct even if keyboard/other-button
  -- presses changed the state mid-cycle.
  --   forward:  nothing shown -> overlay -> items -> party -> nothing -> ...
  --   backward: nothing shown -> party -> items -> overlay -> nothing -> ...
  -- (backward is just the same ring walked the other way -- pass
  -- reverse = true, e.g. from the left touch-nav button)
  -- If a screen can't open right now (canOpen() fails, e.g. mid-battle or no
  -- party), that step is just skipped over rather than getting stuck.
  C.onPadCycle = function(reverse)
    if not reverse then
      if C.screen == "party" then
        C.closeScreen(); C.visible = false; return
      end
      if C.screen == "items" then
        C.closeScreen(); C.openScreen("party"); return
      end
      if C.visible then
        C.visible = false; C.openScreen("items"); return
      end
      C.visible = true
      return
    end
    -- reverse: walk the same ring backward
    if C.visible and not C.screen then
      C.visible = false; return
    end
    if C.screen == "items" then
      C.closeScreen(); C.visible = true; return
    end
    if C.screen == "party" then
      C.closeScreen(); C.openScreen("items"); return
    end
    C.openScreen("party")
  end
  C.onScreenKey = function(key)
    -- v2.9.5: while the confirm popup is up, keyboard is cancel-only --
    -- checked before even the normal escape handling below, so it can
    -- never fall through to closing the whole screen instead.
    if C.confirmPopup then
      if key == "escape" then C.confirmPopup = nil end
      return
    end
    -- v2.9.5: while the search grid is up, this whole function is a
    -- no-op -- real typing is handled entirely by the SEPARATE
    -- C.pollSearchKeys poll instead (see its own comment), specifically
    -- so typing "u"/"i"/"p"/"o"/"c"/"r" for a search query can't ALSO
    -- fire this function's own Undo/screen-switch/etc bindings for those
    -- same letters, the way it would if this ran unguarded.
    if C.searchGrid then return end
    if key == "escape" then
      if C.screen == "items" and C.held then C.held = nil; return end   -- cancel a pending pickup first
      if C.screen == "items" and C.heldHeader then C.heldHeader = nil; return end   -- v2.9.5: same, for an in-progress header drag
      -- v2.9.5, direct request: B/Esc exits select mode first, closes the
      -- screen only on a SECOND press once select mode is already off --
      -- same "cancel the in-progress thing before closing" precedent the
      -- held-item check above already sets, just extended to this mode.
      if C.selectMode then C.exitSelectMode(); return end
      C.closeScreen(); return
    end
    if key == "u" then if C.doUndo then C.doUndo() end; return end   -- keyboard Undo (only reachable while a screen is open)
    if OVERLAY_KEYS[key] then   -- switch away from this screen to the overlay
      C.closeScreen(); C.visible = true; return
    end
    if key == ITEMS_KEY then
      if C.screen == "items" then C.closeScreen()
      else
        C.screen = "items"; C.held = nil; C.heldHeader = nil; C.undoStack = {}; buildItemView(); C.iscroll = { bag = 0, pc = 0 }; C.iCursor = { bag = 1, pc = 1 }; C.iOnSave = false
        C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
      end
      return
    end
    if key == PARTY_KEY then
      if C.screen == "party" then C.closeScreen()
      else
        C.screen = "party"; C.held = nil; C.heldHeader = nil; C.undoStack = {}; C.boxView = C.game.save.currentBox or 1
        C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
      end
      return
    end
    local nbox = (C.Boxes and C.Boxes.COUNT) or 12
    -- v2.9.5: while header-focused (C.headerFocus/C.headerFocusBox, see
    -- C.onPadScroll's own comment for how you get there), left/right
    -- cycles the header's OWN buttons instead of their normal meaning
    -- (switch Bag/PC focus, or cycle which box is viewed) -- checked
    -- first, with an early return, so the two can never both apply to the
    -- same press.
    if C.screen == "party" and C.headerFocusBox > 0 then
      local btns = C.headerButtonsBox()
      local dir = (key == "left") and -1 or (key == "right") and 1 or nil
      if dir then C.headerFocusBox = ((C.headerFocusBox - 1 + dir) % #btns) + 1 end
      return
    end
    if C.screen == "items" and C.headerFocus[C.iFocus or "bag"] > 0 then
      local side = C.iFocus or "bag"
      local btns = C.headerButtons(side)
      local dir = (key == "left") and -1 or (key == "right") and 1 or nil
      if dir then C.headerFocus[side] = ((C.headerFocus[side] - 1 + dir) % #btns) + 1 end
      return
    end
    if C.screen == "party" and key == "left"  then C.boxView = (C.boxView or 1) > 1 and C.boxView-1 or nbox end
    if C.screen == "party" and key == "right" then C.boxView = (C.boxView or 1) < nbox and C.boxView+1 or 1 end
    if C.screen == "items" and key == "left"  then C.iFocus = "bag" end
    if C.screen == "items" and key == "right" then C.iFocus = "pc" end
    -- v2.9.5 bugfix, direct report: "arrow keys dont scroll the item lists
    -- that is in focus like the dpad does." Up/down were already being
    -- polled every frame (see KEY_POLL/C.pollKeys) and reaching this exact
    -- function -- there was just no handler for them here, so they were a
    -- silent no-op on the Items screen. Routes through the SAME
    -- C.onPadScroll real D-pad up/down already calls (love.gamepadpressed's
    -- "dpup"/"dpdown" branch), so keyboard can't drift from D-pad's own
    -- behavior -- including the hold-to-repeat ramp: sets C.padScrollHold
    -- exactly like that same D-pad branch does; C.pollKeys' own edge-detect
    -- loop clears it again once the key is physically released (see its own
    -- comment -- keyboard has no separate "release" event the way a
    -- gamepad button does, so that has to be polled for too).
    if C.screen == "items" and C.onPadScroll and (key == "up" or key == "down") then
      local dir = (key == "up") and 1 or -1
      C.onPadScroll(dir)
      C.padScrollHold = { dir = dir, t = 0, n = 0 }
    end
    -- v2.9.5 bugfix, direct report: "no way for the user, on any platform,
    -- to change the quantity of a grabbed item, without enabling touch nav
    -- or touch icons" -- keyboard specifically still had no path even after
    -- the on-screen stepper was un-gated (drawHeldItem), since a keyboard-
    -- only player has no cursor to click it with. -/kp- and =/kp+ were
    -- already being polled (KEY_POLL) but, like up/down above, had no
    -- handler here. Routes through the SAME C.onPadTrigger the real L2/R2
    -- gamepad triggers already use, same dir convention (1=decrease,
    -- matching L2's physical trigger sense; -1=increase). Gated on actually
    -- holding a real stack (C.held.max>1) -- these keys have no other
    -- meaning anywhere else in this function, on either screen, so nothing
    -- to preserve when not holding one.
    if C.screen == "items" and C.held and C.held.max and C.held.max > 1
        and (key == "-" or key == "kp-" or key == "=" or key == "kp+") then
      local dir = (key == "-" or key == "kp-") and 1 or -1
      if C.onPadTrigger then C.onPadTrigger(dir) end
    end
  end
  -- Left-stick virtual cursor for the Items/Party screens. Moves C.vcx/vcy
  -- (raw pixels, same space as love.mouse.getPosition()) at a speed scaled
  -- off how far the stick is pushed past its dead-zone; C.drawScreen below
  -- substitutes this for the real mouse position (into C.mx/C.my) whenever
  -- C.stickActive is set, which is ALL this needs to do to work -- every
  -- pickup/drag/drop/sort/box-tab/close rule in onScreenMouse/onScreenRelease
  -- already runs purely off C.mx/C.my and a button-down/up pair, so routing
  -- the A button through those same two functions (see love.gamepadpressed/
  -- gamepadreleased further down) gets the whole Items AND Party screen --
  -- including Party's Pokemon grab/drop, which real D-pad/A never covered --
  -- for free, with nothing about the rules duplicated here.
  --
  -- Stick control only takes over once the stick actually gets pushed
  -- (C.stickActive starts false whenever a screen opens or switches -- see
  -- C.openScreen/C.onScreenKey above), and immediately hands back to
  -- D-pad/A/B or mouse/touch the moment either of those is used instead
  -- (see the dpad branch in love.gamepadpressed and the mousepressed
  -- wrapper) -- so all three input styles stay fully usable side by side,
  -- same as D-pad/A/B and mouse/touch already were.
  --
  -- Session 93: also active during overlay edit mode now, on direct
  -- request -- edit mode was otherwise mouse/touch-only (dragging a
  -- header, corner-resizing, tapping the collapse icon all need a real
  -- pointer position, which D-pad/buttons alone can't give). Same
  -- gate-relax as everything else here: C.overlayEdit.active is just
  -- another condition alongside C.screen for whether the cursor should
  -- move at all. See C.driveStickEditMode further down (defined after
  -- updateDrag/updateResize exist) for what actually consumes C.vcx/vcy
  -- during edit mode -- this function only ever moves the cursor, same
  -- as before.
  C.updateStickCursor = function(dt)
    if not C.screen and not C.overlayEdit.active then return end
    local lx, ly = 0, 0
    if C.overlayEdit.active then
      -- Session 95: edit mode reads the axis values recorded by the
      -- love.gamepadaxis callback (see its "leftx"/"lefty" branch)
      -- instead of polling love.joystick directly -- see that callback's
      -- own comment for why. The Items/Party screen path below is
      -- untouched, still polling exactly as before.
      lx, ly = C.editStickX or 0, C.editStickY or 0
    else
      for _, j in ipairs(love.joystick.getJoysticks()) do
        if j:isGamepad() then
          local jx, jy = j:getGamepadAxis("leftx"), j:getGamepadAxis("lefty")
          if math.abs(jx) > 0.15 or math.abs(jy) > 0.15 then lx, ly = jx, jy; break end
          if lx == 0 and ly == 0 then lx, ly = jx, jy end   -- fall back to the first pad if none are pushed
        end
      end
    end
    local DEADZONE = 0.22
    local mag = math.sqrt(lx*lx + ly*ly)
    if mag <= DEADZONE then return end
    C.stickActive = true
    -- v2.9.5 bugfix, direct report ("stuck on the X button, won't move
    -- with the control stick"): originally added because C.mx/C.my (see
    -- C.drawScreen) checked C.touchScreenPos BEFORE C.stickActive, so a
    -- real finger/palm resting on the touchscreen (Odin has one) while
    -- using the physical stick would win every frame with nothing to ever
    -- hand priority back; genuinely pushing the stick past its deadzone
    -- reclaimed it. A later direct report ("I want it independent to
    -- control stick input") showed that one-time reclaim wasn't enough --
    -- any NEW touch after this point still won again -- so C.drawScreen's
    -- priority itself now checks C.stickActive first and stick wins
    -- outright for as long as this screen session's C.stickActive stays
    -- true. This clear is now a secondary backstop, for the OTHER places
    -- that read C.touchScreenPos ~= nil as a plain "is a finger currently
    -- down" signal (e.g. drag-continuation checks), not the cursor-position
    -- priority itself anymore. Screens only -- edit mode's own stick-cursor
    -- path (C.editStickX/Y above) never reads C.touchScreenPos at all,
    -- consistent with the user's own report that edit mode was unaffected.
    if C.screen then C.touchScreenPos = nil end
    local nx, ny = lx / mag, ly / mag                              -- unit direction
    local pull = math.min(1, (mag - DEADZONE) / (1 - DEADZONE))    -- 0..1 eased past the dead-zone
    local W, H = love.graphics.getDimensions()
    local speed = H * 0.9   -- design: ~1s to cross the window height at full deflection
    C.vcx = math.max(0, math.min(W, (C.vcx or W/2) + nx * pull * speed * (dt or 0)))
    C.vcy = math.max(0, math.min(H, (C.vcy or H/2) + ny * pull * speed * (dt or 0)))
  end
  C.onScreenWheel = function(_, dy)
    if C.screen == "party" then
      local nbox = (C.Boxes and C.Boxes.COUNT) or 12
      if dy > 0 then C.boxView = (C.boxView or 1) > 1 and C.boxView-1 or nbox
      elseif dy < 0 then C.boxView = (C.boxView or 1) < nbox and C.boxView+1 or 1 end
      return
    end
    if C.screen ~= "items" then return end
    if C.held and C.held.max and C.held.max > 1 then     -- adjust the carried quantity
      C.held.qty = math.max(1, math.min(C.held.max, C.held.qty + (dy > 0 and 1 or -1)))
      return
    end
    local side = (C.iLayout.bag and C.mx <= C.iLayout.bag.x + C.iLayout.bag.w) and "bag" or "pc"
    local L = C.iLayout[side]
    if L then
      local maxScroll = math.max(0, (L.contentH or 0) - L.h)
      C.iscroll[side] = math.max(0, math.min(maxScroll, (C.iscroll[side] or 0) - dy * 64))
    end
  end
  -- Controller equivalent of the mouse wheel on the Items screen. A D-pad
  -- press has no cursor position to hover a side with, so it acts on
  -- whichever side is currently focused (C.iFocus, toggled by D-pad left/right).
  --
  -- Up/down always moves a row cursor (C.iCursor) through the focused side's
  -- list, one item at a time, auto-scrolling the panel to keep the
  -- highlighted row in view -- this includes the side a held item came from,
  -- which is what lets the D-pad reorder in place instead of only
  -- transferring to the other side. Quantity for a held stack is adjusted
  -- with the L2/R2 triggers instead (C.onPadTrigger), so up/down stays free
  -- for positioning even a multi-item stack. Press A (C.onPadSelect) to pick
  -- up the highlighted item, then D-pad to wherever it should land --
  -- including one slot past the last item, to drop it at the end of the
  -- list -- and A again to drop it there.
  C.onPadScroll = function(dy)
    if C.screen ~= "items" then return end
    local side = C.iFocus or "bag"
    -- Marks the row cursor highlight (see isCursor in itemPanel) visible
    -- for this side -- shown for pad AND touch scroll-arrow navigation
    -- alike. Cleared by an unrecognized/outside tap in onScreenMouse below,
    -- same trigger point that cancels a held item.
    C.iCursorVis[side] = true
    -- "Save order" sits in the Bag's header, above the item list, and is
    -- only reachable by pad while browsing (nothing held, since a held item
    -- has its own drop-target meaning for this side). D-pad up from the top
    -- row selects it; down from it drops back into the list at row 1.
    --
    -- v2.9.5: the Select/Transfer/Discard row (C.headerFocus, both sides)
    -- now sits BETWEEN the list and Save-order in this same up/down chain
    -- -- [list] <-> [Select row] <-> (bag only) [Save order] -- rather than
    -- replacing iOnSave outright, so Save-order's own already-working
    -- behavior is untouched, just one step further up than before on Bag.
    if not C.held then
      if side == "bag" and C.iOnSave then
        if dy < 0 then   -- down from Save-order: land on the LAST select-row button, not straight past it to the list
          C.iOnSave = false
          C.headerFocus.bag = #C.headerButtons("bag")
        end
        return   -- up while already on Save-order: nothing further up
      end
      if C.headerFocus[side] > 0 then
        if dy > 0 then
          if side == "bag" then C.headerFocus.bag = 0; C.iOnSave = true end   -- chain up into Save-order; pc has nothing further up
        else
          C.headerFocus[side] = 0; C.iCursor[side] = 1   -- down: back to the list
        end
        return
      end
      if dy > 0 and (C.iCursor[side] or 1) <= 1 then
        C.headerFocus[side] = 1   -- up from the list's top row: enter the Select row
        return
      end
    end
    local rows = C.visibleRows(side)
    if #rows == 0 then return end
    -- While held, the cursor can go one past the last row to mean "drop at
    -- the end of the list" -- true for either side now.
    local maxCur = C.held and (#rows + 1) or #rows
    local cur = math.max(1, math.min(maxCur, (C.iCursor[side] or 1) + (dy > 0 and -1 or 1)))
    C.iCursor[side] = cur
    local L = C.iLayout[side]
    if L then
      local off, ih = itemContentOffset(side, cur)
      local scroll = C.iscroll[side] or 0
      if off < scroll then scroll = off
      elseif off + ih > scroll + L.h then scroll = off + ih - L.h end
      local maxScroll = math.max(0, (L.contentH or 0) - L.h)
      C.iscroll[side] = math.max(0, math.min(maxScroll, scroll))
    end
  end
  -- Touch page arrows: jump the cursor by however many item rows are
  -- currently visible in the panel (listH / ITEM_ROW_H), same direction
  -- convention as C.onPadScroll (dir > 0 = up). Clamps to the first/last
  -- row if fewer rows remain than a full page, same as C.onPadScroll's own
  -- clamp -- it just reuses that clamp with a bigger step instead of ±1.
  -- Touch-only (no D-pad equivalent yet): always takes an explicit side
  -- rather than falling back to C.iFocus, since it's driven from a tap on
  -- one specific side's arrow stack.
  --
  -- Deliberately does NOT set C.iCursorVis -- unlike the scroll arrows and
  -- D-pad, a page jump shouldn't flash the gold row-highlight on whatever
  -- item the cursor lands on; it's just moving the viewport.
  --
  -- Scroll is driven directly by a full listH jump, NOT by reusing
  -- C.onPadScroll's "scroll just enough to reveal the cursor row" logic --
  -- that logic is right for a single-row D-pad step, but for a page jump
  -- it produced a visible-only-by-one-row scroll whenever the old cursor
  -- was already sitting flush against the edge of the visible list (e.g.
  -- right after scrolling to the very top/bottom), since revealing the new
  -- cursor only took a small nudge from there. The cursor itself was
  -- jumping a full page correctly the whole time -- only the viewport
  -- looked stuck on that first press.
  C.onPadPage = function(dir, side)
    if C.screen ~= "items" then return end
    C.iFocus = side
    local rows = C.visibleRows(side)
    if #rows == 0 then return end
    local L = C.iLayout[side]
    local step = (L and L.h) and math.max(1, math.floor(L.h / ITEM_ROW_H)) or 1
    local maxCur = C.held and (#rows + 1) or #rows
    C.iCursor[side] = math.max(1, math.min(maxCur, (C.iCursor[side] or 1) + (dir > 0 and -step or step)))
    if L then
      local maxScroll = math.max(0, (L.contentH or 0) - L.h)
      local scroll = (C.iscroll[side] or 0) + (dir > 0 and -L.h or L.h)
      C.iscroll[side] = math.max(0, math.min(maxScroll, scroll))
    end
  end
  -- L2/R2 triggers on the Items screen: adjust the quantity of a held stack,
  -- same step as the mouse wheel. Split out from D-pad up/down so that stays
  -- free to move the cursor -- and choose a drop position -- even while
  -- carrying more than one of an item. When nothing qty-adjustable is held,
  -- the triggers fall through to paging the currently-focused side instead
  -- (same C.onPadPage the touch double-chevron arrows already drive) --
  -- gives L2/R2 a use on the Items screen even with empty hands, and the two
  -- behaviors can't collide since a stack is only ever held or not.
  C.onPadTrigger = function(dir)
    if C.screen ~= "items" then return end
    if C.held and C.held.max and C.held.max > 1 then
      -- Quantity adjustment uses the opposite mapping from paging (dir
      -- negated): L2 decreases the carried amount, R2 increases it --
      -- swapped relative to L2/R2's up/down sense everywhere else on this
      -- screen (page-up/page-down), per specific request for this case only.
      C.held.qty = math.max(1, math.min(C.held.max, C.held.qty - dir))
      return
    end
    if C.onPadPage then C.onPadPage(dir, C.iFocus or "bag") end
  end
  -- Hold-to-repeat for the Items screen: shared ramp (slow start, faster
  -- after a few rows) used by both the physical D-pad (C.padScrollHold) and
  -- the touch scroll arrows (C.touchArrowHold). The initial single step on
  -- press/tap already happens at the call site before this state is set --
  -- this only drives the *repeats* while still held/pressed.
  local SCROLL_HOLD_DELAY = 0.40   -- seconds held before auto-repeat starts
  local function scrollHoldInterval(n)   -- n = repeats already fired
    if n < 3 then return 0.22
    elseif n < 8 then return 0.11
    else return 0.05 end
  end
  -- D-pad always moves the cursor/drop-target (matches a single press --
  -- L2/R2 are the separate, dedicated qty control on the pad, so holding
  -- D-pad never changes meaning).
  local function advancePadScrollHold(dt)
    local h = C.padScrollHold
    if not h or C.screen ~= "items" then return end
    h.t = h.t + dt
    local delay = h.n == 0 and SCROLL_HOLD_DELAY or scrollHoldInterval(h.n)
    if h.t >= delay then
      h.t = 0; h.n = h.n + 1
      if C.onPadScroll then C.onPadScroll(h.dir) end
    end
  end
  -- Touch arrows now come in two flavors, each single-purpose: the per-side
  -- scroll pairs (bag/PC) always move the cursor, and the quantity stepper
  -- next to the held-item bubble always adjusts qty -- no more re-reading
  -- C.held to decide which one an arrow means, since with two scroll pairs
  -- on screen at once that would be ambiguous.
  local function advanceTouchArrowHold(dt)
    local h = C.touchArrowHold
    if not h or C.screen ~= "items" then return end
    h.t = h.t + dt
    local delay = h.n == 0 and SCROLL_HOLD_DELAY or scrollHoldInterval(h.n)
    if h.t >= delay then
      h.t = 0; h.n = h.n + 1
      if h.action == "qty" then
        if C.held and C.held.max and C.held.max > 1 then
          if C.onPadTrigger then C.onPadTrigger(h.dir) end
        else
          C.touchArrowHold = nil   -- item dropped/changed mid-hold -- stop
        end
      elseif h.action == "page" then
        if C.onPadPage then C.onPadPage(h.dir, h.side) end
      else   -- "scroll"
        if h.side then C.iFocus = h.side end
        if C.onPadScroll then C.onPadScroll(h.dir) end
      end
    end
  end
  C.updateScrollHold = function(dt)
    advancePadScrollHold(dt)
    advanceTouchArrowHold(dt)
  end
  -- A button on the Items screen: with nothing held, picks up the row under
  -- the D-pad cursor on the focused side (armed immediately, no drag
  -- needed). With something held, drops it at the cursor on whichever side
  -- is currently focused -- the source side included, so this is also how
  -- the D-pad reorders within a side: move the cursor to the target row, A
  -- to drop it there (landing back on its own row is a no-op). B/Esc cancels
  -- a pending pickup instead of A.
  C.onPadSelect = function()
    if C.screen ~= "items" then return end
    local side = C.iFocus or "bag"
    -- v2.9.5: D-pad+A while header-focused (C.headerFocus, see
    -- C.onPadScroll) activates whichever header button is focused,
    -- instead of anything list/row-related below -- checked first, since
    -- C.iCursor[side] isn't even the relevant target in this state.
    if C.headerFocus[side] > 0 then
      local btns = C.headerButtons(side)
      -- Clamped, same reasoning as C.onPadSelectBox's own comment.
      C.activateHeaderButton(btns[math.min(C.headerFocus[side], #btns)], side)
      return
    end
    -- v2.9.5 bugfix, direct report: D-pad+A (as opposed to stick-cursor+A,
    -- which already routes through onScreenMouse and was already correct)
    -- fell straight through to the normal pick-up-item logic below even
    -- while select mode was active, since this D-pad path is a completely
    -- separate function onScreenMouse's own select-mode check never
    -- covered. Toggle the D-pad-highlighted row's checkbox instead.
    if C.selectMode then
      local rows = C.visibleRows(side)
      local r = rows[C.iCursor[side] or 1]
      if r and not (side == "bag" and isBadgeItem(r.id)) then
        local sel = C.multiSelect[side]
        if sel[r.id] then sel[r.id] = nil else sel[r.id] = true end
      end
      return
    end
    if not C.held then
      if side == "bag" and C.iOnSave then
        if isDirty("bag") then applyOrder("bag") end
        return
      end
      local rows = C.visibleRows(side)
      local r = rows[C.iCursor[side] or 1]
      if not r then return end
      if side == "bag" and isBadgeItem(r.id) then return end
      local full = invOf(side)[r.id] or 1
      C.held = { from = side, id = r.id, qty = full, max = full, mode = "armed", pad = true, downX = 0, downY = 0 }
    elseif C.held.mode == "armed" then
      local rows = C.visibleRows(side)
      local beforeId = rows[C.iCursor[side] or 1] and rows[C.iCursor[side] or 1].id or nil
      local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, side, beforeId)
      if not ok then C.setStatus(err) end
      C.held = nil
    end
  end
  local function topHit(dx, dy)
    for i = #C.hit, 1, -1 do
      local r = C.hit[i]
      if dx >= r.x and dx <= r.x+r.w and dy >= r.y and dy <= r.y+r.h then return r.tag, r.data end
    end
  end
  -- Raw window-pixel zone check for the persistent nav-cycle/icon buttons
  -- (percent-of-window, same convention as TOUCH_NAV_LEFT/RIGHT and
  -- TOUCH_ICON_OVERLAY/ITEMS/PARTY above) -- shared between onScreenMouse's
  -- held-item guard and the touchpressed wrapper's own, so both sides of
  -- the touchpressed/mousepressed race agree on what counts as "one of
  -- those buttons".
  local function inNavOrIconZone(rawX, rawY)
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return false end
    local zx, zy = rawX / ww, rawY / wh
    local function inZone(z) return zx >= z.x1 and zx <= z.x2 and zy >= z.y1 and zy <= z.y2 end
    if mod.options:get("touch_nav_buttons") and (inZone(TOUCH_NAV_LEFT) or inZone(TOUCH_NAV_RIGHT)) then return true end
    if mod.options:get("touch_icon_buttons") and (inZone(TOUCH_ICON_OVERLAY) or inZone(TOUCH_ICON_ITEMS) or inZone(TOUCH_ICON_PARTY)) then return true end
    return false
  end
  C.onScreenMouse = function(px, py, button)   -- mouse DOWN
    if not C.screen then return end
    s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
    -- v2.9.5: while the confirm popup is up, it's the ONLY thing that can
    -- receive input -- true modal, not just an overlay. Checked before
    -- even the right-click-cancel below. Tapping the dimmed backdrop
    -- (anything that isn't literally the Cancel/Confirm button) cancels,
    -- same as most real confirm dialogs.
    if C.confirmPopup then
      local dx0, dy0 = px/s, py/s
      local tag0 = topHit(dx0, dy0)
      if tag0 == "popupconfirm" then
        local p = C.confirmPopup; C.confirmPopup = nil
        if p.tag == "release" then C.executeMultiRelease()
        else C.executeMultiToss(p.tag:match("^toss:(.+)$")) end
      else
        C.confirmPopup = nil
      end
      return
    end
    -- v2.9.5: search grid, same true-modal shape as C.confirmPopup above
    -- (tapping the dimmed backdrop -- anything not a real cell -- closes
    -- it, same as tapping outside a confirm dialog).
    if C.searchGrid then
      local dx0, dy0 = px/s, py/s
      local tag0, data0 = topHit(dx0, dy0)
      if tag0 == "searchletter" then C.searchAppendLetter(data0)
      elseif tag0 == "searchdel" then C.searchBackspace()
      elseif tag0 == "searchdone" then C.closeSearchGrid()
      else C.closeSearchGrid() end
      return
    end
    if button == 2 then C.held = nil; return end
    -- Android fires both a raw touchpressed and a simulated mousepressed
    -- for the same tap. The nav/icon buttons' own held-item guard lives in
    -- the touchpressed wrapper, keyed off C.held -- but if THIS handler ran
    -- first and treated a tap over one of those buttons as "unrecognized,
    -- cancel the hold" (the generic armed-placement fallback below), C.held
    -- would already be nil by the time touchpressed's guard checks it,
    -- waving the action through. So: while something's held, a tap in one
    -- of those zones is a complete no-op here -- don't cancel, don't do
    -- anything -- so C.held survives for that guard to actually see.
    if C.held and inNavOrIconZone(px, py) then return end
    local dx, dy = px/s, py/s
    local tag, data = topHit(dx, dy)
    if tag == "close" then C.closeScreen(); return end
    if tag == "undo" then C.held = nil; if C.doUndo then C.doUndo() end; return end   -- on-screen Undo button (both screens)
    -- v2.9.5: grabs the portrait Party list's new scrollbar (see
    -- partyPanel's own comment) -- starts the drag here, on press;
    -- partyPanel itself continues it every frame while held (see its own
    -- comment for why) and C.onScreenRelease below clears it.
    if tag == "pscrollbar" and C.pScrollTrack then
      C.pScrollDrag = { startY = C.my, startScroll = C.pScrollY or 0, thumbH = C.pScrollTrack.thumbH }
      return
    end
    -- v2.9.5: the three scrollbars added alongside it, all identical in
    -- shape -- grab on press here, the owning panel continues the drag
    -- every frame it draws, C.onScreenRelease clears it. `data` carries
    -- the Bag/PC side for the item lists and the screen key for the page.
    if tag == "iscrollbar" and C.iScrollTrack and C.iScrollTrack[data] then
      C.iScrollDrag = { side = data, startY = C.my, startScroll = (C.iscroll and C.iscroll[data]) or 0, thumbH = C.iScrollTrack[data].thumbH }
      return
    end
    if tag == "bscrollbar" and C.bScrollTrack then
      C.bScrollDrag = { startY = C.my, startScroll = C.bScrollY or 0, thumbH = C.bScrollTrack.thumbH }
      return
    end
    if tag == "pagescrollbar" and C.pageTrack then
      C.pageScrollDrag = { key = data, startY = C.my, startScroll = (C.pageScroll and C.pageScroll[data]) or 0, thumbH = C.pageTrack.thumbH }
      return
    end
    -- Default to hiding the row cursor highlight on any tap -- the
    -- scrollarrow branch right below re-shows it (via C.onPadScroll) for
    -- whichever side it's for if that's what was actually tapped. Anything
    -- else -- a row, a sort button, or genuinely nothing -- leaves it
    -- cleared, same "outside tap" trigger a held item cancels on.
    if C.screen == "items" then C.iCursorVis.bag, C.iCursorVis.pc = false, false end
    if tag == "scrollarrow" then
      C.iFocus = data.side
      C.touchArrowHold = { dir = data.dir, t = 0, n = 0, action = "scroll", side = data.side }
      if C.onPadScroll then C.onPadScroll(data.dir) end
      return
    end
    if tag == "pagearrow" then
      C.touchArrowHold = { dir = data.dir, t = 0, n = 0, action = "page", side = data.side }
      if C.onPadPage then C.onPadPage(data.dir, data.side) end
      return
    end
    if tag == "qtyarrow" then
      C.touchArrowHold = { dir = data.dir, t = 0, n = 0, action = "qty" }
      if C.onPadTrigger then C.onPadTrigger(data.dir) end
      return
    end
    -- v2.9.5: multi-select mode toggle + bulk-action buttons, direct
    -- request. Handled before either screen's normal grab/pick-up logic
    -- so the two input modes can never mix (a tap while selecting always
    -- means "toggle selection," never "start a drag").
    if tag == "selectmode" then C.held = nil; C.selectMode = not C.selectMode
      if not C.selectMode then C.multiSelect.bag, C.multiSelect.pc, C.multiSelectBox = {}, {}, {} end
      C.confirmPopup = nil; return end
    if tag == "search" then C.held = nil; C.openSearchGrid(data); return end
    if tag == "searchbox" then C.held = nil; C.openSearchGrid("box"); return end
    if tag == "multitransfer" then C.held = nil; C.doMultiTransfer(data); return end
    if tag == "multitoss"     then C.held = nil; C.doMultiToss(data); return end
    if tag == "multimovebox"  then C.held = nil; C.doMultiMoveBox(); return end
    if tag == "multirelease"  then C.held = nil; C.doMultiRelease(); return end
    if C.screen == "party" then
      local tab = railAt(dx, dy)
      if tab then C.boxView = tab.box; return end          -- click a box tab -> view it, unaffected by select mode
      local slot = monSlotAt(dx, dy)
      if C.selectMode then
        -- v2.9.5: arm the marquee-drag, same deferred tap-vs-drag split as
        -- the Bag/PC panels' own (see that comment). Starts from ANY point
        -- in the box grid, occupied slot or empty -- monSlotAt still
        -- matches an empty slot (mon just comes back nil), so a drag can
        -- begin from empty space same as it can in the item lists. Party
        -- slots are excluded, matching C.doRelease's "party never
        -- selectable" scope.
        if slot and slot.loc == "box" then C.marqueeStart = { x = dx, y = dy, side = "box" } end
        return
      end
      if C.held and C.held.mode == "armed" then          -- placing an armed mon
        local tgt = dropTargetMon(dx, dy)
        if tgt then local ok, err = doMonPlace(C.held.src, tgt); if not ok and err then C.setStatus(err) end end
        C.held = nil; return
      end
      if slot and slot.mon then                            -- grab a Pokemon
        C.held = { mon = slot.mon, src = { loc = slot.loc, box = slot.box, index = slot.index },
                   mode = "pending", downX = dx, downY = dy }
        return
      end
      C.held = nil
      return
    end
    -- ITEMS ------------------------------------------------------------
    if tag == "sort"  then C.held = nil; sortSide(data.side, data.mode); return end
    if tag == "apply" then C.held = nil; applyOrder(data); return end
    if C.selectMode then
      -- v2.9.5: arm the marquee-drag instead of toggling immediately --
      -- the tap-vs-drag decision now happens on RELEASE (see
      -- onScreenRelease), exactly like C.held's own pending->armed/drag
      -- split just below already does for a normal pickup. A tap that
      -- never moves far still resolves to the exact same single-row
      -- toggle as before (see onScreenRelease); this only adds what
      -- happens once you drag past the threshold first.
      local side = (tag == "itemrow" and data.side) or dropTarget(dx, dy)
      if side then C.marqueeStart = { x = dx, y = dy, side = side } end
      return
    end
    if C.held and C.held.mode == "armed" then     -- placing an armed item
      local tside, tidx = dropTarget(dx, dy)
      if tside then local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, tside, tidx); if not ok then C.setStatus(err) end end
      C.held = nil; return
    end
    if tag == "itemrow" and not (data.side == "bag" and isBadgeItem(data.id)) then
      local full = invOf(data.side)[data.id] or 1
      C.held = { from = data.side, id = data.id, qty = full, max = full, mode = "pending", downX = dx, downY = dy }
      return
    end
    -- v2.9.5 (Gen 2 category reordering): press-and-drag a pocket header.
    -- No "armed"/tap-then-tap stage like items have -- see C.heldHeader's
    -- own init comment for why a plain drag covers this fine on its own.
    if tag == "headerrow" then
      C.heldHeader = { side = data.side, cat = data.cat, mode = "pending", downX = dx, downY = dy }
      return
    end
    C.held = nil
  end
  C.onScreenRelease = function(px, py, button)   -- mouse UP
    if button == 1 then C.touchArrowHold = nil end
    C.pScrollDrag = nil   -- v2.9.5: release always ends a party-scrollbar drag, matching every other release-clears-drag-state in this file
    C.iScrollDrag, C.bScrollDrag, C.pageScrollDrag = nil, nil, nil   -- v2.9.5: same for the Bag/PC list, Boxes grid and portrait page scrollbars
    -- v2.9.5: resolve the marquee-drag (or a plain tap if it never got
    -- promoted past the distance threshold) -- checked FIRST, ahead of
    -- the C.held-gated guard right below, since C.held is never set
    -- while a marquee is in progress (select mode and holding an item
    -- are already mutually exclusive) and would otherwise make that
    -- guard return before this ever ran.
    if C.screen and C.marqueeStart then
      s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
      local dx, dy = px/s, py/s
      local m = C.marquee
      if m then
        local minX, maxX = math.min(m.x0, m.x1), math.max(m.x0, m.x1)
        local minY, maxY = math.min(m.y0, m.y1), math.max(m.y0, m.y1)
        if m.side == "box" then
          for _, entry in ipairs(C.pLayout.grid or {}) do
            if entry.mon and rectsOverlap(entry.x, entry.y, entry.x+entry.w, entry.y+entry.h, minX, minY, maxX, maxY) then
              C.multiSelectBox[C.pLayout.curBox .. ":" .. entry.index] = { box = C.pLayout.curBox, index = entry.index }
            end
          end
        else
          local L = C.iLayout[m.side]
          if L then
            for _, entry in ipairs(L.items or {}) do
              if not (m.side == "bag" and isBadgeItem(entry.id))
                  and rectsOverlap(L.x, entry.y, L.x+L.w, entry.y+entry.h, minX, minY, maxX, maxY) then
                C.multiSelect[m.side][entry.id] = true
              end
            end
          end
        end
      else
        -- never promoted -- resolve as the exact same single tap-toggle a
        -- plain click always had, just decided here (on release) instead
        -- of on press, same as C.held's own pending stage already defers
        -- its tap-vs-drag decision to release.
        local tag0, data0 = topHit(dx, dy)
        if tag0 == "itemrow" and not (data0.side == "bag" and isBadgeItem(data0.id)) then
          local sel = C.multiSelect[data0.side]
          if sel[data0.id] then sel[data0.id] = nil else sel[data0.id] = true end
        elseif C.screen == "party" then
          local slot = monSlotAt(dx, dy)
          if slot and slot.loc == "box" and slot.mon then
            local key = slot.box .. ":" .. slot.index
            if C.multiSelectBox[key] then C.multiSelectBox[key] = nil
            else C.multiSelectBox[key] = { box = slot.box, index = slot.index } end
          end
        end
      end
      C.marqueeStart, C.marquee = nil, nil
      return
    end
    -- v2.9.5 (Gen 2 category reordering): resolve a header drag, checked
    -- here for the same reason the marquee block above runs before the
    -- C.held-gated guard below -- C.heldHeader is a separate variable, so
    -- that guard would skip this entirely whenever C.held happens to be nil.
    if C.heldHeader then
      if C.heldHeader.mode == "drag" then
        s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
        local dx, dy = px/s, py/s
        local beforeCat, valid = headerDropTarget(C.heldHeader.side, dx, dy)
        if valid then C.reorderPocketOrder(C.heldHeader.cat, beforeCat) end
      end
      C.heldHeader = nil
      return
    end
    if not C.screen or not C.held or button ~= 1 then return end
    s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
    local dx, dy = px/s, py/s
    if C.screen == "items" then
      if C.held.mode == "drag" then
        local tside, bId = dropTarget(dx, dy)
        if tside then local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, tside, bId); if not ok then C.setStatus(err) end end
        C.held = nil
      elseif C.held.mode == "pending" then C.held.mode = "armed" end
    elseif C.screen == "party" then
      if C.held.mode == "drag" then
        local tgt = dropTargetMon(dx, dy)
        if tgt then local ok, err = doMonPlace(C.held.src, tgt); if not ok and err then C.setStatus(err) end end
        C.held = nil
      elseif C.held.mode == "pending" then C.held.mode = "armed" end
    end
  end
  -- v2.9.5: real starts-with search, replacing alphabet jump-to-letter --
  -- direct request ("cycle through letters isn't good enough"). Modal
  -- letter-grid overlay, same "block everything else while open" shape
  -- as C.confirmPopup just below (see its own comment for the reasoning)
  -- -- see the C.searchGrid checks alongside the C.confirmPopup ones at
  -- the top of onScreenMouse/padPressed/onScreenKey. Mirrors the vanilla
  -- Gen 2 naming screen's own A-I/J-R/S-Z grid (src/ui/gen2/
  -- NamingScreen.lua) deliberately -- confirmed the native mobile OS
  -- keyboard isn't reachable from mod space (love.keyboard.setTextInput
  -- exists in the engine's src/ui/kit/Kit.lua, but that module is
  -- launcher/save-editor tooling outside the mod sandbox, not a mod
  -- require), and the vanilla game's own text entry doesn't use it
  -- either -- so a drawn grid is both the only real option and the
  -- genre-consistent one, working identically for touch (tap) and
  -- gamepad (D-pad+A) with one widget. PC keyboard typing is a second,
  -- independent input path onto the same query -- see
  -- C.SEARCH_KEY_POLL/C.pollSearchKeys below.
  C.openSearchGrid = function(target)
    C.searchGrid = { target = target, cursor = 1 }
  end
  C.closeSearchGrid = function()
    C.searchGrid = nil
  end
  -- Boxes-only: search spans every box (there's no per-box query), so
  -- typing/selecting a letter needs to jump C.boxView to a box that
  -- actually has a match whenever the CURRENT box has none -- otherwise
  -- dimming every slot in the visible box to "no match" with nothing to
  -- look at would read as broken, not filtered. Mirrors the old
  -- C.jumpLetterBox's own box-then-slot scan order.
  C.searchJumpBoxIfNeeded = function()
    local q = C.searchQueryBox
    if q == "" then return end
    local boxes = boxesEnsure()
    local dPoke = C.game.data.pokemon
    local function boxHasMatch(b)
      local arr = boxes[b] or {}
      for i = 1, BCAP do
        local mon = arr[i]
        if mon then
          local def = dPoke[mon.species]
          local name = mon.nickname or (def and def.name) or tostring(mon.species)
          if C.searchMatch(name, q) then return true end
        end
      end
      return false
    end
    local cur = C.boxView or 1
    if boxHasMatch(cur) then return end
    for b = 1, NBOX do
      if boxHasMatch(b) then C.boxView = b; return end
    end
  end
  C.searchAppendLetter = function(ch)
    local g = C.searchGrid; if not g then return end
    if g.target == "box" then
      C.searchQueryBox = C.searchQueryBox .. ch
      C.searchJumpBoxIfNeeded()
    else
      C.searchQuery[g.target] = C.searchQuery[g.target] .. ch
      C.iCursor[g.target] = 1; C.iscroll[g.target] = 0
    end
  end
  C.searchBackspace = function()
    local g = C.searchGrid; if not g then return end
    if g.target == "box" then
      C.searchQueryBox = C.searchQueryBox:sub(1, -2)
      C.searchJumpBoxIfNeeded()
    else
      C.searchQuery[g.target] = C.searchQuery[g.target]:sub(1, -2)
    end
  end
  -- D-pad movement over the grid: nearest-cell-in-the-target-row by X
  -- position for up/down (handles the grid's irregular row widths -- 9/
  -- 9/8 letters then a 2-wide DEL/DONE row -- without hardcoded per-row
  -- column math), same-row cyclic step for left/right. Reads
  -- C.searchCellPos, the flat {x,y,idx} list C.drawSearchGrid rebuilds
  -- every time it draws (same "positions recorded at draw time, read
  -- back on input" shape C.hit/region/topHit already use elsewhere in
  -- this file, just a small local list instead of the shared one, since
  -- this grid is the only thing on screen while it's open).
  C.searchNav = function(dir)
    local g = C.searchGrid; local cells = C.searchCellPos
    if not g or not cells or #cells == 0 then return end
    local curCell
    for _, c in ipairs(cells) do if c.idx == g.cursor then curCell = c; break end end
    if not curCell then g.cursor = cells[1].idx; return end
    if dir == "left" or dir == "right" then
      local d = dir == "left" and -1 or 1
      local row = {}
      for _, c in ipairs(cells) do if c.y == curCell.y then row[#row+1] = c end end
      table.sort(row, function(a, b) return a.x < b.x end)
      local pos = 1
      for i, c in ipairs(row) do if c.idx == g.cursor then pos = i; break end end
      pos = ((pos - 1 + d) % #row) + 1
      g.cursor = row[pos].idx
    else
      local d = dir == "up" and -1 or 1
      local ys = {}
      for _, c in ipairs(cells) do
        local found = false
        for _, y in ipairs(ys) do if y == c.y then found = true; break end end
        if not found then ys[#ys+1] = c.y end
      end
      table.sort(ys)
      local curRow = 1
      for i, y in ipairs(ys) do if y == curCell.y then curRow = i; break end end
      local targetRow = curRow + d
      if targetRow < 1 or targetRow > #ys then return end
      local targetY = ys[targetRow]
      local best, bestDist
      for _, c in ipairs(cells) do
        if c.y == targetY then
          local dist = math.abs(c.x - curCell.x)
          if not best or dist < bestDist then best, bestDist = c, dist end
        end
      end
      if best then g.cursor = best.idx end
    end
  end
  C.drawSearchGrid = function(fullW, fullH)
    local g = C.searchGrid; if not g then return end
    setc({0, 0, 0}, 0.6); love.graphics.rectangle("fill", 0, 0, fullW*s, fullH*s)
    local ROWS = { "ABCDEFGHI", "JKLMNOPQR", "STUVWXYZ" }
    local boxW, boxH = 360, 250
    local bx, by = (fullW-boxW)/2, (fullH-boxH)/2
    setc(COL.panel, 0.98); rrect("fill", bx, by, boxW, boxH, 14)
    love.graphics.setLineWidth(math.max(1, s)); setc(COL.gold, 0.7); rrect("line", bx, by, boxW, boxH, 14)
    local q = (g.target == "box") and C.searchQueryBox or C.searchQuery[g.target]
    txt("Search: " .. q .. "_", bx+20, by+16, 18, COL.text)
    local cell, gx0, gy0 = 34, bx+20, by+50
    C.searchCellPos = {}
    local idx = 0
    for r, row in ipairs(ROWS) do
      for i = 1, #row do
        idx = idx + 1
        local ch = row:sub(i, i)
        local cx, cy = gx0 + (i-1)*cell, gy0 + (r-1)*cell
        local sel = g.cursor == idx
        local hov = region(cx, cy, cell-4, cell-4, "searchletter", ch)
        setc(sel and COL.gold or (hov and COL.hi or COL.border), sel and 0.9 or (hov and 0.4 or 0.5))
        rrect(sel and "fill" or "line", cx, cy, cell-4, cell-4, 6)
        txt(ch, cx+(cell-4)/2, cy+8, 16, sel and COL.panel or COL.text, "center")
        C.searchCellPos[#C.searchCellPos+1] = { x = cx, y = cy, idx = idx, ch = ch }
      end
    end
    local delIdx, doneIdx = idx + 1, idx + 2
    local by2 = gy0 + 3*cell + 10
    local bw2 = (boxW - 40 - 10) / 2
    local delSel, doneSel = g.cursor == delIdx, g.cursor == doneIdx
    local delHov = region(gx0, by2, bw2, 30, "searchdel", nil)
    setc(delSel and COL.gold or COL.panel, delSel and 0.9 or (delHov and 0.75 or 0.6))
    rrect("fill", gx0, by2, bw2, 30, 6)
    txt("DEL", gx0+bw2/2, by2+7, 14, delSel and COL.panel or COL.dim, "center")
    C.searchCellPos[#C.searchCellPos+1] = { x = gx0, y = by2, idx = delIdx, action = "del" }
    local dx2 = gx0 + bw2 + 10
    local doneHov = region(dx2, by2, bw2, 30, "searchdone", nil)
    setc(doneSel and COL.gold or COL.panel, doneSel and 0.9 or (doneHov and 0.75 or 0.6))
    rrect("fill", dx2, by2, bw2, 30, 6)
    txt("DONE", dx2+bw2/2, by2+7, 14, doneSel and COL.panel or COL.dim, "center")
    C.searchCellPos[#C.searchCellPos+1] = { x = dx2, y = by2, idx = doneIdx, action = "done" }
  end
  -- Gamepad A: activate whatever C.searchGrid.cursor currently points at
  -- -- a letter appends, DEL backspaces, DONE closes. Looks the cell up
  -- in C.searchCellPos (the same list C.drawSearchGrid just built) rather
  -- than recomputing the row layout separately, so gamepad activation can
  -- never disagree with what the highlighted cell visually is.
  C.searchActivate = function()
    local g = C.searchGrid; local cells = C.searchCellPos
    if not g or not cells then return end
    for _, c in ipairs(cells) do
      if c.idx == g.cursor then
        if c.action == "del" then C.searchBackspace()
        elseif c.action == "done" then C.closeSearchGrid()
        elseif c.ch then C.searchAppendLetter(c.ch) end
        return
      end
    end
  end
  -- v2.9.5: multi-select's destructive-action confirmation, direct
  -- request replacing the original tap-again-to-confirm pattern ("a pop
  -- up window basically asking if you're sure"). No modal/dialog system
  -- exists anywhere else in this file to reuse, so this is a genuinely
  -- new small one: a dimmed backdrop + centered box (see its call site in
  -- C.drawScreen). v2.9.5 bugfix: drawn BEFORE the stick cursor now (was
  -- after, which hid the cursor underneath it) -- see the cursor's own
  -- comment at its call site. Real modal behavior, not just an
  -- overlay -- see the C.confirmPopup checks at the top of
  -- onScreenMouse/padPressed/onScreenKey, which block every other input
  -- path on this screen while a popup is up, gamepad included (built in
  -- from the start this time -- see C.onPadSelect's own bugfix comment
  -- for the class of bug that comes from only covering mouse/touch).
  local function drawConfirmPopup(fullW, fullH)
    local p = C.confirmPopup; if not p then return end
    setc({0, 0, 0}, 0.6); love.graphics.rectangle("fill", 0, 0, fullW*s, fullH*s)
    local lines = wrapText(p.text, 18, 380)
    local boxW, lineH = 440, 26
    local boxH = 40 + #lines*lineH + 50
    local bx, by = (fullW-boxW)/2, (fullH-boxH)/2
    setc(COL.panel, 0.98); rrect("fill", bx, by, boxW, boxH, 14)
    love.graphics.setLineWidth(math.max(1, s)); setc(COL.lo, 0.7); rrect("line", bx, by, boxW, boxH, 14)
    local ty = by + 26
    for _, line in ipairs(lines) do
      txt(line, bx+boxW/2, ty, 18, COL.text, "center"); ty = ty + lineH
    end
    local byBtn = by + boxH - 40
    local confirmLbl = (p.tag == "release") and "Release" or "Discard"
    local cw1, cw2 = textW("Cancel", 15) + 32, textW(confirmLbl, 15) + 32
    local gap = 16
    local totalW = cw1 + cw2 + gap
    local cx1 = bx + (boxW-totalW)/2
    local cx2 = cx1 + cw1 + gap
    -- v2.9.5: D-pad focus, direct request ("remove the hint text and keep
    -- the function but add dpad/a select function as well") -- replaces
    -- the removed text hint as the way to SEE what A currently does.
    -- C.confirmPopup.focus defaults to "confirm" (see C.doMultiToss/
    -- doMultiRelease, where the popup is opened), preserving A's original
    -- direct-confirm behavior as the default; D-pad left/right (wired in
    -- onScreenKey) switches it, B still cancels directly regardless of
    -- focus, same as before. v2.9.5 bugfix, direct report: the stick/mouse
    -- cursor being visibly over a button didn't mean A would activate it --
    -- A only ever read .focus, and only D-pad ever wrote it. region()'s own
    -- return IS the hover state (same value listPanel's row-highlight
    -- already uses), so hovering either button now also moves focus onto
    -- it, same as D-pad; focus is left untouched while the cursor is over
    -- neither, so a D-pad-set focus survives a cursor just passing through.
    local hovCancel = region(cx1, byBtn, cw1, 34, "popupcancel")
    setc(COL.border, 0.35); rrect("fill", cx1, byBtn, cw1, 34, 8)
    txt("Cancel", cx1+cw1/2, byBtn+9, 15, COL.text, "center")
    if hovCancel then p.focus = "cancel" end
    if p.focus == "cancel" then
      love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95)
      rrect("line", cx1, byBtn, cw1, 34, 8); love.graphics.setLineWidth(1)
    end
    local hovConfirm = region(cx2, byBtn, cw2, 34, "popupconfirm")
    setc(COL.lo, 0.85); rrect("fill", cx2, byBtn, cw2, 34, 8)
    txt(confirmLbl, cx2+cw2/2, byBtn+9, 15, COL.panel, "center")
    if hovConfirm then p.focus = "confirm" end
    if p.focus ~= "cancel" then
      love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95)
      rrect("line", cx2, byBtn, cw2, 34, 8); love.graphics.setLineWidth(1)
    end
  end
  C.drawScreen = function()
    if not C.screen or not (C.game and C.game.save) then return end
    local W, H = love.graphics.getDimensions()
    s = (H / REF_H) * UI_SCALE_SCREEN
    local fullH = H / s     -- actual design-space canvas height at this scale (REF_H only when UI_SCALE_SCREEN = 1)
    C.hit = {}
    if C.stickActive then
      -- v2.9.5 bugfix, direct report: this used to check C.touchScreenPos
      -- FIRST, so once the stick cursor was active, any touch contact --
      -- including incidental palm/finger rest on the Odin's touchscreen,
      -- the exact scenario C.updateStickCursor's own touchScreenPos-clear
      -- below already has to guard against -- would hijack the cursor
      -- right back, every single frame. Direct request: stick input should
      -- be fully independent of touch once active, so stick now wins
      -- outright instead of losing to mere touch presence -- mirrors
      -- C.padPressed's own dpup/down/left/right branch, which already
      -- hands control FROM the stick back to D-pad on a genuine press.
      -- C.stickActive is screen-session-scoped (resets in C.openScreen/
      -- C.closeScreen and on Items<->Party switch), so touch naturally
      -- regains priority on the next screen open, not silently mid-session.
      C.mx, C.my = (C.vcx or W/2)/s, (C.vcy or H/2)/s
    elseif C.touchScreenPos then
      -- a finger is down on this screen (input.pointer touch branch): the held
      -- item / cursor tracks the touch, since LOVE's mouse position no longer
      -- follows a touch under the sandbox
      C.mx, C.my = C.touchScreenPos.px/s, C.touchScreenPos.py/s
    else
      local rmx, rmy = love.mouse.getPosition(); C.mx, C.my = rmx/s, rmy/s
    end
    -- promote a pending press to a drag once the cursor moves past a threshold
    if C.held and C.held.mode == "pending" and (love.mouse.isDown(1) or C.padDown) then
      local ddx, ddy = C.mx - C.held.downX, C.my - C.held.downY
      if ddx*ddx + ddy*ddy > 196 then C.held.mode = "drag" end
    end
    -- v2.9.5 (Gen 2 category reordering): same promotion, parallel state,
    -- for a header press. Released before ever crossing the threshold ->
    -- resolved as a no-op by C.onScreenRelease (mode stays "pending" there,
    -- which it now just clears without acting -- headers have no tap
    -- action, unlike an item row's select-mode toggle).
    if C.heldHeader and C.heldHeader.mode == "pending" and (love.mouse.isDown(1) or C.padDown) then
      local ddx, ddy = C.mx - C.heldHeader.downX, C.my - C.heldHeader.downY
      if ddx*ddx + ddy*ddy > 196 then C.heldHeader.mode = "drag" end
    end
    -- v2.9.5: same promotion, parallel state, for the marquee-drag (see
    -- C.marqueeStart/C.marquee's own comment). Once promoted, keep the
    -- rectangle's live corner following the cursor every frame -- this is
    -- what makes it visually track while dragging, not just a one-time
    -- snapshot at the moment it was promoted.
    if C.marqueeStart and (love.mouse.isDown(1) or C.padDown) then
      local ddx, ddy = C.mx - C.marqueeStart.x, C.my - C.marqueeStart.y
      if C.marquee or ddx*ddx + ddy*ddy > 196 then
        C.marquee = { x0 = C.marqueeStart.x, y0 = C.marqueeStart.y, x1 = C.mx, y1 = C.my, side = C.marqueeStart.side }
      end
    end
    love.graphics.push("all"); love.graphics.origin()
    -- The body below used to run directly between this push and the pop()
    -- at the end of the function -- but the ONLY thing protecting it was
    -- the pcall(c.drawScreen) wrapped around this whole function at the
    -- call site, which can't help here: if anything inside throws, this
    -- function exits via the error before ever reaching its own pop(),
    -- leaking one unmatched push every single frame the error keeps
    -- happening. Wrapping the body in its own pcall means the pop() right
    -- after always runs, success or failure -- an internal error still
    -- gets caught and logged same as before, it just can't leak graphics
    -- state anymore while doing it.
    local screenOk, screenErr = pcall(function()
    setc({0,0,0}, 0.72); love.graphics.rectangle("fill", 0, 0, W, H)
    local fullW = W / s
    -- v2.9.5, portrait redesign, direct report + 2 screenshots: computed up
    -- here (not just for the title fix below) since the panel-height and
    -- footer-position math right below also need it. Fresh from THIS
    -- function's own W/H (line 5490), not the shared C.isPortrait -- that
    -- flag is only ever set inside C.drawOverlay, which doesn't run at all
    -- while a screen is open (see touchGroupOffset's own comment on the
    -- exact same class of staleness, found and fixed earlier this session).
    local isPortraitScreen = H > W
    local M, headerH = 40, 74
    -- v2.9.5, portrait page-scroll: modest portrait-only trim of the screen
    -- chrome. Every unit reclaimed here goes straight into panel height,
    -- which is the scarce resource in portrait (see safeBottom below) --
    -- landscape has room to spare and keeps the roomier original values.
    if isPortraitScreen then M, headerH = 28, 60 end
    local maxW = 1180
    local contentW = math.min(fullW - 2*M, maxW)
    -- Normally a small fixed gap between the two panels. When the touch nav
    -- buttons are on (TOUCH_NAV_LEFT/RIGHT near the top of the file), widen
    -- it so neither panel's edge sits under a button -- computed from the
    -- same percent-of-window button zones, converted into this screen's
    -- design-space units, so it stays correct across any window size the
    -- same way the buttons themselves do, and automatically tracks if those
    -- zones are ever repositioned/resized.
    local G = 26
    if mod.options:get("touch_nav_buttons") or mod.options:get("touch_icon_buttons") then
      local navPad = 14  -- design-space breathing room beyond each button's outer edge
      local navHalfGap = 0
      if mod.options:get("touch_nav_buttons") then
        navHalfGap = math.max(navHalfGap, math.max(0.5 - TOUCH_NAV_LEFT.x1, TOUCH_NAV_RIGHT.x2 - 0.5) * fullW + navPad)
      end
      if mod.options:get("touch_icon_buttons") then
        -- The icon row is wider than the arrow pair (three buttons instead
        -- of one gap), so on its own it usually needs the bigger gap here.
        navHalfGap = math.max(navHalfGap, math.max(0.5 - TOUCH_ICON_OVERLAY.x1, TOUCH_ICON_PARTY.x2 - 0.5) * fullW + navPad)
      end
      G = math.max(G, navHalfGap * 2)
      G = math.min(G, contentW - 240)  -- safety floor: keep each panel at least 120 design units wide
    end
    local ox = (fullW - contentW) / 2      -- centre the whole layout
    -- Footer hint/status text wraps to fit contentW instead of running off
    -- the right edge; footerH is sized off however many lines that actually
    -- takes this frame, so it never gets cut off regardless of message length.
    local footerSize, footerLineH = 16, 20
    -- v2.9.5 bugfix, direct report: this used to vary by whether touch
    -- nav/icon buttons were on, falling back to "mouse wheel" otherwise --
    -- but mouse wheel has been completely unreadable since the sandbox
    -- migration (no sandbox-legal wheel hook exists yet, see the
    -- love.wheelmoved comment near the input.pointer hook) and the
    -- on-screen +/- stepper (drawHeldItem) is no longer gated on those
    -- options at all -- it's a region()-based button like any other, so
    -- mouse/touch/the stick cursor could always reach it once it wasn't
    -- hidden. One unconditional clause now, accurate for every platform.
    -- v2.9.5: added -/+ (and keypad -/+) now that they're actually wired
    -- (C.onScreenKey), direct report that the OLD wording ("the on-screen
    -- +/-") read as a keyboard instruction rather than "look for the drawn
    -- stepper buttons" -- true either way now, so no longer ambiguous.
    local qtyClause = "L2/R2, -/+, or the on-screen +/- to adjust quantity."
    -- Portrait gets its own much shorter hint. The landscape string wraps to
    -- FOUR lines at portrait width, and every one of those lines is 20 units
    -- taken directly out of panel height -- an expensive place to spend them
    -- when the full control list is mostly pad/keyboard detail that a phone
    -- player in portrait isn't using anyway. Mentions the drag-to-scroll
    -- gesture instead, since that one isn't discoverable on its own.
    local hint
    if isPortraitScreen then
      hint = C.screen == "items"
        and "Drag to transfer or reorder. Drag past a panel edge to reach the other. B cancels."
        or  "Drag a Pokemon onto a slot or box tab to move or swap. Drag past a panel edge to reach the other. Esc closes."
    else
      -- v2.10.0 bugfix, direct report: this still described the OLD L3/R3/
      -- [ / ] alphabet jump-to-letter controls, removed a while ago in
      -- favor of the real Search button (see C.openSearchGrid) -- stale
      -- text describing dead controls, never updated when the feature was
      -- replaced. Portrait's own hint (the branch just above) never had
      -- this problem since it was written after the replacement.
      hint = C.screen == "items"
        and ("Drag to transfer or reorder. D-Pad or arrow keys up/down to highlight an item, A to pick it up (or push the left stick for a free cursor). Move to any position or side and drop with A. " .. qtyClause .. " Select Search to find an item by name. B to cancel or exit.")
        or  "Drag a Pokemon onto a slot or box tab (onto an occupied slot = swap), or push the left stick for a free cursor and A to grab/drop  -  D-Pad / click a tab changes box  -  Select Search to find a Pokemon by name  -  Esc closes"
    end
    -- v2.9.5 (ported from the shelved v83 fix): size the RESERVED footer
    -- height off whichever of the status message or the hint is taller
    -- (never below the hint's own height), so a short transient status like
    -- "Undo - N more" replacing the long default hint can't shrink the
    -- footer and make the Party/PC (and Items) panels' height visibly jump
    -- on every Undo/sort. Only the reserved height is stabilized; the lines
    -- actually drawn below are still whatever's current.
    local footerLines = wrapText(C.status or hint, footerSize, contentW)
    local hintLines   = wrapText(hint, footerSize, contentW)
    local footerH = 16 + math.max(#footerLines, #hintLines) * footerLineH
    -- v2.9.5, portrait redesign, direct report + screenshot: this screen's
    -- footer hint text was bottom-anchored to fullH unconditionally, same
    -- issue as drawEditHUD's own fix a moment ago (see that comment) --
    -- the engine's on-screen virtual D-pad/buttons occupy the bottom of a
    -- portrait screen, and kanto has no visibility into that control's
    -- real bounds. safeBottom is the effective bottom edge for BOTH the
    -- panels and the footer in portrait; unchanged (fullH) in landscape,
    -- where nothing lives down there.
    -- v2.9.5 CORRECTION (measured, 2026-08-23): the 0.56 above was an
    -- eyeball estimate and it was badly wrong -- it reserved the bottom 44%
    -- of a portrait screen for the engine's on-screen controls, when a
    -- pixel measurement of a real Odin screenshot puts the top edge of the
    -- D-pad/A/B/SELECT/START cluster at design y=640 of 832 (device y=1478
    -- of 1920 at dpiscale 2.31), i.e. 77% down. The old value threw away
    -- ~174 design units of perfectly usable screen and was the single
    -- biggest reason both stacked panels were unusably short.
    -- Expressed as a fraction of WIDTH, not height: that control cluster is
    -- sized and bottom-anchored off the window's width (the D-pad circle
    -- measures ~0.39*width across), so a width-relative reserve tracks it
    -- across aspect ratios far better than a height fraction would. 0.44
    -- (vs the 0.41 measured) leaves a deliberate clearance band above it.
    local safeBottom = isPortraitScreen and (fullH - fullW * 0.44) or fullH
    local py = M + headerH
    local ph = safeBottom - py - footerH - M
    -- v2.9.5 fix, direct report + screenshot (portrait): this title is a
    -- fixed 30pt string sized for landscape's ~1180-wide contentW ceiling
    -- -- in portrait's much narrower contentW it ran straight into the
    -- Undo/X buttons (right-aligned off contentW independently), visibly
    -- overlapping both. The "Bag <-> PC"/"Party <-> Boxes" half is purely
    -- descriptive (both panels showing at once is already obvious once
    -- they're both on screen) -- dropped in portrait rather than shrunk
    -- further, since a screen this narrow has little room to spare either.
    if isPortraitScreen then
      txt(C.screen == "items" and "ITEMS" or "POKEMON", ox, M+20, 22, COL.gold)
    else
      txt(C.screen == "items" and "ITEMS      Bag  <->  PC"
                               or "POKEMON      Party  <->  Boxes", ox, M+16, 30, COL.gold)
    end
    local cw = 44; local cx, cy = ox+contentW-cw, M+6
    local hovX = region(cx, cy, cw, cw, "close")
    setc(hovX and COL.lo or COL.panel, 0.95); rrect("fill", cx, cy, cw, cw, 10)
    setc(COL.border, 0.3); rrect("line", cx, cy, cw, cw, 10)
    txt("X", cx+cw/2, cy+7, 24, COL.text, "center")
    -- Undo button, immediately left of the close X, same header row on both
    -- screens (ported from v80). Lit + clickable only while the per-screen
    -- undo stack has something in it -- drawn dim and NOT registered as a
    -- hit region when empty (same "register only when actionable" pattern
    -- as Save order). A tap/click (touch, mouse, or the gamepad stick
    -- cursor + A) or keyboard "u" all reach the same C.doUndo.
    do
      local canUndo = C.undoStack and #C.undoStack > 0
      local ulbl = "Undo"
      local uw = textW(ulbl, 20) + 34
      local ux = cx - uw - 12
      local hovU = canUndo and region(ux, cy, uw, cw, "undo")
      setc(hovU and COL.hi or COL.panel, canUndo and 0.92 or 0.4); rrect("fill", ux, cy, uw, cw, 10)
      setc(COL.border, 0.3); rrect("line", ux, cy, uw, cw, 10)
      txt(ulbl, ux+uw/2, cy+11, 20, canUndo and COL.text or COL.dim, "center", canUndo and 1 or 0.55)
    end
    if C.screen == "items" then
      drawItemsPanels(isPortraitScreen, ox, py, contentW, ph, G)
      drawHeldDarken(fullW, fullH)
      if C.held then drawHeldItem() end
      if C.heldHeader then drawHeldHeaderChip() end
    else
      drawPartyPanels(isPortraitScreen, ox, py, contentW, ph, G)
      if C.held then drawHeldMon() end
    end
    local footerCx = ox + contentW/2
    for i, line in ipairs(footerLines) do
      txt(line, footerCx, safeBottom - footerH + 8 + (i-1)*footerLineH, footerSize, C.status and COL.mid or COL.dim, "center")
    end
    -- v2.9.5: the marquee-drag rectangle itself, drawn BEFORE the cursor
    -- (so the cursor stays on top of it, not hidden underneath) -- see
    -- C.marquee's own comment. Gold, matching every other selection-
    -- related visual this feature already uses (checkboxes, focus rings).
    if C.marquee then
      local m = C.marquee
      local rx, ry = math.min(m.x0, m.x1), math.min(m.y0, m.y1)
      local rw, rh = math.abs(m.x1 - m.x0), math.abs(m.y1 - m.y0)
      setc(COL.gold, 0.16); love.graphics.rectangle("fill", rx*s, ry*s, rw*s, rh*s)
      love.graphics.setLineWidth(math.max(1, s)); setc(COL.gold, 0.85)
      love.graphics.rectangle("line", rx*s, ry*s, rw*s, rh*s)
      love.graphics.setLineWidth(1)
    end
    drawConfirmPopup(fullW, fullH)
    C.drawSearchGrid(fullW, fullH)
    -- Left-stick virtual cursor (see C.updateStickCursor/C.stickActive):
    -- only drawn while it's actually the thing in control, so it doesn't
    -- show a phantom cursor while D-pad or mouse/touch are being used.
    -- v2.9.5 bugfix, direct report: moved to AFTER both modals above (was
    -- before them) so the cursor stays visible while confirming a
    -- discard/release or picking a search letter -- clicking already
    -- worked either way, but the cursor itself used to disappear
    -- underneath the popup/grid backdrop.
    if C.stickActive then
      C.drawStickCursor(C.mx, C.my)
    end
    end)
    love.graphics.pop()
    if not screenOk and screenErr ~= C.screenBodyErr then
      C.screenBodyErr = screenErr
      mod.log:error("kanto_ingame screen body: %s", tostring(screenErr))
    end
  end

  -- ---------------------------------------------------------------------
  -- Fit-to-screen helpers. A 7" panel has much less vertical room than the
  -- 1440p layout was designed against, so a full 6-mon party (or a battle
  -- readout with several catch-odds rows) can run past the bottom edge.
  --
  -- Each panel function (party/trainer/items/route/battle) computes its own
  -- needed height via plain arithmetic (row counts × fixed row sizes) as
  -- the very first thing it does, before any drawing -- calling it with
  -- measureOnly=true returns that number immediately, skipping every draw
  -- call, sprite load, and panel() background entirely. Only if that height
  -- doesn't fit is the column redrawn for real inside a uniform scale-down
  -- transform anchored to its top-left corner. Content that already fits is
  -- completely unaffected (scale stays 1, no visual change at all).
  --
  -- This replaces an earlier approach that measured by actually drawing
  -- into a zero-area scissor rect (nothing visible, but every draw call --
  -- including sprite loads -- still ran). That was the prime suspect
  -- behind a long-standing landscape battle-transition crash: a `0,0,0,0`
  -- scissor is a genuinely degenerate GPU state, and this device's GPU
  -- driver (Tensor G5, a brand-new first-generation architecture switch
  -- with documented driver immaturity, especially under emulation-style
  -- workloads) is a plausible place for exactly that kind of edge case to
  -- go wrong -- independent of what was being drawn inside it, which is
  -- why three earlier fix attempts that only changed *what* loaded during
  -- that pass (v1-v3) never actually resolved the crash. Kanto Companion
  -- Lite never had this problem because it never measures this way at
  -- all -- it computes sizes the same way this file now does.
  -- ---------------------------------------------------------------------
  local MIN_FIT_SCALE = 0.72   -- never shrink further than this; readability floor
  local function drawScaled(px, py, scale, fn, ...)
    if scale == 1 then fn(...); return end
    love.graphics.push()
    love.graphics.translate(px * s, py * s)
    love.graphics.scale(scale)
    love.graphics.translate(-px * s, -py * s)
    local ok, err = pcall(fn, ...)
    love.graphics.pop()
    if not ok then error(err, 0) end
  end
  -- LIGHT BUILD, Session 46: overlay customization helpers -- see
  -- C.panelCfg/C.overlayEdit above for the state these read/write.
  local function drawCollapsedHeader(x, y, w, label)
    -- Draws in place of a fully-collapsed panel: just a title bar, no
    -- content. Deliberately not calling into party()/trainer()/etc. at
    -- all -- lowest-risk way to add this without touching any of their
    -- internals.
    --
    -- Session 74 bugfix: w used to always be COLW regardless of the
    -- panel's own current scale -- confirmed and flagged as a known
    -- simplification back when this was first written, but on direct
    -- report it's a real mismatch in practice: scale a panel down (or
    -- up), then collapse it, and the collapsed strip would snap back to
    -- full COLW width instead of tracking where the panel actually was.
    -- Now takes the real current width (COLW * baseScale * cfg.scale,
    -- same formula the expanded branch already uses) from the caller.
    local h = 34
    setc(COL.panel, 0.98); rrect("fill", x, y, w, h, 14)
    love.graphics.setLineWidth(math.max(1, s))
    setc(COL.border, 0.12); rrect("line", x, y, w, h, 14)
    txt(label, x + 16, y + 9, 16, COL.text)
    -- Bug fix, Session 61: this label used to sit right-aligned all the
    -- way to the edge, which put it directly under the collapse icon
    -- (Session 57) once edit mode draws one there -- confirmed from a
    -- screenshot, not assumed. Reserve room for the icon only when edit
    -- mode is actually active (the icon only draws then); keeps this
    -- label at its original position the rest of the time, since there's
    -- nothing to collide with outside edit mode.
    local rightInset = C.overlayEdit.active and 54 or 16
    txt("[collapsed]", x + w - rightInset, y + 10, 12, COL.dim, "right")
  end
  local function drawEditHighlight(pivotX, pivotY, which, natH, totalScale, anchorRight)
    -- A visible border around whichever panel is currently selected in
    -- edit mode, sized and positioned to genuinely match the panel's real
    -- on-screen bounding box at its current scale -- both dimensions,
    -- not just height. The previous version scaled height correctly but
    -- left width hardcoded to COLW regardless of scale, so the border
    -- visibly stopped tracking the panel's actual width the moment scale
    -- moved away from 100% (confirmed directly from a 160% screenshot,
    -- not assumed). Also has to account for *which corner* the panel's
    -- own scale transform pivots around -- the left panel pivots from
    -- its top-left (unscaled corner = pivot), the right panel from its
    -- top-right (pivot fixed, panel grows/shrinks leftward from there)
    -- -- so the highlight's own top-left corner has to be computed
    -- differently for each, not just copy the panel's anchor coordinate.
    local cfg = C.panelCfg[which]
    local selected = C.overlayEdit.sel == which
    if not selected then return end
    local w = COLW * totalScale
    local h = natH * totalScale
    local x = anchorRight and (pivotX - w) or pivotX
    local y = pivotY
    love.graphics.setLineWidth(math.max(2, s * 1.5))
    setc(COL.gold, 0.9); rrect("line", x - 4, y - 4, w + 8, h + 8, 16)
    local label = string.format("%d%%%s", math.floor(cfg.scale * 100 + 0.5), cfg.collapsed and "  (collapsed)" or "")
    txt(label, x, y - 20, 13, COL.gold)
  end
  local function drawCollapseIcon(x, y, w, which, isCollapsed, boxH)
    -- v2.9.5, direct request: panels with no compact level go straight to
    -- fully-invisible when collapsed (see onKeyDown's "C" handler for the
    -- full reasoning) -- fine in landscape, but in portrait's single-panel
    -- carousel that panel IS the whole visible page, so the control to
    -- blank it is removed entirely there, not just neutralized -- no icon
    -- drawn, no hit-test bounds registered, matching "shouldn't have the
    -- option" rather than "has the option but it silently does nothing."
    if C.isPortrait and not SUPPORTS_COMPACT[which] then return end
    -- LIGHT BUILD, Session 57: small, dedicated tap target for collapse/
    -- expand via touch, distinct from the general "tap the panel to
    -- select it" gesture (Session 52) -- deliberately not combined into
    -- one gesture, same reasoning as before: tapping to select shouldn't
    -- also silently collapse something. Visible and tappable on *every*
    -- panel whenever edit mode is active, not gated on which one is
    -- currently selected (unlike the highlight border) -- the point is
    -- direct manipulation of any panel without first cycling to it.
    -- Recorded into C.overlayEdit.bounds[which].icon, checked first in
    -- touch handling, ahead of the plain panel-select check.
    -- Icon fix, Session 58: original 26-design-unit icon measured out to
    -- as little as ~13 real pixels on a smaller handheld screen -- well
    -- under normal touch-target size (~40-44px is the usual guideline) --
    -- confirmed by the math, not just guessed, after Bhk reported taps
    -- not registering. Visual size increased moderately; hit-test area
    -- padded further still beyond what's actually drawn, a common mobile
    -- pattern (tappable region larger than the visible control) that
    -- gives real forgiveness for imprecise taps without the icon itself
    -- looking oversized.
    local iconSize = 34
    local topInset = 4
    -- Session 89 bugfix: fixed 34 + a 4-unit top inset always reached
    -- y+38 -- fine against a tall expanded panel (natH*totalScale is
    -- always comfortably bigger than that), but a COLLAPSED panel's own
    -- bar is only 34 tall in the first place (see drawEditablePanel's
    -- `ch = 34 * totalScale`), so the icon overflowed 4 units past the
    -- bottom of its own bar -- confirmed from a screenshot, the "+" icon
    -- visibly poking out below the thin collapsed strip. boxH (passed by
    -- the caller, the same ch/h it already computes) lets the icon shrink
    -- to actually fit when the box is this small, recentering itself
    -- vertically -- never below 18, the same "still tappable even if it
    -- means a little visual overflow" tradeoff Session 58 already made
    -- for the hit-padding above. Expanded panels pass a boxH that's
    -- always far bigger than iconSize+2*topInset, so this is a no-op for
    -- them -- pixel-identical to before.
    if boxH then
      local maxIcon = boxH - topInset * 2
      if maxIcon < iconSize then
        iconSize = math.max(18, maxIcon)
        topInset = (boxH - iconSize) / 2
      end
    end
    -- Session 90 bugfix: confirmed from a screenshot, the icon wasn't
    -- uniformly positioned across collapsed panels even at the identical
    -- saved scale (1.0) for every one of them -- checked the actual save
    -- file to rule out a per-panel scale difference. Root cause: `y` here
    -- differs per panel (Trainer sits at a clean `margin`; Items/Route
    -- sit at a COMPUTED default Y -- see itemsDefaultY/bottomDefaultY in
    -- drawOverlay), and rrect() floors x/y to whole device pixels
    -- independently for the bar (drawCollapsedHeader) and this icon --
    -- same phase-dependent rounding issue this file's rrect() comment
    -- already documents for corner radius, just showing up here as a
    -- vertical offset instead. Two shapes floored from DIFFERENT
    -- fractional Y values can end up 1 pixel apart even with an
    -- identical, unfractional topInset between them. Fixed by snapping y
    -- to the SAME whole device pixel the bar's own rrect call will land
    -- on, then adding topInset on top of that already-snapped base --
    -- makes the bar-to-icon gap a fixed number of device pixels
    -- (floor(topInset*s)) regardless of which panel's Y this is.
    local snappedY = math.floor(y * s) / s
    local hitPad = 14
    local ix = x + w - iconSize - 4
    local iy = snappedY + topInset
    setc(COL.panel, 1); rrect("fill", ix, iy, iconSize, iconSize, 7)
    love.graphics.setLineWidth(math.max(1.5, s))
    setc(COL.gold, 0.9); rrect("line", ix, iy, iconSize, iconSize, 7)
    txt(isCollapsed and "+" or "-", ix + iconSize/2, iy + 5, 18, COL.gold, "center")
    C.overlayEdit.bounds[which].icon = {
      x = ix - hitPad, y = iy - hitPad, w = iconSize + hitPad*2, h = iconSize + hitPad*2,
    }
  end
  -- Session 73: was drawDragHandle, a small dedicated icon (Session 62)
  -- at the panel's top-left, removed once Session 72 widened the HIT
  -- ZONE to the whole header strip and the icon became a redundant
  -- leftover. Session 74: on request, a real (but different) visual
  -- cue is back -- a small centered "grabber" bar, the same convention
  -- as an iOS bottom-sheet handle or a real OS window's title-bar grip:
  -- a short, pill-shaped horizontal line centered along the top,
  -- hinting "drag here" without a full icon claiming its own corner.
  -- It's purely a visual hint, same as the removed icon was -- the
  -- actual hit zone is still the entire header strip below, not just
  -- this bar. w is the panel's current full (already-scaled) width,
  -- passed in by both call sites the same way drawCollapseIcon already
  -- receives it.
  local function drawHeaderGrabber(x, y, w, which)
    local barW, barH = 44, 5
    local bx, by = x + w/2 - barW/2, y + 8
    setc(COL.gold, 0.5)
    rrect("fill", bx, by, barW, barH, barH/2)
    local HEADER_H = 48
    C.overlayEdit.bounds[which].handle = { x = x, y = y, w = w, h = HEADER_H }
  end
  -- Corner resize, Session 72: originally mouse/PC only, out of concern
  -- it would compete with touch pinch-to-zoom (Session 66/70) for the
  -- same job. Session 73, on direct request: opened to touch as well --
  -- in practice a touch landing precisely on a small corner zone
  -- doesn't meaningfully collide with a real two-finger pinch gesture.
  -- tryEditPanelSelect's resize-start check now accepts either input
  -- method, tracking touchId the same way drag/pinch already do so
  -- updateResize/endResize only respond to whichever touch or mouse
  -- actually started it.
  --
  -- Only bottom corners, not all four -- the top two are already the
  -- collapse icon (top-right) and the drag header (top-left through
  -- top-right, Session 72 above); putting resize there too would be a
  -- third gesture competing for the same pixels. Both bottom corners
  -- scale the panel uniformly around its own existing pivot (the same
  -- point drawEditablePanel already scales from -- top-left if not
  -- anchorRight or already dragged, top-right if still anchorRight),
  -- not around whichever corner is grabbed -- panels only have one
  -- scale value, not independent width/height, so there is no second
  -- corner to keep visually fixed without also moving cfg.pos, and
  -- reusing the existing pivot keeps this consistent with how pinch
  -- already scales the same panel.
  local function drawResizeHandles(x, y, w, h, which)
    -- Session 75: back to the L-bracket shape (Session 73) -- on direct
    -- feedback, the shape itself was right, but every version so far
    -- (thin outline, then dots) borrowed the same thin-gold-glow-line
    -- language used everywhere else in this file for selection borders
    -- and highlights, which reads as "you've selected/highlighted this"
    -- rather than "grab this." Rendered as a solid, chunky, filled
    -- bracket instead of thin strokes for a bordered, tactile, "physical
    -- handle" look, deliberately closer to a real OS resize grip than to
    -- this file's usual delicate outline style. Still fully inset from
    -- the real border -- same discipline as every version before this
    -- one, nothing drawn here extends past the panel's edge.
    --
    -- Session 76 bugfix: the first attempt at this used a dark backing
    -- bar in COL.panel -- the SAME near-black the panel's own background
    -- is already filled with -- directly behind the gold, entirely
    -- inside the panel. Confirmed from an actual on-device screenshot:
    -- zero contrast against itself, so it was invisible the whole time.
    -- Replaced with a real outline stroke in COL.border (white) traced
    -- around the gold fill instead -- contrasts against the dark panel
    -- background regardless of what's directly behind it, which a
    -- same-color-behind-itself fill never could.
    --
    -- Session 77: on direct feedback the bracket read a bit too chunky,
    -- so barThick/barLen came down slightly (7->5, 22->20). The touch
    -- hit zone is intentionally NOT shrunk to match -- if anything it
    -- grew (40->56) -- same "small visible target, generous invisible
    -- hitbox" split iOS/Android use for tiny drag handles, since a
    -- thinner glyph is harder to land a fingertip on precisely.
    --
    -- Session 78: Session 77's cut wasn't enough -- on-device it barely
    -- read as smaller. Root cause: the white outline stroke traced
    -- around the fill (added Session 76 for contrast) has its own fixed
    -- width tied to `s`, independent of barThick/barLen -- shrinking
    -- just the fill left that stroke's bulk untouched, which ate most
    -- of the intended reduction. This pass cuts both: fill down again
    -- (5->4, 20->17) AND the outline stroke itself thinned (from
    -- `s * 1.3` to `s * 0.9`, floor 1.5->1.1), so the visible edge
    -- actually gets thinner this time, not just the fill hidden behind
    -- an unchanged border. Hit zone still untouched (56, unchanged).
    --
    -- Session 79: confirmed from an on-device edit-mode screenshot the
    -- gold fill is no longer visible at all at this size -- the white
    -- outline stroke is thick enough relative to barThick that it now
    -- fully covers the fill underneath (by design intent from Session
    -- 76, just more so now that the fill shrank further in Session 78).
    -- User likes the resulting all-white look and wants to keep it
    -- pixel-identical -- so the gold fill draw is just dead weight now,
    -- removed rather than kept as an invisible layer.
    local inset, barLen, barThick = 9, 17, 4
    local function bar(cx, cy, dx, dy, len, thick)
      -- One of dx/dy is 0 -- draws a filled, fully-rounded bar from the
      -- joint point (cx,cy) extending by len along whichever axis isn't
      -- zero, toward dx/dy's sign.
      local rx, ry, rw, rh
      if dx ~= 0 then
        rw, rh = len, thick
        rx = (dx > 0) and cx or (cx - len)
        ry = cy - thick / 2
      else
        rw, rh = thick, len
        rx = cx - thick / 2
        ry = (dy > 0) and cy or (cy - len)
      end
      love.graphics.setLineWidth(math.max(1.1, s * 0.9))
      setc(COL.border, 0.85); rrect("line", rx, ry, rw, rh, thick / 2)
    end
    local function grip(cornerX, cornerY, dirX, dirY)
      local px, py = cornerX + dirX * inset, cornerY + dirY * inset
      bar(px, py, dirX, 0, barLen, barThick)
      bar(px, py, 0, dirY, barLen, barThick)
    end
    grip(x, y + h, 1, -1)      -- bottom-left: arms point right and up, into the panel
    grip(x + w, y + h, -1, -1) -- bottom-right: arms point left and up, into the panel
    local hitSize = 56
    local blx, bly = x - hitSize/2, y + h - hitSize/2
    local brx, bry = x + w - hitSize/2, y + h - hitSize/2
    C.overlayEdit.bounds[which].resizeBL = { x = blx, y = bly, w = hitSize, h = hitSize }
    C.overlayEdit.bounds[which].resizeBR = { x = brx, y = bry, w = hitSize, h = hitSize }
  end
  -- v69: on direct request -- full rewrite of this box, both look and
  -- copy. Was a flat, square-cornered, 70%-alpha black rectangle (visibly
  -- inconsistent with every other panel's rounded/near-opaque `panel()`
  -- style, and hard to read over a busy background at only 70% opaque)
  -- with one long left-aligned gold wall of text cramming two unrelated
  -- facts onto several lines. Now:
  --  - Reuses `panel()` (the same rounded, near-opaque box every other
  --    panel in the file already uses) instead of a one-off rectangle --
  --    this alone fixes both the style mismatch and the readability
  --    complaint, for free, with no new drawing code.
  --  - Content is filtered by what the player actually has: keyboard
  --    hints only when NOT on a mobile OS (via isMobilePlatform(), which
  --    delegates to the engine's own VideoMode.isMobile()), gamepad
  --    hints only when a real gamepad is currently connected (same
  --    `:isGamepad()` check already used for the stick-cursor code
  --    above), touch-only hints (pinch) only on a mobile OS. Since edit
  --    mode can currently only be ENTERED via keyboard F6 or gamepad R3
  --    (confirmed -- no touch path toggles C.overlayEdit.active anywhere
  --    in this file), this box is never reachable with both a keyboard
  --    and a gamepad unavailable, so there's always at least one exit
  --    method to show.
  --  - Each line is now one coherent topic (was two unrelated facts
  --    jammed onto several lines with ad-hoc triple-spacing), title is
  --    drawn larger/gold, body lines smaller/dim, and every line is
  --    genuinely centered (drawn individually with align="center", not
  --    one \n-joined block centered as a whole -- which would only
  --    center the widest line and leave shorter ones ragged).
  --  - Box width/height are now MEASURED from the actual (now variable,
  --    since it's conditional) content every frame, the same
  --    measure-before-draw principle every panel function in this file
  --    already uses via measureOnly -- not a hardcoded constant. This is
  --    what actually closes off v68's bug class for good: there is no
  --    longer any fixed number that could drift out of sync with the
  --    real content, because there's no fixed number at all anymore.
  local function drawEditHUD(centerX, bottomY)
    -- v70: reads the shared isMobilePlatform() (see its own definition
    -- above, near drawHeldItem) instead of its own inline copy of the
    -- same check -- see that function's comment for why.
    local isMobile = isMobilePlatform()
    local hasGamepad = false
    for _, j in ipairs(love.joystick.getJoysticks()) do
      if j:isGamepad() then hasGamepad = true; break end
    end
    local kbd = not isMobile
    -- v2.9.5 correction: the comment this replaced claimed "no touch path
    -- toggles C.overlayEdit.active" made touch-only-here unreachable -- true
    -- when written, silently made FALSE by the same session's long-press-to-
    -- edit gesture (see C.onFrame), which opens edit mode from a bare touch
    -- hold with no keyboard/gamepad involved at all. Confirmed live on a
    -- touch-only device (Galaxy S23 Ultra): this is a real, regularly
    -- reached state, not a defensive fallback. Captured BEFORE the kbd
    -- fallback below overwrites it, since that fallback exists purely to
    -- keep the OTHER lines' `pick()` prefixes from going blank -- it makes
    -- `kbd` true even here, which would otherwise make the box falsely
    -- claim "exit: F6" on a device with no keyboard at all.
    local touchOnly = isMobile and not hasGamepad
    -- Kept for the other lines' `pick()` calls: without it, a genuinely
    -- keyboard-and-gamepad-less state (only possible via the long-press
    -- touch entry above) produces a stray leading double-space (e.g.
    -- "  select panel"), since every `pick()` call would return "".
    -- Falling back to keyboard-shaped hint text there is cosmetic only --
    -- see C.overlayEdit.hintBoxRect below for the actual fix for touchOnly.
    if not kbd and not hasGamepad then kbd = true end
    -- Joins whichever of its (already-conditional) arguments are
    -- truthy/non-empty with " / " -- e.g. pick(kbd and "Tab", hasGamepad
    -- and "D-pad") reads "Tab / D-pad" with both, just "Tab" with only a
    -- keyboard, just "D-pad" with only a gamepad.
    local function pick(...)
      local parts = {}
      for _, p in ipairs({ ... }) do if p and p ~= "" then parts[#parts + 1] = p end end
      return table.concat(parts, " / ")
    end
    local lines, title
    if touchOnly then
      -- v2.9.5 fix, direct report + screenshot (Galaxy S23 Ultra, portrait):
      -- the kbd fallback two lines above exists so the OTHER (kbd/gamepad-
      -- shaped) lines below don't show a blank prefix -- but it also made
      -- THIS box's own title claim "exit: F6" on a device with no keyboard
      -- at all, and the full kbd/gamepad line set (Tab/Up-Down/-=/I/P/C/R/
      -- F9) was never relevant to touch input to begin with -- that whole
      -- list was already only "cosmetic," never accurate, for touchOnly
      -- (see the comment on that fallback). Confirmed on a real screenshot:
      -- none of it fit portrait's width either, overflowing off BOTH edges
      -- with the one genuinely relevant line ("tap this box to exit")
      -- buried at the bottom, hidden behind the on-screen D-pad. Rather
      -- than trying to cap the old list's width, touchOnly gets its own
      -- short, actually-accurate set instead -- true regardless of
      -- orientation, not just portrait, since none of the kbd/gamepad
      -- lines were ever real touch controls in landscape either.
      title = "EDIT MODE"
      lines = {
        title,
        "Drag header to move, corner to resize",
        "Pinch to scale, tap icon to collapse",
        "Tap this box to exit edit mode",
        -- v2.9.5, direct request: touch-only players had no way to reach
        -- the F9/hold-L3 "reset everything" recovery path at all -- this
        -- is that path's touch equivalent, same ~1s hold gesture as L3's
        -- own (not an instant tap, so a stray touch can't wipe out real
        -- customization by accident). Given its own dedicated row/rect
        -- (C.overlayEdit.resetAllRect, set below) rather than overloading
        -- the whole-box tap-to-close zone, checked first in
        -- tryEditPanelSelect so it can't be swallowed by the close zone.
        "Hold this row 1s: reset everything",
      }
    else
      title = "EDIT MODE"
      local exitHint = pick(kbd and "F6", hasGamepad and "R3")
      if exitHint ~= "" then title = title .. "   exit: " .. exitHint end
      lines = { title }
      lines[#lines + 1] = pick(kbd and "Tab", hasGamepad and "D-pad Left/Right") .. " select panel   "
        .. pick(kbd and "Up/Down", hasGamepad and "D-pad Up/Down") .. " scale it"
      local collapseLine = pick(kbd and "I/P", hasGamepad and "X/Y") .. " collapse step"
      if kbd then collapseLine = collapseLine .. "   C cycle" end
      lines[#lines + 1] = pick(kbd and "-/=", hasGamepad and "L2/R2") .. " scale all   " .. collapseLine
      local dragLine = "Drag header to move, corner to resize, double-tap header to reset"
      if isMobile then dragLine = dragLine .. "   pinch to scale" end
      lines[#lines + 1] = dragLine
      if hasGamepad then
        lines[#lines + 1] = "Left stick + A: move cursor, drag/resize/tap"
      end
      -- Reset controls. R (keyboard) resets the SELECTED panel; F9 (keyboard,
      -- works any time) and L3 (gamepad, edit mode only) reset ALL panels to
      -- default. There's no gamepad/touch equivalent of the per-panel R reset.
      local resetSel = pick(kbd and "R", hasGamepad and "L3")
      if resetSel ~= "" then lines[#lines + 1] = resetSel .. ": reset selected panel" end
      local resetAll = pick(kbd and "F9", hasGamepad and "hold L3")
      if resetAll ~= "" then lines[#lines + 1] = resetAll .. ": reset all panels" end
      lines[#lines + 1] = "Fully-collapsed panels hide outside edit mode"
    end
    -- v2.9.5 fix, direct report (Galaxy S23 Ultra, touch-only): long-press
    -- can OPEN edit mode via touch alone (C.onFrame) but nothing touch-based
    -- could ever CLOSE it again -- confirmed live, not just from reading the
    -- code. The whole hint box is a tap target -- see
    -- C.overlayEdit.hintBoxRect below and its one use in tryEditPanelSelect
    -- -- so the line above already covers this for touchOnly; box is
    -- tappable either way (harmless for mouse/keyboard/gamepad users too).

    local titleSize, bodySize = 16, 12
    local titleH, lineH = titleSize * 1.7, bodySize * 1.7
    local padX, padY = 20, 14
    local contentW = textW(title, titleSize)
    for i = 2, #lines do contentW = math.max(contentW, textW(lines[i], bodySize)) end
    local boxW = contentW + padX * 2
    local boxH = titleH + (#lines - 1) * lineH + padY * 2
    local boxX, boxY = centerX - boxW / 2, bottomY - boxH
    C.overlayEdit.hintBoxRect = { x = boxX, y = boxY, w = boxW, h = boxH }
    panel(boxX, boxY, boxW, boxH, false)
    local cy = boxY + padY
    txt(title, centerX, cy, titleSize, COL.gold, "center")
    cy = cy + titleH
    for i = 2, #lines do
      -- v2.9.5: the reset row (always the last touchOnly line) reads gold
      -- while actually held, the same "this is armed/about to fire" signal
      -- color this file already uses elsewhere (e.g. the active-party
      -- highlight, every edit-mode selection outline) -- cheap, and avoids
      -- a silent held-or-not-held gesture with zero feedback, the same gap
      -- flagged (and left for later) on the long-press-to-edit gesture
      -- this reuses the shape of.
      local isResetRow = touchOnly and i == #lines
      local rowCol = (isResetRow and C.resetAllHoldStart) and COL.gold or COL.dim
      txt(lines[i], centerX, cy, bodySize, rowCol, "center")
      if isResetRow then
        C.overlayEdit.resetAllRect = { x = boxX, y = cy - 4, w = boxW, h = lineH + 4 }
      end
      cy = cy + lineH
    end
    if not touchOnly then C.overlayEdit.resetAllRect = nil end
  end
  -- LIGHT BUILD, Session 51: shared collapse-or-scale-plus-highlight
  -- logic, used for all four editable regions (party, trainer, items,
  -- bottom/route-battle) instead of copy-pasting the same pattern four
  -- times, which is exactly the kind of duplication that drifts out of
  -- sync after the next fix touches only one copy. baseScale is the
  -- auto-fit factor already computed for whichever group this panel
  -- belongs to (shared across trainer/items/bottom, matching how they
  -- always auto-shrunk together before this split); panelCfg.scale
  -- layers the user's own manual override on top of that, same as
  -- before. Returns the effective height actually used on screen, so
  -- the caller can stack whatever comes next.
  -- LIGHT BUILD, Session 63 (bugfix): the eighth argument is now a
  -- FACTORY (x, y) -> drawFn, not a pre-built fn/... pair. Session 62's
  -- version took `fn, ...` with the panel's default x/y already baked
  -- into `...` at the call site, in C.drawOverlay, BEFORE this function
  -- ever got a chance to override pivotX/pivotY from cfg.pos. That meant
  -- a dragged panel's highlight, collapse icon, and drag handle all
  -- correctly followed the drag (they read the overridden pivotX/pivotY
  -- directly) while the actual party()/trainer()/items()/route() draw
  -- call kept using its original default position regardless -- confirmed
  -- on video (screen-20260807-042835.mp4): highlight moves, real panel
  -- content doesn't. Building the real draw call AFTER the override,
  -- from the final pivotX/pivotY, fixes all four panels at once.
  --
  -- EMERGENCY CORRECTION, Session 64: the fix above shipped as v21 was
  -- itself broken -- confirmed by actually running the exact pattern
  -- through a real Lua interpreter, not just re-reading it. fnFactory's
  -- CONTRACT IS: fnFactory(x, y) must return a FUNCTION for drawScaled
  -- to call later. Every v21 call site instead wrote
  -- `function(x, y) return trainer(st, x, y) end` -- which calls
  -- trainer() immediately (as a side effect of building the argument
  -- list) and returns ITS return value (a number, the drawn height) --
  -- not a function at all. drawScaled then tried to call that number,
  -- throwing a real Lua error every single frame, for every expanded
  -- panel, regardless of whether a drag was ever attempted. That error
  -- is caught by the outer pcall around the whole overlay draw
  -- (love.draw), silently, every frame -- so whatever came after the
  -- crash point in that frame's draw order (both later panels, and the
  -- crashed panel's own highlight/icons, all drawn after the failed
  -- drawScaled call) simply never rendered again, consistently, with no
  -- error visible in-game. Reported directly: dragging one panel made
  -- three others vanish with no way to recover. Correct form:
  -- `function(x, y) return function() return trainer(st, x, y) end end`
  -- -- the inner function is what actually gets deferred and called by
  -- drawScaled; verified against a real interpreter before shipping,
  -- not just re-read.
  local function drawEditablePanel(pivotX, pivotY, which, label, natH, baseScale, anchorRight, fnFactory)
    local cfg = C.panelCfg[which]
    -- LIGHT BUILD, Session 62: once a panel has been dragged, it's
    -- positioned by its own explicit top-left corner instead of the
    -- default screen-edge anchor -- overridden here, before anything
    -- else in this function runs, so every downstream piece (collapsed
    -- header, drawScaled, highlight, both icons) automatically uses the
    -- dragged position with no further changes needed anywhere else.
    -- v2.9.5 fix, root-caused not guessed: a saved cfg.pos was being
    -- honored unconditionally regardless of orientation. On a
    -- long-played save (this file's own history spans 90+ edit-mode
    -- sessions of dragging/resizing), that meant every portrait draw call
    -- passing a fresh, safe (margin, topBandY) default was SILENTLY
    -- overridden right here by a stale LANDSCAPE position the instant any
    -- panel had ever been dragged in landscape -- confirmed as the real
    -- cause of the reported "panels stretching off the right edge":
    -- items() itself draws entirely within COLW (checked directly, it
    -- doesn't overflow its own box), so the only way its BOX could start
    -- past the portrait window's right edge is an inherited pivotX from
    -- outside portrait's own layout code entirely. `cfg.pos.portrait` now
    -- tags which orientation a position was saved for; `or false` treats
    -- every pre-existing save (all landscape-only, before today) as
    -- landscape, exactly matching real history, no migration needed. A
    -- position saved in the CURRENT orientation still applies normally --
    -- this only stops the CROSS-orientation leak, it doesn't disable
    -- dragging in either one.
    if cfg.pos and (cfg.pos.portrait or false) == (C.isPortrait or false) then
      pivotX, pivotY, anchorRight = cfg.pos.x, cfg.pos.y, false
    end
    if cfg.collapsed then
      -- Session 74: totalScale computed the same way the expanded
      -- branch already does (baseScale * cfg.scale), instead of always
      -- treating this as a flat, unscaled COLW-wide strip. Without
      -- this, collapsing a panel that had been scaled up or down
      -- snapped its width back to 100% -- confirmed mismatched against
      -- the expanded box's own real width, not just a cosmetic guess.
      local totalScale = baseScale * cfg.scale
      local cw, ch = COLW * totalScale, 34 * totalScale
      local hx = anchorRight and (pivotX - cw) or pivotX
      -- Session 92: on direct request, a fully-collapsed panel is now
      -- genuinely invisible outside edit mode -- not drawn at all, not
      -- just visually thin -- so players can get rid of a section they
      -- don't want entirely. The bar (and its icon/grabber/highlight)
      -- still shows normally WHILE edit mode is active, so there's
      -- always a way to find and re-expand it. Gating the whole
      -- drawCollapsedHeader call on C.overlayEdit.active, not just the
      -- decorations below it, is the actual change -- everything else
      -- here is unchanged.
      if C.overlayEdit.active then
        drawCollapsedHeader(hx, pivotY, cw, label)
        drawEditHighlight(pivotX, pivotY, which, 34, totalScale, anchorRight)
        -- LIGHT BUILD, Session 52: record every panel's real bounding box
        -- (not just the selected one, which drawEditHighlight already
        -- tracks) so touch input can hit-test which panel a tap landed
        -- in. Same x/y math drawEditHighlight uses internally, just
        -- exposed here since hit-testing needs all four, every frame,
        -- not only whichever is currently selected.
        C.overlayEdit.bounds[which] = { x = hx, y = pivotY, w = cw, h = ch }
        drawCollapseIcon(hx, pivotY, cw, which, true, ch)
        drawHeaderGrabber(hx, pivotY, cw, which)
        -- No drawResizeHandles here -- a collapsed panel is a fixed
        -- 34-tall strip with nothing to resize; expand it first.
      end
      return C.overlayEdit.active and ch or 0
    else
      local totalScale = baseScale * cfg.scale
      -- Built from the FINAL pivotX/pivotY (post cfg.pos override above),
      -- not the call site's original default -- this is the actual fix.
      -- Same left-edge derivation drawCollapsedHeader's `hx` already uses:
      -- anchorRight panels (trainer/items/bottom, pre-drag) pivot from
      -- their right edge, so the content fn's real x is pivotX - COLW;
      -- once dragged, anchorRight is false and pivotX already IS the
      -- left edge (cfg.pos.x), same as the collapsed-header case.
      local cx = anchorRight and (pivotX - COLW) or pivotX
      -- v2.9.5 fix: totalScale is now also handed to fnFactory (harmless
      -- for the trainer/items/bottom closures, which don't declare a 3rd
      -- param and simply ignore it) so the party panel's scrollbar can
      -- store its hit-box already correctly mapped through this same
      -- transform -- see party()'s own C.partyScrollbar comment.
      drawScaled(pivotX, pivotY, totalScale, fnFactory(cx, pivotY, totalScale))
      if C.overlayEdit.active then
        drawEditHighlight(pivotX, pivotY, which, natH, totalScale, anchorRight)
        local w = COLW * totalScale
        local h = natH * totalScale
        local x = anchorRight and (pivotX - w) or pivotX
        C.overlayEdit.bounds[which] = { x = x, y = pivotY, w = w, h = h }
        drawCollapseIcon(x, pivotY, w, which, false, h)
        drawHeaderGrabber(x, pivotY, w, which)
        drawResizeHandles(x, pivotY, w, h, which)
      end
      return natH * totalScale
    end
  end

  -- ---------------------------------------------------------------------
  -- Compose: draw everything, anchored to the window edges (widescreen).
  -- ---------------------------------------------------------------------
  C.drawOverlay = function()
    if not C.visible or C.screen then return end
    local st = C.state
    if not st or not st.active then return end
    -- Hold the WHOLE overlay until a real game is in play. The engine makes a
    -- default (empty-party) save at the launcher/title, which would otherwise
    -- flash the trainer/route panels before you've loaded a game. Gate on the
    -- party -- once it has a mon, everything shows together.
    if not (st.party and #st.party > 0) then return end
    -- v2.9.1: safety net for the deferred panel-layout load -- if game.ready
    -- fired before this mod registered its handler (a hot-reload mid-game), pull
    -- the stored layout here the first frame the overlay actually runs.
    -- Self-guards: no-ops once loaded (C.panelCfgLoaded) or until C.game exists.
    C.loadPanelCfgNow()
    local W, H = love.graphics.getDimensions()
    s = (H / REF_H) * UI_SCALE_OVERLAY
    -- Design-space canvas height, used a couple of spots below (availH,
    -- drawEditHUD's Y). Equivalent to the old `REF_H / UI_SCALE_OVERLAY`
    -- shortcut (H/REF_H and REF_H's own H-dependence cancel out) but
    -- computed directly from H/s instead -- one less thing to keep in
    -- sync if s's formula ever changes again.
    local canvasH = H / s
    -- With touch nav on, the overlay panels sit on top of the touch controls
    -- and hide them, so render the whole overlay to an offscreen canvas and
    -- composite it back at reduced alpha. That dims it as a single flat
    -- image -- the touch pad shows through uniformly, and every panel keeps
    -- its own internal contrast (text still reads against its background)
    -- instead of each draw call getting faded individually. Off (the
    -- default) draws straight to the screen exactly as before -- no canvas,
    -- no alpha change.
    local touchButtonsOn = mod.options:get("touch_nav_buttons") or mod.options:get("touch_icon_buttons")
    -- Session 100: a manual, always-available version of the same
    -- dimming, for players who find a fully solid overlay intrusive
    -- during normal play even without touch nav/icon buttons on. Just
    -- another OR term -- touchButtonsOn already forces this on
    -- regardless, so the manual option is a harmless no-op whenever
    -- that's already true (see its own definition/comment above for why
    -- that's the deliberate design rather than trying to grey it out).
    local manualTransparency = mod.options:get("overlay_transparency")
    -- v60: the opt-out for touchButtonsOn's own forced dim (Seiya's
    -- original report -- see keep_overlay_opaque's definition above).
    -- Only touchButtonsOn is conditional on it; FORCE_DIM_OVERLAY (dev
    -- testing only) and manualTransparency (an explicit "dim it" request)
    -- both stay unconditional, same as before.
    local keepOpaque = mod.options:get("keep_overlay_opaque")
    local dimOverlay = FORCE_DIM_OVERLAY or manualTransparency or (touchButtonsOn and not keepOpaque)
    -- TEMP DIAGNOSTIC: was one-shot at battle-enter, but that frame turned
    -- out to often land AFTER the crash (st.battle apparently flips only
    -- once the transition/wipe finishes loading, and the crash has been
    -- landing during that wipe, before this ever fired). Now recomputed
    -- every frame instead, so whatever's on screen in the last frame the
    -- recorder captured before a crash is hard evidence of exactly what
    -- state the overlay was in -- no reliance on catching one special frame.
    do
      local inBattle = st.battle and true or false
      local orient = W > H and "landscape" or "portrait"
      C.diagFrame = (C.diagFrame or 0) + 1
      local canvasInfo = "none"
      if overlayCanvas then
        local cw, ch = overlayCanvas:getWidth(), overlayCanvas:getHeight()
        local dpi = overlayCanvas.getDPIScale and overlayCanvas:getDPIScale() or -1
        canvasInfo = string.format("%dx%d dpiscale=%.2f (~%.1fMB RGBA8)", cw, ch, dpi, (cw*ch*4)/1048576)
      end
      -- Mirror this on screen every frame (persistent, no fade) since the
      -- crash can happen before there's any chance to pull logcat, and the
      -- tester needs to screen-record and send back the last visible frame.
      C.battleDiagText = string.format(
        "win=%dx%d (%s)  dim=%s(forced=%s btn=%s)  f=%d\nbattle=%s  panel=%s  canvas=%s",
        W, H, orient, tostring(dimOverlay), tostring(FORCE_DIM_OVERLAY), tostring(touchButtonsOn), C.diagFrame,
        tostring(inBattle), inBattle and "battle" or "route", canvasInfo
      )
      if inBattle and not wasInBattle then
        local rebuild = dimOverlay and (not overlayCanvas or overlayCanvas:getWidth() ~= W or overlayCanvas:getHeight() ~= H)
        mod.log:info(
          "kanto_companion DIAG battle-enter: window=%dx%d (%s) dimOverlay=%s existingCanvas=%s newFrameWillRebuild=%s",
          W, H, orient, tostring(dimOverlay), canvasInfo, tostring(rebuild)
        )
      end
      wasInBattle = inBattle
    end
    if dimOverlay then
      -- Previously forced dpiscale=1 here to pin the canvas's backing
      -- texture to exactly W x H real pixels, avoiding a (W*dpiscale) x
      -- (H*dpiscale) allocation on high-density screens. That traded
      -- memory for sharpness -- forcing this ONE canvas to render at a
      -- lower internal resolution than literally everything else on
      -- screen, then upscaling it back on composite. The comment here
      -- used to predict "some sharpness cost on very dense screens" and
      -- judge it acceptable since the overlay dims to 62% anyway -- in
      -- practice, on real devices (Pixel 10 Pro, Odin 2 Portal), that
      -- upscale blurred everything the canvas contains -- text, sprites,
      -- panel backgrounds, not just fine detail -- badly enough to be the
      -- single most reported visual issue in testing. Letting LÖVE use
      -- the device's real dpiscale (the default omitting this option)
      -- costs more VRAM on dense screens but renders crisp, matching
      -- every other draw call in the game -- worth it for a UI element
      -- meant to be read continuously during play, not just glanced at.
      -- Explicitly release the old texture before replacing it -- an
      -- orientation flip (or any WxH change) used to just drop the old
      -- canvas object and let Lua's GC get to it whenever, which could
      -- leave the old texture resident in GPU memory well after the new
      -- one is allocated. release() frees it immediately instead.
      if not overlayCanvas or overlayCanvas:getWidth() ~= W or overlayCanvas:getHeight() ~= H then
        if overlayCanvas then overlayCanvas:release() end
        overlayCanvas = love.graphics.newCanvas(W, H)
      end
      love.graphics.push("all")
      love.graphics.setCanvas(overlayCanvas)
      love.graphics.clear(0, 0, 0, 0)
    else
      -- Buttons off: nothing this frame needs the canvas, but a PRIOR frame
      -- (earlier in this same session, maybe a different orientation) may
      -- have left one allocated -- it was never freed just because dimming
      -- stopped being used. Release it now so a buttons-off session has
      -- zero canvas footprint, not just zero canvas *use*.
      if overlayCanvas then overlayCanvas:release(); overlayCanvas = nil end
      love.graphics.push("all")
    end
    love.graphics.origin()
    -- Same reasoning as C.drawScreen's identical restructure: the pcall at
    -- the call site (in the main love.draw hook) can't protect the push()
    -- above from an unmatched pop() if anything below throws -- it would
    -- leak one extra push every frame the error recurs, until the engine's
    -- own render pipeline hits its stack limit and crashes for real. This
    -- inner pcall means the pop() a few lines down always runs regardless.
    local overlayOk, overlayErr = pcall(function()
    local margin = 28
    -- Design-space canvas height -- see canvasH's own comment above (Session
    -- 80) for why this now reads the precomputed H/s instead of the old
    -- REF_H/UI_SCALE_OVERLAY shortcut -- so this is the real amount of
    -- vertical room either column has.
    local availH = canvasH - margin * 2
    -- v2.9.5 portrait mode, Stage 1 -> Stage 2 (direct reports across two
    -- rounds of real-device screenshots). Round 1 (screenshots): the
    -- landscape two-column layout is unusable in portrait -- every
    -- right-column panel's default `rightEdge - width` math goes strongly
    -- negative in a narrow window, pushing Trainer/Items/Route/Battle
    -- mostly off the left edge simultaneously. Fixed with a page carousel
    -- over the same 4 panels (PANEL_KEYS), swiped via input.pointer (see
    -- the swipe-tracking block there). Round 1 SHOWED TWO panels at once
    -- (one per band, top+bottom) -- Round 2 screenshots showed that's
    -- still one too many for comfortable reading, AND that stacking a
    -- second panel low enough to reach the touch-icon row's own screen
    -- position was occluding those buttons once real content (not just
    -- the boot splash) started drawing there. Round 2 also showed
    -- Round 1's battle exclusion was wrong: the landscape battle layout
    -- (Active Party drawn on top of the live FIGHT/ITEM/RUN box, both
    -- panels semi-transparent, totally illegible -- confirmed on a real
    -- screenshot) is just as broken as the overworld case was, so portrait
    -- now uses this SAME single-panel carousel whether a battle is live or
    -- not, rather than falling back to the landscape layout during battle.
    -- ONE panel now, always anchored to the single top band. bandH is
    -- sized from the REAL measured letterbox fraction (render.hud viewport
    -- probe, Galaxy S23 Ultra: gameY=276.48 of window height=882, i.e. the
    -- safe letterbox-only zone is ~31% of the window) rather than an
    -- arbitrary half- or two-thirds-split guess -- Stage 1's `(availH-gap)
    -- /2` (~49% of availH) was ALREADY more generous than this real
    -- boundary, which this file's shrink-to-fit-then-floor pattern
    -- (MIN_FIT_SCALE) doesn't protect against on its own: it only shrinks
    -- an oversized panel DOWN to whatever budget it's given, so a budget
    -- bigger than the real safe space risks a genuinely tall panel
    -- (Trainer's badge grid, say) growing past the real letterbox boundary
    -- and back into the game/battle view -- exactly the failure this
    -- feature exists to avoid. canvasH is a fixed design-space constant
    -- (~REF_H, independent of the live device/orientation -- see canvasH's
    -- own derivation above), so multiplying it by the real, device-
    -- specific safe FRACTION gives a properly-scaled design-space budget;
    -- 0.30 rounds slightly under the measured 0.3135 as a small safety
    -- margin. This fraction is specific to the one device measured so
    -- far -- a phone with a meaningfully different aspect ratio may need
    -- retuning, a known follow-up rather than solved generally here.
    local isPortrait = H > W
    -- Mirrored onto C so drawEditablePanel's cfg.pos orientation check
    -- (see its own comment) can read it without a new parameter threaded
    -- through all 4 call sites -- same "cross-scope helper" reasoning
    -- C.canEditHere/C.editOpen already use.
    C.isPortrait = isPortrait
    local canvasW = W / s
    -- v2.9.5 fix, direct report: "hard or impossible to grab the scroll
    -- bar when the party screen is at the default full width... all the
    -- screens that are currently matching the width of the screen by
    -- default should be a little bit less wide for exactly this reason."
    -- COLW is already comfortably under canvasW at the default scale
    -- (nothing forces a shrink in the common case), so a tighter CEILING
    -- alone wouldn't change anything there -- this is a flat multiplier
    -- applied to every panel's baseline width below, not just a fallback
    -- constraint, so the default case actually gets smaller too. Likely
    -- reason a full-width panel's own right edge was hard to grab at all:
    -- close enough to the real screen edge that a phone's own gesture-
    -- navigation zone can swallow the touch before this mod ever sees it
    -- -- inference, not confirmed against this specific device, but
    -- reserving real margin is the safe move either way. Applies to all 4
    -- panels below, not just Party, since the user's own ask generalized
    -- it to "all the screens."
    local PORTRAIT_SAFE_SCALE = 0.88
    -- Still kept as a hard ceiling too (defense in depth): an extreme
    -- manual cfg.scale should never be ABLE to reach the true screen edge
    -- regardless of the flat multiplier above.
    local canvasWSafe = canvasW - 80
    -- v2.9.5, direct request after the scissor-clip fix above ("extend the
    -- panel area to about half way where the information is currently
    -- extending past it"): 0.30 -> 0.36, a rough eyeball of "roughly
    -- halfway" from the reported screenshot, not a precise measurement.
    -- Left real headroom before the touch-nav row's own default target Y
    -- (0.40 * wh, see touchGroupOffset's portrait branch) rather than
    -- pushing further and risking a new collision there -- if more room is
    -- still wanted, the touch-nav/icon defaults would need to move too.
    local bandH = canvasH * 0.36 - margin
    local topBandY = margin
    C.portraitPage = C.portraitPage or 1
    local portraitPageA = PANEL_KEYS[C.portraitPage]
    -- Per-panel band-fit scale (same shrink-to-fit-then-floor shape pScale/
    -- rScale below already use, just against one panel's own natH and the
    -- band's height instead of the combined landscape column) is computed
    -- inline at each use site below rather than as a shared helper -- no
    -- new `local function` here, matching this file's standing
    -- 200-local-ceiling rule (see the touch-exit fix above for the same
    -- reasoning).

    -- LEFT: party. Prefer the configured density at full size; if a full
    -- party doesn't fit, shrink it uniformly; if it would have to shrink
    -- past the readability floor, drop to the compact density instead
    -- (which still shows every mon, just without move lists). Height
    -- comes directly from party()'s own arithmetic (measureOnly=true
    -- skips straight to `return h` before any drawing) -- no zero-area
    -- scissor measure pass needed at all anymore. See the removed dryRun
    -- function's old comment block for why that mattered. Party has its
    -- own style-1-vs-2 fallback that doesn't generalize to the other
    -- panels, so that part stays inline; the actual draw-or-collapse
    -- step below it uses the same shared helper the right column's three
    -- regions do.
    --
    -- Session 86: Session 85 removed this automatic fallback on a
    -- suspicion it was interfering with testing elsewhere -- it wasn't.
    -- Without it, a full 6-mon party with movesets can be genuinely
    -- taller than the screen even at MIN_FIT_SCALE (0.72), and forcing
    -- style 1 unconditionally meant that height was ALWAYS what got
    -- measured -- confirmed on direct report: the party box stretched
    -- off-screen on reset (which sets scale=1, pos=false -- the exact
    -- "worst case" baseline this fallback exists to catch) and behaved
    -- oddly while scaling, both symptoms of the same missing safety net.
    -- Restored verbatim; only the automatic behavior comes back here --
    -- the old manual F7 toggle (Session 84) stays gone.
    --
    -- Session 88: `C.partyStyle` -- the field this used to prefer -- has
    -- had no write path at all since Session 84 removed F7 (nothing ever
    -- set it to 2), so it was silently dead: party could only ever reach
    -- the compact density via the automatic fallback above, never by
    -- choice. On direct report ("no B screen in the collapse/expand
    -- matrix"), replaced with `C.panelCfg.left.compact` -- the same field
    -- Trainer's compact view already uses (see SUPPORTS_COMPACT near
    -- clamp01Scale), reachable through the exact same C/I,X/P,Y controls
    -- and the touch collapse icon. Starting pStyle at 2 when compact is
    -- set skips straight to the compact measurement; the automatic
    -- fallback below still applies on top of that if even the compact
    -- view somehow doesn't fit (same `math.max(..., MIN_FIT_SCALE)` floor
    -- either way). `C.partyStyle` itself is removed -- nothing reads it
    -- for real anymore (party()'s own fallback read of it was already
    -- unreachable dead code, since every real call site always passes an
    -- explicit styleOverride).
    -- v62: on direct request -- auto-shrink party to compact for the
    -- duration of a battle, and if it would still sit over the VANILLA
    -- game's own enemy HUD, move it below that box until the battle
    -- ends, restoring the original position/density afterward. Driven
    -- off st.battle every frame, like the rest of this function's sizing
    -- -- not a one-shot battle.started/ended event, for the same reason
    -- the diagnostic block above already documents (a one-shot
    -- battle-enter event isn't reliably on the right frame here).
    -- v65: on direct correction -- v64 only gated the REPOSITION step on
    -- dimOverlay; the auto-COMPACT step still fired unconditionally,
    -- which wasn't what was wanted. Rewritten around one continuous
    -- `wantOverride` flag so both compacting and repositioning share the
    -- same on/off condition, and so toggling a touch/transparency option
    -- mid-battle reacts immediately (pop back to normal the instant it
    -- becomes dimmed, re-engage the instant it's opaque again) rather
    -- than only being evaluated once at battle-start.
    -- v89: the per-panel edit-mode handoff that used to live here is gone --
    -- the unified snapshot/restore below handles battle layout for all four
    -- panels at once. Entering edit mode drops battleAdjust (inBattle requires
    -- not-editing), which PAUSES the auto-adjust; v90 keeps the snapshot alive
    -- through edit mode (restore only fires when the battle actually ends), so
    -- the panels stay frozen in their live battle layout for editing instead of
    -- snapping back to the pre-battle one.
    -- v66: gated on enemyHudVisible(), not just st.battle, so this only
    -- ever engages once the vanilla enemy HUD is actually on screen --
    -- see enemyHudVisible's own definition above for exactly what that
    -- checks and why. currentBattle() is this file's existing accessor
    -- (same one buildState() already uses), called fresh here since
    -- st.battle itself is buildState()'s flattened display data, not a
    -- reference to the live object this needs.
    -- v86 / v2.9.3: the old `and not dimOverlay` gate is GONE -- the dimmed
    -- party is still too hard to see the game info through, so it reduces/moves
    -- whether the overlay is opaque OR dimmed. This is the "auto-adjust
    -- regardless of transparency" fix: the public 2.9.x party adjust this block
    -- replaces was opaque-only (its wantOverride carried `and not dimOverlay`),
    -- which is exactly why it "didn't adjust when transparent." The unified
    -- battleAdjust flag below never gates on dim at all.
    -- v87 (Issue 2): LATCHED so it doesn't spring back at the VICTORY moment.
    -- Gating per-frame on enemyHudVisible retracted the instant the enemy
    -- fainted (enemy.fainted -> HUD gone), well before the battle scene
    -- actually cleared back to the overworld. Now: engage once the enemy HUD
    -- has first appeared this battle (still avoids reacting during the intro,
    -- v66's point), then STAY engaged until the battle itself ends -- st.battle
    -- stays true until the BattleState is popped off the stack (overworld
    -- again), not merely until a win is decided. C.battleHudSeen is the latch,
    -- reset whenever not in battle. Shared with the bottom-panel move below.
    local inBattle = st.battle and not C.overlayEdit.active
    if not inBattle then C.battleHudSeen = false
    elseif enemyHudVisible(currentBattle()) then C.battleHudSeen = true end
    -- v89: ONE unified snapshot/restore for EVERY panel, replacing the three
    -- separate per-panel overrides (party/trainer/bottom) that each saved a
    -- different subset of fields and had restore gaps -- a collapse tier not
    -- coming back, a mid-battle move surviving, and (the visible symptom) the
    -- Trainer left stuck off-screen so its relocation below never re-triggered.
    -- battleAdjust is the single "auto-adjust engaged" flag all three panels'
    -- nudges now share. When it first goes true we snapshot every panel's FULL
    -- state (pos/scale/compact/collapsed). We restore it verbatim only when the
    -- BATTLE ITSELF ENDS (st.battle goes false -> back in the overworld) -- NOT
    -- when the player opens edit mode mid-battle. v90 fix (direct report): edit
    -- mode used to trigger the restore, which snapped every panel from its live
    -- battle-adjusted spot/size back to the pre-battle layout the instant you
    -- opened edit mode -- so what you saw/edited never matched what was on screen
    -- a moment earlier (different position AND different collapse tier). Now the
    -- auto-adjust simply PAUSES in edit mode (battleAdjust excludes editing) and
    -- every panel stays frozen exactly where the battle left it, so edit mode
    -- shows the real battle layout; exiting resumes the adjust, and only leaving
    -- the battle restores the pre-battle layout. Purely in-memory (none of the
    -- nudges ever savePanelCfg), so the persisted layout is always the pre-battle
    -- one. Snapshot is taken BEFORE any adjust runs this frame, so it always
    -- captures the pristine pre-battle layout. The restore keys on `not st.battle`
    -- (the battle HUD leaving -> overworld), NOT on a victory/win state -- same
    -- "leaving the battle" trigger the latch above uses for entering.
    local battleAdjust = inBattle and C.battleHudSeen
    if battleAdjust then
      if not C.battleSnapshot then
        C.battleSnapshot = {}
        for _, k in ipairs(PANEL_KEYS) do
          local c = C.panelCfg[k]
          C.battleSnapshot[k] = { pos = c.pos, scale = c.scale, compact = c.compact, collapsed = c.collapsed }
        end
      end
    elseif C.battleSnapshot and not st.battle then
      for _, k in ipairs(PANEL_KEYS) do
        local snap, c = C.battleSnapshot[k], C.panelCfg[k]
        c.pos, c.scale, c.compact, c.collapsed = snap.pos, snap.scale, snap.compact, snap.collapsed
      end
      C.battleSnapshot = nil
    end
    if battleAdjust then C.panelCfg.left.compact = true end
    local pStyle = C.panelCfg.left.compact and 2 or 1
    local natH = party(st, margin, margin, pStyle, true)
    local pScale = 1
    if natH > availH then
      pScale = availH / natH
      if pScale < MIN_FIT_SCALE and pStyle == 1 then
        pStyle = 2
        natH = party(st, margin, margin, pStyle, true)
        pScale = natH > availH and math.max(availH / natH, MIN_FIT_SCALE) or 1
      else
        pScale = math.max(pScale, MIN_FIT_SCALE)
      end
    end
    -- v62 continued: now that natH/pScale reflect the (possibly forced-
    -- compact) size above, check whether party's real on-screen box
    -- still overlaps the enemy HUD's real on-screen box and, if so, move
    -- it just below that box. Reads C.panelCfg.left.pos fresh each time
    -- (rather than caching "already moved") so this self-corrects if the
    -- letterbox changes mid-battle (window resize/rotation) and simply
    -- no-ops once the current position no longer overlaps, including
    -- after it's already been moved once this battle.
    -- v86 / v89 / v2.9.3: moves regardless of dim now -- the dimmed party is
    -- still too hard to see the game info through, so it gets out of the enemy
    -- HUD's way whether the overlay is opaque or dimmed. Gated on the shared
    -- battleAdjust flag (which already excludes edit mode); the old v64/v65
    -- `not dimOverlay` / battlePartyOverride reasoning no longer applies (the
    -- override this replaced was the opaque-only one).
    if battleAdjust then
      local pcfg = C.panelCfg.left
      local px = (pcfg.pos and pcfg.pos.x) or margin
      local py = (pcfg.pos and pcfg.pos.y) or margin
      local totalScale = pScale * pcfg.scale
      local pRight, pBottom = px + COLW * totalScale, py + natH * totalScale
      -- v67: pass the real layout the vanilla battle screen is actually
      -- using (classic vs. the player's own "BATTLE LAYOUT: WIDE" save
      -- option) so enemyHudDesignRect uses the matching width fraction --
      -- see its own definition above for why these differ. Read fresh
      -- from the live battle object each time, same as enemyHudVisible
      -- above, rather than assumed/cached.
      local liveBattle = currentBattle()
      -- v2.9.2 (Gen 2 crash fix): isWideBattleLayout is a GEN 1-ONLY method --
      -- confirmed absent from Gen 2's real Battle.lua/BattleState.lua source (no
      -- stub, nothing) -- so a bare `liveBattle:isWideBattleLayout()` would
      -- error "attempt to call a nil value" the instant a real battle starts on
      -- a Gen 2 save. Existence-checked, matching this file's own defensive
      -- pattern elsewhere (e.g. C.VideoMode.isMobile). Gen 2's HUD geometry is
      -- confirmed (real source, src/ui/gen2/BattleHud.lua +
      -- src/ui/gen2/BattleState.lua) to match the CLASSIC (non-wide) fractions
      -- almost exactly -- "wide battle layout" is a Gen-1-only mod option with
      -- no Gen 2 equivalent -- so falling through to `false` here (the classic
      -- fraction) is not a guess, it's the correct value for Gen 2 either way.
      local isWide = liveBattle and liveBattle.isWideBattleLayout
        and liveBattle:isWideBattleLayout()
      local hudL, hudT, hudR, hudB = enemyHudDesignRect(C.letterbox, s, isWide)
      -- v2.9.5, direct request: battle auto-adjust disabled for portrait --
      -- it exists to dodge landscape's enemy HUD position, which portrait's
      -- single top-anchored, centered panel (see "left" above) doesn't
      -- need automatic help avoiding. Left alone, cfg.pos simply stays
      -- whatever it already was (nil/false by default), so the panel falls
      -- back to its normal centered-top position -- the user can still
      -- drag it elsewhere manually if they want; this only removes the
      -- automatic override.
      if hudL and not isPortrait and rectsOverlap(px, py, pRight, pBottom, hudL, hudT, hudR, hudB) then
        pcfg.pos = { x = px, y = hudB + 8, portrait = C.isPortrait }
      end
      -- v90: publish the party's FINAL on-screen box (after any move above) so
      -- the Trainer's battle relocation below can avoid dropping onto it -- the
      -- party lives on the left during a battle, so the Trainer's left-edge
      -- fallback spots would otherwise land right on top of it. Field on C, not
      -- a drawOverlay local, and recomputed every battle frame; only read by the
      -- relocation while battleAdjust, so a stale value out of battle is inert.
      local fpx = (pcfg.pos and pcfg.pos.x) or margin
      local fpy = (pcfg.pos and pcfg.pos.y) or margin
      C.battlePartyBox = { fpx, fpy, fpx + COLW * totalScale, fpy + natH * totalScale }
    end
    if isPortrait then
      -- v2.9.5 portrait Stage 2: only drawn at all if this page carousel
      -- position happens to be "left" this frame -- see the block above
      -- local isPortrait for the full reasoning. Applies during battle
      -- too now, not just the overworld (Stage 1's exclusion is gone).
      if portraitPageA == "left" then
        -- v2.9.5 fix, root-caused via direct evidence (Odin's own save
        -- data confirmed EVERY panel's cfg.pos was already false -- the
        -- earlier "stale cross-orientation drag" theory, while a real and
        -- worthwhile fix on its own, was not actually why panels were
        -- still overflowing after it shipped). The real cause:
        -- drawEditablePanel multiplies whatever scale this passes by
        -- cfg.scale (the panel's own persisted MANUAL scale) before
        -- drawing -- confirmed by reading its body directly. This fit
        -- calculation only ever budgeted against bandH (height); it never
        -- accounted for cfg.scale at all, so a manual scale set at any
        -- point in this file's 90+ session history (harmless in
        -- landscape's much wider column) could still push the real width
        -- past canvasW in portrait's much tighter one. Width is now a
        -- hard constraint (never exceed canvasW) layered on top of the
        -- existing height-based, MIN_FIT_SCALE-floored fit -- whichever
        -- is tighter wins, same shape the engine's own Renderer:fitScale
        -- uses (min of two axis constraints). Also now centers
        -- horizontally instead of a fixed left margin, closing the
        -- "doesn't sit nicely centered" report together with the same
        -- math.
        -- v2.9.5, direct request (round 2): scrolling is FULL-style only
        -- (pStyle==1) -- direct report that reduced/compact was "messed
        -- up" too, and that it never needed scrolling or capping at all,
        -- "leave that how it was." Reduced rows are short enough to
        -- already read fine shrunk, unlike full's movesets/XP lines, so
        -- it goes back to exactly its pre-scrollbar behavior (height
        -- shrink-to-fit, no scroll params passed to party() at all --
        -- nil there is a real value, not just an omission, since party()
        -- treats a nil maxVisibleH as "old unbounded behavior" by design).
        local pFitScale
        local pMaxVisibleH, pScrollY
        if pStyle == 1 then
          pFitScale = PORTRAIT_SAFE_SCALE
          pMaxVisibleH, pScrollY = bandH, (C.partyScrollY or 0)
        else
          pFitScale = natH > bandH and math.max(bandH / natH, MIN_FIT_SCALE) or 1
          pFitScale = pFitScale * PORTRAIT_SAFE_SCALE
        end
        local pWidthFit = canvasWSafe / (COLW * C.panelCfg.left.scale)
        if pWidthFit < pFitScale then pFitScale = pWidthFit end
        local pX = (canvasW - COLW * pFitScale * C.panelCfg.left.scale) / 2
        C.partyScrollY = C.partyScrollY or 0
        drawEditablePanel(pX, topBandY, "left", "Active Party", pMaxVisibleH and math.min(natH, pMaxVisibleH) or natH, pFitScale, false,
          function(x, y, totalScale) return function() return party(st, x, y, pStyle, false, pMaxVisibleH, pScrollY, totalScale) end end)
      end
    else
      -- Anchored to the left column's own top-left corner, which is
      -- already the screen's left edge -- correct as-is, no pivot change
      -- needed here (unlike the right column below).
      drawEditablePanel(margin, margin, "left", "Active Party", natH, pScale, false,
        function(x, y) return function() return party(st, x, y, pStyle) end end)
    end

    -- RIGHT: trainer, items, and the route-or-battle slot at the bottom --
    -- split into three independently collapsible/scalable regions
    -- (Session 51), each still pivoting from its own top-right corner so
    -- it stays anchored to the screen's right edge regardless of its own
    -- scale, same fix as before, just now applied per-region instead of
    -- once for the whole bundle. They still share one auto-fit baseline
    -- scale, computed from their combined natural height exactly like
    -- before the split -- the three of them still shrink together if
    -- they don't fit, with each one's own manual scale layered on top of
    -- that shared floor, not replacing it.
    local rx = (W / s) - COLW - margin
    local rightEdge = rx + COLW
    -- v86/v89: auto-reduce the Trainer panel to its COMPACT view for the
    -- battle. v89 drives this off the shared battleAdjust flag -- so its full
    -- pre-battle state (full/compact/collapsed AND pos, which the relocation
    -- below can change) is captured and restored by the unified snapshot up in
    -- the party block, not a separate per-panel override. Forces compact and
    -- clears any collapse so the panel is actually on screen to be relocated.
    -- Now latched to the enemy HUD like party (it compacts the moment the HUD
    -- appears rather than at the intro), which also means it no longer flickers
    -- back to full on a mid-battle faint (the latch holds until the battle
    -- truly ends). Must run before trainerEffH / stackContribution below read
    -- cfg.compact.
    -- Reworked on direct request 2026-08-19: Trainer used to shrink to
    -- compact and only relocate/hide if that still overlapped the Battle
    -- panel, while Items just sat in its normal stacked slot the whole
    -- time -- which read as Items silently losing its space whenever the
    -- shrink-and-maybe-hide dance ate the room it needed. Simpler swap:
    -- Trainer now hides outright, unconditionally, for the whole battle.
    -- The unified snapshot above already captures/restores every panel's
    -- pos/scale/compact/collapsed regardless of WHAT mutates it mid-battle,
    -- so this still returns Trainer to its exact pre-battle state the
    -- instant the battle ends -- no changes needed to that mechanism.
    -- Items now inherits the find-a-clear-spot-or-hide-as-last-resort
    -- logic that used to be Trainer's (see below, near the Battle-panel
    -- move) -- same candidate list, same Gen 2 guard, just retargeted.
    if battleAdjust then
      C.panelCfg.trainer.compact, C.panelCfg.trainer.collapsed = false, true
    end
    local trainerNatH = trainer(st, rx, margin, true)
    -- Session 82: measured separately from trainerNatH above, which stays
    -- the FULL-view height on purpose -- combinedNatH/rScale and the
    -- itemsDefaultY/bottomDefaultY stacking below all keep using the full
    -- height regardless of collapsed/compact state, exactly like they
    -- already did for collapsed before this (not something this pass
    -- changes). trainerCompactH is only used just below, to size THIS
    -- panel's own drawn box correctly when it's actually showing the
    -- compact view.
    local trainerCompactH = trainer(st, rx, margin, true, true)
    local itemsNatH = items(st, rx, margin, true)
    -- Bugfix, Session 63: this used to close over `rx` (the column's
    -- default position) directly instead of taking x as an argument --
    -- meaning even a drag-aware caller had no way to actually move this
    -- panel's real content, since there was no x parameter to pass a
    -- dragged position through in the first place. Now takes x like
    -- every other panel function does.
    local function bottomFn(x, y, measureOnly)
      if st.battle then return battle(st, x, y, measureOnly) end
      return route(st, x, y, measureOnly)
    end
    local bottomNatH = bottomFn(rx, margin, true)
    local combinedNatH = trainerNatH + 16 + (itemsNatH > 0 and (itemsNatH + 16) or 0) + bottomNatH
    local rScale = combinedNatH > availH and math.max(availH / combinedNatH, MIN_FIT_SCALE) or 1

    -- Session 69: Sessions 67/68 both tried to make trainer/items/bottom
    -- aware of each other's CURRENT state (67: skip a dragged panel's
    -- slot entirely -- caused the "snaps to upper right" jump; 68:
    -- restore pos when a pinch cancels a drag -- fixed the original
    -- report, but live scale coupling was still there underneath and
    -- is what actually produced the "windows moving in relation to
    -- each other... funky in practice" feedback with pinch now in the
    -- mix). The real source of ALL of this is drawEditablePanel's
    -- return value being natH * totalScale -- totalScale includes live
    -- cfg.scale -- so pinching ANY right-column panel reactively
    -- shifted every panel below it in real time via ry. On direct
    -- request: removed entirely, not patched again. Each panel's
    -- DEFAULT (non-dragged) position is now a fixed offset computed
    -- once per frame from the other panels' unscaled natH only (their
    -- actual on-screen size before baseScale/cfg.scale is applied,
    -- which never changes with pinch/keyboard scale, only with real
    -- content differences like party size) -- not from drawEditablePanel's
    -- scaled return value. Panels no longer see or react to each
    -- other's live scale OR drag state at all. Positioning them
    -- relative to each other, if wanted, is now entirely up to the
    -- user via drag -- exactly the ask.
    --
    -- Session 81 bugfix: this dropped `rScale` (the shared auto-fit
    -- shrink from line ~3323) along with `cfg.scale`, but the two aren't
    -- the same kind of scale. cfg.scale is per-panel and reactive --
    -- exactly what Session 69 above needed to exclude. rScale is shared
    -- by all three right-column panels and is recomputed fresh each frame
    -- purely from their unscaled natH (real content size), never from any
    -- panel's own manual pinch/drag/keyboard scale -- so multiplying by
    -- it here doesn't reintroduce Session 69's reactivity bug. Without
    -- it, whenever content didn't fit (rScale < 1) the panels were drawn
    -- smaller but the gaps between them were still computed from their
    -- FULL unscaled height -- confirmed from a real screenshot: the
    -- bottom (Route/Battle) panel's default Y ended up past the bottom
    -- of the screen entirely. Multiplying each height by rScale here
    -- keeps the stacking in sync with what's actually drawn.
    -- Session 83 bugfix: same category of bug as Session 81 above, just a
    -- different cause -- trainerNatH/itemsNatH here are always the FULL,
    -- expanded-view heights, regardless of whether that panel is actually
    -- collapsed (a fixed 34-tall bar) or, for Trainer, compact. So a
    -- collapsed/compact panel still reserved a full-size gap for whatever
    -- comes after it, leaving a large empty space above Items (or Route/
    -- Battle) any time Trainer or Items was shrunk down. Fixed the same
    -- way as Session 81: use each panel's actual current stacking height
    -- instead of always assuming full. Deliberately still excludes
    -- cfg.scale (Session 69's point stands -- a panel's own manual
    -- pinch/resize must never move anything below it); 34 (the collapsed
    -- bar's fixed content height, same constant drawEditablePanel's own
    -- collapsed branch uses) and trainerCompactH are the only two new
    -- ingredients, both non-reactive to any single panel's manual scale.
    --
    -- Session 92: a fully-collapsed panel is now invisible outside edit
    -- mode entirely (see drawEditablePanel's collapsed branch), not just
    -- a thin bar -- so its stacking contribution has to become 0 too,
    -- not the bar's fixed 34, or the panel after it would still leave a
    -- blank gap where an invisible bar used to reserve space. The +16
    -- gap between panels is likewise skipped when a panel contributes
    -- nothing, so two panels either side of a fully-hidden one sit
    -- directly adjacent -- exactly what "getting rid of" a section
    -- should look like. While edit mode IS active the bar (34) is back,
    -- same as before this session.
    local function stackContribution(cfg, fullH, compH)
      if cfg.collapsed then
        return C.overlayEdit.active and 34 or 0
      elseif cfg.compact and compH then
        return compH
      else
        return fullH
      end
    end
    local trainerStackH = stackContribution(C.panelCfg.trainer, trainerNatH, trainerCompactH)
    local itemsStackH = stackContribution(C.panelCfg.items, itemsNatH, nil)
    local itemsDefaultY = margin + trainerStackH * rScale + (trainerStackH > 0 and 16 or 0)
    local bottomDefaultY = itemsDefaultY + (itemsNatH > 0 and (itemsStackH * rScale + (itemsStackH > 0 and 16 or 0)) or 0)
    -- Session 82: the box drawEditablePanel draws/highlights/hit-tests
    -- (w/h, edit highlight, resize-corner hitboxes) has to match whatever
    -- trainer() is ACTUALLY drawing right now, or the corner grips and
    -- highlight border would sit at the old full-size box's edges while a
    -- shorter compact panel renders underneath them. trainerEffH picks
    -- whichever height applies; the draw closure passes cfg.compact
    -- through to trainer() so the two stay in sync.
    local trainerEffH = C.panelCfg.trainer.compact and trainerCompactH or trainerNatH
    -- v88 (Issue 1): the Trainer draws AFTER the Battle-panel move + Trainer
    -- relocation below, so it can react to the moved Battle panel THIS frame
    -- (it used to draw here, before that logic ran).
    -- Items' draw call moved from here down to just after the relocation
    -- decision below (same "draws after the decision, so it reacts the
    -- same frame" fix v88 already applied to Trainer once, now inherited
    -- along with the relocation logic itself) -- see the comment there.
    -- v86/v88: the bottom "Battle" panel's battle-time avoidance of the
    -- vanilla PLAYER HUD (bottom-right of the viewport, see C.playerHudDesignRect):
    -- if it overlaps that box, move it clear -- BELOW if there's room under the
    -- HUD, else ABOVE ("whichever fits"). Its final on-screen box is kept in
    -- bBox* so the Trainer avoidance just below can react to it this same frame
    -- (v88 reorder). Same save-once / restore-after / self-correcting pattern
    -- as the party override; also applies when dimmed. v89: gated on the shared
    -- battleAdjust flag; the bottom panel's pre-battle pos is captured/restored
    -- by the unified snapshot in the party block.
    local bBoxL, bBoxT, bBoxR, bBoxB
    if battleAdjust then
      local bcfg = C.panelCfg.bottom
      local btotal = rScale * bcfg.scale
      -- same box derivation drawEditablePanel uses: dragged -> cfg.pos top-left,
      -- else anchor-right at rightEdge (left = rightEdge - COLW*totalScale).
      local bLeft = (bcfg.pos and bcfg.pos.x) or (rightEdge - COLW * btotal)
      local bTop  = (bcfg.pos and bcfg.pos.y) or bottomDefaultY
      local bW, bH = COLW * btotal, bottomNatH * btotal
      local liveBattle = currentBattle()
      -- v2.9.3 (Gen 2 crash guard): existence-check isWideBattleLayout, a Gen
      -- 1-only method (see the party dodge / v2.9.2 note above) -- a bare call
      -- would crash the instant a Gen 2 battle starts. false = classic
      -- fractions, which Gen 2's player HUD matches exactly.
      local isWide = liveBattle and liveBattle.isWideBattleLayout
        and liveBattle:isWideBattleLayout()
      local phL, phT, phR, phB = C.playerHudDesignRect(C.letterbox, s, isWide)
      -- v2.9.5, direct request: same portrait exclusion as the party dodge
      -- above -- automatic HUD-avoidance repositioning is a landscape-only
      -- concern now that portrait has its own centered top-band default.
      if phL and not isPortrait and rectsOverlap(bLeft, bTop, bLeft + bW, bTop + bH, phL, phT, phR, phB) then
        local gap = 8
        local roomBelow = (canvasH - margin) - phB
        local roomAbove = phT - margin
        if roomBelow >= bH + gap then bTop = phB + gap
        elseif roomAbove >= bH + gap then bTop = phT - gap - bH
        elseif roomBelow >= roomAbove then bTop = phB + gap
        else bTop = phT - gap - bH end
        -- v90 fix (direct report: "battle screen is cut off at the top"): when
        -- the Battle panel is TALLER than the room on the chosen side (neither
        -- side truly fits), the "above" branch computes phT - gap - bH, which
        -- goes NEGATIVE and clips the panel's top off the screen. Clamp so the
        -- panel always stays fully on-screen -- top pinned to the margin at
        -- worst (accepting a small overlap with the player HUD it was dodging,
        -- which is the lesser evil vs. losing the panel's header off the top).
        bTop = math.max(margin, math.min(bTop, canvasH - margin - bH))
        bcfg.pos = { x = bLeft, y = bTop, portrait = C.isPortrait }
      end
      bBoxL, bBoxT, bBoxR, bBoxB = bLeft, bTop, bLeft + bW, bTop + bH
    end
    -- Retargeted from Trainer to Items 2026-08-19 (see the force-collapse
    -- comment above): if the moved Battle panel now overlaps Items, move
    -- Items out of the way rather than let it get shoved off-screen or
    -- hidden the instant center-top wasn't perfectly clear. Picks the
    -- first clear spot from an ordered candidate list; everything here is
    -- restored by the unified snapshot's saved pos/collapsed, same as
    -- every other panel. Runs BEFORE the Items draw just below, so it
    -- takes effect the same frame (the v88 fix this inherited).
    if battleAdjust and bBoxL and itemsNatH > 0 then
      local icfg = C.panelCfg.items
      local itotal = rScale * icfg.scale
      local iW, iH = COLW * itotal, itemsNatH * itotal
      local iL = (icfg.pos and icfg.pos.x) or (rightEdge - iW)
      local iT = (icfg.pos and icfg.pos.y) or itemsDefaultY
      -- v2.9.5, direct request: same portrait exclusion as the party/
      -- bottom dodges above.
      if not isPortrait and rectsOverlap(iL, iT, iL + iW, iT + iH, bBoxL, bBoxT, bBoxR, bBoxB) then
        local liveBattle = currentBattle()
        -- Gen 2 crash guard: same existence-check as the dodges above.
        local wide = liveBattle and liveBattle.isWideBattleLayout
          and liveBattle:isWideBattleLayout()
        local enL, enT, enR, enB = enemyHudDesignRect(C.letterbox, s, wide)
        local plL, plT, plR, plB = C.playerHudDesignRect(C.letterbox, s, wide)
        local cw, gap = W / s, 8
        local pb = C.battlePartyBox   -- party's live box (set in the left column above)
        -- usable if the whole iW x iH box is on-screen (inside the margins) and
        -- clears the enemy HUD, the player HUD, the moved Battle panel, and the
        -- party panel on the left.
        local function spotClear(x, y)
          if x < margin or y < margin or x + iW > cw - margin or y + iH > canvasH - margin then
            return false end
          if enL and rectsOverlap(x, y, x + iW, y + iH, enL, enT, enR, enB) then return false end
          if plL and rectsOverlap(x, y, x + iW, y + iH, plL, plT, plR, plB) then return false end
          if rectsOverlap(x, y, x + iW, y + iH, bBoxL, bBoxT, bBoxR, bBoxB) then return false end
          if pb and rectsOverlap(x, y, x + iW, y + iH, pb[1], pb[2], pb[3], pb[4]) then return false end
          return true
        end
        local ctX = (cw - iW) / 2
        -- Same upper-center-only band Trainer used to use, same reasoning
        -- (direct report: floating mid-screen read worse than hiding):
        -- true center-top first, then the clear band to either side of the
        -- enemy HUD / Battle panel. If none of the three fit, HIDE rather
        -- than float mid-screen.
        local cand = {
          { ctX, margin },                    -- 1 center-top (upper-center)
          { (enR or margin) + gap, margin },   -- 2 top row, right of enemy HUD
          { bBoxL - gap - iW, margin },        -- 3 top row, left of Battle panel
        }
        local placed = false
        for _, c in ipairs(cand) do
          if spotClear(c[1], c[2]) then icfg.pos = { x = c[1], y = c[2], portrait = C.isPortrait }; placed = true; break end
        end
        if not placed then icfg.collapsed = true end   -- nowhere on the top row fits
      end
    end
    if isPortrait then
      -- v2.9.5 portrait Stage 2: same single-page-carousel treatment as
      -- "left" above -- each of these three (previously always stacked
      -- together in the landscape right column) now only draws when it's
      -- actually this frame's page, left-anchored like everything else in
      -- portrait rather than right-anchored. Applies during battle too.
      if portraitPageA == "trainer" then
        -- v2.9.5: width-vs-cfg.scale fit + horizontal centering, same
        -- reasoning as "left" above -- now also PORTRAIT_SAFE_SCALE'd for
        -- real edge margin (see its own comment), same as all 4 panels.
        local tFitScale = trainerEffH > bandH and math.max(bandH / trainerEffH, MIN_FIT_SCALE) or 1
        tFitScale = tFitScale * PORTRAIT_SAFE_SCALE
        local tWidthFit = canvasWSafe / (COLW * C.panelCfg.trainer.scale)
        if tWidthFit < tFitScale then tFitScale = tWidthFit end
        local tX = (canvasW - COLW * tFitScale * C.panelCfg.trainer.scale) / 2
        drawEditablePanel(tX, topBandY, "trainer", "Trainer", trainerEffH, tFitScale, false,
          function(x, y) return function() return trainer(st, x, y, false, C.panelCfg.trainer.compact) end end)
      end
      if itemsNatH > 0 and portraitPageA == "items" then
        local iFitScale = itemsNatH > bandH and math.max(bandH / itemsNatH, MIN_FIT_SCALE) or 1
        iFitScale = iFitScale * PORTRAIT_SAFE_SCALE
        local iWidthFit = canvasWSafe / (COLW * C.panelCfg.items.scale)
        if iWidthFit < iFitScale then iFitScale = iWidthFit end
        local iX = (canvasW - COLW * iFitScale * C.panelCfg.items.scale) / 2
        drawEditablePanel(iX, topBandY, "items", "Items", itemsNatH, iFitScale, false,
          function(x, y) return function() return items(st, x, y) end end)
      end
      if portraitPageA == "bottom" then
        local bFitScale = bottomNatH > bandH and math.max(bandH / bottomNatH, MIN_FIT_SCALE) or 1
        bFitScale = bFitScale * PORTRAIT_SAFE_SCALE
        local bWidthFit = canvasWSafe / (COLW * C.panelCfg.bottom.scale)
        if bWidthFit < bFitScale then bFitScale = bWidthFit end
        local bX = (canvasW - COLW * bFitScale * C.panelCfg.bottom.scale) / 2
        drawEditablePanel(bX, topBandY, "bottom", st.battle and "Battle" or "Route", bottomNatH, bFitScale, false,
          function(x, y) return function() return bottomFn(x, y) end end)
      end
    else
      drawEditablePanel(rightEdge, margin, "trainer", "Trainer", trainerEffH, rScale, true,
        function(x, y) return function() return trainer(st, x, y, false, C.panelCfg.trainer.compact) end end)
      if itemsNatH > 0 then
        drawEditablePanel(rightEdge, itemsDefaultY, "items", "Items", itemsNatH, rScale, true,
          function(x, y) return function() return items(st, x, y) end end)
      end
      drawEditablePanel(rightEdge, bottomDefaultY, "bottom", st.battle and "Battle" or "Route", bottomNatH, rScale, true,
        function(x, y) return function() return bottomFn(x, y) end end)
    end
    -- v2.9.5 bugfix, direct request: page-dot indicator moved from a
    -- horizontal row near the bottom to a VERTICAL column on the LEFT
    -- edge of the screen, and now only visible for ~1s after an actual
    -- page change instead of being drawn constantly. C.portraitPageActivity
    -- is stamped only by real paging inputs (tap-to-jump and the swipe
    -- handler, both in the input.pointer hook) -- never by the lazy
    -- page-number init above -- so these can only ever appear as a direct
    -- RESULT of the user paging, never just from sitting in portrait mode.
    -- C.portraitDots doubles as the tap-to-jump hit-test table (see
    -- tryPortraitPageStart); going nil while hidden also correctly
    -- disables tapping an invisible dot, no separate flag needed there.
    local pagingActive = isPortrait and C.portraitPageActivity
      and (love.timer.getTime() - C.portraitPageActivity < 1.0)
    if pagingActive then
      local dotR, dotGap = 6, 18
      local dotsH = (#PANEL_KEYS - 1) * dotGap
      local dotX = 16
      local dotY0 = topBandY + (bandH - dotsH) / 2
      C.portraitDots = { x = dotX, y0 = dotY0, gap = dotGap, r = dotR, n = #PANEL_KEYS }
      for i = 1, #PANEL_KEYS do
        local lit = (PANEL_KEYS[i] == portraitPageA)
        love.graphics.setColor(lit and COL.gold or COL.dim)
        love.graphics.circle("fill", dotX, dotY0 + (i - 1) * dotGap, lit and dotR or dotR * 0.6)
      end
      love.graphics.setColor(1, 1, 1, 1)
    else
      C.portraitDots = nil
    end

    if C.overlayEdit.active then
      -- Previously anchored at the left column's own x (margin), which
      -- put it directly over the bottom of a tall/unscaled left panel --
      -- confirmed from a real screenshot, not assumed: at 100% scale, a
      -- full 6-mon party's own content reaches design-Y ~932, while the
      -- HUD (Y computed below) spanned ~878-928, a genuine overlap, not
      -- a flaw in the highlight's own height math (verified separately
      -- against the right column, which had no such conflict and was
      -- correct). Centered in the horizontal gap between the two columns
      -- instead -- open game-world space regardless of either panel's
      -- current height, so this can't collide with either one again.
      -- v68 fixed a magic-number height/position mismatch here; v69 goes
      -- further and removes the fixed size entirely -- drawEditHUD now
      -- measures and centers its own (variable, platform-conditional)
      -- content internally, so this call site just hands it an anchor
      -- (horizontal center, bottom edge) instead of a pre-computed box
      -- rect. See drawEditHUD's own definition above for the rest.
      local gapCenter = (margin + COLW + rx) / 2
      -- v2.9.5 fix, direct report + screenshot (Galaxy S23 Ultra, portrait):
      -- "the hint text is illegible and the reset row is unusable." Root
      -- cause: this anchors to canvasH - margin unconditionally -- fine in
      -- landscape, where nothing else lives down there, but in portrait the
      -- engine's own on-screen virtual D-pad/face-buttons occupy roughly
      -- the bottom 40%+ of the screen (confirmed on the actual screenshot,
      -- not guessed), and kanto has no visibility into that control's real
      -- bounds (grepped for any existing safe-area/touchpad-geometry
      -- concept -- none exists). The box was drawing UNDER those buttons,
      -- making both the hint text and the newest (reset-all) row
      -- unreadable and unreliable to tap. Reserve real headroom above that
      -- zone in portrait specifically -- a deliberately conservative
      -- estimate, easy to tune further from a follow-up screenshot if it's
      -- still not enough.
      local hudBottomY = C.isPortrait and (canvasH * 0.56) or (canvasH - margin)
      drawEditHUD(gapCenter, hudBottomY)
      -- Session 99: on direct request, reusing C.drawScreen's EXISTING
      -- stick-cursor visual verbatim (see its own comment, "Left-stick
      -- virtual cursor... only drawn while it's actually the thing in
      -- control") instead of the custom crosshair Session 98 built --
      -- that visual is already proven working on-device for Items/Party,
      -- so there was no reason to invent a new one for edit mode. Same
      -- gold ring + dot, same sizing, same C.stickActive-only gate.
      -- C.mx/C.my themselves are C.drawScreen-specific state (set from
      -- C.vcx/vcy there, at the top of that function) and aren't
      -- otherwise meaningful during drawOverlay, so computed fresh here
      -- the same way, from the same source (C.vcx/vcy) and the same
      -- formula. Placed here (inside the same pcall-protected,
      -- love.graphics.origin()-reset render pass every other panel in
      -- this function draws through) rather than in the outer love.draw
      -- wrapper, mirroring exactly where C.drawScreen's own copy sits
      -- relative to ITS render pass.
      if C.stickActive then
        local mx, my = (C.vcx or 0) / s, (C.vcy or 0) / s
        C.drawStickCursor(mx, my)
      end
    end
    end)
    love.graphics.pop()
    if not overlayOk and overlayErr ~= C.overlayBodyErr then
      C.overlayBodyErr = overlayErr
      mod.log:error("kanto_ingame overlay body: %s", tostring(overlayErr))
    end
    if dimOverlay then
      love.graphics.push("all")
      local compOk, compErr = pcall(function()
        love.graphics.origin()
        love.graphics.setCanvas()
        love.graphics.setColor(1, 1, 1, 0.62)
        love.graphics.draw(overlayCanvas, 0, 0)
        love.graphics.setColor(1, 1, 1, 1)
      end)
      love.graphics.pop()
      if not compOk and compErr ~= C.overlayCompErr then
        C.overlayCompErr = compErr
        mod.log:error("kanto_ingame overlay composite: %s", tostring(compErr))
      end
    end
  end

  -- Draws the two transparent left/right touch-nav buttons (see
  -- TOUCH_NAV_LEFT/RIGHT above) when the "TOUCH SCREEN NAV BUTTONS" mod
  -- option is on. Semi-transparent rounded rect + arrow so it reads clearly
  -- over any part of the game without blocking much underneath it. Purely
  -- visual pairing for TOUCH_NAV_LEFT/RIGHT -- the actual tap handling lives
  -- in the love.touchpressed wrapper further down.
  -- TEMP TESTING: small persistent tag in the top-left corner naming
  -- exactly which test build is running (see BUILD_TAG above). Raw window
  -- pixels, independent of `s`/whichever screen last set it, same as
  -- drawTouchNav/drawTouchIcons below -- and drawn every frame regardless
  -- of C.visible/C.screen, so it's visible from the plain overworld too,
  -- not just with the overlay open.
  -- Was drawn unconditionally during scroll-features testing to stop
  -- build-mismatch confusion between zips. Controlled by SHOW_BUILD_TAG
  -- (a plain code constant, see above) rather than DEBUG INPUT HUD --
  -- stacks below the diagnostic readout (battleDiagText, drawn further
  -- down) when that's also on, instead of overlapping it -- both would
  -- otherwise land in the same top-left corner.
  C.drawBuildTag = function()
    if not SHOW_BUILD_TAG then return end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return end
    local f = getFont(14)
    love.graphics.setFont(f)
    local pad, tw = 6, f:getWidth(BUILD_TAG)
    local topY = 4
    local c = _G.__KANTO_INGAME
    if mod.options:get("debug_input_hud") and c and c.battleDiagText then
      -- Matches battleDiagText's own box below: origin (6,6), height
      -- 14px/line + 6px padding -- sit just under it instead of guessing
      -- a fixed offset that would drift if that box's line count changes.
      local lineCount = select(2, c.battleDiagText:gsub("\n", "\n")) + 1
      topY = 6 + (14 * lineCount + 6) + 4
    end
    love.graphics.setColor(0, 0, 0, 0.55)
    love.graphics.rectangle("fill", 4, topY, tw + pad*2, f:getHeight() + pad*2 - 4, 4, 4)
    love.graphics.setColor(1, 1, 1, 0.85)
    love.graphics.print(BUILD_TAG, 4 + pad, topY + pad - 2)
    love.graphics.setColor(1, 1, 1, 1)
  end
  -- Shared by drawTouchNav/drawTouchIcons and their touchpressed handlers:
  -- true while something's held via touch on the Items screen, when these
  -- buttons don't do anything useful and are just extra accidental-tap risk
  -- (see the scroll arrows' own disable, same reasoning).
  local function heldBlocksTouchUI()
    local c = _G.__KANTO_INGAME
    return c and c.screen == "items" and c.held and not c.held.pad
  end
  -- Visible border around a draggable group while edit mode is active,
  -- same purpose as drawEditHighlight has for the real panels, but
  -- simpler (no selected-vs-not distinction -- both groups are always
  -- draggable at once, there's nothing to Tab-cycle between) and drawn
  -- in this row's own raw-pixel space rather than rrect/setc's
  -- design-unit one, for the same reason drawBtn/dim already avoid them.
  -- v81 port: bottom-corner resize grips for a touch group in edit mode --
  -- small white L-brackets hugging the group's current (offset + scaled)
  -- bounding-box corners, matching the real panels' own resize-handle
  -- language (see drawResizeHandles). `s` is safe to size against here:
  -- edit mode requires the overlay to be rendering, so `s` is fresh (same
  -- reason drawTouchGroupHighlight already uses it).
  local function drawTouchGroupGrip(which, ww, wh)
    local rx, ry, rw, rh = touchGroupRect(which, ww, wh)
    -- v2.9.5: same stale-`s` fix as touchGroupGripHit just below -- keeps
    -- the drawn bracket matching where the (now correctly-computed) hit
    -- zone actually is, right after a rotation.
    local scale = touchGroupScale(wh)
    local arm = math.max(10, 13 * scale)
    local th  = math.max(3, 4 * scale)
    local by  = ry + rh - 2
    love.graphics.setColor(1, 1, 1, 0.95)
    -- bottom-right bracket (arms point left + up)
    local brx = rx + rw - 2
    love.graphics.rectangle("fill", brx - arm, by - th, arm, th, th * 0.5, th * 0.5)
    love.graphics.rectangle("fill", brx - th, by - arm, th, arm, th * 0.5, th * 0.5)
    -- bottom-left bracket (arms point right + up)
    local blx = rx + 2
    love.graphics.rectangle("fill", blx, by - th, arm, th, th * 0.5, th * 0.5)
    love.graphics.rectangle("fill", blx, by - arm, th, arm, th * 0.5, th * 0.5)
    love.graphics.setColor(1, 1, 1, 1)
  end
  -- v81 port: generous invisible hit box around EACH bottom corner (small
  -- visible glyph, larger touch target -- same split the panels' own resize
  -- grips use). Returns "BR", "BL", or nil. BR is checked first, so it wins
  -- any overlap on a very narrow/shrunk group (same first-come priority the
  -- panels use).
  local function touchGroupGripHit(which, ww, wh, x, y)
    local rx, ry, rw, rh = touchGroupRect(which, ww, wh)
    -- v2.9.5 fix, direct report ("corners weren't resizing, would just
    -- slide left"): the shared `s` upvalue only refreshes when
    -- C.drawOverlay actually runs -- the same staleness the v76 fix above
    -- (see touchGroupDefaultRect's own comment) already root-caused and
    -- fixed for the rect geometry itself, but this hit-test margin was
    -- still reading raw `s` instead of touchGroupScale(wh)'s always-fresh
    -- equivalent. Right after a rotation, rx/ry/rw/rh (built from the
    -- CURRENT ww/wh) and this margin (built from a possibly-STALE `s`
    -- from the previous orientation) could disagree enough that the
    -- corner zone no longer lines up with where the corner is actually
    -- drawn -- a tap meant for it falls through to the group-drag zone
    -- instead, exactly the reported symptom.
    local scale = touchGroupScale(wh)
    local hit = math.max(26, 32 * scale)
    local pad = math.max(6, 7 * scale)
    local by  = ry + rh
    if x >= rx + rw - hit and x <= rx + rw + pad and y >= by - hit and y <= by + pad then return "BR" end
    if x >= rx - pad      and x <= rx + hit      and y >= by - hit and y <= by + pad then return "BL" end
    return nil
  end
  local function drawTouchGroupHighlight(which, ww, wh)
    if not C.overlayEdit.active then return end
    local rx, ry, rw, rh = touchGroupRect(which, ww, wh)
    local gold = COL.gold
    -- v2.9.5: same stale-`s` fix as touchGroupGripHit/drawTouchGroupGrip.
    love.graphics.setLineWidth(math.max(2, touchGroupScale(wh) * 1.5))
    love.graphics.setColor(gold[1], gold[2], gold[3], 0.9)
    love.graphics.rectangle("line", rx - 6, ry - 6, rw + 12, rh + 12, 10, 10)
    love.graphics.setColor(1, 1, 1, 1)
    drawTouchGroupGrip(which, ww, wh)
  end
  -- v72: drag-start/update/end for the two draggable button groups --
  -- mirrors updateDrag/endDrag's own shape (see TOUCH_GROUP_KEYS's
  -- comment above for why this is a small parallel system rather than
  -- folded into that one). Hit-tests the group's CURRENT bounding box
  -- (already-offset if previously dragged, so grabbing a moved group
  -- works from its new position, not the stale original one) in the
  -- same pixel space touchGroupOffset/touchGroupDefaultRect use.
  --
  -- Defined here (ahead of tryTouchNavButtons/the mouse+touch callback
  -- wiring/C.driveStickEditMode, all of which call these) rather than
  -- down next to tryTouchNavButtons where they're used first -- Lua's
  -- `local function` only creates the binding from that point forward,
  -- and C.driveStickEditMode (a plain closure assigned well before
  -- tryTouchNavButtons in this file) needs to close over the real
  -- locals, not fall through to an undefined global of the same name.
  --
  -- v73 fix, direct report ("highlighted gold, not selectable at all"):
  -- every call site had this checked AFTER tryEditPanelSelect, on the
  -- WRONG assumption that tryEditPanelSelect returns false on a miss the
  -- way tryTouchGroupDragStart itself does. It doesn't -- its very last
  -- line is an unconditional `return true` whenever `c and not c.screen
  -- and C.overlayEdit.active`, regardless of whether anything was
  -- actually hit (that's deliberate for ITS job: swallow every tap while
  -- edit mode is open so a miss-click can't fall through to the game
  -- underneath). That meant this function's own hit-test never even ran
  -- -- tryEditPanelSelect had already consumed and returned on every
  -- single press first. Fixed at every call site (6 mouse/touch
  -- callbacks + C.driveStickEditMode) by checking this FIRST, before
  -- tryEditPanelSelect -- it's a small, specific target the same way a
  -- panel's own handle/icon/corner sub-checks are, not a catch-all, so
  -- checking it first matches how those are already prioritized within
  -- tryEditPanelSelect itself. (Edge case, acceptable: if a real panel
  -- is ever dragged to visually overlap the touch-nav/icon area, this
  -- now wins that pixel instead of the panel -- narrow enough in
  -- practice, and vastly better than groups being completely
  -- unreachable, which was the actual bug being fixed here.)
  local function tryTouchGroupDragStart(x, y, touchId)
    if not C.overlayEdit.active then return false end
    -- v73: only one group-drag at a time, by design (no multi-touch
    -- gesture for these, unlike the real panels' pinch). Without this, a
    -- second call for the SAME physical touch -- LOVE synthesizes a
    -- mousepressed echo for every real touchpressed -- would silently
    -- steal ownership by overwriting C.touchGroupDrag.touchId to
    -- "mouse", after which the real finger's own touchmoved events stop
    -- matching and the drag goes dead. Refusing a second grab here lets
    -- tryEditPanelSelect's own existing debounce (or its catch-all
    -- return-true) absorb the echo instead, same as it already does for
    -- every other input path in this file.
    -- v81 port: also refuse a grab while a resize owns the pointer, same
    -- mutual-exclusion reasoning as the check above.
    if C.touchGroupDrag or C.touchGroupResize then return false end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return false end
    local scale = touchGroupScale(wh)
    for _, which in ipairs(TOUCH_GROUP_KEYS) do
      -- v81: touchGroupRect (offset + resize size) instead of
      -- touchGroupDefaultRect+offset -- a resized group's whole box, not
      -- just its default-size footprint, should be grabbable to drag.
      local rx, ry, rw, rh = touchGroupRect(which, ww, wh)
      if x >= rx and x <= rx + rw and y >= ry and y <= ry + rh then
        local dx, dy = x / scale, y / scale
        C.touchGroupDrag = { which = which, touchId = touchId or "mouse",
          offsetX = dx - (rx / scale), offsetY = dy - (ry / scale) }
        return true
      end
    end
    return false
  end
  local function updateTouchGroupDrag(x, y, touchId)
    local drag = C.touchGroupDrag
    if not (drag and drag.touchId == (touchId or "mouse")) then return false end
    -- v76: independent scale, same fix as touchGroupOffset's own -- a
    -- drag can only be IN PROGRESS while edit mode is active (which
    -- requires the overlay to already be visibly rendering), so `s`
    -- itself would actually be safe to read here specifically -- but
    -- using the same touchGroupScale(wh) as every other touch-group
    -- unit conversion keeps all of them provably consistent with each
    -- other rather than one relying on a timing guarantee the others
    -- don't.
    local _, wh = love.graphics.getDimensions()
    local scale = touchGroupScale(wh)
    local dx, dy = x / scale, y / scale
    -- v2.9.5: tagged with the orientation this drag is happening in, same
    -- reasoning and pattern as C.panelCfg[x].pos's own portrait tag -- a
    -- direct report (drag "sliding left" during an attempted portrait
    -- resize, later found "very very large" in landscape) traced back to
    -- this exact group sharing one untagged position/size across two
    -- orientations whose underlying zone geometry was never meant to be
    -- comparable in the first place.
    C.touchGroupPos[drag.which] = { x = dx - drag.offsetX, y = dy - drag.offsetY, portrait = C.isPortrait }
    return true
  end
  local function endTouchGroupDrag(touchId)
    local drag = C.touchGroupDrag
    if not (drag and drag.touchId == (touchId or "mouse")) then return false end
    C.touchGroupDrag = nil
    savePanelCfg()
    return true
  end
  -- v81 port: resize a touch group via its bottom-corner grip, mirroring the
  -- real panels' corner resize (updateResize's distance-from-a-fixed-anchor
  -- scaling). The fixed anchor is the group's current TOP-LEFT (BR grab) or
  -- TOP-RIGHT (BL grab) -- same as the real panels -- so it grows toward/away
  -- from the grabbed corner without needing a separate position rewrite for
  -- BR (top-left already doesn't move); BL shifts touchGroupPos to keep its
  -- opposite (top-right) corner fixed, the same way the panels' BL resize
  -- shifts cfg.pos. Grip hit-test is checked BEFORE the group drag at every
  -- call site (grab the corner -> resize; grab anywhere else in the group ->
  -- move), and both before tryEditPanelSelect -- same touchId-ownership guard
  -- as drag, so a second finger / the mouse echo of a touch can't hijack an
  -- in-progress resize.
  local function tryTouchGroupResizeStart(x, y, touchId)
    if not C.overlayEdit.active then return false end
    if C.touchGroupResize or C.touchGroupDrag then return false end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return false end
    local scale = touchGroupScale(wh)
    for _, which in ipairs(TOUCH_GROUP_KEYS) do
      local corner = touchGroupGripHit(which, ww, wh, x, y)
      if corner then
        local rx, ry, rw, rh = touchGroupRect(which, ww, wh)
        local anchorX = (corner == "BR") and (rx / scale) or ((rx + rw) / scale)
        local anchorY = ry / scale
        local dx, dy = x / scale, y / scale
        local dist0 = math.sqrt((dx - anchorX) ^ 2 + (dy - anchorY) ^ 2)
        C.touchGroupResize = {
          which = which, touchId = touchId or "mouse", corner = corner,
          anchorX = anchorX, anchorY = anchorY,
          startDist = math.max(dist0, 1),
          startSize = C.touchGroupSize[which] or 1,
        }
        return true
      end
    end
    return false
  end
  local function updateTouchGroupResize(x, y, touchId)
    local rz = C.touchGroupResize
    if not (rz and rz.touchId == (touchId or "mouse")) then return false end
    local ww, wh = love.graphics.getDimensions()
    local scale = touchGroupScale(wh)
    local dx, dy = x / scale, y / scale
    local dist = math.sqrt((dx - rz.anchorX) ^ 2 + (dy - rz.anchorY) ^ 2)
    local newSize = clampTouchGroupSize(rz.startSize * (dist / rz.startDist))
    C.touchGroupSize[rz.which] = newSize
    -- v2.9.5: C.touchGroupSize is a bare number, not a table, so it can't
    -- carry its own .portrait field the way cfg.pos does -- tracked in
    -- this parallel side table instead, same tag/same reasoning (see
    -- updateTouchGroupDrag above). Every consumer of C.touchGroupSize
    -- checks this alongside it now.
    C.touchGroupSizePortrait[rz.which] = C.isPortrait
    if rz.corner == "BL" then
      -- Keep the top-RIGHT anchor fixed -- as the group grows, shift its
      -- stored top-left position left so its right edge stays put (BR needs
      -- no shift: top-left not moving is already the default). Design
      -- units; bw is the default bounding-box width, the same base
      -- touchGroupRect scales by C.touchGroupSize.
      local _, _, bw = touchGroupDefaultRect(rz.which, ww, wh)
      C.touchGroupPos[rz.which] = { x = rz.anchorX - (bw * newSize) / scale, y = rz.anchorY, portrait = C.isPortrait }
    end
    return true
  end
  local function endTouchGroupResize(touchId)
    local rz = C.touchGroupResize
    if not (rz and rz.touchId == (touchId or "mouse")) then return false end
    C.touchGroupResize = nil
    savePanelCfg()
    return true
  end
  -- v75/v76: scales one of C.drawTouchNav/drawTouchIcons's own default-
  -- chrome alpha values by the current TOUCH TRANSPARENCY level (see
  -- TOUCH_BTN_TRANSPARENCY_MUL's own comment near FORCE_DIM_OVERLAY).
  -- Clamped to 1 since different elements start from different base
  -- alphas and would otherwise overshoot LÖVE's valid color range at
  -- different levels. NOT applied to gold/active-state colors -- those
  -- are passed straight through, unscaled, at every call site below.
  local function touchBtnAlpha(baseAlpha)
    local level = mod.options:get("touch_btn_transparency")
    local mul = TOUCH_BTN_TRANSPARENCY_MUL[level] or 1
    return math.min(1, baseAlpha * mul)
  end
  C.drawTouchNav = function()
    if not mod.options:get("touch_nav_buttons") then return end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return end
    -- v2.9.5 bugfix, direct report + screenshot (portrait, both Odin and
    -- S23 Ultra): TOUCH_NAV_LEFT/RIGHT's zone fractions were only ever
    -- tuned against one landscape screenshot (see touchGroupOffset's own
    -- comment on this exact limitation) -- in portrait, the same
    -- x-fraction-of-width / y-fraction-of-height math produces a much
    -- taller-than-wide rect, and this function used to draw that raw,
    -- stretched w x h directly, so the button rendered as a tall pill.
    -- C.drawTouchIcons already solves the identical problem for the icon
    -- row by drawing a circle inscribed at radius = half the SHORTER
    -- side (its own comment: "the tappable zone stays a rectangle... only
    -- the visible shape changes") -- same fix here, applied to a rounded
    -- rect instead of a circle: the drawn button is a square sized off
    -- the shorter of w/h, centered within the unchanged tap-zone rect, so
    -- the actual touch target (hit-testing, drag offset, resize -- every
    -- consumer of touchGroupButtonRect) is completely untouched, only the
    -- drawn shape's proportions are corrected.
    local function drawBtn(zone, dir)
      local x1, y1, w, h = touchGroupButtonRect("touchNav", zone, ww, wh)   -- v81: offset + resize size
      local cx, cy = x1 + w / 2, y1 + h / 2
      local side = math.min(w, h)
      local bx1, by1 = cx - side / 2, cy - side / 2
      love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.12))
      love.graphics.rectangle("fill", bx1, by1, side, side, 8, 8)
      love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.35))
      love.graphics.rectangle("line", bx1, by1, side, side, 8, 8)
      local aw, ah = side * 0.28, side * 0.4
      love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.75))
      if dir < 0 then
        love.graphics.polygon("fill", cx + aw / 2, cy - ah / 2, cx + aw / 2, cy + ah / 2, cx - aw / 2, cy)
      else
        love.graphics.polygon("fill", cx - aw / 2, cy - ah / 2, cx - aw / 2, cy + ah / 2, cx + aw / 2, cy)
      end
    end
    drawBtn(TOUCH_NAV_LEFT, -1)
    drawBtn(TOUCH_NAV_RIGHT, 1)
    if heldBlocksTouchUI() then
      local function dim(zone)
        local x1, y1, w, h = touchGroupButtonRect("touchNav", zone, ww, wh)
        local cx, cy = x1 + w / 2, y1 + h / 2
        local side = math.min(w, h)
        love.graphics.setColor(0, 0, 0, 0.55)
        love.graphics.rectangle("fill", cx - side / 2, cy - side / 2, side, side, 8, 8)
      end
      dim(TOUCH_NAV_LEFT); dim(TOUCH_NAV_RIGHT)
    end
    drawTouchGroupHighlight("touchNav", ww, wh)
    love.graphics.setColor(1, 1, 1, 1)
  end

  -- Draws the three direct-jump icon buttons (see TOUCH_ICON_OVERLAY/ITEMS/
  -- PARTY above) when the "TOUCH SCREEN ICON BUTTONS" mod option is on.
  -- Same semi-transparent rounded-rect treatment as C.drawTouchNav just
  -- above -- and, like it, drawn in raw window pixels (zone fractions *
  -- window size) rather than through the rrect/setc helpers used elsewhere
  -- in this file, since those route through the design-space scale factor
  -- `s`, which by this point in the frame belongs to whichever of
  -- drawOverlay/drawScreen last ran, not to this row. Whichever screen is
  -- currently showing gets a gold highlight, so the row doubles as a
  -- status readout, not just three buttons. Purely visual -- the actual
  -- tap handling lives in the love.touchpressed wrapper further down, same
  -- as the arrows.
  C.drawTouchIcons = function()
    if not mod.options:get("touch_icon_buttons") then return end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return end
    local c = _G.__KANTO_INGAME
    local activeOverlay = c and c.visible and not c.screen
    local activeItems   = c and c.screen == "items"
    local activeParty   = c and c.screen == "party"
    local gold = COL.gold

    -- Shared button chrome: background + border, brighter/gold when this
    -- one is the active screen. Drawn as a circle inscribed in the zone
    -- rectangle (radius = half the shorter side) rather than the rounded
    -- rect the arrow buttons use -- the tappable zone stays a rectangle
    -- (same hit-testing as the arrows), only the visible shape changes.
    -- Returns the button's center and that radius, for the icon glyph to
    -- scale against, so the same icon code works at any window size.
    -- v72: applies the group's drag offset here, the one choke point
    -- every icon's position flows through -- every glyph drawn below is
    -- already positioned relative to frame()'s own returned cx/cy, so
    -- this single addition moves the whole row without touching any of
    -- the individual glyph-drawing code beneath it.
    -- v81: touchGroupButtonRect (offset + resize size) instead of a raw
    -- zone-percent + offset -- same reason C.drawTouchNav's drawBtn switched.
    local function frame(zone, active)
      local x1, y1, w, h = touchGroupButtonRect("touchIcons", zone, ww, wh)
      local cx, cy = x1 + w / 2, y1 + h / 2
      local r = math.min(w, h) / 2
      if active then love.graphics.setColor(gold[1], gold[2], gold[3], 0.24)
      else love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.14)) end
      love.graphics.circle("fill", cx, cy, r)
      if active then love.graphics.setColor(gold[1], gold[2], gold[3], 0.9); love.graphics.setLineWidth(2)
      else love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.4)); love.graphics.setLineWidth(1) end
      love.graphics.circle("line", cx, cy, r)
      love.graphics.setLineWidth(1)
      return cx, cy, r * 2
    end
    local function glyphColor(active)
      if active then love.graphics.setColor(gold[1], gold[2], gold[3], 1)
      else love.graphics.setColor(1, 1, 1, touchBtnAlpha(0.75)) end
    end

    -- Overlay icon: two flattened diamonds stacked with a gap between them
    -- -- a plain "layers" glyph, for the info-panel overlay (party /
    -- trainer / route / battle-matchup HUD) sitting on top of the game.
    -- The bottom diamond is filled at a higher alpha (lighter, reads as
    -- sitting on top) and the top one at a lower alpha (darker/dimmer,
    -- reads as sitting further back) -- two intentionally different
    -- shades, not the accidental double-paint seam the other icons avoid.
    -- The gap between them still keeps the two fills from ever touching,
    -- so each pixel only ever gets the one shade meant for it.
    do
      local cx, cy, sz = frame(TOUCH_ICON_OVERLAY, activeOverlay)
      local col = activeOverlay and gold or {1, 1, 1}
      local dw, dh = sz * 0.30, sz * 0.11
      local gap = sz * 0.10
      local totalH = dh*4 + gap
      local topCy = cy - totalH/2 + dh
      local botCy = topCy + dh*2 + gap
      love.graphics.setColor(col[1], col[2], col[3], activeOverlay and 1 or touchBtnAlpha(0.85))
      love.graphics.polygon("fill", cx-dw, botCy, cx, botCy-dh, cx+dw, botCy, cx, botCy+dh)
      love.graphics.setColor(col[1], col[2], col[3], activeOverlay and 0.55 or touchBtnAlpha(0.35))
      love.graphics.polygon("fill", cx-dw, topCy, cx, topCy-dh, cx+dw, topCy, cx, topCy+dh)
    end

    -- Items icon: a plain backpack silhouette -- a rounded-rect body, two
    -- short strap tabs sitting flush above it, and a front-pocket outline.
    -- Not any in-game sprite (this mod ships no game assets, see README).
    --
    -- Everything here is one glyphColor call at one alpha, and no two
    -- shapes ever cover the same pixels: the straps' bottom edge sits
    -- exactly at the body's top edge (touching, not overlapping), so a
    -- semi-transparent strap never gets painted twice over the same spot
    -- as the body -- that double-paint is what caused a visible seam in an
    -- earlier version of this icon. The pocket outline's stroke doesn't
    -- count as a second layer since it's the same color/alpha as the fill
    -- it sits on -- painting one flat color over itself changes nothing.
    do
      local cx, cy, sz = frame(TOUCH_ICON_ITEMS, activeItems)
      glyphColor(activeItems)

      local bw, bh = sz * 0.56, sz * 0.60
      local sw, sh = sz * 0.12, sz * 0.20
      -- centre the full glyph (straps + body) in the button, not just the body
      local top = cy - (bh - sh) / 2
      local bx0 = cx - bw/2

      -- straps: two short tabs, bottom edge flush with the body's top
      love.graphics.rectangle("fill", cx - bw*0.26 - sw/2, top - sh, sw, sh, sw*0.4, sw*0.4)
      love.graphics.rectangle("fill", cx + bw*0.26 - sw/2, top - sh, sw, sh, sw*0.4, sw*0.4)

      -- body: one solid rounded rectangle
      love.graphics.rectangle("fill", bx0, top, bw, bh, sz*0.12, sz*0.12)

      -- front pocket: an outline in the lower half of the body
      local pw, phh = bw * 0.5, bh * 0.32
      local px0 = cx - pw/2
      local py0 = top + bh*0.5
      love.graphics.setLineWidth(math.max(1.5, sz*0.035))
      love.graphics.rectangle("line", px0, py0, pw, phh, sz*0.06, sz*0.06)
      love.graphics.setLineWidth(1)
    end

    -- Party icon: a Poke Ball glyph (ring + center line + center dot) -- a
    -- generic, widely recognized pictogram, not a copy of any in-game
    -- asset -- standing in for the Party/Boxes screen.
    do
      local cx, cy, sz = frame(TOUCH_ICON_PARTY, activeParty)
      glyphColor(activeParty)
      local r = sz * 0.32
      love.graphics.setLineWidth(math.max(1, sz * 0.05))
      love.graphics.circle("line", cx, cy, r)
      love.graphics.line(cx - r, cy, cx - r * 0.35, cy)
      love.graphics.line(cx + r * 0.35, cy, cx + r, cy)
      love.graphics.setLineWidth(1)
      love.graphics.circle("fill", cx, cy, sz * 0.07)
      love.graphics.circle("line", cx, cy, sz * 0.11)
    end
    if heldBlocksTouchUI() then
      local function dim(zone)
        local x1, y1, w, h = touchGroupButtonRect("touchIcons", zone, ww, wh)
        local cx, cy = x1 + w / 2, y1 + h / 2
        local r = math.min(w, h) / 2
        love.graphics.setColor(0, 0, 0, 0.55)
        love.graphics.circle("fill", cx, cy, r)
      end
      dim(TOUCH_ICON_OVERLAY); dim(TOUCH_ICON_ITEMS); dim(TOUCH_ICON_PARTY)
    end
    drawTouchGroupHighlight("touchIcons", ww, wh)
    love.graphics.setColor(1, 1, 1, 1)
  end

  -- ---------------------------------------------------------------------
  -- Draw body (sandbox-safe): factored out of the old love.draw wrapper
  -- into a plain function that the render.hud hook (registered just below)
  -- calls once per frame with the live C as `c`. The mod sandbox forbids
  -- assigning love.draw, so the overlay can no longer hang off love.draw
  -- directly -- render.hud is the sanctioned screen-space draw seam.
  -- ---------------------------------------------------------------------
  C.drawFrame = function(c)
      if c and c.drawOverlay then
        local ok, err = pcall(c.drawOverlay)
        if not ok and err ~= c.drawErr then c.drawErr = err; mod.log:error("kanto_ingame draw: %s", tostring(err)) end
      end
      if c and c.screen and c.drawScreen then
        local ok, err = pcall(c.drawScreen)
        if not ok and err ~= c.screenErr then c.screenErr = err; mod.log:error("kanto_ingame screen: %s", tostring(err)) end
      end
      if c and c.drawTouchNav then
        local ok, err = pcall(c.drawTouchNav)
        if not ok and err ~= c.touchNavErr then c.touchNavErr = err; mod.log:error("kanto_ingame touch nav: %s", tostring(err)) end
      end
      if c and c.drawTouchIcons then
        local ok, err = pcall(c.drawTouchIcons)
        if not ok and err ~= c.touchIconsErr then c.touchIconsErr = err; mod.log:error("kanto_ingame touch icons: %s", tostring(err)) end
      end
      if c and c.drawBuildTag then
        local ok, err = pcall(c.drawBuildTag)
        if not ok and err ~= c.buildTagErr then c.buildTagErr = err; mod.log:error("kanto_ingame build tag: %s", tostring(err)) end
      end
      -- On-screen diagnostic: recomputed every frame (see drawOverlay), so
      -- the last frame the recorder captures before a crash is hard
      -- evidence of exactly what state the overlay was in -- no reliance on
      -- catching one special transition frame, and no need for logcat.
      -- pcall-wrapped like the panels above: a prior test showed this box
      -- going dark for the final ~1s before a crash while the party panel
      -- kept rendering fine, meaning THIS code was erroring unnoticed --
      -- exactly the frames we most need to see. Wrapping it means a future
      -- failure gets logged instead of silently blanking the readout.
      if c and c.battleDiagText and mod.options:get("debug_input_hud") then
        local ok, err = pcall(function()
          local lineCount = select(2, c.battleDiagText:gsub("\n", "\n")) + 1
          love.graphics.setColor(0, 0, 0, 0.65)
          love.graphics.rectangle("fill", 6, 6, 460, 14 * lineCount + 6)
          love.graphics.setColor(0.4, 1, 1, 0.95)
          love.graphics.print(c.battleDiagText, 10, 10)
          love.graphics.setColor(1, 1, 1, 1)
        end)
        if not ok and err ~= c.battleDiagErr then c.battleDiagErr = err; mod.log:error("kanto_companion battle diag draw: %s", tostring(err)) end
      end
      -- On-screen input debug readout: no PC to view logs from an Android
      -- handheld, so this prints the last raw key/gamepad/touch event LOVE
      -- delivered, right on the screen. Shows for a few seconds after each
      -- event, small and out of the way in the bottom-left corner. Set
      -- toggle it off in the mod manager (Options > Kanto Companion) once you're
      -- done positioning/troubleshooting touch controls.
      if c and c.debugLast and c.debugLastAt and (love.timer.getTime() - c.debugLastAt) < 6 and mod.options:get("debug_input_hud") then
        local ww, wh = love.graphics.getDimensions()
        love.graphics.setColor(0, 0, 0, 0.55)
        love.graphics.rectangle("fill", 6, wh - 26, 260, 20)
        love.graphics.setColor(1, 1, 0.4, 0.95)
        love.graphics.print("last input -> " .. c.debugLast, 10, wh - 24)
        love.graphics.setColor(1, 1, 1, 1)
      end
      -- Session 96, TEMP DIAGNOSTIC: the timed "last input" readout above
      -- only updates on discrete events (a button press, an axis change
      -- routed through love.gamepadaxis) and expires after a few seconds
      -- of nothing new -- useless for debugging whether a CONTINUOUS
      -- value (is the stick currently pushed? what does the cursor think
      -- its own position is?) is actually live, since a static reading
      -- gives no sense of whether it's updating at all. This one prints
      -- every frame instead, no expiry, gated on the same toggle so it
      -- costs nothing when off. Meant to be removed once the actual bug
      -- is found -- this is not meant to ship long-term.
      if c and mod.options:get("debug_input_hud") and C.overlayEdit.active then
        local ww, wh = love.graphics.getDimensions()
        local nJoy, nGamepad = 0, 0
        for _, j in ipairs(love.joystick.getJoysticks()) do
          nJoy = nJoy + 1
          if j:isGamepad() then nGamepad = nGamepad + 1 end
        end
        local msg = string.format(
          "STICK DIAG: joysticks=%d gamepads=%d | stickActive=%s vcx=%.0f vcy=%.0f | editStickX=%.2f editStickY=%.2f",
          nJoy, nGamepad, tostring(C.stickActive), C.vcx or -1, C.vcy or -1, C.editStickX or 0, C.editStickY or 0)
        love.graphics.setColor(0, 0, 0, 0.65)
        love.graphics.rectangle("fill", 6, wh - 52, 620, 20)
        love.graphics.setColor(0.5, 1, 1, 0.95)
        love.graphics.print(msg, 10, wh - 50)
        love.graphics.setColor(1, 1, 1, 1)
      end
      -- v2.9.5, Stage 1 of THOR_MODE_DESIGN.md: shows whether the last
      -- second-screen push actually succeeded, printed on the PRIMARY
      -- screen -- this is the main way to tell the pipe is working at
      -- all before there's a real page to look at on the second screen
      -- itself, and it's the only diagnostic available at all once this
      -- ships to the remote Thor tester (no log access, same reasoning
      -- as every other on-screen debug line in this file).
      if c and mod.options:get("debug_input_hud") and mod.options:get("thor_mode") then
        local ww, wh = love.graphics.getDimensions()
        local msg = "THOR MODE: " .. tostring(C.thorStatus or "no push attempted yet")
        love.graphics.setColor(0, 0, 0, 0.65)
        love.graphics.rectangle("fill", 6, wh - 78, 620, 20)
        love.graphics.setColor(1, 0.82, 0.3, 0.95)
        love.graphics.print(msg, 10, wh - 76)
        love.graphics.setColor(1, 1, 1, 1)
      end
      -- LIGHT BUILD, Session 53: panelCfg save/load diagnostics, same
      -- on-screen debug HUD as above rather than mod.log:info -- log
      -- access is a real, unresolved gap on the Odin 2 Portal specifically
      -- (from the original crash investigation), but this toggle is
      -- already reachable on-device through the mod manager. Own field,
      -- not reusing debugLast, since that one gets overwritten by every
      -- key/touch/pad press and could get stomped before it's readable;
      -- shown longer (15s) since these events are rarer and the message
      -- can run multiple lines.
      if c and c.panelCfgDebugMsg and c.panelCfgDebugMsgAt and (love.timer.getTime() - c.panelCfgDebugMsgAt) < 15 and mod.options:get("debug_input_hud") then
        local ww, wh = love.graphics.getDimensions()
        local lineCount = select(2, c.panelCfgDebugMsg:gsub("\n", "\n")) + 1
        love.graphics.setColor(0, 0, 0, 0.7)
        love.graphics.rectangle("fill", 6, wh - 26 - (lineCount * 16) - 6, 480, (lineCount * 16) + 6)
        love.graphics.setColor(0.5, 1, 0.6, 0.95)
        love.graphics.print(c.panelCfgDebugMsg, 10, wh - 26 - (lineCount * 16))
        love.graphics.setColor(1, 1, 1, 1)
      end
  end
  -- v2.9.5, Stage 1 of THOR_MODE_DESIGN.md, ROUND 2: round 1 on real Thor
  -- hardware already proved the plumbing -- usable/available/detected all
  -- true, and the solid fills (navy clear + gold bar) rendered clean on the
  -- physical bottom screen. What came back as a band of noise was anything
  -- drawn as small TEXT. Canvas size is now the Thor's actual bottom-panel
  -- resolution, 1080x1240 (3.92" OLED, per published hardware specs -- the
  -- engine's SecondScreen facade has no dimensions query of its own, so
  -- this is not read from the device itself; if a future round shows this
  -- number is wrong, that itself is useful signal). Round 1 ran at a
  -- placeholder 480x270 -- a completely different aspect ratio, getting
  -- stretched roughly 2.25x non-uniformly onto the real panel -- a simple,
  -- sufficient explanation for why solids survived and thin glyph strokes
  -- didn't. This round's frame is rebuilt around the real size to isolate
  -- the actual cause: a big-vs-medium text probe, a full corner/border crop
  -- check, a ramp of 1/2/4/8/16px stripes, and two checkerboards (fine +
  -- coarse) to find exactly where detail stops surviving. Plain
  -- love.graphics calls, not kanto's own txt/rrect helpers -- those lean
  -- on the shared `s` scale variable, which is computed for the PRIMARY
  -- window's height elsewhere in this file; reusing it here without
  -- saving/restoring it around this pass would risk corrupting whatever
  -- draws next in the same frame. Revisit reusing the real draw
  -- primitives once Stage 3 (the actual carousel) needs proper styling.
  C.THOR_TEST_W, C.THOR_TEST_H = 1080, 1240
  -- v2.9.5: reports usable/available/detected as three SEPARATE
  -- booleans, always, rather than a single derived message that stops
  -- at the first false one -- this is the ONLY diagnostic channel that
  -- will exist once this reaches the remote Thor tester (no log
  -- access), so a partial-failure state needs to be distinguishable
  -- from a total one in a single glance/report back. Attempts the push
  -- regardless of what available()/detected() say, rather than gating
  -- on them first -- SecondScreen.push's own native-path implementation
  -- doesn't require it either (it just tries the FFI call and reports
  -- success/failure via its return value), and gating here on an
  -- assumption about ordering is exactly the kind of untested "should
  -- be fine" reasoning that caused the PC incident.
  C.pushThorTestFrame = function(secondScreen)
    local function safe(fn) local ok, r = pcall(fn); return ok and r end
    local usable   = safe(function() return secondScreen.usable and secondScreen.usable() end)
    local available = safe(function() return secondScreen.available and secondScreen.available() end)
    local detected  = safe(function() return secondScreen.detected and secondScreen.detected() end)
    local w, h = C.THOR_TEST_W, C.THOR_TEST_H
    if not (C.thorCanvas and C.thorCanvas:getWidth() == w and C.thorCanvas:getHeight() == h) then
      C.thorCanvas = love.graphics.newCanvas(w, h)
    end
    local prevCanvas = love.graphics.getCanvas()
    love.graphics.setCanvas(C.thorCanvas)
    -- Stage-1 diagnostic frame, ROUND 2 (v2.9.5) -- same diagnostic intent as
    -- round 1 (border/corners for crop, a bounce block for liveness, a ramp +
    -- checkers for detail survival, a text probe) but redrawn at the Thor's
    -- real 1080x1240 panel size instead of the 480x270 placeholder, and with
    -- TWO text sizes + TWO checker scales instead of one, since round 1
    -- already told us solids survive and small text doesn't -- this round's
    -- job is to find where between "big" and "small" the line actually is.
    -- Every element below carries its own comment on what a wrong result
    -- would mean; see the layout comment above C.THOR_TEST_W for the full
    -- round-1 -> round-2 reasoning. No local helper functions are added here
    -- (the two checkerboards are drawn with separate inline loops, not a
    -- shared `local function`) per this project's standing rule that new
    -- helpers attach to C.* fields rather than adding local-function
    -- declarations -- this file has hit LuaJIT's 200-local ceiling twice
    -- before.
    local t = love.timer.getTime()
    love.graphics.clear(0.10, 0.10, 0.16, 1)
    -- top reference bar: same gold as round 1, so the tester recognises this
    -- as the same test evolved, not a different feature
    love.graphics.setColor(1, 0.82, 0.2, 1)
    love.graphics.rectangle("fill", 0, 0, w, 20)
    -- full-frame border + four corner markers (TL red / TR green / BL blue /
    -- BR gold). "handheld" is documented to preserve the whole frame rather
    -- than crop it -- any missing edge or corner here means that's not
    -- actually happening on this device.
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", 2, 2, w - 4, h - 4)
    local cm, cmargin = 70, 14
    love.graphics.setColor(1, 0.25, 0.25, 1)
    love.graphics.rectangle("fill", cmargin, 30, cm, cm)
    love.graphics.setColor(0.25, 1, 0.35, 1)
    love.graphics.rectangle("fill", w - cmargin - cm, 30, cm, cm)
    love.graphics.setColor(0.35, 0.55, 1, 1)
    love.graphics.rectangle("fill", cmargin, h - cmargin - cm, cm, cm)
    love.graphics.setColor(1, 0.85, 0.2, 1)
    love.graphics.rectangle("fill", w - cmargin - cm, h - cmargin - cm, cm, cm)
    -- text probe at two sizes: if the big word reads clean but the smaller
    -- line still mushes, that pins the legibility threshold between them
    -- instead of just "big text works, small text doesn't"
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("KANTO", 110, 130, 0, 7, 7)
    love.graphics.print("STAGE 1 R2 -- panel 1080x1240", 110, 240, 0, 2.2, 2.2)
    -- liveness: a bright block sweeping a dark lane, driven by getTime() --
    -- replaces round 1's ticking counter (a number is itself small text)
    -- with something readable as "moving" or "frozen" at a glance
    local laneX, laneY, laneW, laneH = 60, 300, w - 120, 60
    love.graphics.setColor(0.04, 0.04, 0.07, 1)
    love.graphics.rectangle("fill", laneX, laneY, laneW, laneH)
    local tri = math.abs(((t * 0.6) % 2) - 1)   -- 0..1..0 triangle wave
    local blockW = 110
    local bx = laneX + tri * (laneW - blockW)
    love.graphics.setColor(0.2, 1, 0.9, 1)
    love.graphics.rectangle("fill", bx, laneY + 5, blockW, laneH - 10)
    -- resolution ramp: 5 groups of vertical bars, 1/2/4/8/16px wide (round 1
    -- only went to 8px; the bigger real canvas has room for a coarser group
    -- too). Whichever group first turns to mush marks the panel's effective
    -- detail limit.
    local rampY, rampH = 390, 50
    local rampGroups = { 1, 2, 4, 8, 16 }
    local gw = math.floor((w - 80) / #rampGroups)
    for gi = 1, #rampGroups do
      local bw = rampGroups[gi]
      local gx0 = 40 + (gi - 1) * gw
      local x = gx0
      local on = true
      while x < gx0 + gw - bw do
        if on then
          love.graphics.setColor(1, 1, 1, 1)
          love.graphics.rectangle("fill", x, rampY, bw, rampH)
        end
        on = not on
        x = x + bw
      end
    end
    -- solid colour swatches: confirms channel order + smooth banding on the
    -- real panel (round 1's yellow bar already read correctly, this widens
    -- the check to red/green/blue/white/grey too)
    local swY, swH = 470, 70
    local swatches = {
      { 1, 0.25, 0.25 }, { 0.25, 1, 0.35 }, { 0.35, 0.55, 1 },
      { 1, 1, 1 }, { 0.5, 0.5, 0.5 }, { 1, 0.85, 0.2 },
    }
    local sw = math.floor((w - 80) / #swatches)
    for si = 1, #swatches do
      local c = swatches[si]
      love.graphics.setColor(c[1], c[2], c[3], 1)
      love.graphics.rectangle("fill", 40 + (si - 1) * sw, swY, sw - 3, swH)
    end
    -- two checkerboards side by side, fine (10px cells) and coarse (24px) --
    -- whichever shimmers/moires and whichever stays clean brackets the
    -- panel's real per-pixel fidelity. Drawn as two separate inline loops
    -- rather than a shared local function (see comment at the top of this
    -- block).
    local chkAx, chkAy, chkAcell, chkAcols, chkArows = 60, 570, 10, 30, 18
    for ry = 0, chkArows - 1 do
      for rx = 0, chkAcols - 1 do
        if (rx + ry) % 2 == 0 then
          love.graphics.setColor(1, 1, 1, 1)
        else
          love.graphics.setColor(0.15, 0.15, 0.2, 1)
        end
        love.graphics.rectangle("fill", chkAx + rx * chkAcell, chkAy + ry * chkAcell, chkAcell, chkAcell)
      end
    end
    local chkBx, chkBy, chkBcell, chkBcols, chkBrows = 580, 570, 24, 18, 11
    for ry = 0, chkBrows - 1 do
      for rx = 0, chkBcols - 1 do
        if (rx + ry) % 2 == 0 then
          love.graphics.setColor(1, 1, 1, 1)
        else
          love.graphics.setColor(0.15, 0.15, 0.2, 1)
        end
        love.graphics.rectangle("fill", chkBx + rx * chkBcell, chkBy + ry * chkBcell, chkBcell, chkBcell)
      end
    end
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(1)
    love.graphics.setCanvas(prevCanvas)
    local ok, imageData = pcall(function() return C.thorCanvas:newImageData() end)
    local pushResult
    if not ok or not imageData then
      pushResult = "newImageData failed: " .. tostring(imageData)
    else
      local okPush, pushed = pcall(secondScreen.push, imageData, w, h, 0, "handheld")
      pushResult = (okPush and pushed) and "pushed OK" or ("push failed: " .. tostring(pushed))
    end
    C.thorStatus = ("usable=%s available=%s detected=%s | %s")
      :format(tostring(usable), tostring(available), tostring(detected), pushResult)
  end
  -- ---------------------------------------------------------------------
  -- Hooks (sandbox-safe). The old love.draw assignment and C.game.update
  -- monkey-patch are both forbidden by the mod sandbox (assigning love.*
  -- throws; patching the engine Game object is not a sanctioned seam).
  --   render.hud  fires once per frame at the end of Game:draw / Game2:draw,
  --               screen-space over the finished frame and below the engine's
  --               own touch controls, on BOTH generations (verified against
  --               real 0.1.85 source).
  --   core.update fires once per frame with dt; next() first runs the vanilla
  --               update, so onFrame reads freshly-updated state exactly as it
  --               did after the old C.origUpdate call.
  -- Registered once (C.wrappedHooks); both look C.drawFrame / c.onFrame up
  -- dynamically, so a hot-reload that redefines them is picked up without
  -- re-registering.
  -- ---------------------------------------------------------------------
  if not C.wrappedHooks then
    mod.hooks:wrap("core.update", function(nextUpdate, game, dt)
      local r = nextUpdate(game, dt)
      local c = _G.__KANTO_INGAME
      -- Poll gamepad + overworld keyboard hotkeys every frame (edge-detect)
      -- now that the old love.gamepad*/keypressed wrappers are gone -- see
      -- C.pollPad / C.pollKeys. Guarded so a bad device query can't break the
      -- frame.
      if C.pollPad then pcall(C.pollPad) end
      if C.pollKeys then pcall(C.pollKeys) end
      if C.pollSearchKeys then pcall(C.pollSearchKeys) end
      if C.pollCursorPreview then pcall(C.pollCursorPreview) end
      if c and c.onFrame then pcall(c.onFrame, dt) end
      return r
    end)
    mod.hooks:wrap("render.hud", function(nextHud, game, viewport)
      local c = _G.__KANTO_INGAME
      if c and c.drawFrame then C.drawFrame(c) end
      if C.drawCursorPreview then pcall(C.drawCursorPreview, viewport) end
      -- v2.9.5, portrait-mode investigation (temporary probe, not a shipped
      -- feature): logs the real render.hud viewport geometry once per actual
      -- change (not every frame) so a physical device's letterbox numbers can
      -- be read straight from logcat on rotation, instead of trusting a
      -- hand-derivation of Renderer:fitScale() against an unverified guess at
      -- the runtime's UI-safe design size. Gated on DEBUG INPUT HUD so normal
      -- play never logs this.
      if viewport and mod.options:get("debug_input_hud") then
        local vw, vh = viewport.width, viewport.height
        if vw ~= C.lastViewportW or vh ~= C.lastViewportH then
          C.lastViewportW, C.lastViewportH = vw, vh
          mod.log:info("kanto_companion: viewport changed -- w=%s h=%s gameX=%s gameY=%s gameW=%s gameH=%s scale=%s",
            tostring(vw), tostring(vh), tostring(viewport.gameX), tostring(viewport.gameY),
            tostring(viewport.gameWidth), tostring(viewport.gameHeight), tostring(viewport.scale))
        end
      end
      return nextHud(game, viewport)
    end)
    -- v2.9.5, Stage 1 of THOR_MODE_DESIGN.md: render.compose is a real,
    -- documented hook (same tier as render.hud/render.letterbox above),
    -- confirmed via the engine's own hook-catalog comment in Game2.lua
    -- and fired on both Gen 1 and Gen 2. Its ctx table hands over
    -- ctx.secondScreen -- the ONLY way to reach the second-display
    -- bridge; src.render.SecondScreen is deliberately never required
    -- directly, since it isn't (and doesn't need to be) on kanto's own
    -- declared engine-requires list. Always calls next() first and
    -- returns exactly what it returns -- kanto never takes over
    -- compositing (that's the `true`-return contract this hook offers
    -- but this mod has no reason to use), so the primary screen's
    -- normal rendering is completely unaffected whether Thor mode is on
    -- or off. C.pushThorTestFrame is pcall-guarded so a bad push can
    -- never break the primary frame either.
    mod.hooks:wrap("render.compose", function(next, renderer, ctx)
      local r = next(renderer, ctx)
      -- v2.9.5 bugfix, direct report (immediate crash, 3 gen1recomp.exe
      -- processes found running after enabling on PC). Root-caused
      -- fully, not just patched: the PC desktop-companion fallback
      -- spawns a SECOND COPY of the game process
      -- (DesktopScreen.lua/HostShell.spawnSelfDetached) tagged with a
      -- --display-companion=port,token argument meant to make it behave
      -- as a lightweight display client -- but nothing anywhere in this
      -- engine's startup path (checked main.lua's own LaunchOptions.
      -- resolve(arg), grepped the whole src tree, read the one existing
      -- test for this spawn mechanism) ever consumes that argument. The
      -- spawned copy just boots as a completely normal full game+mods
      -- instance instead, which -- reading the SAME shared options.lua
      -- with thor_mode still true -- tries to spawn its OWN companion,
      -- cascading. This is a genuine engine-side gap (the receiving half
      -- of this feature was never built), not a version mismatch, and
      -- not something a mod can safely work around -- confirmed this
      -- isn't kanto-fixable and isn't worth an upstream report either
      -- (no other mod in this coordination project has any plausible
      -- use for a second physical display, and dual-screen Android
      -- hardware is a narrow enough niche that nothing else visible in
      -- this engine's modding scene needs it). So: hard-gated to Android
      -- only, permanently, not just until a version/build changes --
      -- native Android has no equivalent process-spawn step at all (a
      -- direct in-process FFI call, see SecondScreen.lua's non-desktop
      -- branch), so this specific cascade risk structurally cannot occur
      -- there regardless of engine version.
      --
      -- Second hardening, proactive, same lesson applied before it can
      -- bite again rather than after: only call setEnabled on an actual
      -- TRANSITION (edge-detected via C.thorModeWas), not every frame.
      -- The desktop path's setEnabled was cheap to call repeatedly
      -- because its own first line already short-circuits on no-change
      -- -- verified by reading it. The native Android implementation is
      -- opaque C++ behind the FFI boundary (SecondScreen.lua's own
      -- comment: "The C functions live in mobile/android/love/src/jni/
      -- ..."), so that same assumption can't be verified the same way.
      -- Calling an unfamiliar native API 60x/second when it may only
      -- need to fire once is exactly the class of untested assumption
      -- that just caused the incident above -- not repeating it here
      -- just because this path currently looks safer.
      local os_ = love.system and love.system.getOS and love.system.getOS()
      if os_ == "Android" and ctx and ctx.secondScreen then
        local on = mod.options:get("thor_mode")
        if on ~= C.thorModeWas then
          pcall(ctx.secondScreen.setEnabled, on)
          C.thorModeWas = on
        end
        if on then
          pcall(C.pushThorTestFrame, ctx.secondScreen)
        end
      end
      return r
    end)
    C.wrappedHooks = true
  end
  -- EMERGENCY, Session 64; factored out Session 65 so both the
  -- unconditional keyboard-F9 path (C.onKeyDown below) and the
  -- edit-mode-gated gamepad-L3 path (love.gamepadpressed further down)
  -- share one implementation instead of duplicating the reset body.
  -- v2.9.5: attached to C (not a bare local) specifically so C.onFrame --
  -- defined much earlier in this file, for the hold-to-reset poll below --
  -- can call it safely. A bare local here would be the exact forward-
  -- reference bug this file has been bitten by before (a closure written
  -- earlier in the file can't see a `local function` declared later, even
  -- though it only actually RUNS after that point) -- C.* field lookups
  -- are resolved at call time, not compile time, so file order stops
  -- mattering.
  C.doPanicReset = function(c)
    for _, k in ipairs(PANEL_KEYS) do
      C.panelCfg[k] = { collapsed = false, scale = 1, pos = false, compact = false }
    end
    -- v72: touch-nav/icon group drag offsets reset alongside the real
    -- panels -- same "panic = everything back to default" contract.
    -- v81 port: sizes reset to default too.
    C.touchGroupPos = { touchNav = false, touchIcons = false }
    C.touchGroupSize = { touchNav = 1, touchIcons = 1 }
    C.touchGroupDrag = nil
    C.touchGroupResize = nil
    C.overlayEdit.active = false
    C.overlayEdit.drag = nil
    C.overlayEdit.pinch = nil
    C.overlayEdit.touches = {}
    C.overlayEdit.resize = nil
    -- v2.9.x-sandbox: edit mode / screens now push a PAUSING modal. A reset
    -- fired from edit mode (F9 / L3) cleared overlayEdit.active but left that
    -- modal on the stack -- an orphaned modal keeps the overworld paused, so
    -- input dies, screens can't open (canOpen sees it on top), and edit can't
    -- re-toggle. Pop it and clear screen/cursor so reset always lands back in a
    -- clean overworld state.
    if C.game and C.game.stack and C.game.stack:top() == C.modalState then
      C.game.stack:pop()
    end
    C.screen = false
    C.touchScreenPos = nil
    if C.cursorWas ~= nil then love.mouse.setVisible(C.cursorWas); C.cursorWas = nil end
    c.visible = true
    savePanelCfg()
    C.panelCfgDebugMsg = "PANIC RESET: all panels restored to default position/scale/collapse"
    C.panelCfgDebugMsgAt = love.timer.getTime()
  end
  -- Key handling lives in a C.* function that is REASSIGNED every load, so an
  -- F5 hot-reload picks up changes. The wrapper below is installed once and just
  -- delegates here (returning true = handled/consumed).
  -- The first arg is the real keyboard's game `self` (truthy) ONLY when this is
  -- driven by an actual keyboard keypress -- the C.game.keypressed wrapper is the
  -- one and only caller that passes it. Every synthetic caller (gamepad via
  -- PAD_KEYMAP, R2/R3, touch icon buttons) passes nil. So `fromKeyboard ~= nil`
  -- is a reliable "this key came from a physical keyboard" test, which is exactly
  -- the axis the F6-vs-R3 edit-mode rule below needs (see EDIT_MODE_KEY).
  C.onKeyDown = function(fromKeyboard, key)
    local c = _G.__KANTO_INGAME
    -- EMERGENCY, Session 64: checked first, before the "not c.screen"
    -- gate everything else here requires -- deliberately unconditional,
    -- so this works as a real recovery path regardless of whatever
    -- state edit mode or the overlay itself is in. Real keyboard F9
    -- only -- gamepad L3 no longer reaches this (Session 65, see
    -- PAD_KEYMAP and love.gamepadpressed).
    if key == PANIC_RESET_KEY and c then
      C.doPanicReset(c)
      return true
    end
    if c and not c.screen then     -- open/toggle only from the plain overworld
      if key == EDIT_MODE_KEY then
        -- v2.9.3: split the "open edit mode with the overlay hidden"
        -- behavior by INPUT SOURCE, restoring the platform-appropriate
        -- feel the user asked for:
        --   * Keyboard F6 (fromKeyboard ~= nil): may open edit mode any
        --     time -- it force-shows the overlay on the way in. Desktop
        --     F-keys are conventionally shortcuts that bypass having to
        --     open a UI first, so this is the expected behavior there.
        --   * Gamepad R3 (fromKeyboard == nil, i.e. every synthetic
        --     caller): requires the overlay to ALREADY be up. If it's
        --     hidden, R3 does nothing -- the normal console/handheld
        --     convention (press R2 to show the overlay first, THEN R3 to
        --     edit it). Note this only gates the OPEN direction; closing
        --     edit mode via R3 always works (edit mode implies visible, so
        --     the guard below never blocks a close).
        if not C.overlayEdit.active and fromKeyboard == nil and not c.visible then
          return true  -- R3 with the overlay hidden: swallow, do nothing
        end
        -- Enter/exit route through C.editOpen / C.editClose, which push and pop
        -- the pausing modal (defined near closeScreen). editOpen enforces the
        -- overworld-only gate and force-shows the overlay; editClose clears the
        -- stale drag/pinch/resize/stick state the old inline branch used to.
        if C.overlayEdit.active then C.editClose(c) else C.editOpen(c) end
        return true
      end
      if C.overlayEdit.active then
        -- LIGHT BUILD, Session 46: edit mode captures every key while
        -- active, whether or not it recognizes it -- deliberately, so
        -- normal movement/menu keys can't leak through and move the
        -- character while the player's mid-edit. Only the keys below do
        -- anything; everything else is just consumed and ignored.
        local cfg = C.panelCfg[C.overlayEdit.sel]
        if key == "tab" or key == "left" or key == "right" then
          -- LIGHT BUILD, Session 51: four regions to cycle now, not two --
          -- a plain toggle no longer makes sense. Tab and D-pad-right move
          -- forward through PANEL_KEYS, D-pad-left moves back; wraps at
          -- both ends.
          local curIdx = 1
          for i, k in ipairs(PANEL_KEYS) do if k == C.overlayEdit.sel then curIdx = i end end
          local dir = (key == "left") and -1 or 1
          local nextIdx = ((curIdx - 1 + dir) % #PANEL_KEYS) + 1
          C.overlayEdit.sel = PANEL_KEYS[nextIdx]
        elseif key == "up" then
          cfg.scale = math.min(2, cfg.scale + 0.1); savePanelCfg()
        elseif key == "down" then
          cfg.scale = math.max(0.4, cfg.scale - 0.1); savePanelCfg()
        elseif key == "c" then
          -- Session 82: Trainer (and, Session 88, Party too -- see
          -- SUPPORTS_COMPACT near clamp01Scale) has a real middle state
          -- (compact), so "C" cycles it through all three (full -> compact
          -- -> bar -> full, wrapping) instead of the plain boolean flip
          -- Items/Route-Battle still use -- they don't have anything to
          -- show at a middle level, so a 2-state toggle stays correct for
          -- them.
          -- v2.9.5, direct request: a panel with no compact level only has
          -- full<->collapsed to toggle between, and collapsed means fully
          -- INVISIBLE outside edit mode -- fine in landscape (the other
          -- panels stay visible alongside it), but in portrait's
          -- single-panel carousel that's the ONE thing currently on
          -- screen, so "collapsing" it just blanks the whole visible page.
          -- Disabled for portrait specifically, not removed outright --
          -- landscape keeps the existing toggle unchanged.
          if SUPPORTS_COMPACT[C.overlayEdit.sel] then
            setLevel(cfg, (levelOf(cfg) + 1) % 3)
          elseif not C.isPortrait then
            cfg.collapsed = not cfg.collapsed
          end
          savePanelCfg()
        elseif key == "i" then
          -- Session 80: collapse the selected panel -- moved here from
          -- gamepad L2 (see love.gamepadaxis) to free L2/R2 for the new
          -- global-scale control below. "i" is what X already maps to via
          -- PAD_KEYMAP (normally the Items-screen shortcut, a total no-op
          -- in edit mode before this, since edit mode swallows every
          -- unrecognized key) -- so X now does this directly, no PAD_KEYMAP
          -- change needed, and "i" on a real keyboard picks up the same
          -- behavior as a side effect (also a prior no-op here, so nothing
          -- lost). Outside edit mode "i"/X still open the Items screen,
          -- completely unchanged.
          --
          -- Session 82: on panels that support it (SUPPORTS_COMPACT),
          -- steps one level MORE collapsed (full->compact->bar) instead
          -- of always jumping straight to bar -- clamped, not wrapped, so
          -- repeated presses converge on bar and stay there, same
          -- non-alternating shape Session 56 established for this control.
          -- v2.9.5: same portrait exclusion as "C" above.
          if SUPPORTS_COMPACT[C.overlayEdit.sel] then
            setLevel(cfg, levelOf(cfg) + 1)
          elseif not C.isPortrait then
            cfg.collapsed = true
          end
          savePanelCfg()
        elseif key == "p" then
          -- Session 80: expand counterpart to "i" above -- Y's existing
          -- PAD_KEYMAP mapping to "p" (normally Party/Boxes), same
          -- previously-a-no-op-in-edit-mode reasoning.
          --
          -- Session 82: on panels that support it, steps one level LESS
          -- collapsed (bar->compact->full), clamped at full.
          if SUPPORTS_COMPACT[C.overlayEdit.sel] then
            setLevel(cfg, levelOf(cfg) - 1)
          else
            cfg.collapsed = false
          end
          savePanelCfg()
        elseif key == "-" or key == "kp-" or key == "=" or key == "kp+" then
          -- Session 80: "scale everything at once" control, distinct from
          -- up/down above (which only touch the one selected panel's own
          -- cfg.scale). Gamepad equivalent is L2/R2 (see love.gamepadaxis)
          -- -- L1/R1 were the first choice but those already control game
          -- speed (the same discovery that moved collapse/expand off
          -- L1/R1 onto L2/R2 back in Session 47).
          --
          -- Session 87: originally a separate `C.globalScale` multiplier
          -- layered underneath every panel's own cfg.scale in the `s`
          -- formula (see gScale()'s old comment, removed). On direct
          -- report, that read as a second, disconnected scaling system --
          -- it changed what was actually drawn without changing any
          -- panel's own displayed percentage. Reworked to bulk-edit every
          -- panel's cfg.scale directly instead -- literally what up/down
          -- already does to the selected panel, just looped over all of
          -- PANEL_KEYS at once. Same clamp01Scale bounds per panel, so a
          -- panel already at 40% or 200% just stops moving on its own
          -- once it hits that end, independent of the others.
          local delta = (key == "-" or key == "kp-") and -0.1 or 0.1
          for _, k in ipairs(PANEL_KEYS) do
            C.panelCfg[k].scale = clamp01Scale(C.panelCfg[k].scale + delta)
          end
          savePanelCfg()
        elseif key == "r" then
          cfg.scale = 1; cfg.collapsed = false; cfg.compact = false; cfg.pos = false; savePanelCfg()
        elseif key == "escape" then
          C.editClose(c)   -- pops the pausing modal + clears drag/pinch/resize
        end
        return true
      end
      if OVERLAY_KEYS[key] then c.visible = not c.visible; return true end
      if key == ITEMS_KEY and c.openScreen then c.visible = false; c.openScreen("items"); return true end
      if key == PARTY_KEY and c.openScreen then c.visible = false; c.openScreen("party"); return true end
    end
    return false  -- when a screen is open the pushed state captures keys itself
  end
  -- Keyboard (sandbox-safe). The old path monkey-patched C.game.keypressed --
  -- not a love.* assignment, so modkit doesn't flag it, but patching the engine
  -- Game object is exactly the sort of reach-in we're moving off. love.keyboard
  -- stays readable under the sandbox, so we POLL the overworld hotkeys once per
  -- frame (from the core.update hook) and edge-detect. In-screen and edit-mode
  -- keys do NOT poll: while a kanto modal is pushed the engine hands keyboard to
  -- its onKeyPressed (the sanctioned top-state path -- see ensureModalState),
  -- and polling too would double-fire. So the poll runs ONLY in the overworld.
  -- These keys (o/f8/i/p/f6/f9) aren't bound to any game action, so not being
  -- able to consume (a poll can't) is fine -- the game ignores them anyway.
  -- Full key set kanto reads: overworld hotkeys (o/f8/i/p/f6/f9), plus every
  -- edit-mode and screen key (tab/arrows/c/r/-/=/escape). Polled ungated in
  -- ALL states and routed exactly like the old keyboard wrapper -- onKeyDown
  -- handles the overworld hotkeys and all edit-mode keys (returns true when it
  -- does); when a screen is open onKeyDown returns false (its `not c.screen`
  -- gate), so we fall through to onScreenKey. This is the single keyboard path
  -- now (the modal onKeyPressed is a consuming no-op, so no double-fire).
  local KEY_POLL = { "o", "f8", "i", "p", "f6", "f9", "escape", "tab",
    "up", "down", "left", "right", "c", "r", "-", "=", "kp-", "kp+" }
  -- v2.9.5: real search typing, replacing the old jump-to-letter's `[`/`]`.
  -- A SEPARATE poll from KEY_POLL above, gated on C.searchGrid being open
  -- (see C.onScreenKey's own matching guard) so typing "u"/"i"/"p"/etc for
  -- a query can never ALSO fire KEY_POLL's unrelated bindings for those
  -- same letters -- and so this list doesn't grow KEY_POLL's own
  -- always-on-every-frame set by 26 entries for a feature that's open a
  -- small fraction of the time.
  C.SEARCH_KEY_POLL = { "a","b","c","d","e","f","g","h","i","j","k","l","m",
    "n","o","p","q","r","s","t","u","v","w","x","y","z",
    "backspace", "return", "escape" }
  C.pollSearchKeys = function()
    if not C.searchGrid then return end
    C.searchKeyPrev = C.searchKeyPrev or {}
    local prev = C.searchKeyPrev
    for _, k in ipairs(C.SEARCH_KEY_POLL) do
      local okD, cur = pcall(love.keyboard.isDown, k)
      cur = okD and cur == true
      if cur and not prev[k] then
        if k == "backspace" then C.searchBackspace()
        elseif k == "return" or k == "escape" then C.closeSearchGrid()
        else C.searchAppendLetter(k:upper()) end
      end
      prev[k] = cur
    end
  end
  C.pollKeys = function()
    local c = _G.__KANTO_INGAME
    if not c then return end
    C.keyPrev = C.keyPrev or {}
    local prev = C.keyPrev
    for _, k in ipairs(KEY_POLL) do
      local okD, cur = pcall(love.keyboard.isDown, k)
      cur = okD and cur == true
      if cur and not prev[k] then
        c.debugLast = "key: " .. k; c.debugLastAt = love.timer.getTime()
        local handled = c.onKeyDown and c.onKeyDown(true, k)
        if not handled and c.screen and c.onScreenKey then c.onScreenKey(k) end
      elseif prev[k] and not cur and (k == "up" or k == "down") then
        -- v2.9.5: keyboard has no separate "release" event the way
        -- love.gamepadreleased gives the real D-pad (see its own
        -- padScrollHold clear on "dpup"/"dpdown" release) -- polling for
        -- the down-to-up transition here is the keyboard equivalent, so a
        -- held arrow key's hold-to-repeat actually stops instead of
        -- running forever once started. Matched by direction (dir 1=up,
        -- -1=down) so releasing one arrow can't stop a hold the OTHER
        -- arrow (or the real D-pad) is still actively driving.
        local dir = (k == "up") and 1 or -1
        if c.padScrollHold and c.padScrollHold.dir == dir then c.padScrollHold = nil end
      end
      prev[k] = cur
    end
  end
  -- LIGHT BUILD, Session 52: first touch-input step for overlay edit
  -- mode -- tap/click a panel to select it, the same thing Tab/D-pad
  -- already do, just via touch instead of cycling. Deliberately just
  -- selection, not select+collapse combined into one gesture: tapping to
  -- look at a panel shouldn't also silently collapse it if the player
  -- then reaches for the keyboard/gamepad scale controls instead.
  -- Consumes the touch/click unconditionally whenever edit mode is
  -- active, whether or not it landed on a panel -- same "capture
  -- everything while active" reasoning onKeyDown already uses, so a tap
  -- meant for adjusting the overlay can't leak through as a move/menu
  -- action in the game underneath.
  local function tryEditPanelSelect(x, y, touchId)
    local c = _G.__KANTO_INGAME
    if not (c and not c.screen and C.overlayEdit.active) then return false end
    -- v2.9.5, direct request ("touch only users have no way to reset the
    -- touch nav or icons, only keyboard or gamepad users do"): F9
    -- (keyboard) and hold-L3 (gamepad) both fire C.doPanicReset, but
    -- neither is reachable without a keyboard or gamepad. This is the
    -- touch equivalent -- same ~1s HOLD gesture as L3's own (not an
    -- instant tap; a stray touch shouldn't be able to wipe out real
    -- customization). Checked BEFORE the hintBoxRect check right below,
    -- since the reset row's rect sits inside that same box's bottom
    -- edge -- same corner-before-icon priority precedent this file
    -- already established for other overlapping hit-zones. Only ARMS
    -- here; C.onFrame's per-frame poll (see its own comment) is what
    -- actually fires C.doPanicReset once the hold completes, the same
    -- split C.longPressStart already uses for the same reason (a single
    -- press/release event can't measure elapsed time on its own).
    do
      local r = C.overlayEdit.resetAllRect
      local ex, ey = x / s, y / s
      if r and ex >= r.x and ex <= r.x + r.w and ey >= r.y and ey <= r.y + r.h then
        C.resetAllHoldStart = { x = x, y = y, t = love.timer.getTime() }
        return true
      end
    end
    -- v2.9.5 fix, direct report (Galaxy S23 Ultra, touch-only): the hint
    -- box drawn by drawEditHUD is also a tap-to-close target (see
    -- C.overlayEdit.hintBoxRect, set there every frame the box draws --
    -- only ever stale if this ran before edit mode's first frame, which
    -- the C.overlayEdit.active guard above already rules out). Checked
    -- FIRST, before pinch/corner/icon/select below, so a tap squarely on
    -- the box can never be swallowed by a panel hit-test underneath it.
    do
      local r = C.overlayEdit.hintBoxRect
      local ex, ey = x / s, y / s
      if r and ex >= r.x and ex <= r.x + r.w and ey >= r.y and ey <= r.y + r.h then
        C.editClose(c)
        return true
      end
    end
    -- Bug fix, Session 60: confirmed via video that a single physical tap
    -- was toggling collapse twice, netting no visible change -- LOVE
    -- synthesizes a mouse event for every touch by default, and this
    -- function is wired into both love.touchpressed and love.mousepressed,
    -- so the "echo" event was re-processing the same tap a moment later.
    -- Debounce: ignore a call landing within 250ms and 20 real px of the
    -- previous one, regardless of which handler it came from -- close
    -- enough in both time and position to be the same physical tap, not
    -- a genuine second one.
    local now = love.timer.getTime()
    -- v2.9.x-sandbox: the old 250ms echo-debounce here guarded LOVE's SYNTHESIZED
    -- mouse-from-touch, which no longer reaches us -- input.pointer delivers a
    -- touch exactly once (the engine drops the istouch mouse twin). It's removed
    -- so it can't swallow an intentional double-tap-the-header reset (added in the
    -- drag-handle block below).
    local dx, dy = x / s, y / s
    local tid = touchId or "mouse"
    -- Pinch-to-zoom, Session 66; relaxed Session 70. A genuinely new
    -- second finger upgrades an already-down finger into a pinch,
    -- provided AT LEAST ONE of the two (not necessarily both, since
    -- Session 70) is inside a panel's bounds -- the other is free to
    -- land anywhere on screen. Originally required both fingers inside
    -- the same panel, which became genuinely hard to do once a panel is
    -- scaled down small (there's just not enough box left to fit two
    -- fingers in). Checked before the icon/handle/select hit-tests below
    -- so it takes priority over starting a fresh single-finger
    -- interaction with the new finger. Deliberately whole-panel-body
    -- based (not handle/icon-specific) -- pinch is a natural "grab the
    -- panel with two fingers" gesture, not something that should
    -- require precisely landing on a dedicated zone the way drag/
    -- collapse do.
    local function panelAt(px, py)
      for which, b in pairs(C.overlayEdit.bounds) do
        if px >= b.x and px <= b.x + b.w and py >= b.y and py <= b.y + b.h then return which end
      end
      return nil
    end
    local hitWhich = panelAt(dx, dy)
    if not C.overlayEdit.pinch then
      for otherId, pos in pairs(C.overlayEdit.touches) do
        -- Session 70: which panel this pinch targets is whichever of
        -- the two fingers actually landed in one -- preferring THIS
        -- (the new) finger's panel if it's in one, otherwise falling
        -- back to the other finger's. If both happen to be in a panel,
        -- they're required to agree (same as before Session 70) --
        -- two fingers each precisely inside two DIFFERENT small panels
        -- at once is exactly the awkward case this change exists to
        -- avoid depending on, so it's left ambiguous/no-op rather than
        -- guessing which one was meant.
        local otherWhich = otherId ~= tid and panelAt(pos.dx, pos.dy) or nil
        -- NOT the `cond and nil or fallback` idiom -- that's a real Lua
        -- footgun here: `cond and nil` is always falsy regardless of
        -- cond, so `or fallback` would always win and silently defeat
        -- the "leave ambiguous" case below. Plain if/else instead.
        local which
        if hitWhich and otherWhich then
          if hitWhich == otherWhich then which = hitWhich end
        else
          which = hitWhich or otherWhich
        end
        if otherId ~= tid and which then
          -- A single-finger drag might already be tracking otherId (if
          -- its press landed on the drag handle specifically) -- cancel
          -- it rather than let both a drag and a pinch respond to the
          -- same finger at once. Session 68: restore cfg.pos to its
          -- own prevPos snapshot from the instant before this drag
          -- started, not just stop tracking it -- otherwise whatever
          -- partial movement the one or two touchmoved events that fired
          -- before the second finger arrived already wrote would stick
          -- around permanently, silently pulling this panel out of the
          -- default stack from what was actually a pinch attempt, not a
          -- real drag.
          if C.overlayEdit.drag and C.overlayEdit.drag.touchId == otherId then
            C.panelCfg[C.overlayEdit.drag.which].pos = C.overlayEdit.drag.prevPos
            C.overlayEdit.drag = nil
          end
          local dist0 = math.sqrt((dx - pos.dx)^2 + (dy - pos.dy)^2)
          C.overlayEdit.pinch = {
            which = which, idA = otherId, idB = tid,
            ax = pos.dx, ay = pos.dy, bx = dx, by = dy,
            startDist = math.max(dist0, 1),
            startScale = C.panelCfg[which].scale,
          }
          C.overlayEdit.sel = which
          C.overlayEdit.touches[tid] = { dx = dx, dy = dy }
          C.panelCfgDebugMsg = string.format("PINCH START: %s, startDist=%.0f, startScale=%.2f",
            which, dist0, C.panelCfg[which].scale)
          C.panelCfgDebugMsgAt = now
          return true
        end
      end
    end
    C.overlayEdit.touches[tid] = { dx = dx, dy = dy }
    -- Bug fix, direct report ("items resize corners feel smaller / harder
    -- to grab than the other panels"): corner-check now runs BEFORE the
    -- icon-check below (was: icon first, see that block's own comment).
    -- Root cause: both hit zones are deliberately oversized for touch
    -- (Session 58 grew the icon to a 62x62 hit box for exactly this
    -- reason; Session 77 grew the corner hit box to 56x56 the same way),
    -- but panels are only stacked 16 design units apart -- so a panel's
    -- OWN icon zone (reaching ~10 units above its own top, into the gap)
    -- and the panel ABOVE it's bottom-corner zone (reaching ~12 units
    -- below the gap, into the panel below) unavoidably overlap by ~22
    -- units. With icon checked first, the icon always won that overlap --
    -- silently eating into the ABOVE panel's corner-grab area. Items sits
    -- in the middle of the stack (Trainer above, Route/Battle below), so
    -- it's squeezed from both directions -- loses reach on its own
    -- bottom corner to Route/Battle's icon, same as Trainer loses reach
    -- on ITS bottom corner to Items' icon -- and since Items' height
    -- tracks actual inventory count (can be short), the lost strip is a
    -- bigger fraction of its total grab area, which is exactly why it
    -- was the one that felt off. Corner-drag is the more deliberate,
    -- precision-sensitive gesture of the two (a miss on the icon just
    -- means tap again; a miss on the corner means the drag never starts),
    -- so it gets priority in the overlap now. Neither hit box was shrunk
    -- -- this only changes which one wins when they genuinely overlap.
    --
    -- Corner resize, Session 72; opened up to touch too, Session 73.
    -- Tracks touchId (Session 73) so updateResize/endResize only respond
    -- to the same touch/mouse that actually started this resize, same
    -- ownership pattern drag/pinch already use.
    --
    -- Session 76 bugfix: both corners used to share ONE anchor per panel
    -- (based on which side it defaults to pivoting from), instead of
    -- each corner anchoring to its OWN diagonally-opposite corner the
    -- way a real window resize works. Confirmed on direct report: the
    -- corner nearest that shared anchor tracked the finger fine, the far
    -- corner didn't -- because dragging it was being measured against a
    -- point nowhere near where the finger actually was. Now anchored per
    -- grab: BR keeps the current top-LEFT fixed, BL keeps the current
    -- top-RIGHT fixed -- both keep the top edge fixed either way, since
    -- both are bottom-corner grabs. See updateResize for the position
    -- math this drives (BL now has to actively shift cfg.pos.x as it
    -- resizes, to keep that fixed right edge actually fixed -- BR
    -- doesn't, since top-left not moving was already true by default).
    if not C.overlayEdit.resize then
      for which, b in pairs(C.overlayEdit.bounds) do
        local cornerName = nil
        if b.resizeBL and dx >= b.resizeBL.x and dx <= b.resizeBL.x + b.resizeBL.w and dy >= b.resizeBL.y and dy <= b.resizeBL.y + b.resizeBL.h then
          cornerName = "BL"
        elseif b.resizeBR and dx >= b.resizeBR.x and dx <= b.resizeBR.x + b.resizeBR.w and dy >= b.resizeBR.y and dy <= b.resizeBR.y + b.resizeBR.h then
          cornerName = "BR"
        end
        if cornerName then
          local anchorX = (cornerName == "BR") and b.x or (b.x + b.w)
          local anchorY = b.y
          local dist0 = math.sqrt((dx - anchorX)^2 + (dy - anchorY)^2)
          C.overlayEdit.sel = which
          C.overlayEdit.resize = {
            which = which, touchId = tid, corner = cornerName,
            anchorX = anchorX, anchorY = anchorY,
            startW = b.w, startH = b.h,
            startDist = math.max(dist0, 1),
            startScale = C.panelCfg[which].scale,
          }
          C.panelCfgDebugMsg = string.format("RESIZE START: %s (%s), startDist=%.0f, startScale=%.2f", which, cornerName, dist0, C.panelCfg[which].scale)
          C.panelCfgDebugMsgAt = now
          return true
        end
      end
    end
    -- LIGHT BUILD, Session 57: check every panel's collapse icon next --
    -- a hit there toggles collapse and selects that panel, consuming the
    -- tap immediately. Only falls through to the plain "select" check
    -- below if no icon was hit, so tapping the icon can never also count
    -- as a plain panel-select tap on top of the collapse toggle. Moved to
    -- run AFTER the corner-check above (was first) -- see that block's
    -- comment for why.
    -- Session 59: report the actual hit-test comparison, not just
    -- whether it hit -- design-space touch position against the closest
    -- icon's real bounds, so a miss shows exactly how close/far it was
    -- instead of just "didn't work."
    local nearestDist, nearestWhich, nearestIcon
    for which, b in pairs(C.overlayEdit.bounds) do
      local icon = b.icon
      if icon then
        if dx >= icon.x and dx <= icon.x + icon.w and dy >= icon.y and dy <= icon.y + icon.h then
          -- Session 82: same 3-way cycle on touch as the "C" key uses (see
          -- onKeyDown/SUPPORTS_COMPACT) -- every other panel keeps the
          -- plain toggle it already had.
          -- v2.9.5: same portrait exclusion as onKeyDown's "C" handler.
          if SUPPORTS_COMPACT[which] then
            setLevel(C.panelCfg[which], (levelOf(C.panelCfg[which]) + 1) % 3)
          elseif not C.isPortrait then
            C.panelCfg[which].collapsed = not C.panelCfg[which].collapsed
          end
          C.overlayEdit.sel = which
          savePanelCfg()
          C.panelCfgDebugMsg = string.format("ICON HIT: %s at design (%.0f,%.0f), icon bounds x[%.0f-%.0f] y[%.0f-%.0f]",
            which, dx, dy, icon.x, icon.x+icon.w, icon.y, icon.y+icon.h)
          C.panelCfgDebugMsgAt = love.timer.getTime()
          return true
        end
        local cx, cy = icon.x + icon.w/2, icon.y + icon.h/2
        local dist = math.sqrt((dx-cx)^2 + (dy-cy)^2)
        if not nearestDist or dist < nearestDist then
          nearestDist, nearestWhich, nearestIcon = dist, which, icon
        end
      end
    end
    if nearestIcon then
      C.panelCfgDebugMsg = string.format("ICON MISS: touch design (%.0f,%.0f), nearest=%s bounds x[%.0f-%.0f] y[%.0f-%.0f] (%.0fpx away)",
        dx, dy, nearestWhich, nearestIcon.x, nearestIcon.x+nearestIcon.w, nearestIcon.y, nearestIcon.y+nearestIcon.h, nearestDist)
      C.panelCfgDebugMsgAt = love.timer.getTime()
    end
    -- LIGHT BUILD, Session 62: drag handle checked next, same "dedicated
    -- zone, not a side effect of general selection" pattern as the
    -- collapse icon. A hit starts tracking a drag for this touch/mouse
    -- id -- the offset is the finger's grab point relative to the
    -- panel's current top-left, in design space, so the panel follows
    -- the finger naturally instead of snapping to re-center under it.
    -- touchId defaults to "mouse" for mouse-originated calls, the same
    -- pseudo-id convention gen1recomp's own source already uses for
    -- synthesized mouse pointer events (Game:touchreleased("mouse",...)).
    for which, b in pairs(C.overlayEdit.bounds) do
      local handle = b.handle
      if handle and dx >= handle.x and dx <= handle.x + handle.w and dy >= handle.y and dy <= handle.y + handle.h then
        -- Double-tap the header to RESET this panel (touch per-panel reset,
        -- matching R on keyboard / short L3 on gamepad). A second header tap on
        -- the same panel within 0.4s resets it and cancels the drag the first tap
        -- started; otherwise this tap begins a normal header drag.
        local dtap = C.overlayEdit.dtap
        if dtap and dtap.which == which and (now - dtap.t) < 0.4 then
          local cfg = C.panelCfg[which]
          cfg.scale = 1; cfg.collapsed = false; cfg.compact = false; cfg.pos = false
          C.overlayEdit.sel = which
          C.overlayEdit.drag = nil
          C.overlayEdit.dtap = nil
          savePanelCfg()
          C.panelCfgDebugMsg = "DOUBLE-TAP RESET: " .. which
          C.panelCfgDebugMsgAt = now
          return true
        end
        C.overlayEdit.dtap = { t = now, which = which }
        C.overlayEdit.sel = which
        C.overlayEdit.drag = {
          which = which, touchId = touchId or "mouse",
          offsetX = dx - b.x, offsetY = dy - b.y,
          -- Session 68: snapshot pos as it was the instant BEFORE this
          -- drag started (false if it was never dragged before), so a
          -- second finger landing moments later and upgrading this into
          -- a pinch (see the pinch-start block above) can restore this
          -- exact value instead of leaving whatever partial movement
          -- updateDrag already wrote from the one/two touchmoved events
          -- that fired in between. Without this, even a single-pixel
          -- accidental drag before the second finger registers would
          -- permanently pull this panel out of the default stack.
          prevPos = C.panelCfg[which].pos,
        }
        C.panelCfgDebugMsg = string.format("DRAG START: %s, grabbed at design (%.0f,%.0f)", which, dx, dy)
        C.panelCfgDebugMsgAt = love.timer.getTime()
        return true
      end
    end
    for which, b in pairs(C.overlayEdit.bounds) do
      if dx >= b.x and dx <= b.x + b.w and dy >= b.y and dy <= b.y + b.h then
        C.overlayEdit.sel = which
        break
      end
    end
    return true
  end
  -- LIGHT BUILD, Session 62: shared drag update/end helpers, used by
  -- touchmoved/mousemoved and touchreleased/mousereleased alike, so the
  -- actual drag logic exists in exactly one place rather than four
  -- near-copies. Both check the touch/mouse id against whichever one
  -- started the drag (Session 62's touchId tracking in
  -- tryEditPanelSelect) -- a second finger moving elsewhere, or the
  -- mouse's own synthesized echo of a touch already being tracked,
  -- can't hijack or interfere with an in-progress drag.
  local function updateDrag(x, y, touchId)
    local drag = C.overlayEdit.drag
    if not (drag and drag.touchId == (touchId or "mouse")) then return false end
    local dx, dy = x / s, y / s
    -- v2.9.5: tagged with the orientation this drag is actually happening
    -- in (see drawEditablePanel's own comment on cfg.pos.portrait) -- a
    -- landscape drag no longer leaks into portrait's layout or vice versa.
    C.panelCfg[drag.which].pos = { x = dx - drag.offsetX, y = dy - drag.offsetY, portrait = C.isPortrait }
    return true
  end
  local function endDrag(touchId)
    local drag = C.overlayEdit.drag
    if not (drag and drag.touchId == (touchId or "mouse")) then return false end
    C.overlayEdit.drag = nil
    savePanelCfg()
    C.panelCfgDebugMsg = string.format("DRAG END: %s", drag.which)
    C.panelCfgDebugMsgAt = love.timer.getTime()
    return true
  end
  -- Pinch-to-zoom, Session 66: mirrors updateDrag/endDrag's shape and
  -- touch-id-ownership pattern exactly, just for a pair of ids instead
  -- of one. touchmoved for either finger recomputes the live distance
  -- between both and derives scale as a ratio against the distance at
  -- pinch-start, through the same clamp01Scale bounds ([0.4, 2]) the
  -- keyboard/gamepad Up/Down scale controls already use, so touch and
  -- non-touch scaling can never disagree on the valid range.
  local function updatePinch(x, y, touchId)
    local pinch = C.overlayEdit.pinch
    if not (pinch and (touchId == pinch.idA or touchId == pinch.idB)) then return false end
    local dx, dy = x / s, y / s
    C.overlayEdit.touches[touchId] = { dx = dx, dy = dy }
    if touchId == pinch.idA then pinch.ax, pinch.ay = dx, dy
    else pinch.bx, pinch.by = dx, dy end
    local dist = math.sqrt((pinch.bx - pinch.ax)^2 + (pinch.by - pinch.ay)^2)
    C.panelCfg[pinch.which].scale = clamp01Scale(pinch.startScale * (dist / pinch.startDist))
    return true
  end
  local function endPinch(touchId)
    local pinch = C.overlayEdit.pinch
    if not (pinch and (touchId == pinch.idA or touchId == pinch.idB)) then return false end
    C.overlayEdit.pinch = nil
    savePanelCfg()
    C.panelCfgDebugMsg = string.format("PINCH END: %s, finalScale=%.2f", pinch.which, C.panelCfg[pinch.which].scale)
    C.panelCfgDebugMsgAt = love.timer.getTime()
    return true
  end
  -- Corner resize, Session 72; opened to touch, Session 73. Mirrors
  -- updatePinch/endPinch's shape -- distance-from-a-fixed-point scaling
  -- -- but the fixed point is the panel's own pivot (recorded at
  -- resize-start) instead of a second finger. Now checks touchId
  -- ownership the same way updateDrag/endDrag do, since Session 73
  -- means this is no longer necessarily the single mouse pointer -- a
  -- second, unrelated finger moving elsewhere must not be able to
  -- affect a resize someone else's finger started.
  --
  -- Session 76: also writes cfg.pos now, not just cfg.scale. A BR grab
  -- keeps the top-left anchor fixed, which is already where the panel's
  -- top-left renders from by default, so pinning pos there doesn't
  -- visibly change anything -- but a BL grab's anchor (top-right) is
  -- NOT where the panel renders from by default, so without actively
  -- moving pos.x left as the width grows, the "fixed" top-right corner
  -- would actually drift right along with the panel's own left edge
  -- instead of staying put. This is what was actually broken before.
  local function updateResize(x, y, touchId)
    local resize = C.overlayEdit.resize
    if not (resize and resize.touchId == (touchId or "mouse")) then return false end
    local dx, dy = x / s, y / s
    local dist = math.sqrt((dx - resize.anchorX)^2 + (dy - resize.anchorY)^2)
    local newScale = clamp01Scale(resize.startScale * (dist / resize.startDist))
    local newW = resize.startW * (newScale / resize.startScale)
    C.panelCfg[resize.which].scale = newScale
    -- v2.9.5: same orientation tag as updateDrag above, same reason.
    if resize.corner == "BR" then
      C.panelCfg[resize.which].pos = { x = resize.anchorX, y = resize.anchorY, portrait = C.isPortrait }
    else -- "BL"
      C.panelCfg[resize.which].pos = { x = resize.anchorX - newW, y = resize.anchorY, portrait = C.isPortrait }
    end
    return true
  end
  local function endResize(touchId)
    local resize = C.overlayEdit.resize
    if not (resize and resize.touchId == (touchId or "mouse")) then return false end
    C.overlayEdit.resize = nil
    savePanelCfg()
    C.panelCfgDebugMsg = string.format("RESIZE END: %s, finalScale=%.2f", resize.which, C.panelCfg[resize.which].scale)
    C.panelCfgDebugMsgAt = love.timer.getTime()
    return true
  end
  -- Session 93: continuous per-frame equivalent of love.mousemoved's
  -- `updateResize(x,y)`/`updateDrag(x,y,"mouse")` pair, for the stick
  -- cursor -- the stick has no "moved" event to hook (see
  -- C.updateStickCursor, which only ever moves C.vcx/vcy), so this gets
  -- called every frame instead (see its call site, right after
  -- C.updateStickCursor(dt)) and relies on updateResize/updateDrag's own
  -- existing no-op guard (only acts if a resize/drag with touchId=="mouse"
  -- is actually in progress) to make that safe and cheap.
  --
  -- Session 97 bugfix: "A" starting a drag/select used to rely entirely
  -- on love.gamepadpressed's one-shot "a" EVENT (fires once, exactly at
  -- the physical down-transition) checking C.stickActive, itself only
  -- set true on a PER-FRAME poll in C.updateStickCursor. Confirmed via a
  -- live diagnostic HUD (stickActive really was true, cursor position
  -- really was live and correct) plus direct report ("accidentally and
  -- coincidentally" got a drag to work once) that this only worked when
  -- the press event happened to land on a frame where stickActive was
  -- ALREADY true -- press the stick and A at nearly the same moment
  -- (the natural way to do it) and the one-shot event can fire before
  -- stickActive catches up, with no second chance since gamepadpressed
  -- never fires again while A stays held. Polling "A" here instead --
  -- every frame, right alongside the cursor's own per-frame update --
  -- removes the race entirely: both checks now happen on the same
  -- cadence. C.padPressed's own "a" handling (see PAD_KEYMAP comments) is
  -- left in place, not removed -- it's needed for the non-edit-mode
  -- (screen-open) stick+A click case this function doesn't cover.
  --
  -- CORRECTION (sandbox-rewrite bugfix, direct report: "can't grab the
  -- header, it registers as a double-tap reset instead"): the paragraph
  -- above used to say tryEditPanelSelect's old echo-debounce kept
  -- C.padPressed's direct call and this function's own poll safe to both
  -- fire for the same press. That debounce is GONE (see
  -- tryEditPanelSelect's own "v2.9.x-sandbox" comment -- removed so it
  -- couldn't swallow an intentional double-tap-header-reset), and nothing
  -- replaced it -- so a single physical A-press on a header was landing
  -- as two tryEditPanelSelect calls moments apart: C.padPressed's fires
  -- first (pollPad runs before onFrame/this function in the same
  -- core.update tick), starts a drag and arms the reset window; this
  -- function's own poll fires microseconds later, same panel, well under
  -- the reset's 0.4s window -- so it self-satisfied the double-tap-reset
  -- and canceled the drag it had just started. (Same root cause explained
  -- a "+/- collapse button does nothing" report too: a boolean collapse
  -- toggled twice nets zero visible change.) Fixed by routing BOTH
  -- C.padPressed and this function's first-press branch through
  -- C.claimStickAPress below, which claims a fresh press exactly once via
  -- the existing C.editStickADown/editStickAConsumed pair -- whichever of
  -- the two runs first in a frame wins, the other is a no-op for that
  -- same press.
  C.claimStickAPress = function()
    if C.editStickADown then return C.editStickAConsumed end
    C.editStickADown = true
    if C.stickActive then
      -- v81 port: resize grip checked before the group-drag zone, same
      -- priority as every other input path (see tryTouchGroupResizeStart's
      -- own comment).
      C.editStickAConsumed = tryTouchGroupResizeStart(C.vcx or 0, C.vcy or 0, "mouse")
        or tryTouchGroupDragStart(C.vcx or 0, C.vcy or 0, "mouse")
        or tryEditPanelSelect(C.vcx or 0, C.vcy or 0, "mouse")
    else
      C.editStickAConsumed = false
      C.editStickAPending = true
    end
    return C.editStickAConsumed
  end
  --
  -- C.editStickAPending covers the narrow remaining case: A goes down on
  -- the very SAME frame stickActive is still false (only realistically
  -- possible the very first time the stick is touched in edit mode this
  -- session, before it's ever latched true). Rather than never trying
  -- again for the rest of that hold, it retries exactly once, the moment
  -- stickActive does catch up -- NOT every frame while held, which would
  -- spam tryEditPanelSelect's debounce (a call within 250ms of the last
  -- one just returns true without re-processing, so blind per-frame
  -- retrying would wrongly mark a genuine miss as "consumed").
  C.driveStickEditMode = function()
    if not C.overlayEdit.active then
      C.editStickADown, C.editStickAConsumed, C.editStickAPending = false, false, false
      return
    end
    -- v79 fix, direct report: "if the control stick cursor is showing,
    -- but no input, and you try to drag a window in edit mode, it pops
    -- to the cursor." Root cause: C.stickActive is deliberately STICKY
    -- (see C.updateStickCursor -- it's set true the moment the stick is
    -- pushed past its deadzone, but never reset back to false once the
    -- stick returns to neutral, so the cursor doesn't vanish the instant
    -- you let go mid-aim). The per-frame block below used to gate only
    -- on that sticky flag, so once the stick had EVER been touched this
    -- session, it kept force-writing the panel's position to the stale,
    -- unmoving C.vcx/C.vcy every single frame -- including while a REAL
    -- mouse or touch drag was in progress, since a real mouse drag also
    -- owns its `C.overlayEdit.drag` under the same "mouse" touchId
    -- sentinel stick+A uses (that sentinel-sharing is intentional, it's
    -- what lets stick+A reuse the exact same drag machinery a mouse
    -- click does -- see updateDrag's own touchId-ownership check, which
    -- can't tell the two apart by touchId alone). Fixed by ALSO
    -- requiring `aDown` (a fresh, non-sticky, real-time poll of the
    -- physical A button, computed once right here instead of further
    -- down) -- a stick-driven drag can only ever be in progress while
    -- A is genuinely, currently held, so this can no longer fire while
    -- an unrelated mouse/touch drag happens to share the same sentinel.
    local aDown = false
    for _, j in ipairs(love.joystick.getJoysticks()) do
      if j:isGamepad() and j:isGamepadDown("a") then aDown = true; break end
    end
    if C.stickActive and aDown then
      updateResize(C.vcx or 0, C.vcy or 0, "mouse")
      updateDrag(C.vcx or 0, C.vcy or 0, "mouse")
      -- v72: same per-frame continuous update the real panels' own
      -- drag already gets here, for the touch-nav/icon groups.
      -- v81 port: resize too (only one of resize/drag is ever in progress).
      updateTouchGroupResize(C.vcx or 0, C.vcy or 0, "mouse")
      updateTouchGroupDrag(C.vcx or 0, C.vcy or 0, "mouse")
    end
    -- v73 fix: tryTouchGroupDragStart now tried FIRST, not as a fallback
    -- after tryEditPanelSelect -- tryEditPanelSelect unconditionally
    -- returns true on every call while edit mode is active (a deliberate
    -- catch-all, see its own definition), so checking it first meant
    -- tryTouchGroupDragStart's own hit-test never ran at all via stick+A,
    -- the same bug this exact ordering had in every mouse/touch callback
    -- too (see tryTouchGroupDragStart's own comment for the full story).
    -- (Body now lives in C.claimStickAPress above, shared with
    -- C.padPressed -- see that function's comment.)
    if aDown and not C.editStickADown then
      C.claimStickAPress()
    elseif aDown and C.editStickAPending and C.stickActive then
      C.editStickAPending = false
      C.editStickAConsumed = tryTouchGroupResizeStart(C.vcx or 0, C.vcy or 0, "mouse")
        or tryTouchGroupDragStart(C.vcx or 0, C.vcy or 0, "mouse")
        or tryEditPanelSelect(C.vcx or 0, C.vcy or 0, "mouse")
    elseif not aDown and C.editStickADown then
      C.editStickADown = false
      C.editStickAPending = false
      if C.editStickAConsumed then endResize(); endDrag("mouse"); endTouchGroupResize("mouse"); endTouchGroupDrag("mouse") end
      C.editStickAConsumed = false
    end
  end
  -- v70: on direct request -- the touch-nav/icon buttons (TOUCH_NAV_LEFT/
  -- RIGHT, TOUCH_ICON_OVERLAY/ITEMS/PARTY) only ever worked via touch,
  -- never mouse, even though every other input path in this file (edit
  -- mode select/drag/resize, the Items/Party screens) already treats
  -- mouse and touch as fully parallel. Confirmed by reading the code:
  -- love.mousepressed never checked these zones at all, only
  -- love.touchpressed did -- an oversight, not a deliberate touch-only
  -- design (nothing anywhere says these were meant to exclude mouse).
  --
  -- Factored the zone-check logic out into this one shared function,
  -- called from BOTH love.mousepressed and love.touchpressed below,
  -- instead of writing it twice -- exactly the "two places that can
  -- drift apart" risk this file's own history already flags repeatedly
  -- (most recently drawEditHUD's v68 bug).
  --
  -- Debounced deliberately: LOVE synthesizes a mousepressed event for
  -- every real touch by default (same fact tryEditPanelSelect's own
  -- debounce above already documents and relies on) -- without this, a
  -- single physical tap on a touch-capable device would fire BOTH the
  -- real touchpressed event and its synthesized mousepressed twin,
  -- double-triggering whatever button was hit (e.g. cycling the overlay
  -- screen twice per tap instead of once). Uses a SEPARATE, shorter
  -- (100ms vs tryEditPanelSelect's 250ms) debounce window rather than
  -- sharing C.overlayEdit.lastTap -- these buttons are meant to support
  -- fast repeated taps (quickly cycling through screens), which a
  -- 250ms window would risk swallowing as false duplicates; 100ms is
  -- still comfortably wider than the same-frame gap between a real touch
  -- and its synthesized echo, while leaving more room for a genuine fast
  -- second tap to still register.
  local function tryTouchNavButtons(x, y, ww, wh)
    local c = _G.__KANTO_INGAME
    if not (c and ww and wh and ww > 0 and wh > 0) then return false end
    -- v72: while edit mode is active, a tap/click here means "grab this
    -- group to drag it" (see tryTouchGroupDragStart), not "activate this
    -- button" -- same split the real panels already have (tapping one in
    -- edit mode selects/drags it instead of doing whatever it normally
    -- does, which for them is nothing at all since content panels have
    -- no tap-to-activate behavior to begin with). Checked first, so
    -- edit mode never fires a screen-cycle/jump by mistake while the
    -- player's actually trying to reposition the row.
    if C.overlayEdit.active then return false end
    local now = love.timer.getTime()
    local last = C.navBtnLastTap
    if last and (now - last.t) < 0.1 and math.abs(x - last.x) < 20 and math.abs(y - last.y) < 20 then
      return true   -- the same physical tap's synthesized echo -- already handled, consume silently
    end
    -- Disabled while something's held on the Items screen -- same
    -- reasoning as the scroll arrows: nothing here is useful mid-transfer,
    -- and leaving them live is just accidental-tap risk right as the
    -- player's trying to tap a destination row.
    local heldBlocksNav = c.screen == "items" and c.held and not c.held.pad
    -- v72: zones now offset by wherever each group was last dragged to
    -- (0,0 if never moved) -- reads the SAME touchGroupOffset the draw
    -- functions use, so a tap always matches where the buttons actually
    -- rendered, never the original fixed position once one has moved.
    -- v81: hit-test each button against its actual on-screen rect (drag
    -- offset AND resize size both applied), through the same single source
    -- of truth the draw code uses -- so a tap always matches where the
    -- button really renders, at whatever position/size it's been set to.
    local function inBtn(which, z)
      local bx, by, bw, bh = touchGroupButtonRect(which, z, ww, wh)
      return x >= bx and x <= bx + bw and y >= by and y <= by + bh
    end
    if not heldBlocksNav and mod.options:get("touch_nav_buttons") and c.onPadCycle then
      if inBtn("touchNav", TOUCH_NAV_LEFT) then
        C.navBtnLastTap = { t = now, x = x, y = y }
        c.onPadCycle(true); return true
      elseif inBtn("touchNav", TOUCH_NAV_RIGHT) then
        C.navBtnLastTap = { t = now, x = x, y = y }
        c.onPadCycle(false); return true
      end
    end
    if not heldBlocksNav and mod.options:get("touch_icon_buttons") then
      local key
      if inBtn("touchIcons", TOUCH_ICON_OVERLAY) then key = "o"
      elseif inBtn("touchIcons", TOUCH_ICON_ITEMS) then key = "i"
      elseif inBtn("touchIcons", TOUCH_ICON_PARTY) then key = "p" end
      if key then
        C.navBtnLastTap = { t = now, x = x, y = y }
        if c.screen and c.onScreenKey then c.onScreenKey(key)
        elseif c.onKeyDown then c.onKeyDown(nil, key) end
        return true
      end
    end
    return false
  end
  -- ---------------------------------------------------------------------
  -- Pointer input (sandbox-safe). The old love.mousepressed/moved/released
  -- and love.touchpressed/moved/released wrappers all assigned love.*, which
  -- the mod sandbox forbids. input.pointer is the sanctioned unified seam: it
  -- delivers ONE event stream for both mouse and touch as
  -- { phase, source, id, x, y, dx, dy, pressure, button }, in the same
  -- window-pixel space the old callbacks used (verified against real 0.1.85
  -- Game:pointerEvent). A real mouse arrives as source="mouse" id="mouse"
  -- (the engine drops synthesized istouch twins, so no double-fire) and a
  -- finger as source="touch" with its own id -- so branching on source
  -- reproduces the two original code paths exactly. Return true to consume
  -- (old bare `return`); call next(...) to fall through (old
  -- `return C.orig...`). The "cancelled" phase (focus / visibility loss) is
  -- handled like a release so an in-progress drag/resize/pinch can't get
  -- stuck -- robustness the old love callbacks never had.
  -- love.wheelmoved is deliberately NOT migrated: there is no sandbox-legal
  -- way to read the wheel yet (no polling API, no input.wheel hook -- see
  -- gen1recomp issue #1285). Box/list scrolling stays reachable via D-pad,
  -- arrow keys and touch drag; C.onScreenWheel is kept defined for when the
  -- hook lands.
  -- ---------------------------------------------------------------------
  -- v2.9.5: long-press to enter Edit Mode, direct report -- a touch-only
  -- player (no keyboard for F6, no gamepad for R3) had genuinely NO path
  -- into Edit Mode at all before this. Confirmed by tracing every real
  -- C.editOpen call site in this file: there is exactly one, inside
  -- C.onKeyDown's "f6" branch, reached only by real keyboard F6 or the R3
  -- hold-timer synthesizing "f6" -- nothing touch-driven anywhere.
  --
  -- Scoped simply rather than to precise per-panel hit-testing ("long
  -- press any of our mod's elements... or something" left room for this):
  -- holding still anywhere on screen for ~1s, WHILE THE OVERLAY IS ALREADY
  -- VISIBLE and edit mode isn't already active and no screen is open,
  -- opens edit mode -- same "show the overlay first, then enter edit"
  -- convention R3 already established (see PAD_KEYMAP's own comment), so
  -- this doesn't introduce a second, inconsistent rule. Armed on press
  -- WITHOUT consuming the event (so a normal tap/short-hold still reaches
  -- the game underneath completely unaffected, e.g. still walks the
  -- character) -- only diverts into opening edit mode if the hold
  -- actually reaches the duration, checked once per frame in C.onFrame
  -- (see its own comment). Cancelled by moving too far (not a "held
  -- still" press anymore) or releasing early.
  -- C-attached (not a bare local): C.onFrame, which does the actual
  -- elapsed-time firing check, is defined much earlier in this file (this
  -- whole input.pointer block comes after it) -- a plain local here
  -- wouldn't be in scope there, same reason C.exitSelectMode and every
  -- other cross-scope helper tonight went on C instead of staying local.
  C.LONG_PRESS_DURATION = 1.0
  local function tryArmLongPress(c, x, y)
    if c and c.visible and not C.overlayEdit.active and not c.screen and C.canEditHere and C.canEditHere() then
      C.longPressStart = { x = x, y = y, t = love.timer.getTime() }
    end
  end
  -- v2.9.5 portrait Stage 1: mirrors the tryTouchGroupDragStart/
  -- endTouchGroupDrag shape already used above for a structurally
  -- identical problem (gesture state shared between the mouse and touch
  -- branches of this same hook) rather than duplicating press/release
  -- handling in both branches separately.
  local PORTRAIT_SWIPE_MIN_DX = 60
  local function tryPortraitPageStart(x, y, touchId)
    local c = _G.__KANTO_INGAME
    if not (c and c.visible and not c.screen and not C.overlayEdit.active) then return false end
    if love.graphics.getWidth() > love.graphics.getHeight() then return false end
    -- v2.9.5 Stage 2: drawOverlay's portrait branch now applies during
    -- battle too (direct report -- the old landscape-during-battle
    -- fallback was just as broken as the overworld case was, confirmed on
    -- a real screenshot), so swipe/dot-tap input is no longer excluded
    -- during battle either -- it's the only way to reach whichever panel
    -- isn't currently showing while the paged layout is up. The battle
    -- menu itself (FIGHT/ITEM/RUN, move selection) is D-pad+A navigated,
    -- not touch-tappable, so consuming a touch here doesn't take anything
    -- away from actual battle controls.
    -- Dot tap jumps straight to that page -- checked first and consumed
    -- immediately, a deliberate precise tap rather than something the
    -- looser swipe-distance check below should also catch.
    local dots = C.portraitDots
    if dots then
      local ddx, ddy = x / s, y / s
      for i = 1, dots.n do
        local cy = dots.y0 + (i - 1) * dots.gap
        if (ddx - dots.x) * (ddx - dots.x) + (ddy - cy) * (ddy - cy) <= (dots.r * 2.5) * (dots.r * 2.5) then
          C.portraitPage = i
          C.portraitPageActivity = love.timer.getTime()
          return true
        end
      end
    end
    -- Arms swipe tracking without consuming -- same non-consuming-arm
    -- shape tryArmLongPress above uses, so a plain tap/drag elsewhere on
    -- the overworld still falls through to the game untouched.
    C.portraitSwipeStart = { x = x, y = y, id = touchId or "mouse" }
    return false
  end
  local function endPortraitPageSwipe(x, y, touchId)
    local armed = C.portraitSwipeStart
    C.portraitSwipeStart = nil
    if not (armed and armed.id == (touchId or "mouse")) then return false end
    local ddx, ddy = x - armed.x, y - armed.y
    if math.abs(ddx) < PORTRAIT_SWIPE_MIN_DX or math.abs(ddx) <= math.abs(ddy) then return false end
    local n = #PANEL_KEYS
    -- Swipe left (finger moves left, ddx negative) advances to the next
    -- page, matching the common "flip to the next card" convention.
    C.portraitPage = (ddx < 0) and ((C.portraitPage % n) + 1) or (((C.portraitPage - 2) % n) + 1)
    C.portraitPageActivity = love.timer.getTime()
    return true
  end
  -- v2.9.5, direct request: grabbable scrollbar for the portrait Party
  -- panel (see party()'s own maxVisibleH/scrollY params and
  -- C.partyScrollbar, set fresh every frame it draws). Same start/update/
  -- end shape as endPortraitPageSwipe/the touch groups above, for the
  -- same reason -- state shared between the mouse and touch branches of
  -- this one hook. Scoped to normal play only (not C.overlayEdit.active)
  -- so this thin right-edge strip never competes with the panel's own
  -- corner-resize grab zone, which only exists in edit mode.
  local function tryPartyScrollbarStart(x, y, touchId)
    if C.overlayEdit.active then return false end
    local sb = C.partyScrollbar
    if not sb then return false end
    local dx, dy = x / s, y / s
    local pad = 10   -- generous touch-target padding, same convention every other grip in this file uses
    if dx >= sb.x - pad and dx <= sb.x + sb.w + pad and dy >= sb.y and dy <= sb.y + sb.h then
      C.partyScrollDrag = { touchId = touchId or "mouse", startY = dy, startScroll = C.partyScrollY or 0, sb = sb }
      return true
    end
    return false
  end
  local function updatePartyScrollbarDrag(x, y, touchId)
    local d = C.partyScrollDrag
    if not (d and d.touchId == (touchId or "mouse")) then return false end
    local dy = y / s
    local track = d.sb.h - d.sb.thumbH
    local scrollDelta = track > 0 and ((dy - d.startY) / track) * d.sb.maxScroll or 0
    C.partyScrollY = math.max(0, math.min(d.sb.maxScroll, d.startScroll + scrollDelta))
    return true
  end
  local function endPartyScrollbarDrag(touchId)
    local d = C.partyScrollDrag
    if not (d and d.touchId == (touchId or "mouse")) then return false end
    C.partyScrollDrag = nil
    return true
  end
  local function cancelLongPressIfMoved(x, y)
    if C.longPressStart then
      local ddx, ddy = x - C.longPressStart.x, y - C.longPressStart.y
      if ddx*ddx + ddy*ddy > 400 then C.longPressStart = nil end   -- ~20 real px of movement cancels it
    end
    -- v2.9.5: same move-cancels-a-hold shape for the reset-all button --
    -- sliding off the row mid-hold shouldn't still fire it.
    if C.resetAllHoldStart then
      local ddx, ddy = x - C.resetAllHoldStart.x, y - C.resetAllHoldStart.y
      if ddx*ddx + ddy*ddy > 400 then C.resetAllHoldStart = nil end
    end
  end
  if not C.wrappedPointer then
    mod.hooks:wrap("input.pointer", function(nextP, game, ev)
      local c = _G.__KANTO_INGAME
      local phase, x, y = ev.phase, ev.x, ev.y
      if ev.source == "mouse" then
        local button = ev.button
        if phase == "pressed" then
          -- v81 port: resize grip checked before the group-drag zone below --
          -- grab the corner -> resize, grab anywhere else in the group -> move
          -- (same priority the real panels' own corner-vs-handle checks use).
          if tryTouchGroupResizeStart(x, y, "mouse") then return true end
          if tryTouchGroupDragStart(x, y, "mouse") then return true end
          if tryEditPanelSelect(x, y) then return true end
          local ww, wh = love.graphics.getDimensions()
          if tryTouchNavButtons(x, y, ww, wh) then return true end
          if c and c.screen and c.onScreenMouse then c.stickActive = false; pcall(c.onScreenMouse, x, y, button); return true end
          -- v2.9.5: nothing else claimed this press -- arm the long-press-
          -- to-edit timer (see its own comment above). Deliberately does
          -- NOT return true: falls through to nextP exactly as it always
          -- did, so a normal click/tap is completely unaffected.
          if tryPartyScrollbarStart(x, y, "mouse") then return true end
          if tryPortraitPageStart(x, y, "mouse") then return true end
          tryArmLongPress(c, x, y)
        elseif phase == "moved" then
          cancelLongPressIfMoved(x, y)
          if updateResize(x, y) then return true end
          if updateDrag(x, y, "mouse") then return true end
          if updateTouchGroupResize(x, y, "mouse") then return true end   -- v81 port
          if updateTouchGroupDrag(x, y, "mouse") then return true end
          if updatePartyScrollbarDrag(x, y, "mouse") then return true end
        elseif phase == "released" or phase == "cancelled" then
          C.longPressStart = nil
          C.resetAllHoldStart = nil   -- v2.9.5: release/cancel before the hold completes is a no-op, not a fire
          -- Bug fix, direct report ("header sometimes resizes instead of
          -- dragging"): unlike the touch branch below (which clears
          -- C.overlayEdit.touches[id] on release), a released mouse never
          -- cleared its "mouse" entry -- only the next press overwrote it.
          -- A stale leftover position could pair with a later, unrelated
          -- single touch to spuriously satisfy tryEditPanelSelect's
          -- two-finger pinch-start check, turning an intended single-
          -- finger header drag into a resize.
          C.overlayEdit.touches["mouse"] = nil
          if endResize() then return true end
          if endTouchGroupResize("mouse") then return true end   -- v81 port
          if endDrag("mouse") then return true end
          if endTouchGroupDrag("mouse") then return true end
          if endPartyScrollbarDrag("mouse") then return true end
          if endPortraitPageSwipe(x, y, "mouse") then return true end
          if c and c.screen then if c.onScreenRelease then pcall(c.onScreenRelease, x, y, button) end; return true end
        end
      else
        local id = ev.id
        if phase == "pressed" then
          local ww, wh = love.graphics.getDimensions()
          if c then
            local px, py = 0, 0
            if ww > 0 and wh > 0 then px, py = x / ww * 100, y / wh * 100 end
            c.debugLast = string.format("touch: %d,%d (%.1f%%,%.1f%% of %dx%d)", math.floor(x), math.floor(y), px, py, ww, wh)
            c.debugLastAt = love.timer.getTime()
          end
          -- v81 port: resize grip checked before the group-drag zone below --
          -- same priority as the mouse branch above.
          if tryTouchGroupResizeStart(x, y, id) then return true end
          if tryTouchGroupDragStart(x, y, id) then return true end
          if tryEditPanelSelect(x, y, id) then return true end
          if tryTouchNavButtons(x, y, ww, wh) then return true end
          -- v2.9.x-sandbox: a screen tap/drag used to reach onScreenMouse via
          -- LOVE's SYNTHESIZED mouse-from-touch, which Game:mousepressed now
          -- drops (istouch). So drive the screen straight from the real touch,
          -- and stash C.touchScreenPos so drawScreen tracks the finger (the held
          -- item follows C.mx/C.my). Mirrors the mouse branch -- INCLUDING its
          -- own `c.stickActive = false` a few lines up (mouse branch, "pressed"):
          -- v2.9.5 bugfix, direct report ("can't see where you're dropping an
          -- item when dragging with your finger after the cursor has been
          -- deployed"). C.drawScreen's C.mx/C.my now favors C.stickActive over
          -- C.touchScreenPos (see its own comment), so once the stick had ever
          -- been nudged this screen session, a finger drag's C.touchScreenPos
          -- kept updating underneath but never won, leaving the held item
          -- visually frozen at the stick's last position. A genuine NEW touch
          -- press is exactly as deliberate a reclaim as a genuine new mouse
          -- press already gets -- this was a same-fix gap between the two
          -- branches, not a new design decision.
          if c and c.screen and c.onScreenMouse then
            c.stickActive = false
            C.touchScreenPos = { px = x, py = y }
            pcall(c.onScreenMouse, x, y, 1)
            return true
          end
          -- v2.9.5: same long-press-to-edit arm as the mouse branch above
          -- (see its own comment) -- deliberately doesn't return true, so
          -- a normal tap still falls through to the game untouched.
          if tryPartyScrollbarStart(x, y, id) then return true end
          if tryPortraitPageStart(x, y, id) then return true end
          tryArmLongPress(c, x, y)
        elseif phase == "moved" then
          cancelLongPressIfMoved(x, y)
          if updatePinch(x, y, id) then return true end
          if updateResize(x, y, id) then return true end
          if updateDrag(x, y, id) then return true end
          if updateTouchGroupResize(x, y, id) then return true end   -- v81 port
          if updateTouchGroupDrag(x, y, id) then return true end
          if updatePartyScrollbarDrag(x, y, id) then return true end
          if c and c.screen then C.touchScreenPos = { px = x, py = y }; return true end
        elseif phase == "released" or phase == "cancelled" then
          C.longPressStart = nil
          C.resetAllHoldStart = nil   -- v2.9.5: release/cancel before the hold completes is a no-op, not a fire
          local handled = endPinch(id) or endResize(id) or endTouchGroupResize(id) or endDrag(id) or endTouchGroupDrag(id)
            or endPartyScrollbarDrag(id) or endPortraitPageSwipe(x, y, id)
          C.overlayEdit.touches[id] = nil
          if handled then return true end
          if c and c.screen then
            C.touchScreenPos = nil
            if c.onScreenRelease then pcall(c.onScreenRelease, x, y, 1) end
            return true
          end
        end
      end
      return nextP(game, ev)
    end)
    C.wrappedPointer = true
  end
  -- ---------------------------------------------------------------------
  -- Gamepad input (sandbox-safe): the old love.gamepadpressed/released/axis
  -- wrappers all assigned love.*, which the mod sandbox forbids. love.joystick
  -- stays readable under the sandbox, so we POLL it once per frame (driven from
  -- the core.update hook) and edge-detect presses/releases ourselves. The
  -- per-button dispatch below is the exact body of the old event handlers, just
  -- reached by comparing this frame's isGamepadDown to last frame's.
  -- Buttons kanto reads: a/b/x/y (face), the four D-pad, leftstick (L3),
  -- rightstick (R3). Axes: triggerleft/right (L2/R2) and leftx/lefty (edit-mode
  -- cursor). Everything is pcall-guarded the way the engine's own raw-pad path
  -- is, so a controller that errors on a button query can't take kanto down.
  -- NOTE: polling can't CONSUME, so in the overworld this is only safe for
  -- buttons the game doesn't bind (X/Y/R3 are free; A/D-pad only act while a
  -- screen or edit mode has pushed a pausing modal). See gen1recomp issue #1285
  -- for the input.gamepad consume hook that would let edit mode run without a
  -- pause.
  -- ---------------------------------------------------------------------
  local PAD_POLL_BUTTONS = { "a", "b", "x", "y",
    "dpup", "dpdown", "dpleft", "dpright", "leftstick", "rightstick" }

  C.padPressed = function(c, button)
    -- v2.9.5: while the confirm popup is up, D-pad left/right moves focus
    -- between Cancel/Confirm (drawn as a gold ring, see drawConfirmPopup
    -- -- replaces the removed "A to confirm / B to cancel" text hint as
    -- the way to see what A currently does) and A activates whichever is
    -- focused; B still cancels directly regardless of focus, unchanged.
    -- Checked before EVERYTHING else in this function (including the
    -- debug/stickActive bookkeeping just below) so no other button can
    -- act while it's showing. Direct fix for the same class of bug as
    -- C.onPadSelect's own bugfix comment: a gamepad path that bypasses
    -- onScreenMouse needs its OWN explicit handling, it doesn't get
    -- covered for free.
    if C.confirmPopup then
      if button == "a" then
        local p = C.confirmPopup; C.confirmPopup = nil
        if p.focus == "cancel" then return end
        if p.tag == "release" then C.executeMultiRelease()
        else C.executeMultiToss(p.tag:match("^toss:(.+)$")) end
      elseif button == "b" then
        C.confirmPopup = nil
      elseif button == "dpleft" or button == "dpright" then
        C.confirmPopup.focus = (C.confirmPopup.focus == "cancel") and "confirm" or "cancel"
      end
      return
    end
    -- v2.9.5: search grid, same "block everything else, D-pad moves a
    -- focus, A activates, B always cancels" shape as C.confirmPopup just
    -- above -- see C.searchNav for the actual cursor movement.
    if C.searchGrid then
      if button == "a" then C.searchActivate()
      elseif button == "b" then C.closeSearchGrid()
      elseif button == "dpup" then C.searchNav("up")
      elseif button == "dpdown" then C.searchNav("down")
      elseif button == "dpleft" then C.searchNav("left")
      elseif button == "dpright" then C.searchNav("right")
      end
      return
    end
    if c then c.debugLast = "pad: " .. tostring(button); c.debugLastAt = love.timer.getTime() end
    if c and (button == "dpup" or button == "dpdown" or button == "dpleft" or button == "dpright") then
      c.stickActive = false   -- D-pad press hands control back from the stick cursor
    end
    -- L3 (left-stick click), edit mode only: SHORT press resets the SELECTED
    -- panel (the per-panel reset that gamepad/touch otherwise lacked -- the
    -- R-key equivalent); HOLD ~1s resets ALL panels. Just arm the timer here;
    -- the release (short) and the hold threshold (long) are decided in
    -- C.padReleased / C.pollPad.
    if c and button == "leftstick" then
      if C.overlayEdit.active then C.l3DownAt = love.timer.getTime(); C.l3Fired = false end
      return
    end
    -- R3 (right-stick click): HOLD ~1s OPENS edit mode; a plain short
    -- press CLOSES it if it's already open (v2.9.5 bugfix, direct report
    -- -- "R3 long press currently opens edit screen AND closes it, can we
    -- just have regular R3 press be close it and keep long press to
    -- open"). Just arm the timer here either way; C.pollPad decides
    -- whether the hold fires (open-only), C.padReleased decides whether
    -- the release fires (close-only) -- see both for the actual split.
    if c and button == "rightstick" then
      C.r3DownAt, C.r3Fired = love.timer.getTime(), false
      return
    end
    -- Left-stick cursor + A: same as a mouse-1 click at the virtual cursor.
    -- Edit mode is claimed through C.claimStickAPress, shared with
    -- C.driveStickEditMode's own per-frame poll -- see that function's
    -- comment for why both exist and the double-tap-reset bug it used to
    -- cause when they both called tryEditPanelSelect for the same press.
    if c and c.stickActive and button == "a" then
      if C.overlayEdit.active then
        if C.claimStickAPress() then return end
      elseif c.screen then
        c.padDown = true
        if c.onScreenMouse then pcall(c.onScreenMouse, c.vcx or 0, c.vcy or 0, 1) end
        return
      end
    end
    if c and c.screen == "items" and c.onPadScroll and (button == "dpup" or button == "dpdown") then
      local dir = button == "dpup" and 1 or -1
      c.onPadScroll(dir)
      c.padScrollHold = { dir = dir, t = 0, n = 0 }
      return
    end
    if c and c.screen == "items" and c.onPadSelect and button == "a" then
      c.onPadSelect(); return
    end
    -- v2.9.5: Boxes never had a D-pad up/down meaning before (only left/
    -- right, to cycle which box is viewed) -- confirmed free before using
    -- it for header-focus entry/exit (Select/Move/Release), same shape as
    -- Items' own C.onPadScroll/onPadSelect just above.
    if c and c.screen == "party" and C.onPadScrollBox and (button == "dpup" or button == "dpdown") then
      C.onPadScrollBox(button == "dpup" and 1 or -1); return
    end
    if c and c.screen == "party" and C.onPadSelectBox and button == "a" then
      C.onPadSelectBox(); return
    end
    local key = PAD_KEYMAP[button]
    if c and key then
      if c.screen then
        if c.onScreenKey then c.onScreenKey(key); return end
      elseif c.onKeyDown then
        if c.onKeyDown(nil, key) then return end
      end
    end
  end

  C.padReleased = function(c, button)
    -- L3 released: if it was a SHORT press (hold threshold never fired), reset
    -- just the selected panel. A long hold already reset all in pollPad and set
    -- l3Fired, so we skip here.
    if c and button == "leftstick" then
      if C.l3DownAt and not C.l3Fired and C.overlayEdit.active and c.onKeyDown then
        c.onKeyDown(nil, "r")   -- per-panel reset (same as the R key)
      end
      C.l3DownAt, C.l3Fired = nil, false
      return
    end
    -- R3 released: a short press (release before the 1s hold fired, i.e.
    -- r3Fired is still false) CLOSES edit mode if it's currently open --
    -- v2.9.5 bugfix, direct report, see C.padPressed's rightstick comment.
    -- Routes through the same onKeyDown "f6" branch the hold uses, so it
    -- picks up that branch's own close-always-works logic for free. If
    -- edit mode is already closed, a short press does nothing (opening
    -- stays long-press-only). If the hold already fired (r3Fired true),
    -- it already opened it -- nothing further to do on release.
    if c and button == "rightstick" then
      if C.r3DownAt and not C.r3Fired and C.overlayEdit.active and c.onKeyDown then
        c.onKeyDown(nil, "f6")
      end
      C.r3DownAt, C.r3Fired = nil, false
      return
    end
    if c and button == "a" then
      -- Same stale-touches cleanup as the mouse-release branch in the
      -- input.pointer hook -- see its comment.
      C.overlayEdit.touches["mouse"] = nil
      if endResize() then return end
      if endDrag("mouse") then return end
    end
    if c and c.screen and button == "a" and c.padDown then
      c.padDown = false
      if c.onScreenRelease then pcall(c.onScreenRelease, c.vcx or 0, c.vcy or 0, 1) end
      return
    end
    if c and (button == "dpup" or button == "dpdown") then
      c.padScrollHold = nil
    end
  end

  -- L2/R2 trigger handling, edge-latched on the 0.5 threshold exactly as the
  -- old love.gamepadaxis did (C.triggerDown remembers each trigger so holding
  -- one doesn't refire every frame). Called with the polled axis value.
  C.padAxis = function(c, axis, value)
    local editActive = c and not c.screen and C.overlayEdit.active
    if not (c and (axis == "triggerleft" or axis == "triggerright")
        and (c.screen == "items" or axis == "triggerright" or editActive)) then
      return
    end
    c.triggerDown = c.triggerDown or {}
    local wasDown = c.triggerDown[axis]
    local isDown = value > 0.5
    c.triggerDown[axis] = isDown
    if isDown and not wasDown then
      c.debugLast = "pad: " .. axis
      c.debugLastAt = love.timer.getTime()
      if editActive then
        local delta = (axis == "triggerleft") and -0.1 or 0.1
        for _, k in ipairs(PANEL_KEYS) do
          C.panelCfg[k].scale = clamp01Scale(C.panelCfg[k].scale + delta)
        end
        savePanelCfg()
      elseif c.screen == "items" and c.onPadTrigger then
        c.onPadTrigger(axis == "triggerleft" and 1 or -1)
      elseif axis == "triggerright" then
        if c.screen and c.onScreenKey then
          c.onScreenKey("o")   -- from Party, switch straight to the overlay
        elseif c.onKeyDown then
          c.onKeyDown(nil, "o")   -- from the overworld, toggle the overlay
        end
      end
    end
  end

  -- Per-frame poll: read the first connected gamepad, edge-detect buttons, and
  -- feed triggers + edit-mode stick through the handlers above. Called from the
  -- core.update hook every frame. pcall-guarded per query.
  C.pollPad = function()
    local c = _G.__KANTO_INGAME
    if not c then return end
    local pad
    local okList, joys = pcall(love.joystick.getJoysticks)
    if okList and joys then
      for _, j in ipairs(joys) do
        local okG, isPad = pcall(j.isGamepad, j)
        if okG and isPad then pad = j; break end
      end
    end
    if not pad then C.padPrev = nil; return end
    C.padPrev = C.padPrev or {}
    local prev = C.padPrev
    for _, btn in ipairs(PAD_POLL_BUTTONS) do
      local okB, cur = pcall(pad.isGamepadDown, pad, btn)
      cur = okB and cur == true
      if cur and not prev[btn] then C.padPressed(c, btn) end
      if (not cur) and prev[btn] then C.padReleased(c, btn) end
      prev[btn] = cur
    end
    -- L3 hold-to-reset-all: once held past ~1s in edit mode, fire the reset-all
    -- once. The subsequent release then sees l3Fired and skips the short-press
    -- per-panel reset.
    if C.l3DownAt and not C.l3Fired and C.overlayEdit.active
        and (love.timer.getTime() - C.l3DownAt) >= 1.0 then
      C.l3Fired = true
      C.doPanicReset(c)
    end
    -- R3 hold-to-open: once held past ~1s, fire the edit-mode toggle once
    -- (same call PAD_KEYMAP used to make instantly on press -- see its own
    -- comment for why this moved behind a hold). v2.9.5: gated on edit mode
    -- NOT already being active, so the hold only ever OPENS -- closing is
    -- C.padReleased's job now (a plain short press), so a hold that's still
    -- down past 1s while already editing no longer fights with that release.
    if C.r3DownAt and not C.r3Fired and not C.overlayEdit.active
        and (love.timer.getTime() - C.r3DownAt) >= 1.0 then
      C.r3Fired = true
      if c.onKeyDown then c.onKeyDown(nil, "f6") end
    end
    local function axis(a)
      local okA, v = pcall(pad.getGamepadAxis, pad, a)
      return (okA and type(v) == "number") and v or 0
    end
    C.padAxis(c, "triggerleft", axis("triggerleft"))
    C.padAxis(c, "triggerright", axis("triggerright"))
    if c and not c.screen and C.overlayEdit.active then
      c.editStickX = axis("leftx")
      c.editStickY = axis("lefty")
    end
  end

  mod.log:info("kanto_companion: overlay=o/R2  items=i/X  party=p/Y  touch=nav-cycle+icon-buttons (see mod options)  (Esc/B closes a screen)  [debug input HUD: %s]", tostring(mod.options:get("debug_input_hud")))
end
