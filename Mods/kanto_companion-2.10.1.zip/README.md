# Kanto Companion

An in-game companion that loads directly on top of the game, built for
controller and touch play on a smaller screen.

> **Fan-made; not affiliated with or endorsed by Nintendo / Game Freak / The Pokémon Company.**

## `2.10.0`

- Full portrait-mode support — the overlay and the Items/Party-Boxes screens now work correctly in portrait, laid out as a swipeable page instead of squeezed into the landscape two-column view.
- Gold/Silver (Gen 2) is no longer experimental. The Battle panel (matchup, catch odds, HP-bar sync) was completely dead on Gen 2 since it was first added — fixed.
- Badges, Pokédex count, and Bag-capacity checks were all reading the wrong data on Gen 2 — fixed.
- Route panel wild-encounter odds weren't showing at all on Gen 2, including proper morning/day/night variation — fixed.
- Gen 2's healing berries weren't recognized by the Items overlay's Healing column — fixed.
- Gen 2's real item pockets (Items / Balls / Key Items / TMs & HMs) now show as their own categories and can be reordered by dragging.
- New: select multiple items or Pokémon at once for bulk transfer, discard, move, or release, with a confirmation popup before anything destructive.
- New: search for an item or Pokémon by name in the Bag, PC, or Boxes instead of scrolling.
- New: Undo button for the Items and Party/Boxes screens.
- New: the Route panel now tracks how many of each species you've battled, caught, and defeated.
- New: a caught indicator next to the opponent's name in battle.
- The quantity +/- stepper on a held item now shows even with touch controls off, and the keyboard can adjust quantity and scroll lists too.

Requires engine **0.1.83+**.

## `2.9.4`

- Fixed: gamepad stick+A grabbing a panel header could immediately trigger the double-tap reset instead of starting a drag (the same bug could also make the +/- collapse button silently do nothing on some panels).
- Fixed: a panel's resize corner could unexpectedly resize instead of drag if a stale touch/click was left over from an earlier interaction.
- Fixed: the Items panel's resize corners were harder to grab than the other panels' (they were losing part of their hit area to the Route/Battle panel's collapse icon).
- Touch-nav and touch-icon button rows can now be resized in Edit Mode via a corner grip, not just repositioned.
- Edit Mode hint text now documents double-tap-header-to-reset.

Requires engine **0.1.83+**.

## `2.9.3`

- Route panel now shows live weather-adjusted encounter odds and weather-only species when a compatible weather mod (e.g. Weather FX 4.26.0+) is installed, plus a current-weather tag next to every location's name — works on routes and cities alike. No weather mod installed, nothing changes.
- Route panel redesigned: each species now shows one true per-step chance instead of a separate "X% / step" rate line next to a differently-scoped per-species percentage.

Requires engine **0.1.83+**.

## `2.9.2`

- Works with gen1recomp's new mod sandbox (0.1.84+) — the previous version couldn't load once the sandbox went live.
- Edit Mode per-panel reset added for gamepad (L3: tap = selected panel, hold = all) and touch (double-tap a panel's header).
- Desktop scroll-wheel box scrolling removed (no sandbox input path yet — use D-pad / arrows / touch).

Requires engine **0.1.83+**.

## `2.9.1`

- Added Pokémon Gold (Gen 2) support — **experimental; some Gen 2 issues are still being fixed**.
- Changed Edit Mode toggle: keyboard **F6** opens it any time; gamepad **R3** now needs the overlay open first.

Requires engine **0.1.83+**. Older engines keep running 2.9.0.

Sandbox note: full mod-sandbox compatibility is still in progress and will land in a later update.

## `stick-mouse-drag-fix-v79` — fixed a panel "popping" to the stick cursor mid-drag with mouse/touch

Direct report: "if the control stick cursor is showing, but no input,
and you try to drag a window in edit mode, it pops to the cursor."

**Root cause:** `C.stickActive` is deliberately **sticky** — set `true`
the moment the left stick is pushed past its dead zone, but never reset
back to `false` once it returns to neutral (so the on-screen stick
cursor doesn't vanish the instant you let go mid-aim, which would be a
worse experience). `C.driveStickEditMode`'s per-frame update used to
gate only on that sticky flag, so once the stick had been touched even
once, it kept force-writing the panel's position to the stale, unmoving
stick-cursor spot every single frame — including while a real mouse or
touch drag was actively in progress, since both a real mouse drag and a
stick+A drag intentionally share the same `"mouse"` ownership sentinel
(that sharing is what lets stick+A reuse the exact same drag code a
mouse click already uses).

**Fix:** the per-frame update now also requires a fresh, real-time poll
of the physical A button, not just the sticky cursor-visibility flag. A
stick-driven drag can only ever be in progress while A is genuinely
held down, so this can no longer collide with an unrelated mouse or
touch drag that happens to share the same sentinel.

Verified with a new isolated test suite (7 checks, including a direct
sanity check reproducing the OLD behavior to confirm this was a real,
demonstrable bug and not just a theoretical one) plus the full existing
regression suite, the module-load harness, a syntax check, and a
byte-diff confirming the change is scoped to this one function.

**Needs an on-device check:** with a gamepad connected, nudge the left
stick once in Edit Mode (so the cursor appears), let go, then drag a
panel with the mouse or a finger — it should track normally now instead
of jumping to wherever the stick cursor is sitting.

## `public-release-v78` — v2.9.0 public release: BUILD_TAG debug banner turned off

Direct catch: the on-screen `BUILD_TAG` debug banner (top-left corner)
was still showing, reading `transparency-midrange-v77` — this has been
`SHOW_BUILD_TAG = true` since `v57`, deliberately turned on for this
whole active dev/test arc so screenshots could always be correlated to
an exact build. That flag's own comment has said "flip off again before
any public release" the entire time; this is that flip. Public players
won't see a build-tag string in the corner of their screen anymore.

Pure one-flag change (`SHOW_BUILD_TAG = true` → `false`), verified with
a byte-diff confirming it's the only line that changed, plus the usual
syntax check and module-load harness. `manifest.json`'s version stays
`2.9.0` — nothing about this counts as a separate release, it's a
finalization of the same one, since `2.9.0` hasn't actually been posted
anywhere publicly yet.

**Needs an on-device check:** confirm no build-tag text appears in the
top-left corner anymore, in any screen state.

## `transparency-midrange-v77` — TOUCH TRANSPARENCY restructured to 5 levels, original look now the exact middle

Direct report: the original always-on button look (today's real
default alpha values) sat at one END of `v76`'s 4-level range (MAX) —
meaning there was no way to make the buttons any MORE transparent than
they'd always been, only more opaque. Restructured to **5 levels, MIN /
LOW / MED / HIGH / MAX**, with the original look now the exact MIDDLE
(**MED**, the option's new default) — a clean ×2-per-step spread,
symmetric in both directions. MIN is the most opaque/solid end (same
role the old OFF had); MAX is genuinely new territory now, more
transparent than these buttons have ever rendered, not just "the
original" relabeled.

Existing stored selections from `v75`/`v76` will read back as whatever
that same stored number now means under the new 5-choice layout — the
same "pure landing, not a real migration" tradeoff already accepted for
this option's earlier key rename, since it's still being actively
iterated on in the same conversation.

Verified with a rewritten isolated test suite (16 checks: MED is an
exact no-op, transparency strictly increases with level, the new range
is exactly symmetric around MED by construction, MAX is provably more
transparent than the old range's MAX ever was, both ends stay within a
valid alpha range) plus the existing suites, module-load harness,
syntax check, and byte-diff review (touched only the option definition
and its multiplier table, nothing else).

**Needs an on-device check:** cycle TOUCH TRANSPARENCY through all 5
levels and confirm MED looks identical to how the buttons always have,
with 2 steps clearly more solid on one side and 2 steps clearly more
faded on the other.

## `touch-transparency-v76` — renamed TOUCH OPACITY to TOUCH TRANSPARENCY; fixed a real "buttons render in the wrong spot on reload" bug

**Renamed, direct correction:** `v75`'s **TOUCH OPACITY** name read
backwards for how its own levels behave — MAX is the MOST transparent
setting (today's already-faint default look), OFF is the MOST opaque
(fully solid), the opposite of what "opacity going up with the level"
would suggest. Renamed to **TOUCH TRANSPARENCY** — same word **DIM
OVERLAY** already uses for the identical "MAX = most see-through"
direction, so the two options now read consistently with each other.
Option key renamed too (`touch_btn_opacity` → `touch_btn_transparency`);
the exact same 4 levels, values, and alpha multipliers are completely
untouched — nothing about how the buttons actually look changed, only
the name.

**Fixed, direct report: after reloading, the touch nav/icon buttons
briefly rendered far down-and-to-the-right of their saved position,
snapping back to correct the instant any menu button was pressed.** Root
cause: a dragged position is stored in "design units" (divided by the
shared `s` scale factor at drag time, matching the real panels' own
save format), but `s` only gets a fresh, correct value once
`C.drawOverlay` or `C.drawScreen` actually renders a frame — and on the
very first frame(s) after a reload, before either has run even once,
`s` is still sitting at its cold-start default of `1`. The touch button
row draws every frame independent of whether the overlay/a screen has
rendered yet, so it could read that stale default — reintroducing
exactly the `s`-reliability risk this row's own drawing code had already
sidestepped by working in raw window pixels instead (see
`C.drawTouchNav`/`drawTouchIcons`'s own comments) — just for the saved-
position unit conversion specifically. Fixed by computing an
independent scale (`touchGroupScale`) from the window height directly,
never reading the shared `s` — any position saved before this fix reads
back identically (dragging only happens in edit mode, which requires the
overlay to already be visibly rendering, so `s` really was correct at
the moment it was originally saved).

Verified with a new dedicated isolated test suite (9 checks, including a
sanity check proving the OLD formula really did disagree with the
correct one at a stale `s`, then confirming the new one doesn't) plus
the existing suites (unaffected — none of them exercised this exact
reload-timing scenario before), the module-load harness, syntax check,
and byte-diff review.

**Needs an on-device check:** drag the nav arrows and/or icon row to a
new spot, fully close and relaunch the app (not just reopen the save),
and confirm they render in the CORRECT saved spot on the very first
visible frame — no longer briefly appearing elsewhere first.

## `touch-btn-opacity-v75` — DIM OVERLAY's levels reverted; the "adjustable transparency" ask was actually about the touch nav/icon buttons, not the overlay; a real nudge-gating bug fixed too

**`v74`'s DIM OVERLAY level change is reverted, on direct correction.**
That option was never the one meant by "add different degrees of
transparency" — turned out the ask was about the touch nav/icon
**buttons'** own opacity, a distinct, separate thing from the overlay's
dim, and one already sitting in the wanted-features list (see
`OPEN_ITEMS.md`). DIM OVERLAY is back to a plain on/off toggle, byte-
identical to `v73`.

**New: TOUCH OPACITY**, applying the exact same 4-level concept (OFF /
LOW / MED / MAX) to the touch-nav arrows and touch-icon row instead.
MAX is today's existing look (unchanged for anyone who picks it) —
but unlike DIM OVERLAY, the other three levels make the buttons
progressively MORE opaque/solid than today's fairly faint default
(background alpha 0.12-0.14 normally), not more transparent — matching
the original ask (buttons being hard to see, not wanting them fainter).
The gold "this is the active screen" highlight is untouched by every
level, so that state indicator stays legible regardless of setting.

**Also fixed, direct report: the reintroduced nav/icon-zone item-bubble
nudge (`v73`) was still nudging even with BOTH touch nav and touch icon
buttons turned off** — a gap present since the original `v70` code (it
never checked those two mod options either, and the `v73` reintroduction
carried the same gap forward unnoticed). Each button group now only
contributes to the avoided zone while its own option is actually on;
the whole check is skipped if neither is.

Verified with two new isolated suites (21 checks: alpha-multiplier
math/clamping/direction for TOUCH OPACITY, and the nudge's per-group
option-gating including the case where the two zones' padding windows
overlap near their shared boundary) plus the existing module-load
harness, syntax check, and byte-diff review confirming the revert is
byte-clean back to `v73`'s exact DIM OVERLAY code.

**Needs an on-device check:** cycle TOUCH OPACITY through its 4 levels
and confirm the nav arrows/icon row get visibly more solid at lower
levels; confirm DIM OVERLAY is a plain toggle again; with both touch
button options off, drag an item and confirm no vertical jump happens
at all (previously it still did).

## `dim-levels-v74` — DIM OVERLAY now has 4 levels instead of on/off

New mod option, direct request: **DIM OVERLAY** (previously a plain
toggle) is now a 4-level cycler — **OFF / LOW / MED / MAX** — instead of
just on/off. **MAX is exactly the old "on" state** (same 0.62 alpha the
overlay has always dimmed to), so anyone who picks it sees zero visible
change from before. LOW and MED sit between that and fully opaque (0.85
and 0.73 alpha) for finer control over how much the overlay fades.

Replaces the old `overlay_transparency` boolean option key outright
rather than reshaping it in place — a prior install's stored `true`/
`false` value simply won't match any of the new choice's entries and
reads back as OFF, a clean landing rather than a real migration (this
mod's install base is small enough that "pick your level again once"
is a reasonable tradeoff against migrating a raw stored boolean by
hand). Touch nav/icon buttons' own automatic dim (see **KEEP OPAQUE**)
is untouched by this — it still falls back to the same legacy 0.62
whenever DIM OVERLAY is left at OFF, exactly as before this version.

**Also investigated, not built: adding descriptive/filler text outside
the option boxes on the mod options screen.** Not possible — read the
engine's own `OptionRows.lua` directly: the whole 160×144 screen is
tiled by up to 4 fixed-size boxes (one label line + one value line
each, `OptionRows.VISIBLE = 4`), no spare screen space, no separate
description field in the row schema, and no hook a mod can use to
substitute a custom screen for its own OPTIONS entry (confirmed
earlier this same investigation thread, see `v59`'s changelog entry).
A short, self-explanatory label — the same approach already used for
every option here — is the only lever this framework gives a mod.

Verified with a new isolated test suite (16 checks covering every
level/touch-button/keepOpaque/dev-flag combination, plus a direct check
that MAX's alpha is byte-identical to the pre-v74 hardcoded value) plus
the existing module-load harness, LuaJIT syntax check, and byte-diff
review.

**Needs an on-device check:** open Mods > Kanto Companion > OPTIONS,
cycle DIM OVERLAY through OFF/LOW/MED/MAX, and confirm the overlay's
actual on-screen dim intensity changes accordingly (with the overlay
visible and no touch nav/icon buttons on, so the manual option is the
only thing driving it).

## `touch-groups-fix-v73` — fixes v72's mod-load crash AND makes the groups actually draggable; reintroduces the nav/icon-zone item nudge (mobile only)

**Two rounds of real bugs found this version, both from direct on-device
reports:**

1. **Mod refused to load at all** (`FAILED: main.lua:227: attempt to
   index global 'C'`, seen on the Odin's own Mod Manager screen). A
   `C.touchGroupPos` initializer had been placed ~60 lines above `local
   C = _G.__KANTO_INGAME or {}`'s own declaration in the same function
   -- indexing `C.` before that point falls through to an undefined
   global instead of the real local. Valid syntax, so a plain syntax
   check never caught it; it threw on every single launch. Fixed by
   moving the initializer to right after `C` is actually declared.
2. **The groups highlighted gold in edit mode but were never actually
   draggable** ("not selectable in any way to move," direct report).
   `tryEditPanelSelect` -- the real panels' own hit-test -- unconditionally
   returns `true` on every call while edit mode is active, even on a
   complete miss (by design, so a stray tap can't fall through to the
   game underneath). Every touch-group call site checked it FIRST, so
   the groups' own hit-test never even ran. Fixed by checking the
   (small, specific) group hit-test before the (catch-all) panel one, at
   all 7 call sites -- 6 mouse/touch callbacks plus gamepad stick+A.
   Also added a guard against a second grab attempt stealing an
   in-progress drag's ownership (the mouse-echo LÖVE synthesizes for
   every real touch would otherwise silently hijack an active touch-
   drag's tracking, since the echo carries a different `touchId`).

**New this version, direct request: the dragged-item name bubble's
nav/icon-zone avoidance nudge is back, mobile-only.** `v71` removed this
outright, reasoning the collision it guarded against (an accidental
button press while adjusting a held item's quantity) was already
impossible since those buttons go fully inert whenever an item's held.
That's still true, but doesn't cover the separate complaint this was
brought back for: the buttons draw on top of everything, so the bubble
visually overlapping them still looks wrong even though a tap there
can't do anything. Gated to `isMobilePlatform()` this time (those
buttons are touch-only; desktop has no reason to enable them) -- same
reasoning already applied to the finger-offset nudge above it. Also now
tracks the touch-nav/icon groups' CURRENT position (via the same
`touchGroupOffset` `v72` added for dragging them), not the old fixed
0.61–0.79 span -- since those groups are draggable now, a static zone
would go stale the instant either one gets moved.

Verified with three isolated runtime test suites (32 checks on
geometry/hit-testing/drag-state-machine, including the new concurrent-
grab guard; 11 on the save/load round trip; 8 new on the nudge's mobile
gate and dynamic zone-tracking) plus a NEW fourth verification step: a
module-load harness that actually executes the real file's top-level
init against a mock environment -- this is what would have caught bug
#1 before shipping, and is now a standing part of this project's
verification discipline going forward.

**Needs an on-device check:** in EDIT MODE, confirm the nav arrows and
icon row are now actually draggable (mouse, touch, and gamepad stick+A)
and relocate correctly; on mobile, drag an item near wherever the
nav/icon row currently sits (including after moving it) and confirm the
name bubble nudges to clear it; on desktop, confirm no vertical jump
happens at all.

## `draggable-touch-groups-v72` — touch-nav and touch-icon buttons can now be repositioned in EDIT MODE

New feature, direct request: the two touch-nav arrows (previous/next
screen) and the three touch icon buttons (overlay/items/party) can now
be dragged to a new spot on screen while EDIT MODE is active — each set
moves together as one rigid group, independently of the other. Position
only, no resize (confirmed scope: "only position").

- Works with mouse, touch, and gamepad left-stick + A, matching every
  other draggable element in edit mode.
- A gold outline appears around each group while edit mode is active, so
  it's clear they're grabbable, same visual language as the four real
  HUD panels.
- Real HUD panels still take priority for any tap/click/stick-press that
  lands on both a panel and a button group at once — the button groups
  only respond as a fallback, so this can never steal a panel drag.
- Positions save to disk and reload on next launch, same file and same
  out-of-bounds sanity check already used for panel positions.
- F9 / L3 panic-reset now also restores both groups to their default
  layout, alongside the four panels it already resets.

Verified with two isolated runtime test suites (geometry/hit-testing/
drag-state-machine — including two-touch ownership rejection — and the
save/load round trip, including out-of-bounds and malformed-save-file
rejection), a LuaJIT syntax check, and a byte-diff review.

**Needs an on-device check:** in EDIT MODE, drag the nav arrows and the
icon row to new spots, exit edit mode and confirm they stay there and
still work, relaunch the app and confirm the position persisted, then
F9/L3 panic-reset and confirm both groups snap back to their original
spot.

## `remove-navzone-nudge-v71` — removed the dragged-item bubble's nudge away from the touch-nav/icon zone entirely

Correction, direct report: `v70` fixed the wrong block for what was
actually meant by "the vertical bump" — that turned out to be a
*different* piece of code in `drawHeldItem`, the one that nudges the
dragged-item name bubble upward if it would otherwise land behind the
touch-nav/icon buttons (`TOUCH_NAV_LEFT/RIGHT`, `TOUCH_ICON_OVERLAY/
ITEMS/PARTY`), which draw on top of everything else.

Removed outright rather than gated by platform, for two reasons
confirmed directly against the code, not assumed:
1. Those buttons only draw at all when their mod options are on —
   nothing a desktop player has reason to enable.
2. `heldBlocksNav` (in the shared `tryTouchNavButtons`, see `v70`)
   already disables the entire nav/icon zone the whole time an item is
   held via touch or mouse. The collision this nudge existed to prevent
   — accidentally pressing a nav/icon button while adjusting a held
   item's quantity — was already structurally impossible on every
   platform, independent of where the bubble was drawn. It was solving
   a problem that couldn't happen.

`v70`'s other change (the finger-offset skipping on desktop, a
*separate* block with its own independent justification — a real finger
covers the touch point, a mouse pointer doesn't) is unrelated and stays
as-is.

Verified with a LuaJIT syntax check and a byte-diff confirming the
change is exactly the one block's removal, nothing else touched.

**Needs an on-device check:** drag an item near the touch-nav/icon row
(with those options on) and confirm the name bubble no longer jumps
away from that area — it should now render at its natural computed
position same as anywhere else on screen.

## `mouse-touch-parity-v70` — touch-nav/icon buttons now work with a mouse; the dragged-item finger-offset no longer applies on desktop

Two related fixes, both closing a mouse/touch parity gap.

**Touch-nav/icon buttons are now mouse-clickable.** `love.mousepressed`
never checked the `TOUCH_NAV_LEFT/RIGHT`/`TOUCH_ICON_OVERLAY/ITEMS/PARTY`
hit zones at all — only `love.touchpressed` did, even though every other
input path in this file (edit-mode select/drag/resize, the Items/Party
screens) already treats mouse and touch as fully parallel. Confirmed
this wasn't a deliberate touch-only design — nothing in the code said
so, it just never got mirrored into `love.mousepressed` the way
everything else was.

Factored the zone-check logic into one shared `tryTouchNavButtons`
function, called from both handlers, instead of writing it twice (the
exact "two places that can drift apart" risk that caused `v68`'s bug).
Debounced deliberately: a real touch on a touch-capable device
synthesizes a `mousepressed` event for the same physical tap (the same
fact `tryEditPanelSelect`'s own debounce already relies on elsewhere in
this file) — without a guard, one physical tap would fire the action
twice, once via each handler. Uses a shorter 100ms window than
`tryEditPanelSelect`'s 250ms, specifically so a genuine fast repeated
tap (quickly cycling through screens) isn't mistaken for a duplicate.

**The dragged-item name bubble's "offset away from the fingertip" no
longer applies on desktop.** That offset exists purely to keep the
bubble from landing directly under/behind a real finger — a mouse
pointer doesn't obscure anything the same way, so the whole rationale
doesn't apply there. Added a shared `isMobilePlatform()` helper (the
same `love.system.getOS()` check `v69`'s edit-hint box already uses,
now factored out to one place instead of two) and gated the offset on
it. This affects both the horizontal and vertical parts of the offset,
not just the vertical half that was asked about directly — both exist
for the identical finger-obscuring reason, so leaving one active while
disabling the other would have left the bubble in an offset position
that no longer had any justification.

Verified with 16 isolated-runtime-test assertions: a real touch + its
synthesized mouse echo at the same instant fires the action exactly
once (not twice), a genuinely later second tap still registers (the
debounce doesn't eat real repeats), a plain mouse click with no touch
involved works correctly, each zone maps to the right action, a miss
outside every zone falls through cleanly, and the finger-offset gate is
checked across all four platform × pad-hold combinations. Plus the
usual LuaJIT syntax check and a byte-diff confirming the change stayed
scoped to the five spots described above.

**Needs an on-device/PC check:** on desktop, confirm clicking the
touch-nav/icon buttons (with the relevant option on) works the same as
tapping them would; confirm a dragged item's name bubble now sits right
at the mouse cursor instead of offset away from it. On the Odin, confirm
touch still works exactly as before (nothing here should have changed
there) and that rapid double-taps on a nav button still register both.

## `edithud-redesign-v69` — full rewrite of the edit-mode hint box: real panel styling, centered, platform-aware content

Direct request, follow-up to `v68`'s cutoff fix: the box itself and its
copy needed real work, not just a position fix.

**The box.** Was a flat, square-cornered, 70%-alpha black rectangle —
visibly inconsistent with every other panel's rounded, near-opaque
`panel()` look, and genuinely harder to read over a busy background at
only 70% opacity. Now reuses `panel()` directly, the same helper every
other box in the overlay already uses — free style-consistency and
readability fix, no new drawing code.

**The text.** Was one long left-aligned wall of gold text cramming two
unrelated facts onto several lines with ad-hoc triple-spacing. Now: each
line is one coherent topic, a larger gold title separated from smaller
dim body text for real visual hierarchy, and every line is genuinely
centered — drawn individually with `align="center"`, not one `\n`-joined
block centered as a whole (which only centers on the *widest* line and
leaves shorter ones ragged).

**The content is now platform-aware**, per direct request: keyboard
hints only show when **not** on a mobile OS (`love.system.getOS()`, the
same signal the engine's own `VideoMode.isMobile()` uses internally),
gamepad hints only show when a real gamepad is **currently connected**
(same `:isGamepad()` check the stick-cursor code already uses), and
touch-only hints (pinch-to-scale) only show on a mobile OS. Confirmed
first that this can't leave a player stranded with zero exit
instructions: edit mode can currently only be *entered* via keyboard F6
or gamepad R3 — no touch path toggles it anywhere in the file — so this
box can never be showing with both unavailable. Added a defensive
fallback anyway (found by the test suite, not by inspection): if that
combination somehow occurs, it falls back to keyboard hints rather than
rendering lines with a stray leading blank from an empty selector.

**The box size is no longer a hardcoded number at all.** Since the
content is now conditional (5-7 lines depending on what's connected),
width and height are measured from the real text every frame — the same
measure-before-draw principle every panel function in this file already
uses via `measureOnly`. This is what actually retires `v68`'s bug class
for good: there's no fixed number left that could ever drift out of
sync with the real content, because there's no fixed number at all.

Verified with 2 test suites: 16 assertions on the box-position math
(carried over from `v68`, still valid since the anchor/margin logic is
unchanged) and 20 new assertions on content generation — all four
platform combinations (desktop-only, mobile+gamepad matching the Odin
itself, the logically-unreachable neither-available case, and
desktop+external-gamepad), each checked for the right lines included,
the right lines excluded, and no malformed/blank-prefixed lines. Plus
the usual LuaJIT syntax check and byte-diff.

**Needs an on-device check:** enter edit mode and confirm the box looks
right — rounded/matching panel style, readable, centered — and reads
right for what's actually connected (the Odin should show its gamepad
hints; toggling touch-relevant behavior isn't testable without an actual
different OS, but the logic is unit-tested for that case).

## `edithud-cutoff-fix-v68` — the edit-mode hint box was drawing its last 2-3 lines below the bottom of the screen

Direct report, spotted from an on-device screenshot: the "EDIT MODE"
hint box (control reminders shown while overlay edit mode is active) was
being drawn with its bottom ~40 design-units below the actual bottom of
the screen — invisible to the player. The box has 7 lines of real
content (drag-to-move, pinch-to-scale, and the entire left-stick+A
gamepad control scheme all live in the last 3 lines), and roughly the
bottom 2-3 of those 7 were completely hidden, cut off mid-character in
the screenshot that caught it.

**Root cause, confirmed by reading the actual math, not guessed:** the
box's Y position at its call site used a bare `canvasH - margin - 54`.
That "54" was never updated as the box grew taller across three separate
past sessions (86 → 104 → 122 tall, right there in the file's own
history comments) — nobody re-derived the position formula each time the
content grew, so the overflow got a little worse with every added line.
There was also a second, independent copy of the box's width (`local
hudW = 420` at the call site, versus a hardcoded `420` inside
`drawEditHUD` itself) that only happened to still match by luck, the
exact same "two places that can drift apart" bug class this file's own
comments already call out elsewhere as a known risk.

**Fix:** both dimensions are now declared once (`EDIT_HUD_W, EDIT_HUD_H
= 420, 122`) and referenced from both the function and its call site, so
the box is always positioned exactly `EDIT_HUD_H` above the bottom
margin — provably correct for any future height, not just today's,
without anyone needing to remember to update a magic number again.

Verified with an isolated runtime test: confirmed the *old* formula
really did overflow by exactly 40 units (proving the bug, not just
theorizing it), confirmed the *new* formula's bottom edge lands exactly
at `canvasH - margin` across five different canvas heights, and
confirmed it stays correct even if `EDIT_HUD_H` changes again in the
future (tested against five different heights, not just 122). Plus the
usual LuaJIT syntax check and byte-diff.

**Needs an on-device check:** enter edit mode and confirm all 7 lines of
the hint box are fully visible, including "Drag the header..." and the
left-stick+A gamepad line at the bottom.

## `wide-layout-fix-v67` — the reposition box now uses the correct fraction for the vanilla WIDE battle layout too

Found during a routine double-check (not a user report): the collision
box for "should party move to get out of the way of the enemy HUD"
always used the classic 160x144 screen's proportions (enemy box = 55% of
viewport width) — but the base engine also has its own separate
**BATTLE LAYOUT: WIDE** vanilla save option
(`battle:isWideBattleLayout()`, a real 304x144 canvas confirmed directly
in `src/battle/WideBattle.lua`), where the enemy box is only 128/304 =
42.1% of the width (the height fraction, 32/144, is identical in both).
A player with that vanilla option on would get a collision box ~13
points wider than the real one — never a false negative (it always
still moved when it needed to), just occasionally moving a bit more
readily than strictly necessary.

`enemyHudDesignRect` now takes a third `wideLayout` argument and picks
the matching fraction; the call site reads it fresh each frame from the
live battle object via `liveBattle:isWideBattleLayout()`, same pattern
`enemyHudVisible` already uses. Classic layout's own numbers are
completely unchanged — this only adds the second, correct fraction for
the wide case.

Verified with 3 new isolated-runtime-test assertions: a regression guard
confirming classic's right edge is exactly what it was before this
change, a check that wide layout's right edge lands exactly at the
128/304 fraction, and a check that the wide box is strictly narrower
than the classic one (not wider, not equal — guards against a
copy-paste mistake swapping the two). Suite is up to 48 assertions
total. Plus the usual LuaJIT syntax check and byte-diff.

**Needs an on-device check:** with the vanilla BATTLE LAYOUT option set
to WIDE, confirm the party panel's reposition still clears the enemy HUD
correctly (same as it already does in classic layout).

## `sync-hud-timing-v66` — the battle party auto-adjust now waits for the vanilla enemy HUD to actually be on screen

Direct report: the party auto-compact/move was firing the instant
`st.battle` went true — well before the vanilla game's own enemy HUD
actually appears (there's an ~80-frame intro slide, then a 12-frame
grow-in scale animation on the enemy sprite, before the engine draws
that HUD at all). Reacting to nothing visible yet risked reading as
confusing/broken and tempting a player to start fiddling with panels
early.

**Used the engine's own real code and data instead of guessing a
delay**, per direct request. Pulled and read `BattleState:drawHUDs`
directly (the exact function that draws the enemy HUD) to find its own
gating condition:

```
self.enemy and not self.showEnemyTrainer and not self.enemySendingOut
  and not self:growInScale(self.enemy) and slide == 0
  and not self.introBalls and not self.enemy.fainted
```

Every one of those is a real field (or method) on the live `BattleState`
object this mod already has access to via `currentBattle()` — including
`slide`, which isn't stored directly but traces straight back to
`self.introSlide` (`local slide = (self.introSlide or 0) * 2` in
`drawClassic`). New `enemyHudVisible(battle)` helper replicates this
exact condition field-for-field against the real live object every
frame — not a copy, not an estimate, the literal same data the engine
itself is about to check this frame to decide whether to draw. Slotted
into `wantOverride` as one more AND-term, so the party auto-adjust now
engages on the *exact* frame the vanilla HUD does, in both directions —
including a battle that starts, sits mid-animation for several frames,
then becomes visible, then (rare edge case, but correct either way) the
enemy fainting again mid-battle, which naturally makes `enemyHudVisible`
false again the instant it happens.

Verified with 9 new isolated-runtime-test assertions covering
`enemyHudVisible` directly (every individual blocking condition: mid
intro-slide, mid grow-in, enemy being sent out, trainer portrait
showing, intro balls, already-fainted), plus 5 more integrating it into
the full state machine (`st.battle` true but HUD not visible yet → does
nothing for several frames → HUD becomes visible → engages exactly
then, not before). Suite is up to 45 assertions total now. Plus the
usual LuaJIT syntax check and byte-diff.

**Needs an on-device check:** start a battle and confirm party doesn't
compact/move until the enemy's name, level, and HP bar are actually
visible on screen — no earlier, no later.

## `compact-opaque-only-v65` — the battle party auto-COMPACT now also only fires while opaque, not just the move

Correction to `v64`: that build only gated the *reposition* step on
`dimOverlay` — the auto-compact step still fired unconditionally on
every battle start regardless of dim state, which wasn't the actual
intent ("what I don't want is for the party to reduce if the
transparency is on").

Rewritten around a single continuous `wantOverride` flag (`st.battle and
not dimOverlay and not editing`) that now drives compacting and
save/restore together, instead of two separately-gated steps. This also
makes the whole feature react immediately if a touch/transparency option
gets toggled mid-battle, rather than only being decided once at
battle-start: turn on `DIM OVERLAY` (or a touch button without `KEEP
OPAQUE`) mid-fight and party pops back to its full size immediately, not
just at the next battle; turn it back off and it re-compacts (and
re-checks for a HUD overlap) right away. The reposition block's own
`not dimOverlay` check is gone too — now redundant, since `wantOverride`
already guarantees the override is never active while dimmed, in the
same frame it changes.

Verified with an expanded isolated runtime test — 36 assertions now (up
from 31): re-confirms the base save/restore/edit-mode-abandon behavior,
adds "battle starts while dimmed → no compact at all," and adds the
full toggle-mid-battle sequence (opaque → compacts → dims → pops back
immediately → opaque again → re-compacts → battle ends → restores).
Plus the usual LuaJIT syntax check and byte-diff.

**Needs an on-device check:** start a battle while `DIM OVERLAY` (or a
touch option without `KEEP OPAQUE`) is on and confirm party stays full
size the whole fight; then toggle the option mid-battle and confirm
party compacts/expands immediately rather than waiting for the next
battle.

## `move-opaque-only-v64` — the battle party auto-move now only fires while the overlay is actually opaque

Follow-up to `v62`, requested directly: the party-panel-below-the-enemy-
HUD reposition should only happen while the overlay is rendering fully
**opaque**. If the overlay is currently dimmed/see-through (`DIM
OVERLAY`, or touch nav/icon buttons on without `KEEP OPAQUE`), the
vanilla enemy HUD already shows through the party panel, so there's
nothing to physically move out of the way of.

One-line change: the reposition block's existing condition gained a
`not dimOverlay` term — `dimOverlay` was already computed earlier in
`drawOverlay` for the canvas-dim decision, so this reuses that exact
same flag rather than adding a new one. Only gates the *reposition*
step; the auto-compact-on-battle-start behavior from `v62` is
unconditional either way, since only "the move" was asked about here.

Verified with 5 new isolated-runtime-test assertions covering all four
combinations of (opaque/dimmed) × (overlap/no-overlap), plus confirming
edit-mode deferral still holds regardless of dim state — 31 assertions
total across the full battle-party-move test suite now. Plus the usual
LuaJIT syntax check and a byte-diff confirming the change is exactly the
one added condition.

**Needs an on-device check:** with party overlapping the vanilla enemy
HUD (see `v62`'s note on this needing a narrower window on the Odin's
own wide screen), confirm it stays put while the overlay is dimmed and
only moves once it's opaque.

## `party-cleanup-v63` — dropped the unexplained A/B letter from the party header, shortened two more option labels

Two small, unrelated cleanups requested directly:

- **The Active Party panel's header used to show a leading "A" or "B"**
  before the party count (e.g. "A · 6/6"), marking which density style
  was showing (full vs. compact). Nothing on screen ever explained what
  A/B meant, so it was just noise to a player. Dropped — the header now
  just reads "6/6". The underlying `style` variable this letter was
  reporting is completely untouched and still drives the actual party
  row rendering (`measureMon`/`drawMonRow`) exactly as before; only this
  one display string changed.
- **`TOUCH SCREEN NAV`/`TOUCH SCREEN ICONS` were still riding the edge of
  their row.** `v61`'s budget correction (~16-17 chars) put both right at
  the line rather than comfortably under it. Dropped "SCREEN" from both:
  **TOUCH NAV** / **TOUCH ICONS** (9/11 chars), matching the real margin
  `DIM OVERLAY`/`KEEP OPAQUE` already have.

Verified with a LuaJIT syntax check and a byte-diff confirming the
change is scoped to the one party-header display line and the two label
strings (plus their comments) — nothing else touched.

**Needs an on-device check:** confirm the party header no longer shows
"A"/"B", and confirm TOUCH NAV / TOUCH ICONS now render with visible
margin inside their rows.

## `battle-party-move-v62` — party auto-compacts during battle and moves below the vanilla enemy HUD if it's in the way

New feature, requested directly: when a battle starts, the Active Party
panel now automatically switches to its compact density, and — only if
it would still overlap the **vanilla game's own** enemy name/level/HP
box (not this mod's own battle panel) — moves below that box for the
rest of the fight, restoring its exact original position and density
once the battle ends.

Two pieces of new plumbing this needed, both confirmed against the
installed engine's own source rather than assumed:
- **The vanilla enemy HUD's screen position.** `BattleState:drawHUDs`
  draws it at a fixed spot: the top-left 88×32 pixels of the classic
  160×144 battle screen (name row 0, HP bar starting at tile (2,2)).
  Expressed as a *fraction* of the viewport (55% width, 22.2% height)
  rather than an absolute pixel count, so it stays correct regardless of
  how the engine internally derives its own viewport size.
- **Where that viewport actually sits on screen.** The engine exposes a
  `render.letterbox` hook (`src/render/Renderer.lua`) that hands any mod
  wrapping it the live on-screen rect (`ox, oy, vpw, vph`) the classic
  game view is drawn into, every frame. kanto_companion now wraps it
  read-only (stores the payload, passes it straight through) — this is
  the first hook (as opposed to event) this mod has ever used.

Driven off `st.battle` every frame — like the rest of this function's
panel sizing — rather than a one-shot `battle.started`/`battle.ended`
event pair, for the same reason an existing nearby diagnostic comment
already documents: a one-shot battle-enter event isn't reliably on the
right frame here.

The saved pre-battle position/density lives in a new in-memory-only
`C.battlePartyOverride` table, never written through `savePanelCfg()` —
confirmed by checking every `savePanelCfg()` call site in the file, all
of which stay exactly what they were, none newly added here — so this
never touches the persisted panel-layout file, only a temporary nudge
for the fight's duration. If edit mode gets entered mid-battle (dragging
party by hand while the auto-move is active), the override is abandoned
outright rather than restored over, so a manual edit made mid-fight
survives the battle ending exactly like any other manual edit would.

**SoC-impact note (asked about specifically, Tensor G5 in particular):**
this feature is low-risk *by design* for the class of GPU-driver issue
that actually caused trouble on that chip before (see the separate
recheck below) — it adds no new `love.graphics.setScissor` call of any
kind, degenerate or otherwise. The `render.letterbox` hook wrap is a
pure read (store the payload, pass it through immediately) and the
collision check is a handful of arithmetic comparisons; both run once
per frame only while `st.battle` is true, reusing the same panel-draw
path that already runs every frame today.

Verified with an isolated runtime test (26 assertions): the two pure
geometry helpers (`rectsOverlap`, `enemyHudDesignRect`) directly,
including nil-safety for a missing/zero-size letterbox and a realistic
widescreen unit-conversion check; a wide-screen scenario where party
sits entirely in the left margin and never reaches the viewport at all
(confirming the feature correctly does nothing when there's nothing to
do); a narrow-screen scenario where it does overlap and the reposition
correctly clears it; and the full save/restore state machine, including
the "don't re-save on the second in-battle frame," "custom pre-battle
drag position restored exactly," and "edit-mode-mid-battle abandons
instead of clobbering" cases specifically. Plus the usual LuaJIT syntax
check and a byte-diff confirming the change stayed scoped to one hook
registration, two pure helper functions, and the two new blocks inside
the party-panel section of `drawOverlay`.

**Separately, re-checked whether the older Pixel 10 Pro / Tensor G5
crash fix (base `2.8.2`, unrelated to this session's `-light` branch
work) has regressed across all 61 versions since**, since it hadn't been
re-verified in a while. That crash's exact, confirmed root cause was a
degenerate `love.graphics.setScissor(0, 0, 0, 0)` call during an old
auto-fit height-measurement trick, which a first-generation PowerVR
driver mishandled regardless of what was drawn inside it — fixed
originally by replacing that measurement approach with the `measureOnly`
parameter every panel function still uses today. Grepped current
`main.lua`: zero degenerate scissor calls anywhere, the old `dryRun`
function that caused it is gone, and `measureOnly` is still the pattern
used throughout (16 call sites). The *specific, known* mechanism hasn't
regressed. This is a source-level check, not a device re-test — it can't
rule out some different Tensor-unfriendly pattern from the newer overlay
work, only confirm the original bug's exact cause is still absent.

**Needs an on-device check:** enter a battle with party positioned
somewhere that actually overlaps the vanilla enemy HUD (may require a
narrower window or a manually-dragged party position on the Odin's own
wide screen, since the default layout likely doesn't overlap at all —
see the "wide screen" test case above) and confirm it compacts, moves
below the HUD, and restores exactly after the battle ends.

## `label-budget-fix-v61` — v59's label fix was wrong; real character budget is ~16-17, not ~25

Direct report: `v59`/`v60`'s labels (**OVERLAY TRANSPARENCY**, **KEEP
OVERLAY OPAQUE**) were *still* cut off on-device. A real on-device
screenshot settled it — `v59` had assumed a ~25-character budget based on
**TOUCH SCREEN ICON BUTTONS** believed to fit, but that was never
actually verified against a screenshot, only inferred from it not having
been separately reported as cut off. The screenshot showed **that label
cut off too** ("BUTTONS" missing entirely), proving the assumption
itself wrong, not just insufficient for one label. Comparing what does
fit (**TOUCH SCREEN NAV**, 16 chars, comfortable margin) against what
doesn't (17-25 chars, all cut to varying degrees), the real working
budget is roughly 16-17 characters — about half of what `v59` assumed.

Shortened all three affected labels with real margin this time:
- `OVERLAY TRANSPARENCY` (20 chars) → **DIM OVERLAY** (11 chars)
- `KEEP OVERLAY OPAQUE` (19 chars) → **KEEP OPAQUE** (11 chars) — reads
  as the natural short pair with DIM OVERLAY now
- `TOUCH SCREEN ICON BUTTONS` (25 chars, pre-existing, not something this
  session introduced) → **TOUCH SCREEN ICONS** (18 chars)

The underlying behavior (which option does what, the OR-term redundancy
between DIM OVERLAY and the touch-button options, KEEP OPAQUE's
opt-out) is unchanged — only the label text and the code comments
documenting it changed.

**On the "how will players understand what these do" concern:** this
engine's generic per-mod options screen (`src/mods/ManagerState.lua` +
`src/ui/OptionRows.lua`) has **no description/detail mechanism at all**
for an individual option row — checked its input handling directly
(`ManagerState:updateOptions`) and confirmed SELECT does nothing there
(it's only bound one screen up, on the mods list itself). There is
genuinely no in-row way to convey more than a short label, confirmed
twice now from two different angles. Real explanation of what these
toggles do and how they interact has to live somewhere outside this
list — the mod's own `description` field in `manifest.json` (shown one
screen up, on Kanto Companion's own detail page) is the closest
available option, or the Discord/README as already used for everything
else. Not changed as part of this build — flagged for a decision, not
assumed.

Verified with a LuaJIT syntax check and a byte-diff confirming the
change is scoped to the three label strings and their comments.

**Needs an on-device check:** confirm all three labels — TOUCH SCREEN
ICONS, DIM OVERLAY, KEEP OPAQUE — now render fully inside their rows
with visible margin, not just less-cut-off.

## `keep-opaque-v60` — new mod option: KEEP OVERLAY OPAQUE, the missing other half of the transparency control

Resolves a Discord report from **Seiya**: touch nav/icon buttons being on
has always force-dimmed the overlay unconditionally (so the panels don't
visually block the touch controls underneath), with no way to opt back
out of that. `v57`/`v59`'s **OVERLAY TRANSPARENCY** option only ever
added a way to dim the overlay *more* (manually, even with touch buttons
off) — it never addressed players who want the opposite: full opacity,
even with touch buttons on.

New option, **KEEP OVERLAY OPAQUE**, does exactly that: when on, it
cancels the touch-buttons-on dim specifically, leaving the overlay fully
solid regardless of touch nav/icon button state. It does **not** override
**OVERLAY TRANSPARENCY** itself or the developer-only `FORCE_DIM_OVERLAY`
test flag — both of those are explicit "dim it" requests and still win
outright, so this option can only ever make the overlay *more* opaque
than the touch-buttons-on default, never override an explicit dim
request into staying transparent.

`dimOverlay`'s formula went from
`FORCE_DIM_OVERLAY or touchButtonsOn or manualTransparency` to
`FORCE_DIM_OVERLAY or manualTransparency or (touchButtonsOn and not keepOpaque)`
— only the `touchButtonsOn` term is now conditional.

Verified with an isolated runtime test covering all 16 combinations of
the four inputs (`FORCE_DIM_OVERLAY`, `touchButtonsOn`,
`manualTransparency`, `keepOpaque`) against the intended rule, plus a
LuaJIT syntax check and a byte-diff confirming the change is scoped to
the new option definition and the one formula line.

**Needs an on-device check:** turn on Touch Screen Nav or Touch Screen
Icon Buttons (either forces the dim by default), then turn on KEEP
OVERLAY OPAQUE and confirm the overlay goes back to fully solid while the
touch buttons stay usable underneath.

## `transparency-label-fix-v59` — shortened the OVERLAY TRANSPARENCY option label so it stops bleeding past the row

Follow-up to `v57`: the **OVERLAY TRANSPARENCY (auto-on with Touch Nav/
Icon)** label was running past the edge of its row in the mod-options
list (Mods > Kanto Companion > OPTIONS).

Investigated whether this could be fixed with a scrolling/ticker label
instead of just shortening it — read the actual base-engine source
(`src/ui/OptionRows.lua` + `src/mods/ManagerState.lua`, pulled from the
installed app's own `game.love`) to check. Confirmed that screen is
entirely engine-owned: it draws each row's label with a single
unclipped `love.graphics.print`, no truncation, no scissoring, and no
per-row customization hook of any kind — and the "OPTIONS.." button that
opens it is hardcoded straight to that renderer, with no wrap point a
mod could intercept to substitute its own screen. A scrolling label
would only be reachable through an entirely separate, self-invented menu
entry point, which wouldn't fix the actual row players see today and
would split this mod's settings across two different places for a
cosmetic-only reason — so that idea was dropped in favor of the simple
fix.

Shortened the label to just **OVERLAY TRANSPARENCY**. The existing
25-character **TOUCH SCREEN ICON BUTTONS** label (two rows up) is the
longest one confirmed to render fine, so that's the working budget this
was sized against. The redundancy note (this option overlaps with the
touch-button options, which already dim the overlay) is still documented
in the code comment — only the on-screen text changed; the underlying
`dimOverlay` OR-term behavior is unchanged.

Verified with a LuaJIT syntax check and a byte-diff confirming the
change is scoped to the one label string plus its surrounding comment.

## `route-dex-tally-v58` — Route panel: battled/caught indicators + a per-species defeat counter (built, not shipped — see below)

Built and internally verified this same session, but **descoped from
the actual ask**: the request was to add this concept to the mod's list
of wanted features, not to build it yet. The working build/zip is being
kept on hand (`kanto_companion-2_8_2-route-dex-tally-v58.zip`) since the
investigation and implementation are already done and verified, but it
was **not installed** — the device stayed on `v57`, and `v59` above
branches from `v57` directly, not from this entry. Original v58 writeup
kept below for reference if this gets picked up again later.

New feature: each wild-encounter row in the Route panel would show
whether you've battled that species, whether you've caught it, and how
many times you've defeated it.

- **Battled** (●/○) and **caught** (◆/◇) read straight off the same
  `save.pokedex.seen`/`.owned` flags the Trainer panel's dex-seen/
  dex-owned counts already use — no new tracking needed, these are
  global per-save exactly like the game's own Pokédex screen (seeing or
  catching a species on any route marks it everywhere it appears, not
  just the current one).
- **Defeat count** (`×N`) is new: a per-species KO tally kept in
  `save.modData.kanto_companion.ko`, the sanctioned per-save slot the
  engine serializes alongside the rest of the save whenever the game
  itself saves. A new `battle.fainted` event hook records one KO per
  enemy Pokémon actually defeated (wild or trainer) — never the player's
  own side, and never a capture, since a caught mon leaves battle
  through the catch path rather than fainting.
- Indicators sit right after the species name, filled/hollow so the row
  never changes width between species; the `×N` count only appears once
  it's nonzero, same "no zero state" convention the Items panel's "+N
  more" already uses. Checked clearance for the longest Gen1 names
  (e.g. "Farfetch'd") against the Lv/% columns — over 150px to spare.

Verified with an isolated runtime test (mocked mod/save) covering: reads
start at zero without mutating the save, an enemy faint increments,
the player's own faint is correctly ignored, repeat/multi-species
faints accumulate independently, malformed event payloads never throw,
and battled/caught mirror the dex flags exactly — plus a LuaJIT syntax
check and a diff confirming the change stayed scoped to the new helpers,
the route encounter-table builder, and `drawEncSection`.

The engine's actual `battle.fainted` payload shape (`{ battle, battler }`,
with `battler.isPlayer`/`battler.mon.species`) was confirmed directly
against the installed engine's own `game.love` archive
(`src/battle/BattleState.lua:onFaint`), not assumed — same for
`save.pokedex`'s seen/owned key shape and `save.modData`'s per-save
persistence, both confirmed against `src/core/SaveData.lua`.

## `manual-transparency-v57` — new mod option: overlay transparency, independent of touch buttons

New feature, requested directly: a new mod option, **OVERLAY
TRANSPARENCY**, that triggers the same dimmed/see-through overlay
rendering that already happens automatically whenever Touch Screen
Nav or Touch Screen Icon Buttons are on — now available on its own,
for players who find a fully solid overlay intrusive during normal
play even without wanting the touch buttons at all.

Researched whether the mod-options framework supports greying out one
option based on another's state first, since the two are naturally
redundant with each other. Checked two other installed mods for a real
example (the "VOXEL" setting mentioned) — turned out to be a whole
custom subsystem (`ModSetting`/`gate`) one of those mods built for
itself, not something the base `mod.options:define()` schema natively
supports. Rather than build an equivalent subsystem just for this, the
new option is simply an additional, independent OR term alongside the
existing touch-button check — harmless and redundant (not double-dimmed,
no conflict) whenever a touch option is already on, with the label
itself noting that directly: "OVERLAY TRANSPARENCY (auto-on with Touch
Nav/Icon)".

Verified with a runtime test covering every combination of the three
inputs (touch nav, touch icon, manual transparency) — confirms the
baseline (nothing on) is unaffected, confirms the new option alone
triggers dimming, and confirms every combination with an existing touch
option still just dims once, never double-dims or conflicts — plus a
LuaJIT syntax check and a diff confirming the change stayed scoped to
the option definition and the one `dimOverlay` formula.

Also, per direct request: the on-screen `BUILD_TAG` banner is turned off
for this build only (`SHOW_BUILD_TAG = false`) — flip it back to `true`
for the next round of active dev/version testing, since it's what caught
a stale-build screenshot earlier this session.

**Needs an on-device check:** enable OVERLAY TRANSPARENCY in the mod
manager with touch buttons OFF, and confirm the overlay dims the same
way it already does when touch buttons are on.

## `stick-cursor-reused-v56` — corrected: reuses the EXISTING Items/Party cursor visual, not a new one

Direct correction from the user: `v55`'s claim that no cursor existed
anywhere was wrong — `C.drawScreen` (the Items/Party screen renderer)
already has one, a simple gold ring + dot gated on `C.stickActive`,
proven working on-device. `v55` missed it and built a new custom
crosshair design from scratch instead of reusing it.

Fixed properly this time: the custom crosshair is gone. In its place,
the exact same visual `C.drawScreen` already uses — same gold ring
(radius 10) + dot (radius 2), same alpha, same line width, same
`C.stickActive`-only gate, no other conditions. Placed inside
`drawOverlay`, in the equivalent spot to where the original sits inside
`drawScreen` (right after the edit-mode HUD, within the same
transform-reset render pass every panel already draws through), instead
of the outer draw wrapper `v55` used.

Verified with a runtime test: confirms the coordinate math
(`vcx/s` then `*s` back) is an exact round-trip for several realistic
scale factors, confirms the gate matches `C.drawScreen`'s condition
exactly, and confirms every visual parameter (radius, alpha, line width)
matches the original verbatim, not a redesign — plus a LuaJIT syntax
check and a diff showing the custom cursor fully removed and replaced.

**Needs an on-device check:** push the stick in edit mode and confirm you
see the same gold ring-and-dot cursor Items/Party already shows.

## `stick-cursor-visible-v55` — the actual root gap: the stick cursor was never drawn anywhere, for any screen

Confirmed on direct report: after `v54`'s input-timing fix, aiming was
still impossible for a much more basic reason — **the virtual stick
cursor has never had a visible on-screen marker anywhere in this file**,
for either edit mode or the Items/Party screens. It's a real, tracked
position (`C.vcx`/`C.vcy`), just never drawn. Items/Party gets away with
this because its rows are big, easy targets to land on by feel; edit
mode's panels and small collapse icons need real precision, which isn't
possible while aiming completely blind.

Added a visible cursor: a gold-filled ring with a black outline and a
small crosshair, drawn last (on top of everything), in raw pixel space
(the same space `C.vcx`/`C.vcy` already use). Deliberately high-contrast
against both dark panel backgrounds and bright overworld art, since it
has to stay visible over anything. Scoped to edit mode with the stick
actually active — doesn't touch or add anything to the Items/Party
screens.

Verified the gating logic (only edit mode + active stick, not touching
the Items/Party path) with a runtime test, plus a LuaJIT syntax check and
a diff confirming a single, purely additive draw block.

**Needs an on-device check:** push the stick in edit mode and confirm you
can now actually see where you're pointing, then aim at a panel and
press A.

## `stick-a-poll-v54` — the actual fix: A now polled every frame instead of a race-prone one-shot event

The `v53` diagnostic HUD gave a real answer: `stickActive` genuinely was
`true` and the cursor position was live and correct — the problem was
narrower than "the stick doesn't work." Combined with a direct report of
it working once "accidentally, coincidentally," the actual cause became
clear: starting a drag/select on "A" relied entirely on
`love.gamepadpressed`'s **one-shot** `"a"` event (fires exactly once, at
the instant the button physically goes down) checking `C.stickActive`,
itself only set `true` on a per-frame poll. Press the stick and A at
nearly the same moment — the natural way to do it — and the one-shot
event can fire on a frame before `stickActive` has caught up. Since it
only fires once, holding A afterward never gives it a second chance.

Fixed by polling "A" every frame instead, right alongside the cursor's
own per-frame update, so both checks now happen on the same cadence. A
narrower remaining gap (A going down on the exact frame `stickActive` is
still false) retries **exactly once**, the moment `stickActive` catches
up — not every frame while held, which would spam the existing
tap-debounce logic and risk marking a genuine miss as handled.
`love.gamepadpressed`'s original event-based handling is left in place,
not removed — the existing debounce (same position within 250ms) already
makes it safe for both paths to fire for the same physical press.

The `v53` diagnostic HUD stays in for this build too, in case one more
verification round is needed.

Verified with a runtime test simulating the frame-by-frame state machine:
confirms the exact reported race (A down before `stickActive` is ready)
now retries correctly once instead of never, confirms holding A doesn't
re-trigger repeatedly, confirms release always cleans up drag/resize
state exactly once, and confirms closing edit mode resets everything so
a stuck flag can't cause a missed press next time — plus a LuaJIT syntax
check and a diff confirming the change stayed scoped to this one function.

**Needs an on-device check:** push the stick, aim at a panel, and press A
— should now reliably select/drag every time, not occasionally.

## `stick-diag-v53` — TEMPORARY diagnostic build, not a fix

`v52` still didn't fix the edit-mode stick cursor — confirmed on direct
report, still nothing happens. Rather than guess a third time, this build
adds a live, continuously-updating diagnostic line to the existing DEBUG
INPUT HUD (Options > Kanto Companion — same toggle you already have on),
so the actual real-time state can be read directly instead of inferred
from source. The existing "last input" line only updates on discrete
events and expires after a few seconds, which is useless for a
continuous question like "is the stick currently registering as
pushed?" — so this adds a second line, cyan-colored, showing (updated
every single frame, no expiry):

```
STICK DIAG: joysticks=N gamepads=N | stickActive=true/false vcx=# vcy=# | editStickX=#.## editStickY=#.##
```

Only visible while edit mode is active and the debug HUD toggle is on.
This is **not meant to ship long-term** — it's here to gather one real
diagnostic screenshot (push the stick, watch these numbers, ideally
while also pressing A) so the actual fix can be targeted correctly, not
guessed again.

## `stick-cursor-eventsource-v52` — edit-mode cursor now actually moves (was reading a source that goes stale)

Confirmed on direct report: after `v51` fixed the character walking
while the stick moved the cursor, the cursor itself turned out to not be
moving at all — pressing A did nothing, no panel selected, no drag
started.

Root cause: `C.updateStickCursor` (the function that actually moves the
cursor) reads the stick via `love.joystick`'s `getGamepadAxis()`
**polling** API — a separate mechanism from the `love.gamepadaxis`
**event** callback `v51`'s fix consumes. Both are supposed to reflect the
same hardware state in stock LÖVE, but this engine runs a custom
recompiled LÖVE build, and the event pathway is the one we have actual
proof works reliably here (it's what makes the movement-block fix work
at all). Polling silently not tracking real-time state the same way in
this specific build is a real, plausible explanation, not something
provable from source alone.

Fix: during edit mode specifically, the cursor now moves from the axis
value already being received in the (proven-reliable) event callback,
recorded there and read back by `C.updateStickCursor`, instead of trusting
polling. The Items/Party screen's cursor is completely untouched — it
was never reported broken, so it keeps using the original polling path
exactly as before.

Verified with a runtime test: confirms the event callback correctly
records each axis independently (LÖVE fires one event per axis, not both
together), confirms edit mode reads from the recorded values while the
Items/Party path still uses polling, and confirms closing edit mode
resets the tracked values so a stale reading can't cause a spurious
cursor jump next time it opens — plus a LuaJIT syntax check and a diff
confirming the Items/Party path is untouched.

**Needs an on-device check:** push the stick in edit mode and confirm the
cursor now actually moves and A selects/drags a panel — the character
should still stay put per `v51`.

## `stick-movement-lock-v51` — left stick no longer walks the character while in edit mode

Confirmed on direct report: pushing the stick in `v50`'s new edit-mode
cursor mode also still walked the player character around — edit mode
already captures every keyboard key and every discrete gamepad button
(D-pad included), but the stick's movement was never a "button" to begin
with. It's reported through `love.gamepadaxis` as `leftx`/`lefty` axis
events, the same callback L2/R2 already use for `triggerleft`/
`triggerright` — and nothing here was looking at `leftx`/`lefty` at all,
so they always fell straight through to the engine's own handler.

Fixed by consuming those two axis events before that fallthrough,
whenever edit mode is active — mirrors exactly how D-pad button presses
already get captured. The `v50` stick cursor itself reads the joystick
directly (polling, not through this callback), so it's unaffected either
way; this only stops the *engine* from also seeing the same stick push as
movement. Triggers, and every other axis, are untouched.

Verified with a runtime test covering every relevant state: edit mode
(now consumed), plain overworld (unaffected, movement still works
normally), the Items/Party screen (unaffected — it already blocks
movement its own way), triggers (unaffected), and an unrelated axis name
(unaffected, not accidentally swallowed) — plus a LuaJIT syntax check and
a diff confirming only this one addition landed.

**Needs an on-device check:** push the stick in edit mode and confirm the
cursor moves without the character walking underneath it.

## `stick-editmode-v50` — the left-stick virtual cursor now works in overlay edit mode

New feature, requested directly: edit mode was mouse/touch-only until
now — dragging a panel's header, corner-resizing, and tapping the
collapse icon all need a real pointer position, which the existing
keyboard/gamepad button controls (Tab, Up/Down, C/I/P, L2/R2) can't give.
Gamepad-only players had no way to reposition or resize a panel at all.

Reused the mod's existing left-stick virtual cursor — the same one
already used on the Items/Party screens for Pokémon/item drag-and-drop —
and extended it to also activate during edit mode. Push the left stick to
move the cursor, hold **A** to press-and-drag/resize (same as a real
finger or mouse button down), release to drop. Every existing edit-mode
gesture (select a panel, tap the collapse icon, drag the header, grab a
resize corner, even fully-collapse a panel per `v49`) works through the
stick exactly like a real tap would, since it's wired through the exact
same underlying functions — nothing about panel editing was duplicated
for this.

D-pad/keyboard controls are untouched and still work standalone; pinch-
to-zoom stays touch-only (a stick has one cursor, not two fingers), but
Up/Down already covers per-panel scale for gamepad users either way.

Verified with a runtime test covering the dispatch logic directly: the
existing Items/Party stick behavior is provably unaffected (same call
counts before and after), a new edit-mode hit is consumed correctly
without also triggering the Items/Party path, and a miss falls through
safely with no stray calls — plus a LuaJIT syntax check and a diff
confirming the changes stayed scoped to exactly what this needed.

**Needs an on-device check:** enter edit mode with the gamepad, push the
left stick, and confirm the cursor lets you drag a header, resize a
corner, and tap the collapse icon, all with A.

## `invisible-collapse-v49` — new feature: fully collapse a panel to hide it completely outside edit mode

New feature, requested directly: fully collapsing a panel (the third
rung of the collapse ladder — "bar") now makes it genuinely **invisible**
during normal play, not just a thin bar. The bar (with its collapse
icon, drag grabber, and edit-mode highlight) still shows exactly as
before whenever edit mode is active, so there's always a way to find and
re-expand a hidden panel. This gives players a real way to get rid of a
HUD section they don't want at all, not just shrink it.

Panels stacked below a hidden one close the gap completely — if Trainer
is fully collapsed and hidden, Items now sits exactly where Trainer's
top would have been, with no leftover blank space; if both Trainer and
Items are hidden, Route/Battle moves all the way up too. This reuses and
extends the same stacking-height logic from the earlier gap fixes
(`v40`/`v42`) — a hidden panel now contributes zero height *and* zero
gap, instead of the bar's fixed 34 units.

Verified with a runtime test covering the full matrix: expanded (baseline
unchanged), collapsed-and-in-edit-mode (bar still reserved, matching
prior behavior), collapsed-and-hidden (gap fully closes), both Trainer
and Items hidden at once (everything stacks up to the top margin), and
compact panels (confirmed unaffected by any of this) — plus a LuaJIT
syntax check and a diff confirming only the intended lines changed.

**Needs an on-device check:** fully collapse a panel, exit edit mode, and
confirm it disappears completely with the gap closed — then re-enter
edit mode and confirm the bar (and the ability to re-expand it) is still
there.

## `trainer-compact-oneline-v48` — Trainer's compact stats no longer wrap to a second row

On direct report: the compact Trainer view's 3 stats (Money, Play Time,
Party) were laid out in a 2-column grid — Money and Play Time on the
first row, Party alone wrapping down to a second row. Changed to a
single 3-column row instead, so all three sit on one line beneath the
name, matching what "reduced" was supposed to look like. The panel is
correspondingly shorter now (one row's worth instead of two).

Verified with a runtime test: confirms the new height is shorter (no
wrapped second row), and confirms the three columns divide the panel's
width evenly with no overlap — plus a LuaJIT syntax check and a diff
confirming only this one layout changed.

**Needs an on-device check:** confirm Trainer's compact view now shows
Money/Play Time/Party all on one line under the name.

## `icon-align-fix-v47` — the collapse/expand icon's inset from the bar is now uniform across panels

Confirmed from a screenshot: after `v46` fixed the icon overflowing past
the bottom of a collapsed bar, the icon's inset from the top of the bar
still wasn't perfectly consistent between panels — pulled the actual save
file to rule out a per-panel scale difference first (all four panels
were genuinely at the same 100% scale), which pointed at something more
subtle.

Root cause: each panel's Y position differs (Trainer sits at a clean,
fixed `margin`; Items and Route sit at a *computed* default Y — see
`itemsDefaultY`/`bottomDefaultY`), and this file's low-level `rrect()`
helper floors every shape's position to a whole device pixel
independently. The bar and its icon are two separate shapes, each
floored from their own fractional Y — so even with the exact same,
already-whole-number 4-unit inset between them, two panels with
differently-fractional Y positions could round to a bar-to-icon gap that
differs by a pixel. This is the same class of rounding-phase issue this
file's own `rrect()` comment already documents for corner radius, just
showing up here as a vertical offset instead.

Fixed by snapping the icon's base Y to the exact same whole device pixel
the bar's own shape will land on, before adding the inset on top of that
— makes the gap a fixed number of device pixels regardless of which
panel's Y is being used.

Verified with a runtime test sweeping several realistic scale factors and
Y positions: confirmed the old approach really does produce an
inconsistent gap for several of them (reproducing the bug), and confirmed
the fix produces a perfectly uniform gap in every case tested — plus a
LuaJIT syntax check and a one-line diff.

**Needs an on-device check:** compare the collapse icon's inset across
Trainer/Items/Route (Party's icon sits on a much taller box when
expanded, so it's less likely to show this at all, but worth a glance)
and confirm they now all sit at the same visual height within their bars.

## `collapsed-icon-fit-v46` — the collapse/expand touch icon no longer pokes out of a collapsed bar

Confirmed from a screenshot: the collapse/expand touch icon is a fixed
34-unit square inset 4 units from the top of whatever it's drawn on — but
a *collapsed* panel's own bar is also only 34 units tall, so the icon
always reached 4 units past the bottom of its own bar. Invisible against
a tall expanded panel (plenty of room to spare); very visible as a
"+"-icon square poking out below a thin collapsed strip, which is exactly
what looked "weird and out of place."

Fixed by having the icon shrink and recenter itself to actually fit
inside whatever box it's drawn on, with a floor of 18 units so it never
shrinks below a still-tappable size (same tradeoff Session 58 already
made for the icon's touch hit-padding). Expanded panels pass a box height
that's always far bigger than the icon needs, so this is a complete
no-op there — pixel-identical to before.

Verified with a runtime test: the reported case (a 34-tall collapsed bar
at 100% scale) now keeps the icon fully contained and centered, an
extreme scale-down floors at the minimum tappable size instead of
vanishing, and every expanded-panel size tested produces the exact same
34-unit icon as before (confirming zero visual change there) — plus a
LuaJIT syntax check and a diff confirming only this one function and its
two call sites changed.

**Needs an on-device check:** collapse a panel and confirm the icon now
sits fully inside the thin bar instead of overflowing past its bottom
edge.

## `party-compact-v45` — Party's B/compact density is back in the collapse cycle

On direct report: Party used to have three effective states reachable
one way or another (full, compact/B, collapsed bar), but the compact one
had quietly become unreachable by choice — its only manual control (the
`F7` key) was removed in `v42` as part of the gamepad-Select fix, and
nothing else ever set it. It could still appear automatically (`v44`'s
restored fallback, when a full party doesn't fit), just never on request.

Party now joins Trainer as a second panel with the real 3-way collapse
ladder: **full → compact → bar**, through the exact same controls —
`C`/the touch collapse icon (cycles all three), `I`/`X` and `P`/`Y` (step
toward/away from collapsed), all persisted the same way. Compact is the
same style-B density that's always existed (every mon still shown, just
without move lists) — nothing new was built for the visual, just a real
way to reach it deliberately instead of only by accident when the
screen's too small.

The old `C.partyStyle` field this used to read is gone — it had no write
path left after `v42` and was silently dead. Replaced with
`C.panelCfg.left.compact`, the same field Trainer's compact view already
uses. The automatic fallback (`v44`) still works exactly the same on top
of this — if you manually pick compact and even that doesn't fit, it
still floors at the same readability limit rather than shrinking further.

Verified with a runtime test: `SUPPORTS_COMPACT` membership, the 3-way
cycle behaving identically for Party as it already does for Trainer,
manual compact taking priority even when full would've fit, and the
automatic fallback still working correctly underneath it — plus a LuaJIT
syntax check and a full diff review.

**Needs an on-device check:** cycle Party through all three states with
`C` and confirm compact shows the no-movesets density, and confirm a
manually-compact Party persists across a restart the same way everything
else does.

## `tied-scale-v44` — party's auto-shrink safety net restored; "scale everything" reworked to actually tie into each panel's own percentage

**1. Party's automatic density fallback is back.** `v43` removed it on a
suspicion it was interfering with something else — it wasn't, and
removing it caused a real regression: without it, a full 6-mon party with
movesets can be genuinely taller than the screen even at the readability
floor, and forcing full/style-1 always meant that height was always what
got measured. Confirmed on direct report: the party box stretched off
the bottom of the screen on reset (the exact "worst case" baseline —
scale 1, no saved position — this fallback exists to catch) and behaved
oddly while scaling. Restored verbatim. `v42`'s Select-button fix is
untouched and still correct — the old manual `F7` toggle stays removed;
only the *automatic* behavior comes back.

**2. "Scale everything" now actually scales everything's own percentage,
not a hidden second number.** On direct report: the global-scale control
(`v39`) was a separate multiplier layered underneath every panel's own
`cfg.scale` — pressing it changed what was drawn without changing any
panel's own displayed percentage, which read as two disconnected scaling
systems instead of one. Reworked: `-`/`=` and L2/R2 now bulk-edit every
panel's own scale directly — literally what Up/Down already does to the
selected panel, just applied to all four panels' independent percentages
at once. Each panel still respects its own 40–200% bounds independently,
so a panel already maxed out just stops moving on its own while the
others keep going.

**This also fixes a reset complaint as a side effect**: reset (`R` or the
panic-reset `F9`) always operates on `cfg.scale` directly, so with no
more hidden separate multiplier for it to miss, resetting now reliably
returns to the true 100% default — there's nothing left for reset to
leave stale.

Also noted in passing: while investigating, found a recurring crash in
the on-device Lua error log (`attempt to compare number with nil`) from
the same testing window, but couldn't pin it to an exact line with
certainty across the several versions in flight at the time — flagging
this in case it recurs; this build's own build-tag banner will make it
easy to confirm exactly which version any future occurrence comes from.

Verified with a runtime test: the restored party fallback (switches to
style 2 in an extreme case, stays style 1 for a mild shrink, matches
exactly for both), and the bulk-scale redesign (each panel moves
independently, clamps at its own bounds, reflects directly in the
displayed percentage) — plus a LuaJIT syntax check and a full diff review
confirming only the intended lines changed.

**Needs an on-device check:** confirm a full party no longer stretches
off-screen on reset, confirm `-`/`=`/L2/R2 now visibly change each
panel's own percentage together, and confirm `F9` reliably returns
everything to a clean 100% default.

## `no-auto-party-switch-v43` — party no longer auto-switches density, to isolate it while testing other overlay changes

On direct request: removed the automatic switch to the Party panel's
compact density (style 2 — the version without move lists) that used to
kick in whenever a full party would have needed to shrink past the
`MIN_FIT_SCALE` readability floor. It was suspected of interfering with
testing/verifying the other recent overlay changes, so it's isolated out
for now.

**What's kept:** the actual out-of-bounds prevention. Party still shrinks
uniformly to fit the available space, still floored at the same
`MIN_FIT_SCALE` so it can't shrink to unreadable — it just never switches
density anymore. In practice, party will now always render at style
1/full, since nothing sets the density to 2 any more either (`v42`
already removed the old manual `F7` toggle for it). The style-2 rendering
code itself isn't deleted, just unreachable automatically for now — easy
to bring back later if wanted.

Verified with a runtime test on the new scale formula (fits with no
shrink, mild shrink, and an extreme case that used to trigger the
density switch — confirmed it now just clamps at the floor instead), plus
a LuaJIT syntax check and a byte diff confirming only this one branch
changed.

## `stacking-select-fix-v42` — two bugs: the stacking gap's other half, and gamepad Select swallowed globally

**1. Stacking gap, part 2.** `v40` fixed the gap that opened up when the
right column auto-shrunk to fit (the shared `rScale`). This is the same
bug's other half: Items/Route-Battle's default position was *also*
always computed as if Trainer (and Items) were showing their full,
expanded height — even when actually collapsed (a 34px bar) or, since
`v41`, compact. So collapsing or compacting Trainer left a large empty
gap above Items instead of closing it up. Fixed the same way: use each
panel's real current height for stacking, not always its full height —
still deliberately excluding each panel's own manual pinch/resize scale
(`cfg.scale`), same distinction `v40` already established.

**2. Gamepad Select doing nothing, anywhere, confirmed root cause.** This
matches an old unresolved report ("Select/touchpad button unresponsive
for some controller users") from the Discord bug list. Root cause: Select
(`back`) was bound to a leftover "TEMP TESTING" key (`F7`, manually
toggling the Party screen's old A/B density preview) — and
`love.gamepadpressed`'s dispatch logic unconditionally swallows *any*
button with an entry in its keymap, whether or not anything actually
handles it. On the Items/Party screen this called into a function that
had no `F7` case at all — a pure no-op swallow — while still blocking
the press from ever reaching the real engine or any other mod's own
Select handling. Found this via a report that a *different* mod's
Select-triggered item-favorite feature wasn't firing via gamepad, only
touch.

**Fix: removed the binding outright**, not moved elsewhere — it was only
ever a dev preview toggle, explicitly labeled temporary, and the party
density's real automatic shrink-to-compact fallback (when a full party
doesn't fit) is untouched and keeps working exactly as before. Real
keyboard `F7` was never actually the problem (it already passed through
correctly when a screen was open) and needed no separate fix. Gamepad
Select should now reach the real engine/other mods normally, in both the
overworld and on the Items/Party screens.

Verified with an isolated runtime test for both: the stacking formula
(confirmed unchanged for the fully-expanded case, confirmed the
collapsed/compact cases now use the right height) and the Select dispatch
logic (confirmed the old keymap swallowed it in both states, confirmed
removing the entry lets it fall through to the real handler in both) —
plus a LuaJIT syntax check and a byte diff confirming only these two
changes landed.

**Needs an on-device check:** confirm Items/Route-Battle sit right up
against a collapsed or compact Trainer with no big gap, and confirm
gamepad Select now does whatever it's supposed to on the Items screen
(favoriting, in the other mod's case) instead of nothing.

## `trainer-compact-v41` — a real middle ground between expanded and collapsed, on the Trainer panel

New feature: the Trainer panel now has a third view between "fully
expanded" and "just the header bar" — a **compact** view showing only
name, money, play time, and party count. This is the same idea the
Party screen's A/B density toggle already uses (Select), extended into
the collapse control itself as a proper 3-way ladder: **full → compact →
bar**, and back.

**Controls (Trainer selected, edit mode):**
- `C` / tapping the panel's collapse icon: cycles through all three,
  wrapping around
- `I` / **X** (gamepad): one step more collapsed (full→compact→bar),
  clamped — repeated presses converge on bar and stay there, same as
  before
- `P` / **Y** (gamepad): one step less collapsed (bar→compact→full),
  clamped
- `R`: resets fully back to expanded (now also clears compact, not just
  collapsed)

Every other panel (Party, Items, Route/Battle) is untouched — they keep
the exact same two-state collapse they already had, since they don't
have a reduced view to show yet.

Persists across restarts the same way everything else does (one more
field per panel in the same save file; old save files with no `compact`
field just default to `false`, no migration needed). The edit-highlight
border and resize-corner grips now correctly track the panel's actual
current size (compact panels get a smaller highlight box, not the old
full-size one).

Verified with an isolated runtime test: the full/compact/bar cycling
logic (wrap on `C`, clamp on `I`/`P`, never both collapsed-and-compact
at once), the save/load round-trip (including old files with no
`compact` field), and the compact view's own height formula (confirmed
smaller than a real full view) — all passing — plus a LuaJIT syntax
check and a byte diff confirming only the intended lines changed.

**Needs an on-device check:** cycle Trainer through all three states via
`C` and via the touch icon, confirm the compact view shows exactly
name/money/play time/party count, and confirm the resize-grip/highlight
box now hugs the smaller compact panel instead of floating at the old
full-size box's edges.

## `rightcol-stack-fix-v40` — Route/Battle panel running off the bottom of the screen, fixed

Confirmed from a real screenshot: the right column (Trainer / Items /
Route-or-Battle) auto-shrinks all three panels together when their
combined content doesn't fit the screen — but the vertical gap between
them was still being computed from their FULL, un-shrunk height. So the
panels themselves got smaller while the space between them didn't,
pushing the last one (Route/Battle) further and further down each time
more content pushed it into shrink territory — in the reported case,
straight off the bottom of the screen.

Root cause: a `Session 69` fix that deliberately stopped panels reacting
to each other's own manual pinch/resize scale (`cfg.scale`) also
accidentally dropped the *shared* auto-fit shrink (`rScale`) from the
same formula — those are two different things. `cfg.scale` is
per-panel and reactive (exactly what needed to be excluded); `rScale` is
shared by all three panels and only changes with real content size, not
with any single panel's pinch/drag. Restoring just `rScale` to the
stacking math fixes the overflow without undoing Session 69's fix.

This bug predates this session's other changes and wasn't caused by the
resize-grip or global-scale work — but the new global-scale control (see
`v39` above) makes it much easier to hit: turning the overlay up now
shrinks the available screen space, which triggers this same auto-fit
path far more often than before.

Verified with an isolated runtime test modeling the exact stacking
formula: the old math overflowed by ~170+ design units in a
representative shrink scenario; the fix brings that down to ~7 (the
small remainder is two intentionally-unscaled 16-unit gaps, not a bug),
and the normal/unshrunk case is provably pixel-identical to before (no
behavior change when nothing needs to shrink).

**Needs an on-device check:** the exact save/scene that showed the
Route panel running off-screen, to confirm it now stays fully on
screen — and worth trying with the new global-scale turned up too,
since that's the easiest way to reproduce the shrink path on demand.

## `global-scale-v39` — one control to scale the whole overlay at once

New feature: a single player-adjustable multiplier that scales
**everything** together — every panel, the Items/Party full screens, all
of it — separate from each panel's own independent scale (which still
works exactly as before, for repositioning panels relative to each
other). The idea: on a PC monitor the built-in defaults are probably
already fine, but plenty of other screens will still want the whole
thing bigger or smaller, without having to resize four panels one at a
time.

**Controls, edit mode only:**
- Keyboard: `-` / `=` (numpad `-`/`+` also work)
- Gamepad: **L2 / R2**

L2/R2 used to collapse/expand the selected panel — that moved to **X
(collapse) / Y (expand)** instead, since L1/R1 (the first choice for
global scale) turned out to already control game speed, the same
discovery that put collapse/expand on L2/R2 in the first place. X/Y did
nothing at all in edit mode before this, so nothing existing changes —
outside edit mode X/Y still open Items/Party exactly as before.

Persists across restarts the same way per-panel layout already does (one
more field in the same save file). Verified with an isolated runtime
test (clamp bounds, save/load round-trip including old save files with
no global-scale field at all, and the scale-math itself) — all passing
— plus a LuaJIT syntax check, before packaging.

**Needs an on-device check:** confirm `-`/`=` and L2/R2 both scale
everything up/down together in edit mode, that X/Y now collapse/expand
the selected panel instead of L2/R2, and that a restart remembers
whatever scale you left it on.

## `grip-white-only-v38` — dropped the now-invisible gold fill, kept the white look as-is

Confirmed from an on-device edit-mode screenshot of `v37`: the gold
fill is no longer visible at all — the white outline stroke is thick
enough relative to the shrunken bar to fully cover it. You said you
like that all-white look and want to keep it exactly as it looks now,
so rather than leave a gold fill drawing underneath and doing nothing,
it's removed outright. Purely a dead-code removal — same pixels on
screen, one fewer draw call. Nothing else changed (sizes, hit zone all
identical to `v37`).

## `grip-thin-v37` — corner grip thinned again, this time including its outline

`v36`'s cut (bar thickness `7 -> 5`) barely read as smaller on-device.
Root cause: the white outline stroke traced around the gold fill (added
`v35` purely for contrast against the panel background) has its own
fixed width tied to the screen scale factor, independent of the fill's
own thickness — shrinking only the fill left that stroke's bulk
untouched, which ate most of the intended reduction. This pass thins
both: the fill again (`5 -> 4`, bar length `20 -> 17`) and the outline
stroke itself (`s * 1.3 -> s * 0.9`, floor `1.5 -> 1.1`), so the actual
visible edge gets thinner this time, not just the fill hidden behind an
unchanged border. Touch hit zone still untouched (56).

Also fixed: the on-screen build-tag banner (top-left corner) was still
reading `resize-anchor-fix-v35` in the `v36` build — an oversight, the
tag just wasn't updated when that zip went out. Now correctly reads
`grip-thin-v37`.

**Needs an on-device check, this time from an edit-mode screenshot** so
the bracket size is actually visible for comparison (the last
screenshot sent wasn't in edit mode).

## `resize-grip-tune-v36` — corner grip made slimmer, its touch target made bigger

Direct feedback from the on-device `v35` screenshot: the corner-resize
brackets are the right shape and now visible, but read a bit too thick.
Trimmed the visual down (bar thickness `7 -> 5`, bar length `22 -> 20`
design units) without touching the touch/mouse hit zone to match —
if anything the hit zone grew (`40 -> 56`), on the same "small visible
glyph, generous invisible hitbox" logic iOS/Android both use for tiny
drag handles: a thinner bracket is harder to land a fingertip on
precisely, so the grabbable area shouldn't shrink just because the
drawn shape did.

Pure numeric/visual tweak, no logic changed — diffed clean against
`v35` (only the three changed constants plus their comment). LuaJIT
syntax-checked before packaging.

**Needs an on-device check:** confirm the bracket looks slimmer, and
that the corners still feel easy (or easier) to grab precisely by
touch.

## `resize-anchor-fix-v35` — two real bugs found from your screenshot/report, both fixed and verified

**Bug 1 — the corner grip was invisible.** Confirmed directly from the
screenshot you sent: `v34`'s "backing bar" used `COL.panel`, the exact
same near-black the panel's own background is already filled with,
entirely inside the panel. Zero contrast against itself — it was never
going to show up. Replaced with a real outline stroke in `COL.border`
(white) traced around the gold fill, which contrasts against the dark
panel background no matter what's directly behind it.

**Bug 2 — resize only tracked the finger correctly on one corner.**
Root cause: both corners were sharing ONE anchor point per panel
(whichever side it defaults to pivoting from), instead of each corner
anchoring to its own diagonally-opposite corner, the way a real window
resize works. The corner near that shared anchor happened to track
fine; the far corner was being measured against a point nowhere near
where your finger actually was. Fixed properly: grabbing the
bottom-right corner now keeps the current top-left fixed, grabbing the
bottom-left corner now keeps the current top-right fixed — both keep
the top edge in place either way, since both are bottom-corner grabs.
This meant resize now also has to actively move the panel's position
as it resizes from the left, not just its scale (a right-corner resize
never needed to, since top-left already doesn't move by default) —
implemented and it's the actual fix, not a workaround.

**Verified with an isolated runtime test before shipping** — not just
re-read: dragging the bottom-right corner outward keeps top-left fixed
exactly, dragging the bottom-left corner outward *or* inward keeps the
top-right edge fixed exactly, both confirmed against real execution.
Diffed clean against the confirmed-good `v34`.

**Needs an on-device check:** confirm the corner grips are now visibly
white-bordered gold brackets, and confirm dragging the LEFT corner now
tracks your finger the same way the right one already did (try growing
*and* shrinking from the left corner specifically).

## `solid-corner-grip-v34` (grip visibility and left-corner tracking both found broken via screenshot/testing; fixed above)

Back to the L-bracket shape from `v32` — that part was right. What
wasn't: every version so far (thin outline, then dots) rendered it in
the same thin-gold-glow-line language this file already uses
everywhere for selection borders and highlights, which reads as
"this is selected" rather than "grab this."

**Rendered as a solid, chunky, filled bracket instead of thin
strokes.** A dark backing bar (the same near-black already used for
panel backgrounds) sits just behind a smaller solid gold bar, giving
it a bordered, tactile look — closer to a real OS resize grip than to
this mod's usual delicate outline style, while still built entirely
from colors already in this file's own palette, so it shouldn't feel
like an unrelated import. Same inset discipline as every version
before it — still fully inside the panel, nothing pokes past the
border.

Diffed clean against the confirmed-good `v33` — only this one function
changed. If this still isn't landing, happy to work directly from
whatever reference you find.

## `polish-pass-v33` (grabber bar and collapsed-width fix confirmed good; corner-grip presentation addressed above, another round in progress)

Three more refinements on direct request/report:

**Header now has a visible "grab me" cue.** A small centered pill-
shaped bar near the top of each panel's header, the same convention
as an iOS bottom-sheet handle or a real desktop window's title-bar
grip. Purely visual — the actual draggable hit zone is still the
entire header strip, not just this bar.

**Real bug fixed: collapsing a scaled panel no longer changes its
width.** The collapsed-strip drawing code always used a flat `COLW`
regardless of the panel's own current scale — confirmed as a known,
deliberate simplification when first written, but a real mismatch in
practice: scale a panel up or down, collapse it, and the strip would
snap back to 100% width instead of matching where the panel actually
was. Now computed the same way (`COLW * baseScale * cfg.scale`) the
expanded branch already does — width *and* height, for full
consistency with the highlight border and hit-testing, which both
depend on the same number.

**Corner-resize visual replaced again** — the `v32` L-bracket was the
right idea but, on request, not sleek enough. Swapped for the classic
diagonal resize-grip dot pattern (three small dots trailing into the
panel from the corner, growing slightly as they approach it) — the
same visual language as a textarea's or a Mac window's resize corner.
Still fully inset from the real border, same as before. If this still
isn't the right look, happy to take another pass against a reference.

**Verified:** real LuaJIT syntax check; diffed clean against the
confirmed-good `v32` — every change traced to one of the three asks
above, nothing else moved.

**Needs an on-device look:**
- Does the header grabber bar read clearly as "drag here" without
  being distracting?
- Scale a panel up or down, collapse it, confirm the collapsed strip's
  width (and height) now actually matches where the panel was.
- How do the new corner-resize dots feel — sleeker than the bracket,
  or still not it?

## `resize-touch-corner-brackets-v32` (confirmed working — resize/touch/visual asks addressed above)

Three refinements to `v31`, all on direct request after real on-device
testing:

**The old drag-handle icon is gone, completely.** `v31` widened the
drag hit-zone to the whole header but kept the small icon glyph
drawn as a visual hint. Removed entirely now — the header itself is
the affordance, a redundant icon on top of it wasn't adding anything.
The function that used to draw it now only records the hit zone;
renamed (`recordHeaderDragZone`) since it no longer draws anything.

**Corner resize now works with touch, not just mouse.** `v31` gated
resize-start to the mouse specifically, out of concern it would
conflict with pinch-to-zoom. On-device testing showed that's not
actually a real conflict in practice — a touch landing precisely on a
small corner zone doesn't meaningfully collide with a two-finger pinch
gesture. Opened up to both. This meant resize now needs the same
touchId-ownership tracking drag/pinch already have (so a second,
unrelated finger moving elsewhere can't affect someone else's
in-progress resize) — added and verified with an isolated runtime
test (one finger starts and ends its own resize correctly; a second,
different finger moving or releasing does NOT affect it; plain mouse
input, no touchId, still works exactly as before).

**Corner resize icons replaced with inset corner-brackets.** The old
icon was a filled square with a diagonal line, centered directly ON
the panel's true corner — meaning half of it visually stuck out past
the panel's own border. Replaced with a small two-line bracket that
mirrors the corner's own L-shape, displaced a little inward from the
real border instead of straddling it, so nothing drawn here ever
extends outside the panel. The actual grabbable area is unchanged in
size and position (still centered on the true corner, with the usual
a-bit-more-than-what's-drawn forgiveness) — only the visual moved.

Verified properly again: real LuaJIT syntax check, plus an isolated
runtime test of the updated resize-start/update/end logic (touch
ownership isolation specifically, since that's the new risk here).
Diffed clean against the confirmed-good `v31` — every change accounted
for.

**Needs an on-device retest:**
- Confirm no icon is drawn at a panel's top-left anymore — just the
  (now invisible) full-header drag zone.
- Confirm resize now works by touch as well as mouse, from either
  bottom corner.
- Confirm the corner-bracket marks are fully inside each panel's
  border, not poking out past it.
- With two fingers down, confirm one finger resizing a corner and
  another finger doing something else (e.g. starting to drag a
  different panel's header) don't interfere with each other.

## `header-drag-corner-resize-v31` (header-drag confirmed working; icon removal, touch resize, and corner visuals addressed above)

Two new edit-mode interactions, on direct request:

**Drag by the header, not a tiny icon.** Grabbing anywhere across the
top strip of a panel (its full width, ~48 design units tall) now
starts a drag — the same convention as dragging a window by its title
bar on a desktop OS. The small drag-glyph icon is still drawn in the
same spot as a visual hint, but it's no longer the actual target —
missing it by a few pixels no longer matters. Works identically for
touch and mouse, same as before.

**Resize by dragging a bottom corner — mouse/PC only.** Each expanded
panel now has small grip handles at its bottom-left and bottom-right
corners. Dragging one with a mouse scales the panel up or down,
anchored to the panel's own fixed pivot point (the same corner it
already scales from for keyboard/gamepad/pinch — top-left normally,
top-right for the still-undragged right-column panels), using the same
distance-ratio math pinch already uses, just against that fixed point
instead of a second finger.

**Deliberately mouse-only, not touch.** Touch already has pinch for
scaling; letting a single touch also resize from a corner would be a
second gesture competing for the same job. The corner grips are drawn
and hit-tested the same regardless of input method, but the resize
gesture itself only *starts* when the press's origin is the mouse
pseudo-id — a real touch landing on a corner just falls through to
ordinary panel-select/pinch behavior, same as landing anywhere else in
the panel body. Confirmed this gating actually works with an isolated
runtime test (real touch input on a corner correctly does NOT start a
resize), not just by reading the code.

Only the bottom two corners have resize grips, not all four — the top
two are already claimed by the collapse icon (top-right) and the new
full-width header-drag zone (top-left through top-right). Both bottom
corners scale the panel uniformly from its existing pivot rather than
from whichever corner is grabbed, since panels only have one scale
value, not independent width/height — dragging either bottom corner
produces the same visual result, just a different grab point.

Verified this build properly this time: syntax-checked the whole file
with a real LuaJIT interpreter, and ran the new resize-start/update/end
logic through an isolated runtime test with mocked state (both
anchor-corner cases, confirming touch input is correctly rejected,
confirming a stray mouse press away from any corner does nothing) —
not just re-read by eye. Diffed clean against the confirmed-good
`wwwh-scope-fix-v30` — only the header/resize additions changed.

**Needs an on-device retest:**
- Touch: drag still works by grabbing the header area (not just the
  small icon); pinch still scales correctly; the bottom corners do
  nothing special for touch (fall through to normal select/pinch).
- Mouse: drag by clicking anywhere on the header; resize by
  click-dragging a bottom corner; confirm the panel scales the
  direction you'd expect (drag outward = bigger, inward = smaller).
- Confirm exiting edit mode (F6/R3/Esc) or panic-reset (F9/L3) cleanly
  cancels an in-progress resize, same as it already does for drag/pinch.

## `wwwh-scope-fix-v30` — real crash fixed, confirmed via on-device error log

**This fixes the "any tap anywhere crashes" report from v29 testing —
and it turned out to have nothing to do with drag/pinch at all.**

Diagnosed properly this time, not guessed at: installed a real Lua
interpreter (LuaJIT, matching what LÖVE uses) to actually verify
things instead of just re-reading code, confirmed v29's `main.lua` has
zero syntax errors, and confirmed the new pinch-start logic doesn't
error in an isolated runtime test. Then captured `adb logcat` live
during an on-device repro and, more usefully, found
`lua-error.log` sitting in the mod's own save folder (readable via
`run-as`, no root needed) with the exact error, timestamped to the
second against the observed crash:

```
mods/kanto_companion/main.lua:3961: attempt to compare number with nil
```

Line 3961 is the on-screen touch-nav-button check inside
`love.touchpressed` — `ww > 0 and wh > 0`. `ww`/`wh` were declared
`local` inside an earlier, separate `if c then ... end` block and had
already gone out of scope by the time this later block reads them —
so they silently fell back to undeclared globals (always `nil`),
throwing that exact error on every tap that reached this check. With
`touch_nav_buttons` or `touch_icon_buttons` enabled (both were on),
that's effectively **every tap outside edit mode** — matching "any
screen tap, anywhere" exactly.

**This bug is NOT new to `v29`.** Diffed byte-for-byte against
`independent-panels-v28` and it's identical there too — confirmed with
the same tools, not assumed. `v28` was never actually safe from this;
the earlier regression test just didn't happen to trigger it. Fixed by
hoisting the single `local ww, wh = love.graphics.getDimensions()` to
the top of `love.touchpressed`, before either `if c then` block, so
both the nav-button and icon-button checks read the real values.

The drag/pinch work itself (independent panels, one-finger pinch) is
untouched by this fix and still needs its own retest per
`onefinger-pinch-v29`'s notes below.

**Needs an on-device retest:** confirm normal tapping (nav/icon
buttons on, outside edit mode) no longer crashes at all. Separately,
retest the pinch/drag items below since those weren't touched here.

## `onefinger-pinch-v29` (pinch mechanics confirmed good; the crash below is unrelated to this, fixed above)

**Pinch no longer requires both fingers inside the panel.** On
`independent-panels-v28`, once a panel gets scaled down small, its box
can become too small to physically fit two fingers inside to pinch it
back up — a real dead end. Now only ONE of the two fingers needs to
land inside a panel's bounds to start a pinch on it; the other finger
can land anywhere else on screen. If both fingers happen to land inside
panels, they still have to agree on which one (landing in two
different panels at once is left as a no-op, not a guess).

Caught and fixed one real bug while writing this: the first draft used
Lua's `cond and nil or fallback` idiom to express "pick either one, but
nil if they disagree" — that idiom can never actually produce `nil` as
its result (`cond and nil` is always falsy no matter what `cond` is),
so the "disagree" case would have silently always picked one panel
anyway instead of correctly declining to pinch. Replaced with a plain
if/else before this ever got tested.

Diffed against the exact bytes already on-device (`v28`) — only the
pinch-start hit-test logic changed; the scale math, drag, and
independent-default-position behavior from `v28` are untouched.

**Needs an on-device retest:** shrink a right-column panel down small
via keyboard/gamepad scale, then try pinching it back up with one
finger inside the box and the other finger elsewhere on screen —
should now work. Also confirm a normal both-fingers-inside pinch still
works exactly as before.

## `independent-panels-v28` (confirmed working — panels fully independent now; pinching a very small panel still hard to grab, fixed above)

**Right-column panels (Trainer/Items/Battle-or-Route) no longer react
to each other at all.** `v27` fixed the original "losing their hook"
report, but on real-device testing with pinch in the mix, the
right-column panels still felt "funky" — moving in relation to each
other during normal use. Root cause, finally isolated: it was never
really about drag. `drawEditablePanel`'s return value (used to
position the *next* panel down) is `natH * totalScale`, and
`totalScale` includes live `cfg.scale` — so pinch-scaling *any*
right-column panel reactively shifted every panel below it in real
time, every frame, for as long as the pinch lasted. That's what read
as "funky."

**Removed entirely rather than patched again, per direct request.**
Panels no longer see each other's current scale, position, or drag
state at all. Each one's *default* (never-dragged) position is now a
fixed offset computed once from the other panels' `natH` alone —
their real unscaled content size, which only changes with actual game
content (e.g. party size), never with pinch or the keyboard/gamepad
scale controls. Positioning them relative to each other is now
entirely up to you via drag — that's the actual design now, not a
limitation.

Diffed against the exact bytes already on-device (`v27`) — only this
one block changed; drag, pinch, and the accidental-drag-prevention fix
from `v27` are untouched.

**Needs an on-device retest:** pinch/scale a right-column panel
repeatedly and confirm the others hold still now, no matter what.
Then confirm drag still works exactly as before to reposition any
panel manually.

## `drag-pinch-fix-v27` (confirmed working — drag/pinch functional, but panel repositioning still felt "funky"; superseded by v28 above)

**`reflow-fix-v26`'s approach is reverted — it caused a new bug.**
On-device testing found that dragging a right-column panel now made
the panel below it "snap to the upper right side of the screen."
Root cause of *that*: `v26` made a dragged panel contribute zero
height to the stacking calculation, so the moment you began dragging
it — even one pixel of movement, the instant `cfg.pos` went from
`false` to a real position — the next panel jumped straight to
wherever the stack had reached at that point (the very top of the
column, if the dragged panel was Trainer). Reverted back to the
original behavior: a manually dragged panel's slot stays reserved in
the stack, and the others don't reflow to fill it — the same
previously-accepted Session 62/63 limitation, but at least it never
jumps.

**The actual `v25` "losing their hook" report is instead fixed at its
real trigger.** A single-finger drag only starts if a press lands
precisely on a panel's small drag-handle zone — but that's exactly
where a finger attempting to *pinch* a panel can easily land for a
moment before the second finger registers. Previously, even that
brief, accidental drag would leave `cfg.pos` permanently set once the
pinch took over, silently pulling the panel out of the default stack
for good. Now, starting a drag snapshots what `cfg.pos` was the
instant before (`false`, if it had never been dragged); if a pinch
then supersedes that drag, `cfg.pos` is restored to that snapshot
instead of keeping whatever partial movement leaked in — so a pinch
attempt can no longer accidentally "drag" a panel out of the stack at
all. A real, deliberate drag (one finger, held, no second finger
joining) is completely unaffected.

Diffed against the exact bytes already on-device (`v26`) — only the
build tag differs at the top; diffed against `v25` (the last
confirmed-good baseline before the reflow detour) to confirm the rest
is exactly the snapshot/restore fix and nothing else.

**Needs an on-device retest of both symptoms together:** pinch/scale
right-column panels repeatedly and confirm they keep stacking
correctly (the original report). Separately, deliberately drag a
right-column panel with one finger and confirm nothing below it
snaps or jumps (the regression this build fixes). If a real,
deliberate drag still doesn't feel right afterward, that's the
already-known, still-accepted "no reflow" limitation, not a new bug.

## `reflow-fix-v26` (found a new bug — panel below a dragged one snapped to the top; superseded by v27 above)

**Right-hand column (Trainer/Items/Battle-or-Route) now actually
reflows when a panel is dragged out of it.** On-device testing of
`pinch-zoom-v25` found the panels "losing their hook to each other" —
correct at first, then stuck — after a while. Root cause: once any
right-column panel gets an explicit dragged position (`cfg.pos`), even
briefly and by accident (a finger landing on its drag-handle zone
right before a second finger arrives and upgrades a touch into a
pinch), the stacking math that positions the *next* panel down kept
reserving space for that panel in its old default slot regardless of
where it actually rendered now — a permanent "ghost slot." The column
below it then stacked relative to nothing, and further scale changes
to the moved panel stopped visibly affecting the others at all. Fixed
by having each panel's contribution to the next one's stacking
position drop to zero the moment it's been dragged out of the default
flow, so the ones after it close the gap for real instead of leaving a
hole. This was a known, previously-flagged limitation (Session 62/63)
that pinch just made far easier to trigger by accident — not a new bug
introduced by pinch itself.

Diffed clean against the exact bytes already on-device (`v25`) — only
this fix changed.

**Needs an on-device retest of the exact symptom:** pinch/scale one
right-column panel repeatedly, switch which one you're touching, and
confirm they keep correctly stacking below each other throughout,
instead of freezing after a while. Also worth deliberately dragging a
right-column panel away and confirming the one(s) below it visibly
close the gap now, not just stop breaking.

## `pinch-zoom-v25` (tested on-device — pinch itself confirmed good; found the reflow bug fixed above)

**Touch pinch-to-zoom for panel scale.** The one core edit-mode
capability with no touch equivalent — scale was keyboard/gamepad-only
(`Up`/`Down`) since Session 62 declined touch scale buttons in favor of
drag first. With drag now stable, this adds real two-finger
pinch-to-zoom instead of the button-based interim step: while edit
mode is active, putting a second finger down inside a panel that
already has a finger on it starts a pinch (anywhere in the panel body,
not a dedicated handle) — panel scale then tracks the live ratio of
the two fingers' current distance to their distance when the pinch
started, through the exact same `clamp01Scale` bounds (`0.4`-`2.0`)
the keyboard/gamepad controls already enforce, so touch and
non-touch scaling can never disagree on the valid range. Lifting
either finger ends the pinch and saves; the remaining finger (if
still down) does nothing further until released and pressed again,
rather than surprising you by resuming as a drag. A single-finger
drag already in progress on a panel is cleanly handed off to a pinch
if a second finger joins it, and the reverse (finishing a pinch)
never leaves a stale drag behind either — pinch and drag are mutually
exclusive by construction, not just by convention.

Layered directly on top of `persistence-fix-v24` below (both of that
build's fixes are included, unchanged) — this is genuinely new
functionality, not a bugfix, and it has not been run at all, on
device or otherwise (no local Lua interpreter was available to even
syntax-check it). Diffed clean against the confirmed-good `v24` before
building this — every change is exactly this feature, nothing else
moved.

**Needs a real on-device test before trusting it for anything:**
two-finger pinch actually scales the panel it's pinched, tracking
naturally rather than jumping/stuttering; lifting one finger ends the
pinch cleanly; an in-progress single-finger drag correctly hands off
to a pinch when a second finger joins; nothing crashes or leaves a
panel in a bad state if fingers lift in an unusual order.

## `persistence-fix-v24` (confirmed working on-device)

Internal follow-up to the `emergency-reset-v22` / `emergency-fix-v23`
pair (the overlay-edit-mode drag crash and its recovery key — see
those builds' own notes). Both v22 and v23 shipped with
`EMERGENCY_WIPE_SAVED_CONFIG` hardcoded `true`, which was only meant
to force one clean load past the corrupted state — but the check runs
on every real session, not once, so it was silently discarding and
overwriting the saved panel layout (position/scale/collapsed) on
every single launch. That's why nothing persisted across play
sessions even after the crash itself was fixed in v23. Flag turned
back `false` here; the normal load-and-validate path (including the
out-of-bounds-`pos` rejection added alongside the emergency wipe) is
active again, and the crash fix itself is untouched.

**L3 (left-stick click) is now locked to edit mode.** In v22/v23, L3
was mapped straight through the same shared keymap as every other
gamepad button, which routed it into the exact same unconditional
panic-reset path as real keyboard F9 — so an accidental stick-click
during ordinary overworld or battle play (much easier to do by
accident than an F9 keypress) would silently wipe your layout back to
default. L3 is now handled separately and only fires the reset while
overlay edit mode (`F6` / `R3`) is actually active; outside edit mode
it does nothing. Keyboard `F9` is unchanged — still unconditional, any
time, any state — since that's the real "edit mode itself won't even
open" escape hatch and needs to stay that way.

**Needs an on-device retest:** confirm the crash stays fixed; confirm
a layout customized in one session is still there after fully closing
and relaunching the game; confirm L3 no longer resets anything outside
edit mode, and still does while edit mode is active; confirm F9 still
works unconditionally.

## What's new in 2.8.2

- **Type-badge sizing fixed at the actual root cause.** 2.8.1's
  "centering corrected" fix addressed where the text sat within a type
  badge's pill, but not the pill's own size, which was still a
  hardcoded constant with no awareness that the game font has a
  minimum render size on small windows. On small enough screens, the
  font could hit that floor and end up rendering larger than its own
  pill. The pill's height is now derived directly from the font's real
  rendered size, so the two can't mismatch again regardless of screen
  size.
- **Rounded corners fixed on badges and other rounded UI elements.**
  Two related issues, both from the pill-sizing fix above: corners
  could render inconsistently — crisp on some badges, nearly square on
  others — from a sub-pixel rounding gap; and once badge height became
  size-dependent, the corner radius itself wasn't rescaled to match,
  making corners noticeably flatter than intended. Both fixed.
- **Battle panel move/threat list spacing fixed.** The same
  fixed-spacing assumption behind the badge issue above also affected
  row spacing in the battle screen's move and threat lists, crowding
  entries together (and the last move row into the "THREATS" header)
  on small screens. Now scales consistently with the rest of the fix.

## What's new in 2.8.1

- **Landscape battle-transition crash fixed.** Listed as a known issue in
  2.8.0 above — the overlay was issuing a degenerate
  `setScissor(0, 0, 0, 0)` call every frame it was open, regardless of
  which touch buttons were enabled or canvas state. Removed; confirmed
  fixed across repeated real-device testing of full trainer battles in
  landscape with the overlay open throughout.
- **Blur regression fixed.** A separate, pre-2.8.0 issue where the
  overlay's compositing canvas forced `dpiscale = 1`, softening on-screen
  text and icons versus 2.7.x. No longer forced.
- **Type-badge text centering corrected.** The type badge on party/battle
  panels now centers its text within the pill consistently instead of
  sitting visibly off-center.

## What's new in 2.8.0

- **Items screen page-jump:** a shorter double-chevron pair sits above/below
  the existing scroll arrows on touch, and **L2/R2** now jump a full page
  on the controller whenever nothing's held (they adjust a held stack's
  quantity instead, as before).
- **Live quantity feedback:** while adjusting a held stack's quantity (touch
  stepper, mouse wheel, or L2/R2), the row it came from now updates in
  real time to show what would be left behind if you dropped right now.
- **Touch-only UI now stays touch-only:** the background darken and the
  on-screen quantity stepper that appear while holding an item only show
  up when **TOUCH SCREEN NAV** or **TOUCH SCREEN ICON BUTTONS** is
  enabled — controller/mouse play no longer sees either.
- **Bottomless Bag compatibility:** bag capacity is read through the
  documented mod registry API rather than a guessed field, so the Items
  screen shows the correct capacity (or an infinity symbol past 255) with
  any bag-expansion mod that raises it the standard way.
- **Crash fix:** a graphics push/pop leak that could compound into a full
  engine crash on a recurring internal error is fixed.
- **Known issue carried over:** a landscape-orientation crash on the
  battle-transition wipe is still unresolved; see the project's session
  notes if you're picking up that investigation.

## Controls

| Button | Action |
| --- | --- |
| **R2** | Toggle the live **overlay** (off by default), from the overworld, the overlay itself, or the Party screen. On the Items screen, R2 instead adjusts a held stack's quantity, so it doesn't also switch there. |
| **X** | Open the **Items** screen (move items between your Bag and the PC). |
| **Y** | Open the **Party / Boxes** screen (deposit, withdraw, rearrange, swap Pokémon). |
| **B** | Close whichever screen is open. The overlay itself only closes with **R2** again, or by opening Items/Party. |

- **Touch screen nav buttons** (off by default — enable in mod options,
  "TOUCH SCREEN NAV"): two transparent left/right arrow buttons,
  positioned just above where Start/Select appear on Gen1Recomp's built-in
  touch control layout, step through overlay → Items → Party/Boxes →
  closed — left goes backward, right goes forward. When this is on, the
  Items and Party/Boxes screens also widen the gap between their two
  panels so neither one sits under a button.
- **Touch screen icon buttons** (off by default — enable in mod options,
  "TOUCH SCREEN ICON BUTTONS"): a row of three round transparent buttons,
  one per screen — two stacked diamonds for the overlay, a backpack for
  Items, a Poké Ball glyph for Party/Boxes — sitting low, in the gap
  between the nav-arrow row and Select/Start. Each one jumps straight to
  its own screen (or closes it, if that screen's already open) instead of
  cycling; whichever screen is currently showing lights up gold. Can be
  used on its own or alongside the nav buttons above — both are
  percent-of-window positioned, so they hold their place across different
  screen sizes, and can be retuned the same way (see the debug input HUD
  note below) if either lands somewhere awkward on your device.
- **Left stick cursor** (always on): on the Items or Party/Boxes screen,
  pushing the left stick brings up a free-moving cursor (a small gold
  circle); A/B click/cancel just like touch — including on the Party
  screen, which the D-pad row-cursor doesn't cover (grabbing and dropping
  a Pokémon). Push far enough to start a drag, or tap A to pick something
  up and tap it again to place it. It only takes over once you push the
  stick, and D-pad or direct touch hand control straight back — all three
  ways of controlling the screen work side by side.

The Items and Party/Boxes screens open only from the overworld; while one
is up, the game pauses and all input goes to the screen. Press the same
button again, or **B**, to close.

## Overlay — R2

- **Left:** your party — sprite, HP bar (animated), XP-to-next, level,
  status, types, and moves + PP. The mon that's out in battle is
  highlighted.
- **Right:** trainer info (money, play time, badges, dex) + route
  encounters (grass/surf with %, level ranges, sprites). During a battle
  this swaps to a battle readout: your best moves ranked by effectiveness
  + STAB, the enemy's super-effective threats, a speed indicator, and —
  in wild battles — live per-ball catch odds at the target's current
  HP/status.

The overlay is read-only. Panels are anchored to the left/right edges and
scale to your window (designed against 1440p); since the game renders
widescreen, they sit over the sides of the view. When **TOUCH SCREEN NAV**
is on, the overlay also dims to about 60% opacity so the touch
controls underneath stay visible through it.

## Items (Bag ⇄ PC) — X

- **Drag** an item to the other side, or tap it then tap the other side.
  Reordering within a side works the same way.
- Picking up a stack takes the whole stack.
- **Controller:** **D-pad left/right** picks which side (Bag or PC) is
  focused — it gets a gold outline. **D-pad up/down** moves a
  gold-outlined cursor row by row through the focused side's list. Press
  **A** to pick up the highlighted item (armed immediately, no need to
  drag), then **D-pad** to wherever it should land — the **same** side to
  reorder it in place, or **left/right** to the **other** side to
  transfer it — with up/down there picking exactly where in that list
  it'll land, including one slot past the last item to drop it at the
  **end of the list** — and **A** again to drop it (landing back on its
  own row is a no-op). **L2/R2** double up depending on whether something's
  held: with an item held, they adjust the quantity of the held stack (L2
  decreases it, R2 increases it) so up/down stays free to pick a drop
  spot even mid-stack — the row it came from updates live to show what
  would be left behind if you dropped right now. With nothing held, L2/R2
  instead jump the focused side up/down by a full page. **B** cancels a
  pending pickup; with nothing held, it closes the screen. Or push the
  **left stick** for a free cursor — see above.
- **Touch:** tap an item to arm it (or drag it directly), then tap a
  destination row to drop it. While something's armed or dragging, each
  side gets its own pair of scroll arrows plus a page-jump pair (shorter,
  double-chevron) above/below them for jumping a full screen of rows at a
  time; a stack of more than one also gets a dedicated gold +/- stepper
  next to the held-item bubble. All of this — the darken behind the
  panels included — only appears when **TOUCH SCREEN NAV** or **TOUCH
  SCREEN ICON BUTTONS** is on; with both off, dragging/tapping items still
  works the same, just without the extra on-screen controls layered over
  it (adjust quantity with the mouse wheel or **L2/R2** instead).
- **Sort** each side by Type / A–Z / Qty (view only). On the **Bag** you
  can **Save order** to make it stick in-game (with a controller: **D-pad
  up** from the top row of the Bag list selects it, **A** saves, **D-pad
  down** returns to the list); the in-game **PC is always A–Z**, so its
  sort is browsing-only.
- A destination that can't accept the item turns **red** with the reason
  (bag/PC full, stack maxed).

## Party / Boxes — Y

- **Left:** your party (up to 6) with HP. **Right:** a rail of all 12
  boxes plus the selected box as a sprite grid. Tap a box tab, or (with a
  controller) press **D-pad left/right**, to switch boxes.
- **Grab** a Pokémon and drop it on a slot or a box tab to deposit /
  withdraw / move between boxes. Dropping onto an **occupied** slot
  **swaps** the two.
- **Controller:** the D-pad only switches boxes here — for grabbing and
  dropping a Pokémon, push the **left stick** for a free cursor, same as
  Items above.
- Rules are enforced: boxes hold 20, the party holds 6, you can't deposit
  your last Pokémon, and the party is **never left without a healthy
  Pokémon** (a swap that brings a healthy one in is fine).

## Debug input HUD (Android / no log access)

Since v2.4.0, a small "last input -> ..." readout appears in the
bottom-left corner for a few seconds after any button, gamepad input, or
raw touch event — useful for confirming exactly what a control reports,
without needing a computer to read logs. Off by default; it's a toggle in
the **F10 mod manager** — open the manager, select **Kanto Companion**,
and flip **DEBUG INPUT HUD** on (e.g. when positioning the touch nav
buttons on a new device). No file editing or restart needed; it takes
effect immediately.

As of v2.4.1, raw touches also show as a **percentage of the current
window size**, e.g. `touch: 392,406 (20.4%,37.6% of 1920x1080)`, not just
raw pixel coordinates — raw pixels only mean something on the exact
screen they were measured on, so percentage is what actually carries over
to a different screen size or resolution. This is the same
percentage-of-window approach `TOUCH_NAV_LEFT`/`TOUCH_NAV_RIGHT` (and
`TOUCH_ICON_OVERLAY`/`TOUCH_ICON_ITEMS`/`TOUCH_ICON_PARTY`) in `main.lua`
use to position the touch nav/icon buttons — if they land somewhere
awkward on your device, tap around where you'd expect them and read the
percentage off the HUD to retune the bounds.

As of v2.8.0, the same **DEBUG INPUT HUD** toggle also controls a small
build-tag label in the top-left corner naming the exact installed build
(e.g. `kanto_companion-2_8_0-scroll-features-v1`) — off by default along
with the rest of this HUD, so a normal install shows nothing.

## Install

Copy this whole folder into `%APPDATA%\pokemon-love2d\mods\`, launch the
game, and enable **Kanto Companion** in the **F10** mod manager.

## Notes

- Ships no game assets: sprites and the badge sheet are read from your
  own game install at runtime, and it uses LÖVE's built-in font. A few
  symbols the font lacks (♀/♂, some battle glyphs) are shown as safe text
  equivalents.
