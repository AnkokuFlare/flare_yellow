-- Asset transform (sandbox / MK301): kanto's trainer-card badge sheet used to
-- be loaded straight from the player's ROM-derived cache
-- (assets/generated/trainer_card/badges.png). Under the mod sandbox a mod may
-- not reference that cache directly, so instead we ship this recipe -- never
-- the pixels -- and it runs once at install inside the restricted transform
-- context: read the player's OWN imported cache and write the same sheet under
-- save/mod-derived/kanto_companion/, which main.lua then loads. A plain copy
-- (no recolor) is all we need; the point is to route the art through the
-- sanctioned derive path rather than touch assets/generated from mod code.
--
-- A player who has not imported a ROM yet simply gets no derived file; main.lua
-- already falls back to a drawn glyph, so the mod stays loaded either way.
local BADGE_SHEET = "trainer_card/badges.png"

return function(ctx)
  if ctx.exists(BADGE_SHEET) then
    ctx.writeImage(ctx.readImage(BADGE_SHEET), BADGE_SHEET)
  end
end
